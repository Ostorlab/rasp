/// Typed C boundary for CoreFoundation array values. The returned certificate is independently owned.
#pragma once
#include <CoreFoundation/CFBase.h>
#include <Security/SecBase.h>

#ifdef __cplusplus
extern "C" {
#endif
SecCertificateRef rasp_reporting_retain_certificate(CFTypeRef value) CF_RETURNS_RETAINED;
#ifdef __cplusplus
}
#endif
