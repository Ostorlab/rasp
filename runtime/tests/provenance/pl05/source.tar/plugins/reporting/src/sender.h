/// The reporting plugin's sender: its own thread, which posts the newest run's request, so the runtime's thread never
/// waits for the network, and leaves each run it does not deliver in the context the plugins share.

#pragma once

#include <atomic>
#include <memory>
#include <optional>
#include <string_view>
#include <vector>

#include "config.h"
#include "mailbox.h"
#include "rasp/context.h"
#include "rasp/observation.h"
#include "reporting/cancellation.h"
#include "reporting/undelivered_run.h"
#include "transport.h"

namespace rasp::plugins::reporting {

/// A function that posts one request, with the shape of the platform's `post`.
///
/// @param config The plugin's config. Only its endpoint is read.
/// @param body The request.
/// @return `true` when the endpoint accepted it.
using PostFunction = TransportResult (*)(const Config& config, std::string_view body,
                                         Cancellation cancellation) noexcept;

/// Everything the sender's thread needs. It lives as long as the process once the thread has started.
struct Sender {
  /// Where the requests are posted, and the fields every request holds.
  Config config;
  /// The function that posts a request: the platform's `post`.
  PostFunction post = nullptr;
  /// The context the plugins share, where each run that is not delivered is left under kAuthorizedUndeliveredRun or
  /// kSecuritySuppressedRun. It must be set before delivery and outlive every delivery; the detached production
  /// sender and its Context both live for the process lifetime.
  Context* context = nullptr;
  /// The run waiting to be posted.
  Mailbox mailbox;
  CancellationSource cancelled = CancellationSource::create();
};

/// Delivers one run: serialises its observations into a request, and posts the request once.
///
/// It blocks until the post ends. When the request would be larger than kMaxRequestSize, nothing is posted. When
/// nothing is posted or the post fails, a bounded run is left in the sender's context under an owning authorized
/// envelope or the suppressed-run key. This is volatile one-shot best effort: suppressed results (including ambiguous
/// 2xx, HTTP errors and redirects) have no retry/consumer and are lost on replacement/context teardown/process exit.
/// Oversized retained input is dropped with a typed diagnostic without evicting earlier valid evidence. A run is never
/// posted again; DNS completion never acknowledges it. Development logging reports only the precise typed codes.
///
/// @param sender The sender.
/// @param run All the observations of the run.
void deliver(const Sender& sender, std::vector<Observation> run);
/// Retain one atomic legacy data/authorization envelope, or suppress it when no original opt-in exists.
void retain_fallback(const Config& config, Context& context, std::vector<Observation> run,
                     std::shared_ptr<const std::atomic<bool>> cancellation,
                     std::optional<TransportResult> result = std::nullopt);

/// Starts the sender's thread: a detached thread that takes each run from the mailbox and delivers it, until the
/// process exits.
///
/// @param sender The sender. It must live as long as the process, and is used by the thread from now on.
/// @return Whether the thread started.
[[nodiscard]] bool start_sender(Sender& sender);

}  // namespace rasp::plugins::reporting
