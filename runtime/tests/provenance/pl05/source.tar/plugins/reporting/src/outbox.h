/// Bounded private outbox. Only validated HTTPS publication acknowledgement permits removal.
#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <expected>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "cycle_payload.h"
#include "posix_file.h"

namespace rasp::plugins::reporting {
enum class OutboxError : std::uint8_t {
  kUnavailable,
  kBusy,
  kInvalid,
  kIdentityMismatch,
  kIo,
  kFull,
  kOverflow,
  kChanged,
};
inline constexpr std::size_t kOutboxSlots = 32;
inline constexpr std::size_t kOutboxBytes = std::size_t{4} * 1024 * 1024;
inline constexpr std::size_t kMaxRecordBytes = 128 + 4096 + kMaxCanonicalBytes;
/// Kernel stat field types retain the full device/inode width even on 32-bit Android.
using FileDevice = decltype(std::declval<struct stat>().st_dev);
using FileInode = decltype(std::declval<struct stat>().st_ino);
/// Exact immutable file identity; callers cannot acknowledge a newer item occupying an old slot.
struct RecordToken {
  unsigned slot = 0;
  FileDevice device = 0;
  FileInode inode = 0;
  std::uint64_t ordinal = 0;
  Digest record_digest{};
  friend bool operator==(const RecordToken&, const RecordToken&) = default;
};
struct QueuedCycle {
  RecordToken token;
  std::shared_ptr<const PreparedCycle> payload;
  std::string authority;
  unsigned stage = 0;
  bool acknowledged = false;
};
struct OutboxScan {
  std::vector<QueuedCycle> records;
  std::size_t held = 0;
  std::size_t occupied = 0;
  std::size_t bytes = 0;
};
/// Worker-only descriptor owner. The provider descriptor is borrowed during initialize; caller retains capability.
class Outbox {
 public:
  Outbox(int provider_directory, std::string install_id);
  ~Outbox();
  Outbox(const Outbox&) = delete;
  Outbox& operator=(const Outbox&) = delete;
  Outbox(Outbox&&) = delete;
  Outbox& operator=(Outbox&&) = delete;
  /// Opens and validates only fixed names beneath the owned provider. No fallback path or identity rotation.
  [[nodiscard]] std::expected<void, OutboxError> initialize();
  /// Nonblocking sender election; once acquired, retained until close/destruction.
  [[nodiscard]] std::expected<void, OutboxError> elect_sender();
  /// Scans at most32 records, repairs only proven publication/tombstone residue and preserves unknown bytes.
  [[nodiscard]] std::expected<OutboxScan, OutboxError> scan();
  /// Persists atomically without replacing another item; identical uncertain publication reconciles by content.
  [[nodiscard]] std::expected<RecordToken, OutboxError> persist(const PreparedCycle& payload,
                                                                std::string_view authority);
  /// Durably advances stage up to16, then validates unchanged bounded log and continues returning16.
  [[nodiscard]] std::expected<unsigned, OutboxError> reserve(const RecordToken& token);
  /// Writes a hashed publication tombstone before exact-item cleanup; caller must have validated HTTPS ack.
  [[nodiscard]] std::expected<void, OutboxError> acknowledge(const RecordToken& token);
  /// Process-local durable tombstone recognitions; repeated scans of the same slot/hash count once.
  [[nodiscard]] std::uint64_t acknowledged_count() const { return acknowledged_count_; }
  /// Checked single close of all owned descriptors; no blocking join or lock acquisition.
  [[nodiscard]] std::expected<void, OutboxError> close();

 private:
  void recognize(unsigned slot, const Digest& record_digest);
  std::array<std::optional<Digest>, kOutboxSlots> recognized_{};
  std::uint64_t acknowledged_count_ = 0;
  int provider_directory_;
  std::string install_id_;
  int directory_ = -1;
  int sender_lock_ = -1;
};
}  // namespace rasp::plugins::reporting
