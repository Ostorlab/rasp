#include "cycle_delivery.h"

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <concepts>
#include <cstdint>
#include <memory>
#include <mutex>
#include <optional>
#include <pthread.h>
#include <rasp/cycle.h>
#include <rasp/private_storage.h>
#include <span>
#include <string>
#include <utility>

#include "collection_authority.h"
#include "config.h"
#include "cycle_payload.h"
#include "hash.h"
#include "outbox.h"
#include "posix_file.h"
#include "reporting/delivery.h"
#include "reporting/fallback_authorization.h"
#include "reporting/transport_result.h"
#include "security_profile.h"
#include "sender.h"
#include "transport.h"

namespace rasp::plugins::reporting {
namespace {
std::atomic<const DnsFallback*>& dns_fallback() {
  static std::atomic<const DnsFallback*> value{nullptr};
  return value;
}
std::atomic<CycleDelivery*>& process_delivery() {
  static std::atomic<CycleDelivery*> value{nullptr};
  return value;
}
constexpr std::int64_t kSecond = 1000000000;
template <std::integral Seconds>
std::int64_t after(std::int64_t now, Seconds seconds) {
  const auto delay = static_cast<std::int64_t>(seconds) * kSecond;
  return now > INT64_MAX - delay ? INT64_MAX : now + delay;
}
std::optional<std::uint64_t> retry_seconds(unsigned stage) {
  const auto base = backoff_seconds(stage);
  std::array<std::uint8_t, 4> entropy{};
  if (!secure_random(entropy)) {
    return std::nullopt;
  }
  unsigned random = 0;
  for (const auto byte : entropy) {
    random = (random << 8U) | byte;
  }
  return base + (random % (static_cast<unsigned>(base / 10) + 1U));
}
DeliveryFailure storage_failure(OutboxError error) {
  switch (error) {
    case OutboxError::kBusy:
      return DeliveryFailure::kBusy;
    case OutboxError::kIdentityMismatch:
      return DeliveryFailure::kIdentityMismatch;
    case OutboxError::kFull:
      return DeliveryFailure::kCapacity;
    case OutboxError::kUnavailable:
      return DeliveryFailure::kStorageUnavailable;
    case OutboxError::kInvalid:
    case OutboxError::kChanged:
    case OutboxError::kOverflow:
      return DeliveryFailure::kInvalidRecord;
    case OutboxError::kIo:
      return DeliveryFailure::kIo;
  }
  return DeliveryFailure::kIo;
}
}  // namespace
void register_dns_fallback(const DnsFallback* fallback) { dns_fallback().store(fallback); }
const DnsFallback* selected_dns_fallback() { return dns_fallback().load(); }
void set_cycle_delivery(CycleDelivery* delivery) { process_delivery().store(delivery); }
DeliveryHealth delivery_health() {
  const auto* delivery = process_delivery().load();
  return delivery == nullptr ? DeliveryHealth{} : delivery->health();
}
std::int64_t delivery_clock() {
  const auto now = std::chrono::steady_clock::now().time_since_epoch();
  return std::chrono::duration_cast<std::chrono::nanoseconds>(now).count();
}
std::uint64_t backoff_seconds(unsigned stage) {
  return stage == 0 ? 1 : std::min(std::uint64_t{300}, std::uint64_t{1} << (std::min(stage, 16U) - 1));
}
CycleDelivery::CycleDelivery(Config config, PostFunction post, StorageFunction acquire, ClockFunction clock)
    : config_(std::move(config)), post_(post), acquire_(acquire), clock_(clock) {}
void CycleDelivery::increment(std::atomic<std::uint64_t>& counter, std::uint64_t amount) {
  auto previous = counter.load();
  for (unsigned attempt = 0; attempt < 8; ++attempt) {
    const bool overflow = amount > UINT64_MAX - previous;
    const auto next = overflow ? UINT64_MAX : previous + amount;
    if (counter.compare_exchange_weak(previous, next)) {
      if (overflow) {
        counters_.counter_lower_bound.store(true);
      }
      return;
    }
  }
  counters_.counter_lower_bound.store(true);
}
void CycleDelivery::fail(DeliveryFailure failure, bool held) {
  counters_.failure.store(failure);
  if (held) {
    counters_.state.store(DeliveryState::kHeld);
  }
}
bool CycleDelivery::admit(std::shared_ptr<const CycleSnapshot> snapshot) {
  if (snapshot == nullptr || stopped_.requested()) {
    increment(counters_.admission_dropped);
    return false;
  }
  std::unique_lock const lock(admission_mutex_, std::try_to_lock);
  if (!lock.owns_lock() || count_ == fifo_.size()) {
    increment(counters_.admission_dropped);
    return false;
  }
  std::span{fifo_}[(head_ + count_) % fifo_.size()] = std::move(snapshot);
  ++count_;
  counters_.volatile_pending.store(count_);
  wake_.notify_one();
  return true;
}
std::optional<std::string> CycleDelivery::current_authority() const {
  const auto profile =
      parse_security_profile({.profile = config_.security_profile.value_or(""), .endpoint = config_.endpoint});
  const auto security = profile.has_value() ? security_descriptor(*profile) : std::nullopt;
  if (!security.has_value()) {
    return std::nullopt;
  }
  const auto* dns = dns_fallback().load();
  return collection_authority({
      .endpoint = config_.endpoint,
      .policy = config_.collection_policy,
      .zone = dns == nullptr ? "" : dns->zone,
      .dns_policy = dns == nullptr ? "default" : dns->collection_policy,
      .security = *security,
  });
}
bool CycleDelivery::storage(std::int64_t now, bool check_provider) {
  if (now < resource_due_) {
    return false;
  }
  if (storage_.has_value() && outbox_ != nullptr && !check_provider && !identity_held_) {
    return true;
  }
  auto acquired = acquire_();
  if (!acquired.has_value()) {
    DeliveryFailure failure = DeliveryFailure::kStorageUnavailable;
    bool held = false;
    if (acquired.error() == StorageError::kBusy) {
      failure = DeliveryFailure::kBusy;
    } else if (acquired.error() == StorageError::kRandomUnavailable) {
      failure = DeliveryFailure::kEntropyUnavailable;
    } else if (acquired.error() == StorageError::kInvalidIdentity) {
      failure = DeliveryFailure::kIdentityMismatch;
      held = true;
    } else if (acquired.error() == StorageError::kUnsafeFile || acquired.error() == StorageError::kInvalidDirectory) {
      failure = DeliveryFailure::kInvalidRecord;
      held = true;
    }
    fail(failure, held);
    resource_stage_ = std::min(resource_stage_ + 1, 16U);
    resource_due_ = after(now, backoff_seconds(resource_stage_));
    return false;
  }
  struct stat info{};
  if (fstat(acquired->native_handle(), &info) != 0) {
    fail(DeliveryFailure::kIo);
    return false;
  }
  if (storage_.has_value()) {
    if (storage_->install_id() != acquired->install_id() || std::cmp_not_equal(provider_device_, info.st_dev) ||
        std::cmp_not_equal(provider_inode_, info.st_ino)) {
      identity_held_ = true;
      fail(DeliveryFailure::kIdentityMismatch, true);
      resource_due_ = after(now, 300);
      return false;
    }
    if (!acquired->close().has_value()) {
      fail(DeliveryFailure::kIo);
      return false;
    }
    identity_held_ = false;
  } else {
    provider_device_ = info.st_dev;
    provider_inode_ = info.st_ino;
    storage_.emplace(std::move(*acquired));
  }
  if (outbox_ == nullptr) {
    outbox_ = std::make_unique<Outbox>(storage_.value().native_handle(), std::string(storage_.value().install_id()));
  }
  if (outbox_ == nullptr) {
    fail(DeliveryFailure::kWorkerUnavailable);
    return false;
  }
  const auto opened = outbox_->initialize();
  if (!opened.has_value()) {
    fail(storage_failure(opened.error()),
         opened.error() == OutboxError::kIdentityMismatch || opened.error() == OutboxError::kInvalid);
    resource_stage_ = std::min(resource_stage_ + 1, 16U);
    resource_due_ = after(now, backoff_seconds(resource_stage_));
    return false;
  }
  resource_stage_ = 0;
  resource_due_ = 0;
  return true;
}
void CycleDelivery::persist_front(std::int64_t now) {
  if (now < front_due_) {
    return;
  }
  std::shared_ptr<const CycleSnapshot> snapshot;
  {
    std::unique_lock const lock(admission_mutex_, std::try_to_lock);
    if (!lock.owns_lock() || count_ == 0) {
      return;
    }
    snapshot = std::span{fifo_}[head_];
  }
  if (!storage(now, true) || !storage_.has_value()) {
    return;
  }
  if (!prepared_.has_value()) {
    const auto batch = new_batch_id();
    const auto authority = current_authority();
    if (!batch.has_value()) {
      fail(DeliveryFailure::kEntropyUnavailable);
      front_due_ = after(now, 1);
      return;
    }
    if (!authority.has_value()) {
      fail(DeliveryFailure::kAuthorityMismatch, true);
      front_due_ = after(now, 300);
      return;
    }
    prepared_ = prepare_cycle(*snapshot, config_.build_id, storage_.value().install_id(), *batch);
    if (!prepared_.has_value()) {
      std::unique_lock const lock(admission_mutex_, std::try_to_lock);
      if (lock.owns_lock() && count_ != 0 && std::span{fifo_}[head_] == snapshot) {
        std::span{fifo_}[head_].reset();
        head_ = (head_ + 1) % fifo_.size();
        --count_;
        counters_.volatile_pending.store(count_);
        increment(counters_.admission_dropped);
      }
      fail(DeliveryFailure::kSerialization);
      return;
    }
    prepared_authority_ = *authority;
    increment(counters_.serialization_dropped, prepared_->serialization_dropped);
    counters_.state.store(DeliveryState::kPreparedPending);
  }
  if (!prepared_.has_value()) {
    return;
  }
  const auto saved = outbox_->persist(*prepared_, prepared_authority_);
  recognize_acknowledged();
  if (!saved.has_value()) {
    counters_.persistence_uncertain.store(saved.error() == OutboxError::kIo || saved.error() == OutboxError::kChanged);
    fail(storage_failure(saved.error()),
         saved.error() == OutboxError::kInvalid || saved.error() == OutboxError::kIdentityMismatch);
    front_stage_ = std::min(front_stage_ + 1, 16U);
    front_due_ = after(now, backoff_seconds(front_stage_));
    return;
  }
  counters_.persistence_uncertain.store(false);
  front_stage_ = 0;
  front_due_ = 0;
  const std::scoped_lock lock(admission_mutex_);
  if (count_ != 0 && std::span{fifo_}[head_] == snapshot) {
    std::span{fifo_}[head_].reset();
    head_ = (head_ + 1) % fifo_.size();
    --count_;
    counters_.volatile_pending.store(count_);
    prepared_.reset();
    prepared_authority_.clear();
  }
}
void CycleDelivery::refuse_dns(TransportResult status) {
  counters_.last_transport_result.store(status);
  fail(DeliveryFailure::kTransportRefused, status != TransportResult::kCancelled);
}
void CycleDelivery::offer_dns(const QueuedCycle& record, Timer& timer, TransportResult result) {
  if (!permits_dns(result)) {
    return;
  }
  const auto* dns = dns_fallback().load();
  if (dns == nullptr) {
    return;
  }
  const auto profile =
      parse_security_profile({.profile = config_.security_profile.value_or(""), .endpoint = config_.endpoint});
  const auto descriptor = profile.has_value() ? security_descriptor(*profile) : std::nullopt;
  if (!descriptor.has_value()) {
    refuse_dns(TransportResult::kProfileInvalid);
    return;
  }
  const auto binding = collection_authority({
      .endpoint = config_.endpoint,
      .policy = config_.collection_policy,
      .zone = dns->zone,
      .dns_policy = dns->collection_policy,
      .security = *descriptor,
  });
  if (dns->enqueue != nullptr && binding.has_value() &&
      same_https_authority({.original = record.authority, .current = *binding}) &&
      same_dns_authority({.original = record.authority, .current = *binding})) {
    const auto status = transport_policy(config_, Cancellation(stopped_.share().get()));
    if (status != TransportResult::kPublicationUnconfirmed) {
      timer.authority_held = status != TransportResult::kCancelled;
      refuse_dns(status);
      return;
    }
    const auto authorization =
        std::make_shared<const FallbackAuthorization>(config_, record.authority, stopped_.share());
    const auto authorized = authorization->status();
    if (authorized != TransportResult::kPublicationUnconfirmed) {
      refuse_dns(authorized);
      return;
    }
    if (dns->enqueue(record.payload, authorization)) {
      increment(counters_.dns_attempted);
      timer.dns_wait = true;
    }
  } else {
    fail(DeliveryFailure::kFallbackAuthorityMismatch);
  }
}
void CycleDelivery::send(const QueuedCycle& record, Timer& timer, std::int64_t now) {
  if (stopped_.requested() || !storage(now, true)) {
    return;
  }
  const auto current = current_authority();
  const auto status = transport_policy(config_, Cancellation(stopped_.share().get()));
  if (status != TransportResult::kPublicationUnconfirmed) {
    timer.authority_held = status != TransportResult::kCancelled;
    refuse_dns(status);
    return;
  }
  const auto endpoint = authority_endpoint(record.authority);
  if (!current.has_value() || !endpoint.has_value() ||
      !same_https_authority({.original = record.authority, .current = *current})) {
    timer.authority_held = true;
    fail(DeliveryFailure::kAuthorityMismatch, true);
    return;
  }
  const auto stage = outbox_->reserve(record.token);
  if (!stage.has_value()) {
    fail(storage_failure(stage.error()), true);
    timer.due = after(now, 300);
    return;
  }
  timer.stage = *stage;
  Config original = config_;
  original.endpoint = *endpoint;
  original.build_id = record.payload->build_id;
  original.install_id = record.payload->install_id;
  counters_.state.store(DeliveryState::kDurableReady);
  increment(counters_.https_attempted);
  next_start_ = after(now, 1);
  const auto result = post_ == nullptr ? TransportResult::kConnectFailed
                                       : post_(original, record.payload->request, Cancellation(stopped_.share().get()));
  counters_.last_transport_result.store(result);
  const bool published = result == TransportResult::kPublicationAcknowledged && !stopped_.requested();
  if (published) {
    counters_.state.store(DeliveryState::kAckCleanupPending);
    const auto removed = outbox_->acknowledge(record.token);
    recognize_acknowledged();
    if (removed.has_value()) {
      counters_.state.store(DeliveryState::kPublicationAcknowledged);
      counters_.failure.store(DeliveryFailure::kNone);
    } else {
      counters_.persistence_uncertain.store(true);
      fail(storage_failure(removed.error()));
    }
  } else {
    fail(permits_dns(result) ? DeliveryFailure::kNetwork : DeliveryFailure::kTransportRefused);
    offer_dns(record, timer, result);
  }
  const auto finished = clock_();
  if (finished < now) {
    fail(DeliveryFailure::kClockUnavailable, true);
    timer.due = INT64_MAX;
    return;
  }
  const auto delay = retry_seconds(timer.stage);
  if (!delay.has_value()) {
    fail(DeliveryFailure::kEntropyUnavailable);
  }
  last_now_ = finished;
  timer.due = after(finished, delay.value_or(backoff_seconds(timer.stage)));
  if (!published) {
    counters_.state.store(DeliveryState::kDurableBackoff);
  }
}
bool CycleDelivery::ready(const QueuedCycle& record, const std::optional<std::string>& current, std::int64_t now) {
  auto& timer = std::span{timers_}[record.token.slot];
  if (!timer.token.has_value() || *timer.token != record.token) {
    timer = Timer{.token = record.token, .due = after(now, backoff_seconds(record.stage)), .stage = record.stage};
  }
  const auto status = transport_policy(config_, Cancellation(stopped_.share().get()));
  if (status != TransportResult::kPublicationUnconfirmed) {
    counters_.last_transport_result.store(status);
    timer.authority_held = true;
    return false;
  }
  if (!current.has_value() || !same_https_authority({.original = record.authority, .current = *current})) {
    timer.authority_held = true;
    return false;
  }
  if (timer.authority_held) {
    timer.authority_held = false;
    timer.due = after(now, backoff_seconds(record.stage));
  }
  if (timer.dns_wait) {
    const auto* dns = dns_fallback().load();
    if (dns != nullptr && dns->busy != nullptr && dns->busy(record.payload->batch_id)) {
      return false;
    }
    const auto delay = retry_seconds(timer.stage);
    if (!delay.has_value()) {
      fail(DeliveryFailure::kEntropyUnavailable);
    }
    timer.dns_wait = false;
    timer.due = after(now, delay.value_or(backoff_seconds(timer.stage)));
  }
  return now >= timer.due && now >= next_start_;
}
bool CycleDelivery::elect(std::int64_t now) {
  if (!leader_) {
    const auto elected = outbox_->elect_sender();
    if (!elected.has_value()) {
      fail(storage_failure(elected.error()));
      resource_due_ = after(now, 1);
      return false;
    }
    leader_ = true;
    next_start_ = after(now, 1);
    for (auto& timer : timers_) {
      timer = Timer{};
    }
  }
  return true;
}
void CycleDelivery::step() {
  if (stopped_.requested()) {
    return;
  }
  const auto now = clock_();
  if (now < 0 || now < last_now_) {
    fail(DeliveryFailure::kClockUnavailable, true);
    return;
  }
  last_now_ = now;
  if (!storage(now, false)) {
    return;
  }
  persist_front(now);
  if (identity_held_ || now < resource_due_) {
    return;
  }
  if (!elect(now)) {
    return;
  }
  const auto scan = outbox_->scan();
  recognize_acknowledged();
  if (!scan.has_value()) {
    fail(storage_failure(scan.error()), true);
    resource_due_ = after(now, 1);
    return;
  }
  counters_.durable_pending.store(scan->occupied);
  counters_.held_records.store(scan->held);
  std::uint64_t held = 0;
  std::uint64_t saturated = 0;
  std::uint64_t dns_held = 0;
  const auto current = current_authority();
  const auto current_profile =
      parse_security_profile({.profile = config_.security_profile.value_or(""), .endpoint = config_.endpoint});
  const bool profile_ready =
      current_profile.has_value() && profile_active(*current_profile, security_time()) && platform_security_available();
  const auto* dns = dns_fallback().load();
  std::optional<QueuedCycle> selected;
  for (const auto& record : scan->records) {
    if (record.stage == 16) {
      ++saturated;
    }
    const bool matching = profile_ready && current.has_value() &&
                          same_https_authority({.original = record.authority, .current = *current});
    if (!matching) {
      ++held;
    }
    if (dns != nullptr && current.has_value() &&
        !same_dns_authority({.original = record.authority, .current = *current})) {
      ++dns_held;
    }
    const bool eligible = ready(record, current, now);
    if (!selected.has_value() && eligible) {
      selected = record;
    }
  }
  counters_.authority_held_records.store(held);
  counters_.held_records.store(scan->held + held);
  counters_.dns_fallback_held_records.store(dns_held);
  counters_.backoff_saturated_records.store(saturated);
  if (held != 0) {
    fail(DeliveryFailure::kAuthorityMismatch, true);
  }
  if (selected.has_value()) {
    send(*selected, std::span{timers_}[selected->token.slot], now);
  }
}
void CycleDelivery::recognize_acknowledged() {
  const auto count = outbox_->acknowledged_count();
  increment(counters_.publication_acknowledged, count - acknowledged_seen_);
  acknowledged_seen_ = count;
  if (count == UINT64_MAX) {
    counters_.counter_lower_bound.store(true);
  }
}
DeliveryHealth CycleDelivery::health() const {
  return {
      .volatile_pending = counters_.volatile_pending.load(),
      .durable_pending = counters_.durable_pending.load(),
      .held_records = counters_.held_records.load(),
      .authority_held_records = counters_.authority_held_records.load(),
      .dns_fallback_held_records = counters_.dns_fallback_held_records.load(),
      .backoff_saturated_records = counters_.backoff_saturated_records.load(),
      .admission_dropped = counters_.admission_dropped.load(),
      .serialization_dropped = counters_.serialization_dropped.load(),
      .publication_acknowledged = counters_.publication_acknowledged.load(),
      .https_attempted = counters_.https_attempted.load(),
      .dns_attempted = counters_.dns_attempted.load(),
      .counter_lower_bound = counters_.counter_lower_bound.load(),
      .persistence_uncertain = counters_.persistence_uncertain.load(),
      .state = counters_.state.load(),
      .failure = counters_.failure.load(),
      .last_transport_result = counters_.last_transport_result.load(),
  };
}
void CycleDelivery::run() {
  while (!stopped_.requested()) {
    step();
    std::unique_lock lock(wake_mutex_);
    wake_.wait_for(lock, std::chrono::milliseconds(250), [this] { return stopped_.requested(); });
  }
}
bool CycleDelivery::start() {
  if (stopped_.requested()) {
    return false;
  }
  bool expected = false;
  if (!running_.compare_exchange_strong(expected, true)) {
    return true;
  }
  pthread_attr_t attributes{};
  if (pthread_attr_init(&attributes) != 0) {
    running_.store(false);
    fail(DeliveryFailure::kWorkerUnavailable);
    return false;
  }
  pthread_t thread{};
  const bool started = pthread_attr_setdetachstate(&attributes, PTHREAD_CREATE_DETACHED) == 0 &&
                       pthread_create(
                           &thread, &attributes,
                           [](void* argument) noexcept -> void* {
                             static_cast<CycleDelivery*>(argument)->run();
                             return nullptr;
                           },
                           this) == 0;
  static_cast<void>(pthread_attr_destroy(&attributes));
  if (!started) {
    running_.store(false);
    fail(DeliveryFailure::kWorkerUnavailable);
  }
  return started;
}
void CycleDelivery::stop() {
  stopped_.request();
  wake_.notify_all();
}
}  // namespace rasp::plugins::reporting
