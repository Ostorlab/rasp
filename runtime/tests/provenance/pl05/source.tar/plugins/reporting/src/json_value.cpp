#include "json_value.h"

#include <algorithm>
#include <charconv>
#include <cstddef>
#include <cstdint>
#include <initializer_list>
#include <iterator>
#include <memory>
#include <optional>
#include <ranges>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <variant>
#include <vector>
#include <yyjson.h>

namespace rasp::plugins::reporting {
namespace {
constexpr std::string_view kHex = "0123456789abcdef";
constexpr std::size_t kMaxNodes = 32768;
constexpr std::size_t kMaxDepth = 16;

std::optional<std::uint32_t> next_scalar(std::string_view text, std::size_t& offset) {
  const auto lead = static_cast<unsigned char>(text[offset++]);
  if (lead < 0x80) {
    return lead;
  }
  std::size_t length = 0;
  if (lead >= 0xc2 && lead <= 0xdf) {
    length = 2;
  } else if (lead >= 0xe0 && lead <= 0xef) {
    length = 3;
  } else if (lead >= 0xf0 && lead <= 0xf4) {
    length = 4;
  }
  if (length == 0 || text.size() - offset < length - 1) {
    return std::nullopt;
  }
  const auto mask = 0x7fU >> length;
  std::uint32_t scalar = lead & mask;
  for (std::size_t part = 1; part < length; ++part) {
    const auto byte = static_cast<unsigned char>(text[offset++]);
    if (byte < 0x80 || byte > 0xbf) {
      return std::nullopt;
    }
    scalar = (scalar << 6U) | (byte & 0x3fU);
  }
  if ((length == 2 && scalar < 0x80) || (length == 3 && scalar < 0x800) || (length == 4 && scalar < 0x10000) ||
      (scalar >= 0xd800 && scalar <= 0xdfff) || scalar > 0x10ffff) {
    return std::nullopt;
  }
  return scalar;
}
void escape_unit(std::string& output, std::uint32_t scalar) {
  output += "\\u";
  for (const unsigned shift : {12U, 8U, 4U, 0U}) {
    output += kHex[(scalar >> shift) & 15U];
  }
}
bool quote(std::string& output, std::string_view text, std::size_t limit) {
  output += '"';
  std::size_t offset = 0;
  while (offset < text.size()) {
    const auto scalar = next_scalar(text, offset);
    if (!scalar.has_value() || *scalar == 0) {
      return false;
    }
    switch (*scalar) {
      case '"':
        output += "\\\"";
        break;
      case '\\':
        output += "\\\\";
        break;
      case '\b':
        output += "\\b";
        break;
      case '\f':
        output += "\\f";
        break;
      case '\n':
        output += "\\n";
        break;
      case '\r':
        output += "\\r";
        break;
      case '\t':
        output += "\\t";
        break;
      default:
        if (*scalar >= 0x20 && *scalar < 0x7f) {
          output += static_cast<char>(*scalar);
        } else if (*scalar <= 0xffff) {
          escape_unit(output, *scalar);
        } else {
          const auto supplementary = *scalar - 0x10000;
          escape_unit(output, 0xd800 + (supplementary >> 10U));
          escape_unit(output, 0xdc00 + (supplementary & 0x3ffU));
        }
    }
    if (output.size() > limit) {
      return false;
    }
  }
  output += '"';
  return output.size() <= limit;
}
enum class WriteKind : std::uint8_t { kValue, kKey, kPunctuation };
struct WriteTask {
  WriteKind kind = WriteKind::kValue;
  const JsonValue* value = nullptr;
  std::optional<std::string_view> key = std::nullopt;
  char punctuation = 0;
  std::size_t depth = 0;
};
bool schedule_children(std::vector<WriteTask>& tasks, std::string& output, const WriteTask& task) {
  if (const auto* array = task.value->array(); array != nullptr) {
    if (tasks.size() >= kMaxNodes || array->size() > (kMaxNodes - tasks.size() - 1) / 2) {
      return false;
    }
    output += '[';
    tasks.push_back({.kind = WriteKind::kPunctuation, .punctuation = ']'});
    for (auto item = array->rbegin(); item != array->rend(); ++item) {
      tasks.push_back({.value = &*item, .depth = task.depth + 1});
      if (item + 1 != array->rend()) {
        tasks.push_back({.kind = WriteKind::kPunctuation, .punctuation = ','});
      }
    }
    return true;
  }
  const auto* object = task.value->object();
  if (object == nullptr || tasks.size() >= kMaxNodes || object->size() > (kMaxNodes - tasks.size() - 1) / 4) {
    return false;
  }
  output += '{';
  tasks.push_back({.kind = WriteKind::kPunctuation, .punctuation = '}'});
  for (auto item = object->rbegin(); item != object->rend(); ++item) {
    tasks.push_back({.value = &item->second, .depth = task.depth + 1});
    tasks.push_back({.kind = WriteKind::kPunctuation, .punctuation = ':'});
    tasks.push_back({.kind = WriteKind::kKey, .key = item->first});
    if (std::next(item) != object->rend()) {
      tasks.push_back({.kind = WriteKind::kPunctuation, .punctuation = ','});
    }
  }
  return true;
}
bool write_scalar(std::string& output, const JsonValue& value, std::size_t limit) {
  if (value.null()) {
    output += "null";
  } else if (const auto flag = value.boolean(); flag.has_value()) {
    output += *flag ? "true" : "false";
  } else if (const auto* text = value.text(); text != nullptr) {
    return quote(output, *text, limit);
  } else if (const auto* signed_value = value.signed_integer(); signed_value != nullptr) {
    output += std::to_string(*signed_value);
  } else if (const auto* unsigned_value = value.unsigned_integer(); unsigned_value != nullptr) {
    output += std::to_string(*unsigned_value);
  } else {
    return false;
  }
  return output.size() <= limit;
}
bool write_json(std::string& output, const JsonValue& value, std::size_t limit) {
  std::vector<WriteTask> tasks{{.value = &value}};
  std::size_t nodes = 0;
  while (!tasks.empty()) {
    const auto task = tasks.back();
    tasks.pop_back();
    if (task.kind == WriteKind::kPunctuation) {
      output += task.punctuation;
    } else if (task.kind == WriteKind::kKey) {
      if (!quote(output, task.key.value_or(""), limit)) {
        return false;
      }
    } else {
      if (task.depth > kMaxDepth || ++nodes > kMaxNodes) {
        return false;
      }
      if (task.value->array() != nullptr || task.value->object() != nullptr) {
        if (!schedule_children(tasks, output, task)) {
          return false;
        }
      } else if (!write_scalar(output, *task.value, limit)) {
        return false;
      }
    }
    if (output.size() > limit) {
      return false;
    }
  }
  return true;
}
struct ReadTask {
  yyjson_val* value = nullptr;
  std::size_t depth = 0;
  bool assemble = false;
};
std::optional<JsonValue> read_scalar(const yyjson_val* value) {
  if (yyjson_is_null(value)) {
    return JsonValue{};
  }
  if (yyjson_is_bool(value)) {
    return JsonValue(yyjson_get_bool(value));
  }
  if (yyjson_is_str(value)) {
    return JsonValue(std::string(yyjson_get_str(value), yyjson_get_len(value)));
  }
  if (yyjson_is_uint(value)) {
    return JsonValue(yyjson_get_uint(value));
  }
  if (yyjson_is_sint(value)) {
    return JsonValue(yyjson_get_sint(value));
  }
  return std::nullopt;
}
std::vector<yyjson_val*> children(const yyjson_val* value) {
  std::vector<yyjson_val*> result;
  if (yyjson_is_arr(value)) {
    std::size_t index = 0;
    std::size_t count = 0;
    yyjson_val* item = nullptr;
    yyjson_arr_foreach(value, index, count, item) { result.push_back(item); }
  } else {
    std::size_t index = 0;
    std::size_t count = 0;
    yyjson_val* key = nullptr;
    yyjson_val* item = nullptr;
    yyjson_obj_foreach(value, index, count, key, item) { result.push_back(item); }
  }
  return result;
}
bool assemble(const yyjson_val* source, std::vector<JsonValue>& values) {
  const auto count = yyjson_is_arr(source) ? yyjson_arr_size(source) : yyjson_obj_size(source);
  if (values.size() < count) {
    return false;
  }
  const auto start = values.size() - count;
  JsonValue result;
  if (yyjson_is_arr(source)) {
    JsonValue::Array array;
    for (std::size_t index = start; index < values.size(); ++index) {
      array.push_back(std::move(values[index]));
    }
    result = JsonValue(std::move(array));
  } else {
    JsonValue::Object object;
    std::size_t index = 0;
    std::size_t size = 0;
    const yyjson_val* key = nullptr;
    const yyjson_val* item = nullptr;
    yyjson_obj_foreach(source, index, size, key, item) {
      if (!object.emplace(std::string(yyjson_get_str(key), yyjson_get_len(key)), std::move(values[start + index]))
               .second) {
        return false;
      }
    }
    result = JsonValue(std::move(object));
  }
  values.resize(start);
  values.push_back(std::move(result));
  return true;
}
std::optional<JsonValue> read_value(yyjson_val* root) {
  std::vector<ReadTask> tasks{{.value = root}};
  std::vector<JsonValue> values;
  std::size_t nodes = 0;
  while (!tasks.empty()) {
    const auto task = tasks.back();
    tasks.pop_back();
    if (task.assemble) {
      if (!assemble(task.value, values)) {
        return std::nullopt;
      }
      continue;
    }
    if (task.value == nullptr || task.depth > kMaxDepth || ++nodes > kMaxNodes) {
      return std::nullopt;
    }
    if (!yyjson_is_ctn(task.value)) {
      auto scalar = read_scalar(task.value);
      if (!scalar.has_value()) {
        return std::nullopt;
      }
      values.push_back(std::move(*scalar));
      continue;
    }
    const auto count = yyjson_is_arr(task.value) ? yyjson_arr_size(task.value) : yyjson_obj_size(task.value);
    if (tasks.size() >= kMaxNodes || count > kMaxNodes - tasks.size() - 1 || count > kMaxNodes - nodes) {
      return std::nullopt;
    }
    tasks.push_back({.value = task.value, .depth = task.depth, .assemble = true});
    const auto items = children(task.value);
    for (auto* item : std::ranges::reverse_view(items)) {
      tasks.push_back({.value = item, .depth = task.depth + 1});
    }
  }
  return values.size() == 1 ? std::optional<JsonValue>(std::move(values[0])) : std::nullopt;
}
template <typename Integer>
std::optional<Integer> decimal(const JsonValue& value) {
  const auto* text = value.text();
  if (text == nullptr || text->empty() || text->size() > 20) {
    return std::nullopt;
  }
  Integer result{};
  const auto parsed = std::from_chars(text->data(), std::to_address(text->end()), result);
  if (parsed.ec != std::errc{} || parsed.ptr != std::to_address(text->end()) || std::to_string(result) != *text) {
    return std::nullopt;
  }
  return result;
}
}  // namespace
struct JsonValue::Node {
  std::variant<bool, std::int64_t, std::uint64_t, std::string, Array, Object> value;
};
JsonValue::JsonValue(bool item) : node_(std::make_shared<const Node>(Node{.value = item})) {}
JsonValue::JsonValue(std::int64_t item) : node_(std::make_shared<const Node>(Node{.value = item})) {}
JsonValue::JsonValue(std::uint64_t item) : node_(std::make_shared<const Node>(Node{.value = item})) {}
JsonValue::JsonValue(std::string item) : node_(std::make_shared<const Node>(Node{.value = std::move(item)})) {}
JsonValue::JsonValue(std::string_view item) : JsonValue(std::string(item)) {}
JsonValue::JsonValue(const char* item) : JsonValue(std::string(item)) {}
JsonValue::JsonValue(Array item) : node_(std::make_shared<const Node>(Node{.value = std::move(item)})) {}
JsonValue::JsonValue(Object item) : node_(std::make_shared<const Node>(Node{.value = std::move(item)})) {}
JsonValue JsonValue::get(std::string_view key) const {
  const auto* members = object();
  if (members == nullptr) {
    return {};
  }
  const auto found = members->find(key);
  return found == members->end() ? JsonValue{} : found->second;
}
const std::string* JsonValue::text() const {
  return node_ == nullptr ? nullptr : std::get_if<std::string>(&node_->value);
}
const JsonValue::Array* JsonValue::array() const {
  return node_ == nullptr ? nullptr : std::get_if<Array>(&node_->value);
}
const JsonValue::Object* JsonValue::object() const {
  return node_ == nullptr ? nullptr : std::get_if<Object>(&node_->value);
}
const std::int64_t* JsonValue::signed_integer() const {
  return node_ == nullptr ? nullptr : std::get_if<std::int64_t>(&node_->value);
}
const std::uint64_t* JsonValue::unsigned_integer() const {
  return node_ == nullptr ? nullptr : std::get_if<std::uint64_t>(&node_->value);
}
std::optional<bool> JsonValue::boolean() const {
  const auto* flag = node_ == nullptr ? nullptr : std::get_if<bool>(&node_->value);
  return flag == nullptr ? std::nullopt : std::optional<bool>(*flag);
}
std::optional<std::uint64_t> JsonValue::unsigned_number() const {
  if (const auto* number = unsigned_integer(); number != nullptr) {
    return *number;
  }
  if (const auto* number = signed_integer(); number != nullptr && *number >= 0) {
    return static_cast<std::uint64_t>(*number);
  }
  return std::nullopt;
}
bool JsonValue::null() const { return node_ == nullptr; }
std::optional<JsonValue> parse_json(std::string_view input, std::size_t limit) {
  if (input.empty() || input.size() > limit) {
    return std::nullopt;
  }
  const std::unique_ptr<yyjson_doc, decltype(&yyjson_doc_free)> doc(yyjson_read(input.data(), input.size(), 0),
                                                                    yyjson_doc_free);
  if (doc == nullptr) {
    return std::nullopt;
  }
  auto value = read_value(yyjson_doc_get_root(doc.get()));
  if (!value.has_value() || !canonical_json(*value, limit).has_value()) {
    return std::nullopt;
  }
  return value;
}
std::optional<std::string> canonical_json(const JsonValue& value, std::size_t limit) {
  std::string output;
  if (!write_json(output, value, limit)) {
    return std::nullopt;
  }
  return output;
}
bool bounded_text(std::string_view text, std::size_t limit, bool ascii, bool nonempty) {
  if (text.size() > limit || (nonempty && text.empty())) {
    return false;
  }
  std::size_t offset = 0;
  while (offset < text.size()) {
    const auto scalar = next_scalar(text, offset);
    if (!scalar.has_value() || *scalar == 0 || (ascii && *scalar > 127)) {
      return false;
    }
  }
  return true;
}
bool keys_are(const JsonValue& value, std::initializer_list<std::string_view> keys) {
  const auto* object = value.object();
  if (object == nullptr || object->size() != keys.size()) {
    return false;
  }
  return std::ranges::all_of(keys, [object](std::string_view key) { return object->contains(key); });
}
std::optional<std::uint64_t> decimal_uint(const JsonValue& value) { return decimal<std::uint64_t>(value); }
std::optional<std::int64_t> decimal_long(const JsonValue& value) { return decimal<std::int64_t>(value); }
}  // namespace rasp::plugins::reporting
