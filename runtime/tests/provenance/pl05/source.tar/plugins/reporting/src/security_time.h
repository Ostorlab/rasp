/* Checked POSIX UTC clock, shared by both reporting transports. */
#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
int64_t rasp_reporting_utc_seconds(void);
#ifdef __cplusplus
}
#endif
