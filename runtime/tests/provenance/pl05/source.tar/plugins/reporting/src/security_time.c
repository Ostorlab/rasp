#include "security_time.h"

#include <time.h>
int64_t rasp_reporting_utc_seconds(void) {
  struct timespec now = {0};
  if (clock_gettime(CLOCK_REALTIME, &now) != 0 || now.tv_sec < 0 || (uint64_t)now.tv_sec > UINT64_C(253402300799)) {
    return -1;
  }
  return (int64_t)now.tv_sec;
}
