#include "hash.h"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#if !defined(__APPLE__) && !defined(__ANDROID__)
#include <unistd.h>
#endif
#ifdef __APPLE__
#include <CommonCrypto/CommonDigest.h>
#include <Security/SecBase.h>
#include <Security/SecRandom.h>
#elifdef __ANDROID__
#include <bits/getentropy.h>
#endif

#ifndef __APPLE__
extern "C" int rasp_reporting_sha256(const void* input, std::size_t length, unsigned char* output);
#endif
namespace rasp::plugins::reporting {
namespace {
constexpr std::string_view kHex = "0123456789abcdef";
}
std::optional<Digest> content_hash(std::string_view bytes) {
  Digest digest{};
  const auto input = std::as_bytes(std::span(bytes));
#ifdef __APPLE__
  if (bytes.size() > UINT32_MAX) {
    return std::nullopt;
  }
  if (CC_SHA256(input.data(), static_cast<CC_LONG>(input.size()), digest.data()) == nullptr) {
    return std::nullopt;
  }
#else
  if (rasp_reporting_sha256(input.data(), input.size(), digest.data()) != 0) {
    return std::nullopt;
  }
#endif
  return digest;
}
bool secure_random(std::span<std::uint8_t> bytes) {
  if (bytes.empty() || bytes.size() > 256) {
    return false;
  }
#ifdef __APPLE__
  return SecRandomCopyBytes(kSecRandomDefault, bytes.size(), bytes.data()) == errSecSuccess;
#else
  return getentropy(bytes.data(), bytes.size()) == 0;
#endif
}
std::optional<std::string> new_batch_id() {
  std::array<std::uint8_t, 16> random{};
  if (!secure_random(random)) {
    return std::nullopt;
  }
  random[6] = static_cast<unsigned char>((random[6] & 15U) | 0x40U);
  random[8] = static_cast<unsigned char>((random[8] & 63U) | 0x80U);
  std::string uuid;
  for (std::size_t index = 0; index < random.size(); ++index) {
    if (index == 4 || index == 6 || index == 8 || index == 10) {
      uuid += '-';
    }
    uuid += kHex[std::span{random}[index] >> 4U];
    uuid += kHex[std::span{random}[index] & 15U];
  }
  return uuid;
}
std::optional<std::string> canonical_uuid(std::string_view text, bool v4) {
  if (text.size() != 36) {
    return std::nullopt;
  }
  std::string result(text);
  bool nonzero = false;
  for (std::size_t index = 0; index < result.size(); ++index) {
    char& byte = result[index];
    if (index == 8 || index == 13 || index == 18 || index == 23) {
      if (byte != '-') {
        return std::nullopt;
      }
    } else {
      if (byte >= 'A' && byte <= 'F') {
        byte = static_cast<char>(byte + ('a' - 'A'));
      }
      if (!kHex.contains(byte)) {
        return std::nullopt;
      }
      nonzero = nonzero || byte != '0';
    }
  }
  if (!nonzero || (v4 && (result[14] != '4' || !std::string_view("89ab").contains(result[19])))) {
    return std::nullopt;
  }
  return result;
}
bool full_digest(std::string_view text) {
  return text.size() == 64 && std::ranges::all_of(text, [](char byte) { return kHex.contains(byte); });
}
}  // namespace rasp::plugins::reporting
