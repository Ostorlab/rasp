#include "outbox_posix.h"

#include <fcntl.h>
#include <stddef.h>

int rasp_outbox_open(int directory, const char* name, int flags, mode_t mode) {
  return openat(directory, name, flags, mode);
}
const char* rasp_outbox_next_entry(DIR* stream) {
  const struct dirent* entry = readdir(stream);
  return entry == NULL ? NULL : entry->d_name;
}
