/// The iOS transport: posts a request over a Network.framework connection, with TLS for `https://` endpoints, and
/// speaks HTTP/1.1 itself. TLS checks the endpoint's certificate and host name against the system's trust, and allows
/// TLS 1.2 or newer only.

#include "transport.h"

#include <Availability.h>
#include <Network/Network.h>
#include <Security/SecProtocolObject.h>
#include <Security/SecProtocolOptions.h>
#include <Security/SecProtocolTypes.h>
#include <algorithm>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <dispatch/dispatch.h>
#include <memory>
#include <mutex>
#include <optional>
#include <os/availability.h>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>

#include "config.h"
#include "http.h"
#include "json.h"
#include "reporting/transport_result.h"
#include "security_profile.h"
#include "trust.h"
#ifdef RASP_REPORTING_TRANSPORT_TEST
#include <iostream>
#include <thread>

#include "transport_fixture.h"
#endif

namespace rasp::plugins::reporting {

namespace {

/// The most bytes one receive reads.
constexpr std::uint32_t kMaxReceiveSize = 1024;

/// Releases a dispatch object when the pointer that owns it goes away.
struct DispatchRelease {
  /// Releases `object`.
  void operator()(dispatch_object_t object) const noexcept { dispatch_release(object); }
};

/// A dispatch semaphore, released with its owner.
using Semaphore = std::unique_ptr<std::remove_pointer_t<dispatch_semaphore_t>, DispatchRelease>;
/// A dispatch queue, released with its owner.
using Queue = std::unique_ptr<std::remove_pointer_t<dispatch_queue_t>, DispatchRelease>;

/// What the connection's blocks share with the thread that waits for them. The blocks keep it alive after a timeout.
struct Exchange {
  /// Signalled whenever one of the flags below is set, or a receive ends.
  Semaphore signal{dispatch_semaphore_create(0)};
  /// Set once the connection is ready to send.
  std::atomic<bool> ready{false};
  bool tls = true;
  /// Set once the connection failed; an orderly receive EOF goes to the decoder instead.
  std::atomic<bool> failed{false};
  /// Set once the request was sent.
  std::atomic<bool> sent{false};
  /// Set while a receive is pending.
  std::atomic<bool> receiving{false};
  std::shared_ptr<IosTrustState> trust;
  std::atomic<bool> proxy_ready{false};
  std::atomic<bool> path_changed{false};
  std::atomic<bool> terminal{false};
  std::atomic<TransportResult> failure{TransportResult::kPublicationUnconfirmed};
  std::chrono::steady_clock::time_point deadline = std::chrono::steady_clock::now() + kPostTimeout;
  std::string first_line;
  int status = 0;
  /// Guards `answer`.
  std::mutex mutex;
  /// The bounded decoder; orderly EOF is distinct from a transport failure.
  HttpResponse answer;
  /// Last decoder state, guarded by mutex.
  HttpResponse::State state = HttpResponse::State::kReading;
};

/// Waits until a condition holds or the connection fails.
///
/// @param exchange What the connection's blocks share with this thread.
/// @param holds The condition, which the blocks make true.
/// @param deadline When to stop waiting.
/// @return `true` when the condition holds, `false` when the connection failed or the deadline passed.
template <typename Condition>
[[nodiscard]] bool wait_for(Exchange& exchange, Condition holds, std::chrono::steady_clock::time_point deadline,
                            Cancellation cancellation) {
  while (!holds()) {
    if (cancellation.requested()) {
      exchange.failure.store(TransportResult::kCancelled);
      return false;
    }
    if (!profile_active(exchange.trust->profile, security_time())) {
      exchange.failure.store(TransportResult::kProfileNotActive);
      return false;
    }
    if (exchange.path_changed.load()) {
      exchange.failure.store(TransportResult::kProxyRejected);
      return false;
    }
    if (exchange.failed.load()) {
      return false;
    }
    if (std::chrono::steady_clock::now() >= deadline) {
      exchange.failure.store(exchange.ready.load() && !exchange.proxy_ready.load() ? TransportResult::kProxyRejected
                                                                                   : TransportResult::kTimeout);
      return false;
    }
    static_cast<void>(dispatch_semaphore_wait(exchange.signal.get(), dispatch_time(DISPATCH_TIME_NOW, 50000000)));
  }
  return !cancellation.requested() && !exchange.path_changed.load();
}

/// Keeps TLS 1.2 as the minimum, using the legacy setter only for deployment targets predating its replacement.
void require_tls12(sec_protocol_options_t options) {
#if (defined(__IPHONE_OS_VERSION_MIN_REQUIRED) && __IPHONE_OS_VERSION_MIN_REQUIRED < 130000) || \
    (defined(__MAC_OS_X_VERSION_MIN_REQUIRED) && __MAC_OS_X_VERSION_MIN_REQUIRED < 101500)
  sec_protocol_options_set_tls_min_version(options, kTLSProtocol12);
#else
  sec_protocol_options_set_min_tls_protocol_version(options, tls_protocol_version_TLSv12);
#endif
}

/// Creates the connection to the endpoint, with TLS 1.2 or newer for an `https://` one.
///
/// @param endpoint The endpoint.
/// @return The connection, or null when it can't be created.
[[nodiscard]] nw_connection_t create_connection(const Endpoint& endpoint, dispatch_queue_t verify_queue,
                                                std::shared_ptr<IosTrustState> trust) {
#ifdef RASP_REPORTING_TRANSPORT_TEST
  const auto& fixture = transport_fixture();
  // An injected proxy needs the logical origin. Rewriting it to the proxy's loopback endpoint makes it self-target.
  const auto& address = fixture.proxy_port.empty() && !fixture.address.empty() ? fixture.address : endpoint.host;
#else
  const auto& address = endpoint.host;
#endif
  const auto retained_trust = std::move(trust);
  auto* const host = nw_endpoint_create_host(address.c_str(), endpoint.port.c_str());
  if (host == nullptr) {
    return nullptr;
  }
  auto* const parameters = endpoint.tls ? nw_parameters_create_secure_tcp(
                                              ^(nw_protocol_options_t tls_options) {
                                                auto* const options = nw_tls_copy_sec_protocol_options(tls_options);
                                                require_tls12(options);
                                                configure_trust(options, verify_queue, retained_trust);
                                                sec_release(options);
                                              },
                                              NW_PARAMETERS_DEFAULT_CONFIGURATION)
                                        : nw_parameters_create_secure_tcp(NW_PARAMETERS_DISABLE_PROTOCOL,
                                                                          NW_PARAMETERS_DEFAULT_CONFIGURATION);
  if (parameters == nullptr) {
    nw_release(host);
    return nullptr;
  }
  nw_parameters_set_prefer_no_proxy(parameters, true);
#ifdef RASP_REPORTING_TRANSPORT_TEST
  if (!fixture.proxy_port.empty()) {
    if (__builtin_available(iOS 17.0, macOS 14.0, *)) {
      auto* const proxy_endpoint = nw_endpoint_create_host("127.0.0.1", fixture.proxy_port.c_str());
      auto* const proxy = nw_proxy_config_create_http_connect(proxy_endpoint, nullptr);
      auto* const privacy = nw_privacy_context_create("reporting test fixture");
      if (proxy_endpoint == nullptr || proxy == nullptr || privacy == nullptr) {
        if (proxy_endpoint != nullptr) {
          nw_release(proxy_endpoint);
        }
        if (proxy != nullptr) {
          nw_release(proxy);
        }
        if (privacy != nullptr) {
          nw_release(privacy);
        }
        nw_release(parameters);
        nw_release(host);
        return nullptr;
      }
      nw_privacy_context_add_proxy(privacy, proxy);
      nw_proxy_config_set_failover_allowed(proxy, false);
      nw_parameters_set_privacy_context(parameters, privacy);
      // Exercise the injected CONNECT route using its logical origin and prohibit unproxied failover.
      // Shipping connections keep prefer_no_proxy=true; this override exists only in marked test executables.
      nw_parameters_set_prefer_no_proxy(parameters, false);
      std::clog << "RASP_TEST_NW_PROXY_SETUP logical_host=" << (address == endpoint.host)
                << " loopback_origin=" << (address == "127.0.0.1")
                << " self_target=" << (address == "127.0.0.1" && endpoint.port == fixture.proxy_port)
                << " prefer_no_proxy=" << nw_parameters_get_prefer_no_proxy(parameters)
                << " failover=" << nw_proxy_config_get_failover_allowed(proxy) << '\n';
      nw_release(privacy);
      nw_release(proxy);
      nw_release(proxy_endpoint);
    } else {
      nw_release(parameters);
      nw_release(host);
      return nullptr;
    }
  }
#endif
  auto* const connection = nw_connection_create(host, parameters);
  nw_release(parameters);
  nw_release(host);
  return connection;
}

/// Starts one receive and passes bytes, orderly EOF and errors to the bounded decoder.
///
/// @param connection The connection.
/// @param borrowed_exchange Shared state retained locally and copied into the escaping receive blocks.
void receive(nw_connection_t connection, const std::shared_ptr<Exchange>& borrowed_exchange) {
  const auto exchange = std::shared_ptr<Exchange>(borrowed_exchange);
  exchange->receiving.store(true);
  nw_connection_receive(
      connection, 1, kMaxReceiveSize,
      ^(dispatch_data_t content, nw_content_context_t, bool is_complete, nw_error_t error) {
        if (content != nullptr) {
          dispatch_data_apply(content, ^bool(dispatch_data_t, std::size_t, const void* buffer, std::size_t size) {
            const std::scoped_lock lock(exchange->mutex);
            const std::string_view bytes(static_cast<const char*>(buffer), size);
            if (exchange->status == 0 && exchange->first_line.size() <= 1024) {
              exchange->first_line.append(bytes.substr(0, 1024 - exchange->first_line.size()));
              const auto end = exchange->first_line.find("\r\n");
              if (end != std::string::npos) {
                exchange->status = parse_status(std::string_view(exchange->first_line).substr(0, end)).value_or(-1);
              }
            }
            exchange->state = exchange->answer.read(bytes);
            return exchange->state != HttpResponse::State::kFailed;
          });
        }
        {
          const std::scoped_lock lock(exchange->mutex);
          exchange->state = exchange->answer.read("", is_complete, error != nullptr);
        }
        if (error != nullptr) {
          exchange->failed.store(true);
        }
        exchange->receiving.store(false);
        dispatch_semaphore_signal(exchange->signal.get());
      });
}

TransportResult exchange_failure(const Exchange& exchange) {
  const auto local = exchange.failure.load();
  const auto trust = exchange.trust->failure.load();
  if (local != TransportResult::kPublicationUnconfirmed && !permits_dns(local)) {
    return local;
  }
  if (trust != TransportResult::kPublicationUnconfirmed && !permits_dns(trust)) {
    return trust;
  }
  return local != TransportResult::kPublicationUnconfirmed ? local : trust;
}
TransportResult send_status(const Exchange& exchange, Cancellation cancellation,
                            std::chrono::steady_clock::time_point response_by) {
  if (cancellation.requested()) {
    return TransportResult::kCancelled;
  }
  if (!profile_active(exchange.trust->profile, security_time())) {
    return TransportResult::kProfileNotActive;
  }
  const auto now = std::chrono::steady_clock::now();
  if (now >= exchange.deadline || now >= response_by) {
    return TransportResult::kTimeout;
  }
  if (exchange.path_changed.load() || !exchange.proxy_ready.load()) {
    return TransportResult::kProxyRejected;
  }
  const auto trust_failure = exchange.trust->failure.load();
  if (exchange.tls && trust_failure != TransportResult::kPublicationUnconfirmed) {
    return trust_failure;
  }
  if (exchange.tls && !exchange.trust->verified.load()) {
    return TransportResult::kTrustVerificationFailed;
  }
  return TransportResult::kPublicationUnconfirmed;
}

/// Sends the request on a started connection and reads the status of the answer.
///
/// @param connection The connection, started on its queue.
/// @param exchange Owned value copied into the send block so cancellation may outlive this call.
/// @param request The request.
/// @param endpoint The endpoint, for the logs.
/// @return True only after a complete, valid publication acknowledgement.
[[nodiscard]] bool exchange_request(nw_connection_t connection, dispatch_queue_t queue,
                                    std::shared_ptr<Exchange> exchange, const std::string& request,
                                    Cancellation cancellation) {
  const auto connected_by = std::min(exchange->deadline, std::chrono::steady_clock::now() + kConnectTimeout);
  if (!wait_for(
          *exchange, [&exchange] { return exchange->ready.load() && exchange->proxy_ready.load(); }, connected_by,
          cancellation)) {
    return false;
  }
  const auto answered_by = std::min(exchange->deadline, std::chrono::steady_clock::now() + kResponseTimeout);
  const auto status = send_status(*exchange, cancellation, answered_by);
  if (status != TransportResult::kPublicationUnconfirmed) {
    exchange->failure.store(status);
    return false;
  }
  auto* const content = dispatch_data_create(request.data(), request.size(), nullptr, DISPATCH_DATA_DESTRUCTOR_DEFAULT);
  if (content == nullptr) {
    return false;
  }
#ifdef RASP_REPORTING_TRANSPORT_TEST
  const auto& fixture = transport_fixture();
  if (fixture.send_queue_delay_ms > 0) {
    const auto delay = fixture.send_queue_delay_ms;
    auto* const queued = fixture.queued_sends;
    auto* const entered = fixture.on_send_queue_entered;
    dispatch_async(queue, ^{
      if (queued != nullptr) {
        queued->fetch_add(1);
      }
      if (entered != nullptr) {
        entered();
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(delay));
    });
  }
#endif
  // Serialize the final policy check/send with establishment and path callbacks on this connection queue.
  dispatch_sync(queue, ^{
    const auto current = send_status(*exchange, cancellation, answered_by);
    if (current != TransportResult::kPublicationUnconfirmed || exchange->terminal.load() || exchange->failed.load()) {
      exchange->failure.store(current == TransportResult::kPublicationUnconfirmed ? TransportResult::kIoFailed
                                                                                  : current);
      exchange->failed.store(true);
      return;
    }
    nw_connection_send(connection, content, NW_CONNECTION_DEFAULT_MESSAGE_CONTEXT, true, ^(nw_error_t error) {
      if (error != nullptr) {
        exchange->failed.store(true);
      } else {
        exchange->sent.store(true);
      }
      dispatch_semaphore_signal(exchange->signal.get());
    });
  });
  dispatch_release(content);
  if (!wait_for(*exchange, [&exchange] { return exchange->sent.load(); }, answered_by, cancellation)) {
    return false;
  }
  while (true) {
    receive(connection, exchange);
    if (!wait_for(*exchange, [&exchange] { return !exchange->receiving.load(); }, answered_by, cancellation)) {
      return false;
    }
    const std::scoped_lock lock(exchange->mutex);
    if (exchange->failed.load() || exchange->state == HttpResponse::State::kFailed) {
      return false;
    }
    if (exchange->state == HttpResponse::State::kComplete) {
      return exchange->answer.successful();
    }
  }
}

TransportResult network_failure(nw_error_t error, const IosTrustState& trust) {
  const auto domain = nw_error_get_error_domain(error);
  const auto code = nw_error_get_error_code(error);
  if (domain == nw_error_domain_dns) {
    return TransportResult::kResolutionFailed;
  }
  if (domain == nw_error_domain_posix && (code == ECONNREFUSED || code == ENETUNREACH || code == EHOSTUNREACH)) {
    return TransportResult::kConnectFailed;
  }
  return domain == nw_error_domain_tls || !trust.verified.load() ? TransportResult::kTrustVerificationFailed
                                                                 : TransportResult::kIoFailed;
}
void establishment_report(nw_connection_t connection, dispatch_queue_t queue, std::shared_ptr<Exchange> owner)
    API_AVAILABLE(ios(13.0), macos(10.15));
void establishment_report(nw_connection_t connection, dispatch_queue_t queue, std::shared_ptr<Exchange> owner) {
  const auto exchange = std::move(owner);
  nw_connection_access_establishment_report(connection, queue, ^(nw_establishment_report_t report) {
    if (exchange->terminal.load()) {
      return;
    }
#ifdef RASP_REPORTING_TRANSPORT_TEST
    if (report == nullptr || nw_establishment_report_get_proxy_configured(report) ||
        nw_establishment_report_get_used_proxy(report)) {
      std::clog << "RASP_TEST_NW_PROXY present=" << (report != nullptr)
                << " configured=" << (report != nullptr && nw_establishment_report_get_proxy_configured(report))
                << " used=" << (report != nullptr && nw_establishment_report_get_used_proxy(report)) << '\n';
    }
#endif
    if (report == nullptr || nw_establishment_report_get_proxy_configured(report) ||
        nw_establishment_report_get_used_proxy(report)) {
      exchange->failure.store(TransportResult::kProxyRejected);
      exchange->failed.store(true);
    } else {
      exchange->proxy_ready.store(true);
    }
    dispatch_semaphore_signal(exchange->signal.get());
  });
}
void observe_state(nw_connection_t connection, dispatch_queue_t queue, const std::shared_ptr<Exchange>& exchange,
                   bool http_fixture, nw_connection_state_t state, nw_error_t error) {
  if (exchange->terminal.load()) {
    return;
  }
  if (state == nw_connection_state_ready) {
    exchange->ready.store(true);
    if (http_fixture) {
      exchange->proxy_ready.store(true);
    } else if (__builtin_available(iOS 13.0, macOS 10.15, *)) {
      establishment_report(connection, queue, exchange);
    }
  } else if (state == nw_connection_state_failed || state == nw_connection_state_cancelled ||
             (state == nw_connection_state_waiting && error != nullptr)) {
    // Waiting carries a failed establishment attempt's error. This bounded post does not wait for a path retry;
    // classify the supplied error exactly as failed, rather than replacing it with the later elapsed deadline.
    if (error != nullptr) {
      const auto reason = network_failure(error, *exchange->trust);
#ifdef RASP_REPORTING_TRANSPORT_TEST
      if (state == nw_connection_state_waiting) {
        std::clog << "RASP_TEST_NW_WAITING domain=" << static_cast<int>(nw_error_get_error_domain(error))
                  << " code=" << nw_error_get_error_code(error) << " result=" << static_cast<unsigned>(reason) << '\n';
      }
#endif
      auto expected = TransportResult::kPublicationUnconfirmed;
      static_cast<void>(exchange->trust->failure.compare_exchange_strong(expected, reason));
    }
    exchange->failed.store(true);
  }
  dispatch_semaphore_signal(exchange->signal.get());
}
void install_callbacks(nw_connection_t connection, dispatch_queue_t queue, std::shared_ptr<Exchange> owner,
                       bool http_fixture) {
  const auto exchange = std::move(owner);
  nw_connection_set_state_changed_handler(connection, ^(nw_connection_state_t state, nw_error_t error) {
    observe_state(connection, queue, exchange, http_fixture, state, error);
  });
  nw_connection_set_path_changed_handler(connection, ^(nw_path_t) {
    if (!http_fixture && !exchange->terminal.load() && exchange->proxy_ready.load()) {
      exchange->path_changed.store(true);
      exchange->failed.store(true);
      exchange->failure.store(TransportResult::kProxyRejected);
      dispatch_semaphore_signal(exchange->signal.get());
    }
  });
}
TransportResult publication_result(const Config& config, Cancellation cancellation, bool accepted, Exchange& exchange) {
  TransportResult result = TransportResult::kPublicationUnconfirmed;
  const auto policy = accepted ? TransportResult::kPublicationUnconfirmed : transport_policy(config, cancellation);
  const auto failure = exchange_failure(exchange);
  if (cancellation.requested()) {
    result = TransportResult::kCancelled;
  } else if (policy != TransportResult::kPublicationUnconfirmed) {
    result = policy;
  } else if (failure != TransportResult::kPublicationUnconfirmed) {
    result = failure;
  } else {
    const std::scoped_lock lock(exchange.mutex);
    if (exchange.status >= 300 && exchange.status < 400) {
      result = TransportResult::kRedirectRejected;
    } else if (exchange.status == 204 || exchange.status == 205 || exchange.status >= 400) {
      result = TransportResult::kHttpRejected;
    } else if (accepted) {
      result = TransportResult::kPublicationAcknowledged;
    } else if (exchange.state == HttpResponse::State::kFailed) {
      result = TransportResult::kResponseInvalid;
    } else if (exchange.failed.load()) {
      result = TransportResult::kIoFailed;
    }
  }
  return result;
}

}  // namespace

TransportResult post(const Config& config, std::string_view body, Cancellation cancellation) noexcept {
  if (cancellation.requested()) {
    return TransportResult::kCancelled;
  }
  const auto endpoint = parse_endpoint(config.endpoint);
  if (!endpoint.has_value() || body.size() > kMaxRequestSize) {
    return TransportResult::kProfileInvalid;
  }
  auto profile = parse_security_profile({.profile = config.security_profile.value_or(""), .endpoint = config.endpoint});
  const bool http_fixture =
#ifdef RASP_REPORTING_TRANSPORT_TEST
      transport_fixture().http_fixture && !endpoint->tls && endpoint->host == "127.0.0.1";
#else
      false;
#endif
#ifdef RASP_REPORTING_TRANSPORT_TEST
  if (http_fixture) {
    profile = SecurityProfile{};
  }
#endif
  if (!endpoint->tls && !http_fixture) {
    return TransportResult::kHttpRejected;
  }
  if (!profile.has_value()) {
    return TransportResult::kProfileInvalid;
  }
  if (!profile_active(*profile, security_time())) {
    return TransportResult::kProfileNotActive;
  }
  if (!http_fixture && !platform_security_available()) {
    return TransportResult::kPlatformPolicyUnavailable;
  }
  const auto exchange = std::make_shared<Exchange>();
  exchange->tls = endpoint->tls;
  exchange->trust = std::make_shared<IosTrustState>();
  exchange->trust->profile = std::move(*profile);
  exchange->trust->hostname = endpoint->host;
  const Queue queue(dispatch_queue_create(nullptr, DISPATCH_QUEUE_SERIAL));
  const Queue verify_queue(dispatch_queue_create(nullptr, DISPATCH_QUEUE_SERIAL));
  if (exchange->signal == nullptr || queue == nullptr || verify_queue == nullptr) {
    return TransportResult::kTransportBusy;
  }
  auto* const connection = create_connection(*endpoint, verify_queue.get(), exchange->trust);
  if (connection == nullptr) {
    return TransportResult::kPlatformPolicyUnavailable;
  }
  nw_connection_set_queue(connection, queue.get());
  install_callbacks(connection, queue.get(), exchange, http_fixture);
  nw_connection_start(connection);
  const bool accepted =
      exchange_request(connection, queue.get(), exchange, make_request(*endpoint, body), cancellation);
  const auto result = publication_result(config, cancellation, accepted, *exchange);
  exchange->terminal.store(true);
  cancel_trust(exchange->trust, result);
  // Drain state callbacks before releasing their borrowed connection; late report/receive blocks own only Exchange.
  dispatch_sync(queue.get(), ^{
    nw_connection_cancel(connection);
    nw_connection_set_state_changed_handler(connection, nullptr);
    nw_connection_set_path_changed_handler(connection, nullptr);
  });
  nw_release(connection);
  return result;
}

}  // namespace rasp::plugins::reporting
