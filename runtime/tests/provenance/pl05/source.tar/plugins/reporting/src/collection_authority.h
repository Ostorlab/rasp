/// Immutable local collector configuration; never included in the backend producer digest.
#pragma once
#include <optional>
#include <string>
#include <string_view>

namespace rasp::plugins::reporting {
struct CollectionSettings {
  std::string_view endpoint;
  std::string_view policy;
  std::string_view zone;
  std::string_view dns_policy;
  std::optional<std::string_view> security = std::nullopt;
};
/// Builds a bounded canonical binding, or fails for ambiguous/unsupported configuration. Empty zone means no DNS.
[[nodiscard]] std::optional<std::string> collection_authority(const CollectionSettings& settings);
/// Validates persisted canonical authority bytes, including closed transport policy versions.
[[nodiscard]] bool valid_authority(std::string_view binding);
struct AuthorityComparison {
  std::string_view original;
  std::string_view current;
};
/// Exact comparison of scheme/host/effective-port/request-target and both HTTPS policies.
[[nodiscard]] bool same_https_authority(const AuthorityComparison& bindings);
/// Independent full-zone/policy comparison, requiring DNS present in both bindings.
[[nodiscard]] bool same_dns_authority(const AuthorityComparison& bindings);
/// Returns the exact HTTPS endpoint represented by a valid binding, otherwise nothing.
[[nodiscard]] std::optional<std::string> authority_endpoint(std::string_view binding);
/// Returns the original validated zone, otherwise nothing.
[[nodiscard]] std::optional<std::string> authority_zone(std::string_view binding);
}  // namespace rasp::plugins::reporting
