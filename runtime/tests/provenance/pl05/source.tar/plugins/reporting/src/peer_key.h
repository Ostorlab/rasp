/// Bounded canonical leaf SPKI and reviewed public-key algorithm, independent of trust evaluation.
#pragma once
#include <optional>
#include <string>
#include <string_view>

#include "security_profile.h"
namespace rasp::plugins::reporting {
struct PeerKey {
  std::string algorithm;
  std::string spki;
};
/// Only canonical RSA-2048/3072/4096 and named P-256/P-384 uncompressed public keys are supported.
[[nodiscard]] std::optional<PeerKey> certificate_key(std::string_view certificate);
/// Wrap bounded public RSA PKCS#1 or uncompressed EC X9.63 export in its canonical AlgorithmIdentifier/SPKI.
struct PublicKeyExport {
  std::string_view algorithm;
  std::string_view key;
};
[[nodiscard]] std::optional<std::string> canonical_spki(PublicKeyExport exported);
/// Match digest and algorithm on the SAME primary/backup pin. Never establishes CA/hostname trust.
[[nodiscard]] bool matches_leaf(const SecurityProfile& profile, std::string_view certificate);
}  // namespace rasp::plugins::reporting
