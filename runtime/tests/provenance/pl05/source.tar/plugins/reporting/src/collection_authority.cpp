#include "collection_authority.h"

#include <algorithm>
#include <charconv>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>

#include "json_value.h"
#include "security_profile.h"

namespace rasp::plugins::reporting {
namespace {
constexpr std::string_view kHttpsPolicy = "https-cycle-v2-system-trust-noauth-no-redirect-v1";
constexpr std::string_view kProfiledHttpsPolicy = "https-cycle-v2-profiled-trust-noauth-no-redirect-v2";
constexpr std::string_view kDnsPolicy = "dns-v2-plain-system-resolver-v1";
bool policy_token(std::string_view value) {
  return !value.empty() && value.size() <= 64 && std::ranges::all_of(value, [](char byte) {
    return (byte >= 'a' && byte <= 'z') || (byte >= 'A' && byte <= 'Z') || (byte >= '0' && byte <= '9') ||
           byte == '.' || byte == '_' || byte == '-';
  });
}
std::string lowercase(std::string_view value) {
  std::string result(value);
  for (char& byte : result) {
    if (byte >= 'A' && byte <= 'Z') {
      byte = static_cast<char>(byte + ('a' - 'A'));
    }
  }
  return result;
}
bool canonical_octet(std::string_view label) {
  unsigned octet = 0;
  const auto parsed = std::from_chars(std::to_address(label.begin()), std::to_address(label.end()), octet);
  return (label.size() <= 1 || label.front() != '0') && parsed.ec == std::errc{} &&
         parsed.ptr == std::to_address(label.end()) && octet <= 255;
}
bool hostname(std::string_view host, bool dns_zone = false) {
  if (host.empty() || host.size() > 253 || host.back() == '.') {
    return false;
  }
  std::size_t start = 0;
  std::size_t wire_bytes = 0;
  std::size_t labels = 0;
  const bool numeric = std::ranges::all_of(host, [](char byte) { return (byte >= '0' && byte <= '9') || byte == '.'; });
  while (start < host.size()) {
    const auto end = host.find('.', start);
    const auto label = host.substr(start, end == std::string_view::npos ? host.size() - start : end - start);
    if (label.empty() || label.size() > 63 || label.front() == '-' || label.back() == '-') {
      return false;
    }
    if (!std::ranges::all_of(label, [](char byte) {
          return (byte >= 'a' && byte <= 'z') || (byte >= '0' && byte <= '9') || byte == '-';
        })) {
      return false;
    }
    if (numeric && !dns_zone && !canonical_octet(label)) {
      return false;
    }
    ++labels;
    wire_bytes += label.size() + 1;
    if (end == std::string_view::npos) {
      break;
    }
    start = end + 1;
  }
  return dns_zone ? wire_bytes <= 48 : !numeric || labels == 4;
}
bool valid_endpoint_bytes(std::string_view endpoint) {
  for (std::size_t index = 0; index < endpoint.size(); ++index) {
    const auto byte = static_cast<unsigned char>(endpoint[index]);
    if (byte <= 0x20 || byte >= 0x7f || byte == '"' || byte == '\\' || byte == '#') {
      return false;
    }
    if (byte == '%') {
      const auto hex = [](char item) {
        return (item >= '0' && item <= '9') || (item >= 'a' && item <= 'f') || (item >= 'A' && item <= 'F');
      };
      if (endpoint.size() - index < 3 || !hex(endpoint[index + 1]) || !hex(endpoint[index + 2])) {
        return false;
      }
    }
  }
  return true;
}
std::optional<JsonValue> https_binding(std::string_view endpoint, std::string_view policy, std::size_t limit = 2048,
                                       std::string_view security = {}) {
  if (endpoint.size() > limit || !endpoint.starts_with("https://") || !policy_token(policy) ||
      !valid_endpoint_bytes(endpoint)) {
    return std::nullopt;
  }
  const auto rest = endpoint.substr(8);
  const auto separator = rest.find_first_of("/?");
  const auto authority = rest.substr(0, separator);
  const auto colon = authority.find(':');
  const std::string host = lowercase(authority.substr(0, colon));
  if (!hostname(host) || authority.contains('@')) {
    return std::nullopt;
  }
  std::uint64_t port = 443;
  if (colon != std::string_view::npos) {
    const auto text = authority.substr(colon + 1);
    const auto parsed = std::from_chars(std::to_address(text.begin()), std::to_address(text.end()), port);
    if (text.empty() || parsed.ec != std::errc{} || parsed.ptr != std::to_address(text.end()) || port == 0 ||
        port > 65535 || std::to_string(port) != text) {
      return std::nullopt;
    }
  }
  std::string target = separator == std::string_view::npos ? "/" : std::string(rest.substr(separator));
  if (target.starts_with('?')) {
    target.insert(target.begin(), '/');
  }
  JsonValue::Object result{
      {"scheme", JsonValue("https")},
      {"host", JsonValue(host)},
      {"port", JsonValue(port)},
      {"target", JsonValue(target)},
      {"collection_policy", JsonValue(policy)},
      {"transport_policy", JsonValue(security.empty() ? kHttpsPolicy : kProfiledHttpsPolicy)},
  };
  if (!security.empty()) {
    const auto parsed = parse_json(security, 2048);
    if (!parsed.has_value() || !keys_are(*parsed, {"profile", "proxy", "tls", "trust_store"}) ||
        canonical_json(*parsed, 2048) != security) {
      return std::nullopt;
    }
    const auto encoded_profile = canonical_json(parsed->get("profile"), 1536);
    const auto profile = encoded_profile.has_value()
                             ? parse_security_profile({.profile = *encoded_profile, .endpoint = endpoint})
                             : std::nullopt;
    if (!profile.has_value() || security_descriptor(*profile) != security) {
      return std::nullopt;
    }
    result.emplace("security", *parsed);
  }
  return JsonValue(std::move(result));
}
std::optional<JsonValue> parsed_binding(std::string_view binding) {
  auto value = parse_json(binding, 4096);
  if (!value.has_value() || !keys_are(*value, {"version", "https", "dns"}) ||
      (value->get("version").unsigned_number() != 1 && value->get("version").unsigned_number() != 2) ||
      canonical_json(*value, 4096) != binding) {
    return std::nullopt;
  }
  const auto& https = value->get("https");
  const bool profiled = value->get("version").unsigned_number() == 2;
  const bool valid_keys =
      profiled
          ? keys_are(https, {"scheme", "host", "port", "target", "collection_policy", "transport_policy", "security"})
          : keys_are(https, {"scheme", "host", "port", "target", "collection_policy", "transport_policy"});
  if (!valid_keys || https.get("host").text() == nullptr || https.get("target").text() == nullptr ||
      https.get("collection_policy").text() == nullptr || https.get("scheme").text() == nullptr ||
      *https.get("scheme").text() != "https" || https.get("transport_policy").text() == nullptr ||
      *https.get("transport_policy").text() != (profiled ? kProfiledHttpsPolicy : kHttpsPolicy)) {
    return std::nullopt;
  }
  const auto port = https.get("port").unsigned_number();
  if (!port.has_value() || *port == 0 || *port > 65535) {
    return std::nullopt;
  }
  const std::string endpoint =
      "https://" + *https.get("host").text() + ":" + std::to_string(*port) + *https.get("target").text();
  const auto security = profiled ? canonical_json(https.get("security"), 2048) : std::optional<std::string>("");
  if (!security.has_value()) {
    return std::nullopt;
  }
  const auto normalized = https_binding(endpoint, *https.get("collection_policy").text(), 2054, *security);
  if (!normalized.has_value() || canonical_json(*normalized, 4096) != canonical_json(https, 4096)) {
    return std::nullopt;
  }
  const auto& dns = value->get("dns");
  if (!dns.null()) {
    if (!keys_are(dns, {"zone", "collection_policy", "transport_policy"}) || dns.get("zone").text() == nullptr ||
        dns.get("collection_policy").text() == nullptr || !policy_token(*dns.get("collection_policy").text()) ||
        dns.get("transport_policy").text() == nullptr || *dns.get("transport_policy").text() != kDnsPolicy ||
        !hostname(*dns.get("zone").text(), true)) {
      return std::nullopt;
    }
  }
  return value;
}
}  // namespace
std::optional<std::string> collection_authority(const CollectionSettings& settings) {
  const auto& [endpoint, policy, zone, dns_policy, supplied_security] = settings;
  const auto security = supplied_security.value_or("");
  auto https = https_binding(endpoint, policy, 2048, security);
  if (!https.has_value()) {
    return std::nullopt;
  }
  JsonValue dns;
  if (!zone.empty()) {
    const auto canonical_zone = lowercase(zone);
    if (!hostname(canonical_zone, true) || !policy_token(dns_policy)) {
      return std::nullopt;
    }
    dns = JsonValue(JsonValue::Object{
        {"zone", JsonValue(canonical_zone)},
        {"collection_policy", JsonValue(dns_policy)},
        {"transport_policy", JsonValue(kDnsPolicy)},
    });
  }
  return canonical_json(JsonValue(JsonValue::Object{
                            {"version", JsonValue(std::uint64_t{security.empty() ? 1U : 2U})},
                            {"https", std::move(*https)},
                            {"dns", std::move(dns)},
                        }),
                        4096);
}
bool valid_authority(std::string_view binding) { return parsed_binding(binding).has_value(); }
bool same_https_authority(const AuthorityComparison& bindings) {
  const auto first = parsed_binding(bindings.original);
  const auto second = parsed_binding(bindings.current);
  return first.has_value() && second.has_value() &&
         canonical_json(first->get("https"), 4096) == canonical_json(second->get("https"), 4096);
}
bool same_dns_authority(const AuthorityComparison& bindings) {
  const auto first = parsed_binding(bindings.original);
  const auto second = parsed_binding(bindings.current);
  return first.has_value() && second.has_value() && !first->get("dns").null() && !second->get("dns").null() &&
         canonical_json(first->get("dns"), 4096) == canonical_json(second->get("dns"), 4096);
}
std::optional<std::string> authority_endpoint(std::string_view binding) {
  const auto value = parsed_binding(binding);
  if (!value.has_value()) {
    return std::nullopt;
  }
  const auto& https = value->get("https");
  return "https://" + *https.get("host").text() + ":" +
         std::to_string(https.get("port").unsigned_number().value_or(0)) + *https.get("target").text();
}
std::optional<std::string> authority_zone(std::string_view binding) {
  const auto value = parsed_binding(binding);
  if (!value.has_value() || value->get("dns").null()) {
    return std::nullopt;
  }
  return *value->get("dns").get("zone").text();
}
}  // namespace rasp::plugins::reporting
