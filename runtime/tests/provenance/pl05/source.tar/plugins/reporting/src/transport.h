/// The platform's HTTP(S) transport: posts one JSON request to the endpoint, with bounded timeouts.
///
/// On Android it uses libcurl, with Mbed TLS for TLS, both compiled into the runtime, and trusts only the system's CA
/// certificates. On iOS it uses a Network.framework connection, with the system's TLS and trust, and writes the
/// HTTP/1.1 request itself (`http.h`). Each platform has its own source file in a folder named after it. A development
/// machine, which builds the plugin only for the tests, uses the one in `dev/`, which sends nothing.

#pragma once

#include <atomic>
#include <chrono>
#include <cstdint>
#include <string_view>

#include "config.h"
#include "reporting/transport_result.h"

namespace rasp::plugins::reporting {

/// A borrowed stop token valid for the synchronous call; escaping callbacks retain only their owned terminal state.
class Cancellation {
 public:
  Cancellation() = default;
  explicit Cancellation(const std::atomic<bool>* stop) : stop_(stop) {}
  [[nodiscard]] bool requested() const { return stop_ != nullptr && stop_->load(); }

 private:
  const std::atomic<bool>* stop_ = nullptr;
};
/// Plain DNS fallback is permitted only for network availability failures, never security/protocol/cancellation.
[[nodiscard]] constexpr bool permits_dns(TransportResult result) {
  return result == TransportResult::kResolutionFailed || result == TransportResult::kConnectFailed ||
         result == TransportResult::kTimeout || result == TransportResult::kIoFailed;
}

/// Revalidate cancellation, compiled profile/UTC validity and platform enforcement at a non-ack handoff.
/// PublicationUnconfirmed means policy still permits a separately authorized network fallback.
[[nodiscard]] TransportResult transport_policy(const Config& config, Cancellation cancellation = {});

/// How long a post waits to connect to the endpoint.
inline constexpr std::chrono::seconds kConnectTimeout{10};

/// How long a post waits for the endpoint to answer, once connected.
inline constexpr std::chrono::seconds kResponseTimeout{10};

/// How long a whole post may take, from the request to the end of the answer.
inline constexpr std::chrono::seconds kPostTimeout = kConnectTimeout + kResponseTimeout;

/// Posts one JSON request to the endpoint, once, with the `Content-Type: application/json` header and no
/// authorization. Redirects are not followed and nothing is cached.
///
/// It blocks the calling thread until the endpoint answers, a timeout passes or the post fails. In a development build
/// it logs why a post failed.
///
/// @param config The compiled endpoint and explicit security profile.
/// @param body The request.
/// @return PublicationAcknowledged only for a complete bounded 2xx response with valid JSON, exact boolean
/// data.submitObservations true and no errors member. This acknowledges publication, not durable storage.
[[nodiscard]] TransportResult post(const Config& config, std::string_view body,
                                   Cancellation cancellation = {}) noexcept;

}  // namespace rasp::plugins::reporting
