#include "reporting/fallback_authorization.h"

#include <atomic>
#include <memory>
#include <optional>
#include <string>
#include <utility>

#include "collection_authority.h"
#include "config.h"
#include "reporting/transport_result.h"
#include "security_profile.h"
#include "transport.h"
namespace rasp::plugins::reporting {
FallbackAuthorization::FallbackAuthorization(const Config& config, std::string authority,
                                             std::shared_ptr<const std::atomic<bool>> cancellation)
    : config_(std::make_shared<const Config>(config)),
      authority_(std::move(authority)),
      cancellation_(std::move(cancellation)) {
  const auto profile =
      parse_security_profile({.profile = config.security_profile.value_or(""), .endpoint = config.endpoint});
  const auto descriptor = profile.has_value() ? security_descriptor(*profile) : std::nullopt;
  if (!descriptor.has_value()) {
    return;
  }
  const auto current = collection_authority({
      .endpoint = config.endpoint,
      .policy = config.collection_policy,
      .zone = "",
      .dns_policy = "default",
      .security = *descriptor,
  });
  bound_ = cancellation_ != nullptr && current.has_value() && authority_zone(authority_).has_value() &&
           same_https_authority({.original = authority_, .current = *current});
}
TransportResult FallbackAuthorization::status() const {
  return bound_ ? transport_policy(*config_, Cancellation(cancellation_.get())) : TransportResult::kProfileInvalid;
}
bool FallbackAuthorization::matches_dns(DnsSelection selection) const {
  const auto [zone, policy] = selection;
  const auto selected = collection_authority({
      .endpoint = config_->endpoint,
      .policy = config_->collection_policy,
      .zone = zone,
      .dns_policy = policy,
  });
  return bound_ && selected.has_value() && same_dns_authority({.original = authority_, .current = *selected});
}
}  // namespace rasp::plugins::reporting
