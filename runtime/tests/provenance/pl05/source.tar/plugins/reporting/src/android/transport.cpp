/// Reporting HTTPS through the pinned curl/Mbed TLS island. No alternate trust or proxy fallback.
#include "transport.h"

#include <chrono>
#include <cstddef>
#include <curl/curl.h>
#include <curl/easy.h>
#include <curl/multi.h>
#include <curl/system.h>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <string_view>
#include <utility>

#include "config.h"
#include "http.h"
#include "json.h"
#include "peer_key.h"
#include "reporting/transport_result.h"
#include "security_profile.h"
#include "tls_island.h"
#ifdef RASP_REPORTING_TRANSPORT_TEST
#include <thread>

#include "transport_fixture.h"
#endif

namespace rasp::plugins::reporting {
namespace {
constexpr const char* kSystemCaPath = "/system/etc/security/cacerts";
constexpr long kConnectTimeoutMs = static_cast<long>(std::chrono::milliseconds(kConnectTimeout).count());
constexpr long kPostTimeoutMs = static_cast<long>(std::chrono::milliseconds(kPostTimeout).count());
struct Attempt {
  SecurityProfile profile;
  Cancellation cancellation;
  TransportResult failure = TransportResult::kPublicationUnconfirmed;
  ReportingVerify verify{};
  std::chrono::steady_clock::time_point total = std::chrono::steady_clock::now() + kPostTimeout;
  std::optional<std::chrono::steady_clock::time_point> response = std::nullopt;
};
bool expired(const Attempt& attempt) {
  const auto now = std::chrono::steady_clock::now();
  return now >= attempt.total || (attempt.response.has_value() && now >= *attempt.response);
}
/// The ABI has no unload hook. Keep one bounded resolver pool for process lifetime; never join OS DNS on a sender.
struct CurlPool {
  std::mutex mutex;
  std::unique_ptr<CURLM, decltype(&curl_multi_cleanup)> multi{nullptr, curl_multi_cleanup};
};
CurlPool& curl_pool() {
  static CurlPool* const kPool = std::make_unique<CurlPool>().release();
  return *kPool;
}
template <typename Value>
bool set(CURL* handle, CURLoption option, Value value) {
  // NOLINTNEXTLINE(cppcoreguidelines-pro-type-vararg): libcurl takes options through its variadic C API.
  return curl_easy_setopt(handle, option, value) == CURLE_OK;
}
int check_leaf(void* context, const ReportingCertificate* certificate) noexcept {
  const auto [bytes, length, depth, flags] = *certificate;
  auto& attempt = *static_cast<Attempt*>(context);
  if (attempt.cancellation.requested()) {
    attempt.failure = TransportResult::kCancelled;
  } else if (!profile_active(attempt.profile, security_time())) {
    attempt.failure = TransportResult::kProfileNotActive;
  } else if (flags != 0) {
    attempt.failure = TransportResult::kTrustVerificationFailed;
  } else if (depth == 0 &&
             (bytes == nullptr || length > 16384 ||
              !matches_leaf(attempt.profile, std::string_view(static_cast<const char*>(bytes), length)))) {
    attempt.failure = TransportResult::kPinVerificationFailed;
  } else {
    return 0;
  }
  return 1;
}
constexpr auto kProgress = +[](void* context, curl_off_t /*download_total*/, curl_off_t /*download_now*/,
                               curl_off_t /*upload_total*/, curl_off_t /*upload_now*/) noexcept {
  auto& attempt = *static_cast<Attempt*>(context);
  if (attempt.cancellation.requested()) {
    attempt.failure = TransportResult::kCancelled;
    return 1;
  }
  if (attempt.failure != TransportResult::kPublicationUnconfirmed && !permits_dns(attempt.failure)) {
    return 1;
  }
  if (!profile_active(attempt.profile, security_time())) {
    attempt.failure = TransportResult::kProfileNotActive;
    return 1;
  }
  if (expired(attempt)) {
    attempt.failure = TransportResult::kTimeout;
    return 1;
  }
  return 0;
};
constexpr curl_prereq_callback kBeforeSend = [](void* context, char* /*remote_ip*/, char* /*local_ip*/,
                                                int /*remote_port*/, int /*local_port*/) noexcept -> int {
  auto& attempt = *static_cast<Attempt*>(context);
  if (!attempt.response.has_value()) {
    attempt.response = std::chrono::steady_clock::now() + kResponseTimeout;
  }
#ifdef RASP_REPORTING_TRANSPORT_TEST
  const auto& fixture = transport_fixture();
  if (fixture.send_queue_delay_ms > 0) {
    if (fixture.queued_sends != nullptr) {
      fixture.queued_sends->fetch_add(1);
    }
    if (fixture.on_send_queue_entered != nullptr) {
      fixture.on_send_queue_entered();
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(fixture.send_queue_delay_ms));
  }
#endif
  return kProgress(&attempt, 0, 0, 0, 0) == 0 ? CURL_PREREQFUNC_OK : CURL_PREREQFUNC_ABORT;
};
constexpr curl_write_callback kCollect = [](char* data, std::size_t /*byte_size*/, std::size_t count,
                                            void* context) noexcept -> std::size_t {
  return append_response(*static_cast<std::string*>(context), data, 1, count);
};
constexpr curl_write_callback kCollectHeaders = [](char* data, std::size_t /*byte_size*/, std::size_t count,
                                                   void* context) noexcept -> std::size_t {
  auto& headers = *static_cast<std::string*>(context);
  if (count > 16384 - headers.size()) {
    return std::size_t{0};
  }
  headers.append(data, count);
  return count;
};
TransportResult translate(CURLcode code, const Attempt& attempt) {
  if (attempt.failure != TransportResult::kPublicationUnconfirmed) {
    return attempt.failure;
  }
  switch (code) {
    case CURLE_OK:
      return TransportResult::kPublicationUnconfirmed;
    case CURLE_SSL_CACERT_BADFILE:
    case CURLE_SSL_CONNECT_ERROR:
    case CURLE_PEER_FAILED_VERIFICATION:
      return TransportResult::kTrustVerificationFailed;
    case CURLE_SSL_PINNEDPUBKEYNOTMATCH:
      return TransportResult::kPinVerificationFailed;
    case CURLE_OPERATION_TIMEDOUT:
      return TransportResult::kTimeout;
    case CURLE_COULDNT_RESOLVE_HOST:
      return TransportResult::kResolutionFailed;
    case CURLE_COULDNT_CONNECT:
      return TransportResult::kConnectFailed;
    case CURLE_ABORTED_BY_CALLBACK:
      return TransportResult::kCancelled;
    case CURLE_PARTIAL_FILE:
    case CURLE_WEIRD_SERVER_REPLY:
    case CURLE_BAD_CONTENT_ENCODING:
    case CURLE_WRITE_ERROR:
      return TransportResult::kResponseInvalid;
    default:
      return TransportResult::kIoFailed;
  }
}
void initialize_pool(CurlPool& pool) {
  if (pool.multi != nullptr) {
    return;
  }
  pool.multi.reset(curl_multi_init());
  if (pool.multi != nullptr && rasp_reporting_configure_multi(pool.multi.get()) != 0) {
    pool.multi.reset();
  }
}
TransportResult finish_attempt(TransportResult result, const Attempt& attempt) {
  if (attempt.cancellation.requested()) {
    return TransportResult::kCancelled;
  }
  if (attempt.failure != TransportResult::kPublicationUnconfirmed && !permits_dns(attempt.failure)) {
    return attempt.failure;
  }
  if (result != TransportResult::kPublicationUnconfirmed && !permits_dns(result)) {
    return result;
  }
  return expired(attempt) ? TransportResult::kTimeout : result;
}
TransportResult perform(CURL* handle, Attempt& attempt) {
  auto& pool = curl_pool();
  const std::unique_lock lock(pool.mutex, std::try_to_lock);
  if (!lock.owns_lock()) {
    return TransportResult::kTransportBusy;
  }
  initialize_pool(pool);
  auto* const multi = pool.multi.get();
  if (multi == nullptr || curl_multi_add_handle(multi, handle) != CURLM_OK) {
    return TransportResult::kIoFailed;
  }
  TransportResult result = TransportResult::kIoFailed;
  int active = 0;
  while (true) {
    if (kProgress(&attempt, 0, 0, 0, 0) != 0) {
      result = attempt.failure;
      break;
    }
    if (expired(attempt)) {
      result = TransportResult::kTimeout;
      break;
    }
    if (curl_multi_perform(multi, &active) != CURLM_OK) {
      break;
    }
    int done = 0;
    const int code = rasp_reporting_multi_result(multi, &done);
    if (done != 0) {
      result = translate(static_cast<CURLcode>(code), attempt);
      break;
    }
    if (active == 0 || curl_multi_poll(multi, nullptr, 0, 100, nullptr) != CURLM_OK) {
      break;
    }
  }
  static_cast<void>(curl_multi_remove_handle(multi, handle));
  return finish_attempt(result, attempt);
}
TransportResult send(CURL* handle, curl_slist* headers, const Config& config, const Endpoint& endpoint,
                     std::string_view body, Attempt& attempt) {
  std::string response;
  std::string response_headers;
  const std::string pins =
      attempt.profile.pinned ? attempt.profile.pins[0].value + ";" + attempt.profile.pins[1].value : "";
#ifdef RASP_REPORTING_TRANSPORT_TEST
  std::unique_ptr<curl_slist, decltype(&curl_slist_free_all)> routing(nullptr, curl_slist_free_all);
#endif
  const std::unique_ptr<CURL, decltype(&curl_easy_cleanup)> owned_handle(handle, curl_easy_cleanup);
  const char* protocols = "https";
#ifdef RASP_REPORTING_TRANSPORT_TEST
  if (transport_fixture().http_fixture && !endpoint.tls && endpoint.host == "127.0.0.1") {
    protocols = "http,https";
  }
#endif
  bool ready =
      set(handle, CURLOPT_NOSIGNAL, 1L) && set(handle, CURLOPT_URL, config.endpoint.c_str()) &&
      set(handle, CURLOPT_PROTOCOLS_STR, protocols) && set(handle, CURLOPT_FOLLOWLOCATION, 0L) &&
      set(handle, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1) && set(handle, CURLOPT_PATH_AS_IS, 1L) &&
      set(handle, CURLOPT_FRESH_CONNECT, 1L) && set(handle, CURLOPT_FORBID_REUSE, 1L) &&
      set(handle, CURLOPT_REQUEST_TARGET, endpoint.target.c_str()) &&
      set(handle, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2) && set(handle, CURLOPT_SSL_VERIFYPEER, 1L) &&
      set(handle, CURLOPT_SSL_VERIFYHOST, 2L) && set(handle, CURLOPT_CAPATH, kSystemCaPath) &&
      set(handle, CURLOPT_SSL_SESSIONID_CACHE, 0L) && rasp_reporting_set_verify(handle, &attempt.verify) == 0 &&
      set(handle, CURLOPT_CONNECTTIMEOUT_MS, kConnectTimeoutMs) && set(handle, CURLOPT_TIMEOUT_MS, kPostTimeoutMs) &&
      set(handle, CURLOPT_LOW_SPEED_LIMIT, 1L) &&
      set(handle, CURLOPT_LOW_SPEED_TIME, static_cast<long>(kResponseTimeout.count())) &&
      set(handle, CURLOPT_NOPROGRESS, 0L) && set(handle, CURLOPT_XFERINFOFUNCTION, kProgress) &&
      set(handle, CURLOPT_XFERINFODATA, &attempt) && set(handle, CURLOPT_PREREQFUNCTION, kBeforeSend) &&
      set(handle, CURLOPT_PREREQDATA, &attempt) && set(handle, CURLOPT_HTTPHEADER, headers) &&
      set(handle, CURLOPT_WRITEFUNCTION, kCollect) && set(handle, CURLOPT_WRITEDATA, &response) &&
      set(handle, CURLOPT_HEADERFUNCTION, kCollectHeaders) && set(handle, CURLOPT_HEADERDATA, &response_headers) &&
      rasp_reporting_set_body(handle, body.data(), body.size()) == 0;
  if (attempt.profile.pinned) {
    ready = ready && set(handle, CURLOPT_PINNEDPUBLICKEY, pins.c_str());
  }
#ifdef RASP_REPORTING_TRANSPORT_TEST
  const auto& fixture = transport_fixture();
  if (!fixture.ca_file.empty()) {
    ready = ready && set(handle, CURLOPT_CAPATH, static_cast<const char*>(nullptr)) &&
            set(handle, CURLOPT_CAINFO, fixture.ca_file.c_str());
  }
  if (!fixture.address.empty()) {
    const std::string mapping = endpoint.host + ":" + endpoint.port + ":" + fixture.address;
    routing.reset(curl_slist_append(nullptr, mapping.c_str()));
    ready = ready && routing != nullptr && set(handle, CURLOPT_RESOLVE, routing.get());
  }
#endif
  const TransportResult result = ready ? perform(handle, attempt) : TransportResult::kProfileInvalid;
  if (result != TransportResult::kPublicationUnconfirmed) {
    return result == TransportResult::kIoFailed && !response_headers.empty() ? TransportResult::kResponseInvalid
                                                                             : result;
  }
  long status = 0;
  // NOLINTNEXTLINE(cppcoreguidelines-pro-type-vararg): libcurl returns status through its variadic C API.
  if (curl_easy_getinfo(handle, CURLINFO_RESPONSE_CODE, &status) != CURLE_OK) {
    return TransportResult::kIoFailed;
  }
  if (status >= 300 && status < 400) {
    return TransportResult::kRedirectRejected;
  }
  if (status < 200 || status >= 300 || status == 204 || status == 205) {
    return TransportResult::kHttpRejected;
  }
  return acknowledged(response) ? TransportResult::kPublicationAcknowledged : TransportResult::kPublicationUnconfirmed;
}
}  // namespace
TransportResult post(const Config& config, std::string_view body, Cancellation cancellation) noexcept {
  if (cancellation.requested()) {
    return TransportResult::kCancelled;
  }
  const auto endpoint = parse_endpoint(config.endpoint);
  if (!endpoint.has_value() || body.size() > kMaxRequestSize) {
    return TransportResult::kProfileInvalid;
  }
  auto profile = parse_security_profile({.profile = config.security_profile.value_or(""), .endpoint = config.endpoint});
#ifdef RASP_REPORTING_TRANSPORT_TEST
  if (transport_fixture().http_fixture && !endpoint->tls && endpoint->host == "127.0.0.1") {
    profile = SecurityProfile{};
  } else
#endif
      if (!endpoint->tls) {
    return TransportResult::kHttpRejected;
  }
  if (!profile.has_value()) {
    return TransportResult::kProfileInvalid;
  }
  if (!profile_active(*profile, security_time())) {
    return TransportResult::kProfileNotActive;
  }
  static const bool kInitialized = curl_global_init(CURL_GLOBAL_DEFAULT) == CURLE_OK;
  if (!kInitialized) {
    return TransportResult::kIoFailed;
  }
  CURL* const handle = curl_easy_init();
  const std::unique_ptr<curl_slist, decltype(&curl_slist_free_all)> headers(
      curl_slist_append(nullptr, "Content-Type: application/json"), curl_slist_free_all);
  if (handle == nullptr || headers == nullptr) {
    if (handle != nullptr) {
      curl_easy_cleanup(handle);
    }
    return TransportResult::kIoFailed;
  }
  Attempt attempt{.profile = std::move(*profile), .cancellation = cancellation};
  attempt.verify = {.context = &attempt, .check = check_leaf};
  return send(handle, headers.get(), config, *endpoint, body, attempt);
}
}  // namespace rasp::plugins::reporting
