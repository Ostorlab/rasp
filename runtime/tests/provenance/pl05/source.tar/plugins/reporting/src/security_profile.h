/// Strict immutable reporting profile; no trust bypass or routing state.
#pragma once
#include <array>
#include <cstdint>
#include <optional>
#include <string>
#include <string_view>

#include "hash.h"
namespace rasp::plugins::reporting {
struct Pin {
  std::string algorithm;
  std::string value;
  Digest digest{};
};
struct SecurityProfile {
  std::string canonical;
  bool pinned = false;
  std::array<Pin, 2> pins;
  std::uint64_t not_before = 0;
  std::uint64_t not_after = 0;
};
/// Validate bounded profile bytes and strict origin; check expiry separately at send time.
struct ProfileInput {
  std::string_view profile;
  std::string_view endpoint;
};
[[nodiscard]] std::optional<SecurityProfile> parse_security_profile(ProfileInput input);
/// Check validity using UTC Unix seconds; negative time is unavailable.
[[nodiscard]] bool profile_active(const SecurityProfile& profile, std::int64_t now);
/// Return the platform's canonical immutable profile/trust/proxy/TLS descriptor.
[[nodiscard]] std::optional<std::string> security_descriptor(const SecurityProfile& profile);
/// Return reviewed compiled settings, independent of caller/environment state.
[[nodiscard]] std::string_view compiled_security_profile();
/// Whether the platform can enforce the complete profile, including pre-POST proxy evidence.
[[nodiscard]] bool platform_security_available();
/// Platform UTC seconds, or -1 when unavailable.
[[nodiscard]] std::int64_t security_time();
/// Canonical base64 encoding of a SHA256 digest.
[[nodiscard]] std::string pin_value(const Digest& digest);
}  // namespace rasp::plugins::reporting
