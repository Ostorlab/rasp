/// Fixed-arity bridge to the required POSIX varargs API and independently owned directory streams.
#pragma once
#include <dirent.h>
#include <sys/types.h>
#ifdef __cplusplus
extern "C" {
#endif
int rasp_outbox_open(int directory, const char* name, int flags, mode_t mode);
/// Each caller owns a separate stream; returned storage belongs to that stream until its next read.
const char* rasp_outbox_next_entry(DIR* stream);
#ifdef __cplusplus
}
#endif
