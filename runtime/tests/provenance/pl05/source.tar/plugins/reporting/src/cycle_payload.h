/// One owning, validated cycle representation shared by persistence and both transports.
#pragma once
#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <string_view>

#include "hash.h"
#include "rasp/cycle.h"

namespace rasp::plugins::reporting {
inline constexpr std::size_t kMaxCanonicalBytes = std::size_t{192} * 1024;
inline constexpr std::size_t kMaxCycleRequestBytes = std::size_t{256} * 1024;
/// Immutable once published through shared_ptr<const PreparedCycle>; no views into a snapshot/parser.
struct PreparedCycle {
  std::string canonical;
  std::string request;
  std::string dns_json;
  std::string build_id;
  std::string install_id;
  std::string batch_id;
  Digest digest{};
  std::uint64_t serialization_dropped = 0;
};
/// Serializes a native immutable snapshot once, dropping whole unrepresentable observations with exact accounting.
[[nodiscard]] std::optional<PreparedCycle> prepare_cycle(const CycleSnapshot& snapshot, std::string_view build_id,
                                                         std::string_view install_id, std::string_view batch_id);
/// Validates strict canonical persisted producer bytes and recreates the identical transport representations.
[[nodiscard]] std::optional<PreparedCycle> restore_cycle(std::string_view canonical);
}  // namespace rasp::plugins::reporting
