#include "outbox.h"

#include <algorithm>
#include <array>
#include <bit>
#include <cerrno>
#include <cstdint>
#include <cstring>
#include <dirent.h>
#include <expected>
#include <limits>
#include <memory>
#include <optional>
#include <set>
#include <span>
#include <string>
#include <string_view>
#include <utility>

#include "collection_authority.h"
#include "cycle_payload.h"
#include "hash.h"
#include "json_value.h"
#include "outbox_posix.h"
#include "posix_file.h"

namespace rasp::plugins::reporting {
namespace {
constexpr int kFileFlags = O_RDWR | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK;
constexpr int kDirectoryFlags = O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK;
constexpr std::size_t kHeaderBytes = 128;
constexpr std::string_view kRecordMagic = "RSPCY01\n";
constexpr std::string_view kLogMagic = "RSPTRY1\n";
constexpr std::string_view kAckMagic = "RSPACK1\n";
constexpr char kStageByte = static_cast<char>(0xa5);
class Descriptor {
 public:
  explicit Descriptor(int descriptor) : descriptor_(descriptor) {}
  ~Descriptor() { static_cast<void>(close()); }
  Descriptor(const Descriptor&) = delete;
  Descriptor& operator=(const Descriptor&) = delete;
  Descriptor(Descriptor&&) = delete;
  Descriptor& operator=(Descriptor&&) = delete;
  [[nodiscard]] int get() const { return descriptor_; }
  [[nodiscard]] int release() { return std::exchange(descriptor_, -1); }
  [[nodiscard]] bool close() {
    const int descriptor = release();
    return descriptor < 0 || ::close(descriptor) == 0;
  }

 private:
  int descriptor_;
};
std::string slot_name(unsigned slot, std::string_view suffix) {
  return "slot" + std::string(slot < 10 ? "0" : "") + std::to_string(slot) + std::string(suffix);
}
bool private_directory(int descriptor) {
  struct stat info{};
  return fstat(descriptor, &info) == 0 && S_ISDIR(info.st_mode) && info.st_uid == geteuid() &&
         (info.st_mode & 07777U) == 0700;
}
bool file_matches(int directory, std::string_view name, int descriptor, struct stat& info, unsigned links = 1) {
  struct stat entry{};
  const std::string path(name);
  return fstat(descriptor, &info) == 0 && S_ISREG(info.st_mode) && info.st_uid == geteuid() &&
         (info.st_mode & 07777U) == 0600 && std::cmp_equal(info.st_nlink, links) &&
         fstatat(directory, path.c_str(), &entry, AT_SYMLINK_NOFOLLOW) == 0 && S_ISREG(entry.st_mode) &&
         entry.st_dev == info.st_dev && entry.st_ino == info.st_ino;
}
int open_file(int directory, const std::string& name, int extra = 0) {
  struct stat entry{};
  if (fstatat(directory, name.c_str(), &entry, AT_SYMLINK_NOFOLLOW) == 0) {
    if (!S_ISREG(entry.st_mode) || entry.st_uid != geteuid() || (entry.st_mode & 07777U) != 0600) {
      errno = EINVAL;
      return -1;
    }
  } else if (errno != ENOENT) {
    return -1;
  }
  return rasp_outbox_open(directory, name.c_str(),
                          static_cast<int>(static_cast<unsigned>(kFileFlags) | static_cast<unsigned>(extra)),
                          static_cast<mode_t>(0600));
}
std::expected<int, OutboxError> lock_file(int directory, const std::string& name) {
  Descriptor descriptor(open_file(directory, name, O_CREAT));
  struct stat info{};
  if (descriptor.get() < 0 || !file_matches(directory, name, descriptor.get(), info) || info.st_size != 0) {
    return std::unexpected(OutboxError::kInvalid);
  }
  if (flock(descriptor.get(), LOCK_EX | LOCK_NB) != 0) {
    return std::unexpected(errno == EWOULDBLOCK || errno == EAGAIN ? OutboxError::kBusy : OutboxError::kIo);
  }
  if (!file_matches(directory, name, descriptor.get(), info)) {
    return std::unexpected(OutboxError::kChanged);
  }
  return descriptor.release();
}
bool write_all(int descriptor, std::string_view bytes, std::size_t start = 0) {
  if (!std::in_range<off_t>(start) || !std::in_range<off_t>(bytes.size())) {
    return false;
  }
  const auto file_start = static_cast<off_t>(start);
  if (std::cmp_greater(bytes.size(), std::numeric_limits<off_t>::max() - file_start)) {
    return false;
  }
  std::size_t offset = 0;
  for (unsigned operation = 0; offset < bytes.size() && operation < 64; ++operation) {
    const ssize_t count =
        pwrite(descriptor, bytes.substr(offset).data(), bytes.size() - offset, file_start + static_cast<off_t>(offset));
    if (count < 0 && errno == EINTR) {
      continue;
    }
    if (count <= 0 || std::cmp_greater(count, bytes.size() - offset)) {
      return false;
    }
    offset += static_cast<std::size_t>(count);
  }
  return offset == bytes.size();
}
struct ReadFile {
  std::string bytes;
  struct stat info{};
};
std::expected<std::optional<ReadFile>, OutboxError> read_file(int directory, const std::string& name, std::size_t limit,
                                                              unsigned links = 1, bool durable = false) {
  Descriptor descriptor(open_file(directory, name));
  if (descriptor.get() < 0) {
    if (errno == ENOENT) {
      return std::nullopt;
    }
    return std::unexpected(OutboxError::kInvalid);
  }
  ReadFile result;
  if (!file_matches(directory, name, descriptor.get(), result.info, links) || result.info.st_size < 0 ||
      std::cmp_greater(result.info.st_size, limit)) {
    return std::unexpected(OutboxError::kInvalid);
  }
  result.bytes.resize(static_cast<std::size_t>(result.info.st_size));
  std::size_t offset = 0;
  for (unsigned operation = 0; offset < result.bytes.size() && operation < 64; ++operation) {
    const ssize_t count = pread(descriptor.get(), std::span(result.bytes).subspan(offset).data(),
                                result.bytes.size() - offset, static_cast<off_t>(offset));
    if (count < 0 && errno == EINTR) {
      continue;
    }
    if (count <= 0 || std::cmp_greater(count, result.bytes.size() - offset)) {
      return std::unexpected(OutboxError::kIo);
    }
    offset += static_cast<std::size_t>(count);
  }
  struct stat after{};
  if (offset != result.bytes.size() || !file_matches(directory, name, descriptor.get(), after, links) ||
      after.st_size != result.info.st_size || after.st_mtime != result.info.st_mtime ||
      after.st_ctime != result.info.st_ctime) {
    return std::unexpected(OutboxError::kChanged);
  }
  const bool synced = !durable || fsync(descriptor.get()) == 0;
  const bool closed = descriptor.close();
  if (!synced || !closed || (durable && fsync(directory) != 0)) {
    return std::unexpected(OutboxError::kIo);
  }
  return std::optional<ReadFile>(std::move(result));
}
std::string digest_bytes(const Digest& digest) {
  const auto bytes = std::bit_cast<std::array<char, 32>>(digest);
  return {bytes.data(), bytes.size()};
}
Digest read_digest(std::string_view bytes) {
  Digest result{};
  std::ranges::transform(bytes.substr(0, result.size()), result.begin(),
                         [](char byte) { return static_cast<std::uint8_t>(byte); });
  return result;
}
bool hash_matches(std::string_view bytes, const Digest& expected) {
  const auto hash = content_hash(bytes);
  return hash.has_value() && *hash == expected;
}
enum class HeaderInteger : std::uint8_t {
  kVersion = 8,
  kHeaderSize = 12,
  kOrdinal = 16,
  kPayloadSize = 24,
  kAuthoritySize = 28,
};
void put_integer(std::string& bytes, HeaderInteger field, std::uint64_t value) {
  const auto offset = static_cast<std::size_t>(field);
  const std::size_t count = field == HeaderInteger::kOrdinal ? 8 : 4;
  for (std::size_t index = 0; index < count; ++index) {
    bytes[offset + count - index - 1] = static_cast<char>(value & 255U);
    value >>= 8U;
  }
}
std::uint64_t get_integer(std::string_view bytes, HeaderInteger field) {
  const auto offset = static_cast<std::size_t>(field);
  const std::size_t count = field == HeaderInteger::kOrdinal ? 8 : 4;
  std::uint64_t value = 0;
  for (std::size_t index = 0; index < count; ++index) {
    value = (value << 8U) | static_cast<unsigned char>(bytes[offset + index]);
  }
  return value;
}
std::optional<std::string> record_bytes(const PreparedCycle& payload, std::string_view authority,
                                        std::uint64_t ordinal) {
  if (!valid_authority(authority) || !restore_cycle(payload.canonical).has_value()) {
    return std::nullopt;
  }
  std::string header(kHeaderBytes, '\0');
  header.replace(0, 8, kRecordMagic);
  put_integer(header, HeaderInteger::kVersion, 1);
  put_integer(header, HeaderInteger::kHeaderSize, kHeaderBytes);
  put_integer(header, HeaderInteger::kOrdinal, ordinal);
  put_integer(header, HeaderInteger::kPayloadSize, payload.canonical.size());
  put_integer(header, HeaderInteger::kAuthoritySize, authority.size());
  const auto binding_hash = content_hash(authority);
  const auto producer_hash = content_hash(payload.canonical);
  if (!binding_hash.has_value() || !producer_hash.has_value()) {
    return std::nullopt;
  }
  header.replace(32, 32, digest_bytes(*producer_hash));
  header.replace(96, 32, digest_bytes(*binding_hash));
  const auto header_hash = content_hash(header);
  if (!header_hash.has_value()) {
    return std::nullopt;
  }
  header.replace(64, 32, digest_bytes(*header_hash));
  return header + std::string(authority) + payload.canonical;
}
std::optional<QueuedCycle> decode_record(const ReadFile& file, unsigned slot, std::string_view install_id) {
  const std::string_view bytes(file.bytes);
  if (bytes.size() < kHeaderBytes || !bytes.starts_with(kRecordMagic) ||
      get_integer(bytes, HeaderInteger::kVersion) != 1 ||
      get_integer(bytes, HeaderInteger::kHeaderSize) != kHeaderBytes ||
      get_integer(bytes, HeaderInteger::kOrdinal) == 0) {
    return std::nullopt;
  }
  const auto length = get_integer(bytes, HeaderInteger::kPayloadSize);
  const auto binding_length = get_integer(bytes, HeaderInteger::kAuthoritySize);
  if (length == 0 || length > kMaxCanonicalBytes || binding_length == 0 || binding_length > 4096 ||
      bytes.size() != kHeaderBytes + length + binding_length) {
    return std::nullopt;
  }
  std::string header(bytes.substr(0, kHeaderBytes));
  header.replace(64, 32, 32, '\0');
  const auto authority = bytes.substr(kHeaderBytes, static_cast<std::size_t>(binding_length));
  const auto canonical = bytes.substr(kHeaderBytes + static_cast<std::size_t>(binding_length));
  if (!hash_matches(header, read_digest(bytes.substr(64, 32))) ||
      !hash_matches(authority, read_digest(bytes.substr(96, 32))) ||
      !hash_matches(canonical, read_digest(bytes.substr(32, 32))) || !valid_authority(authority)) {
    return std::nullopt;
  }
  auto payload = restore_cycle(canonical);
  const auto record_hash = content_hash(bytes);
  if (!payload.has_value() || payload->install_id != install_id || !record_hash.has_value()) {
    return std::nullopt;
  }
  return QueuedCycle{
      .token =
          {
              .slot = slot,
              .device = file.info.st_dev,
              .inode = file.info.st_ino,
              .ordinal = get_integer(bytes, HeaderInteger::kOrdinal),
              .record_digest = *record_hash,
          },
      .payload = std::make_shared<const PreparedCycle>(std::move(*payload)),
      .authority = std::string(authority),
  };
}
bool same_entry(int directory, const std::string& name, const struct stat& owned) {
  struct stat entry{};
  return fstatat(directory, name.c_str(), &entry, AT_SYMLINK_NOFOLLOW) == 0 && S_ISREG(entry.st_mode) &&
         entry.st_uid == geteuid() && (entry.st_mode & 07777U) == 0600 && entry.st_dev == owned.st_dev &&
         entry.st_ino == owned.st_ino;
}
bool unlink_owned(int directory, const std::string& name, const struct stat& owned) {
  return same_entry(directory, name, owned) && unlinkat(directory, name.c_str(), 0) == 0;
}
std::expected<void, OutboxError> publish(int directory, std::string_view bytes, const std::string& name) {
  Descriptor temporary(open_file(directory, "publish.tmp", O_CREAT | O_EXCL));
  struct stat owned{};
  if (temporary.get() < 0 || !file_matches(directory, "publish.tmp", temporary.get(), owned)) {
    return std::unexpected(OutboxError::kInvalid);
  }
  const bool written = write_all(temporary.get(), bytes);
  const bool synced = written && fsync(temporary.get()) == 0;
  const bool closed = temporary.close();
  if (!written || !synced || !closed) {
    const bool cleaned = unlink_owned(directory, "publish.tmp", owned);
    const bool directory_synced = fsync(directory) == 0;
    return std::unexpected(cleaned && directory_synced ? OutboxError::kIo : OutboxError::kChanged);
  }
  const auto verified = read_file(directory, "publish.tmp", kMaxRecordBytes);
  if (!verified.has_value() || !verified->has_value() || (*verified)->bytes != bytes ||
      (*verified)->info.st_dev != owned.st_dev || (*verified)->info.st_ino != owned.st_ino) {
    return std::unexpected(OutboxError::kChanged);
  }
  if (linkat(directory, "publish.tmp", directory, name.c_str(), 0) != 0) {
    const int failure = errno;
    const bool cleaned = unlink_owned(directory, "publish.tmp", owned);
    const bool directory_synced = fsync(directory) == 0;
    if (!cleaned || !directory_synced) {
      return std::unexpected(OutboxError::kIo);
    }
    return std::unexpected(failure == EEXIST ? OutboxError::kBusy : OutboxError::kIo);
  }
  Descriptor linked(open_file(directory, name));
  struct stat linked_info{};
  if (linked.get() < 0 || !file_matches(directory, name, linked.get(), linked_info, 2) ||
      !same_entry(directory, "publish.tmp", owned) || !unlink_owned(directory, "publish.tmp", owned) ||
      fsync(linked.get()) != 0) {
    return std::unexpected(OutboxError::kIo);
  }
  const bool link_closed = linked.close();
  const bool directory_synced = fsync(directory) == 0;
  if (!link_closed || !directory_synced) {
    return std::unexpected(OutboxError::kIo);
  }
  return {};
}
std::optional<std::string> uuid_bytes(std::string_view uuid) {
  if (!canonical_uuid(uuid).has_value()) {
    return std::nullopt;
  }
  constexpr std::string_view kHex = "0123456789abcdef";
  std::string result;
  unsigned high = 0;
  bool half = false;
  for (const char byte : uuid) {
    if (byte == '-') {
      continue;
    }
    const auto digit = kHex.find(byte);
    if (digit == std::string_view::npos) {
      return std::nullopt;
    }
    if (!half) {
      high = static_cast<unsigned>(digit);
    } else {
      result += static_cast<char>((high << 4U) | digit);
    }
    half = !half;
  }
  return result;
}
std::string log_header(const QueuedCycle& record) {
  return std::string(kLogMagic) + digest_bytes(record.token.record_digest) + digest_bytes(record.payload->digest) +
         uuid_bytes(record.payload->batch_id).value_or(std::string{});
}
struct RetryState {
  unsigned stage = 0;
  bool ack = false;
};
std::optional<RetryState> decode_log(std::string_view bytes, std::string_view expected_header) {
  if (bytes.size() < 88 || bytes.size() > 144 || bytes.substr(0, 88) != expected_header) {
    return std::nullopt;
  }
  std::size_t offset = 88;
  while (offset < bytes.size() && bytes[offset] == kStageByte && offset < 104) {
    ++offset;
  }
  const auto stage = static_cast<unsigned>(offset - 88);
  if (offset == bytes.size()) {
    return RetryState{.stage = stage};
  }
  if (stage == 0 || bytes.size() != offset + 40 || bytes.substr(offset, 8) != kAckMagic ||
      !hash_matches(std::string(kAckMagic) + std::string(bytes.substr(0, offset)),
                    read_digest(bytes.substr(offset + 8, 32)))) {
    return std::nullopt;
  }
  return RetryState{.stage = stage, .ack = true};
}
std::expected<QueuedCycle, OutboxError> load_record(int directory, const RecordToken& token,
                                                    std::string_view install_id) {
  const auto file = read_file(directory, slot_name(token.slot, ".rec"), kMaxRecordBytes, 1, true);
  if (!file.has_value() || !file->has_value()) {
    return std::unexpected(OutboxError::kChanged);
  }
  auto record = decode_record(**file, token.slot, install_id);
  if (!record.has_value() || record->token != token) {
    return std::unexpected(OutboxError::kChanged);
  }
  return std::move(*record);
}
std::expected<void, OutboxError> cleanup(int directory, const QueuedCycle& record, const ReadFile& log) {
  const auto current = read_file(directory, slot_name(record.token.slot, ".rec"), kMaxRecordBytes);
  if (!current.has_value() || !current->has_value()) {
    return std::unexpected(OutboxError::kChanged);
  }
  if (std::cmp_not_equal((*current)->info.st_dev, record.token.device) ||
      std::cmp_not_equal((*current)->info.st_ino, record.token.inode) ||
      !hash_matches((*current)->bytes, record.token.record_digest)) {
    return std::unexpected(OutboxError::kChanged);
  }
  if (!unlink_owned(directory, slot_name(record.token.slot, ".rec"), (*current)->info) || fsync(directory) != 0 ||
      !unlink_owned(directory, slot_name(record.token.slot, ".try"), log.info) || fsync(directory) != 0) {
    return std::unexpected(OutboxError::kIo);
  }
  return {};
}
bool known_names(int directory) {
  Descriptor copy(rasp_outbox_open(directory, ".", kDirectoryFlags, 0));
  if (copy.get() < 0) {
    return false;
  }
  DIR* const stream = fdopendir(copy.get());
  if (stream == nullptr) {
    return false;
  }
  static_cast<void>(copy.release());
  bool valid = true;
  unsigned count = 0;
  errno = 0;
  while (const char* entry_name = rasp_outbox_next_entry(stream)) {
    const std::string_view name(entry_name);
    if (name == "." || name == "..") {
      continue;
    }
    if (++count > 68) {
      valid = false;
      break;
    }
    if (name == "binding" || name == "queue.lock" || name == "sender.lock" || name == "publish.tmp") {
      continue;
    }
    bool slot = false;
    for (unsigned index = 0; index < kOutboxSlots; ++index) {
      slot = slot || name == slot_name(index, ".rec") || name == slot_name(index, ".try");
    }
    if (!slot) {
      valid = false;
      break;
    }
  }
  const bool read_ok = errno == 0;
  const bool closed = closedir(stream) == 0;
  return valid && read_ok && closed;
}
bool valid_binding(const ReadFile& file, std::string_view install_id) {
  const auto binding = parse_json(file.bytes, 256);
  if (!binding.has_value() || !keys_are(*binding, {"format", "provider_install_id"}) ||
      binding->get("format").unsigned_number() != 1) {
    return false;
  }
  const auto* identity = binding->get("provider_install_id").text();
  return identity != nullptr && *identity == install_id;
}
bool valid_linked_temporary(int directory, const ReadFile& temporary, std::string_view install_id) {
  unsigned matches = 0;
  for (unsigned slot = 0; slot < kOutboxSlots; ++slot) {
    if (same_entry(directory, slot_name(slot, ".rec"), temporary.info)) {
      if (!decode_record(temporary, slot, install_id).has_value()) {
        return false;
      }
      ++matches;
    }
  }
  if (same_entry(directory, "binding", temporary.info)) {
    if (!valid_binding(temporary, install_id)) {
      return false;
    }
    ++matches;
  }
  return matches == 1;
}
std::expected<void, OutboxError> recover_temporary(int directory, std::string_view install_id) {
  Descriptor descriptor(open_file(directory, "publish.tmp"));
  if (descriptor.get() < 0) {
    return errno == ENOENT ? std::expected<void, OutboxError>{} : std::unexpected(OutboxError::kInvalid);
  }
  struct stat info{};
  if (fstat(descriptor.get(), &info) != 0 || info.st_size < 0 || std::cmp_greater(info.st_size, kMaxRecordBytes)) {
    return std::unexpected(OutboxError::kInvalid);
  }
  const auto links = std::cmp_equal(info.st_nlink, 2) ? 2U : 1U;
  const auto temporary = read_file(directory, "publish.tmp", kMaxRecordBytes, links, true);
  if (!temporary.has_value() || !temporary->has_value()) {
    return std::unexpected(OutboxError::kInvalid);
  }
  if (links == 2) {
    if (!valid_linked_temporary(directory, **temporary, install_id)) {
      return std::unexpected(OutboxError::kInvalid);
    }
  } else if (!decode_record(**temporary, 0, install_id).has_value() && !valid_binding(**temporary, install_id)) {
    return std::unexpected(OutboxError::kInvalid);
  }
  if (!unlink_owned(directory, "publish.tmp", info) || fsync(descriptor.get()) != 0 || !descriptor.close() ||
      fsync(directory) != 0) {
    return std::unexpected(OutboxError::kIo);
  }
  return {};
}
template <typename Recognize>
std::expected<void, OutboxError> scan_orphan(int directory, unsigned slot, const std::optional<ReadFile>& log,
                                             OutboxScan& scan, const Recognize& recognize) {
  if (log.has_value()) {
    const auto& bytes = log->bytes;
    const auto retry = bytes.size() >= 88 ? decode_log(bytes, std::string_view(bytes).substr(0, 88)) : std::nullopt;
    if (retry.has_value() && retry->ack && bytes.starts_with(kLogMagic)) {
      recognize(slot, read_digest(std::string_view(bytes).substr(8, 32)));
      if (!unlink_owned(directory, slot_name(slot, ".try"), log->info) || fsync(directory) != 0) {
        return std::unexpected(OutboxError::kIo);
      }
    } else {
      ++scan.held;
      ++scan.occupied;
    }
  }
  return {};
}
template <typename Recognize>
std::expected<void, OutboxError> scan_slot(int directory, unsigned slot, std::string_view install_id, OutboxScan& scan,
                                           std::set<std::uint64_t>& ordinals, const Recognize& recognize) {
  const auto file = read_file(directory, slot_name(slot, ".rec"), kMaxRecordBytes);
  const auto log = read_file(directory, slot_name(slot, ".try"), 144, 1, true);
  if (!file.has_value() || !log.has_value()) {
    return std::unexpected(OutboxError::kInvalid);
  }
  if (!file->has_value()) {
    return scan_orphan(directory, slot, *log, scan, recognize);
  }
  ++scan.occupied;
  scan.bytes += (*file)->bytes.size();
  auto record = decode_record(**file, slot, install_id);
  if (!record.has_value() || !ordinals.insert(record->token.ordinal).second) {
    ++scan.held;
    return {};
  }
  if (log->has_value()) {
    const auto retry = decode_log((*log)->bytes, log_header(*record));
    if (!retry.has_value()) {
      ++scan.held;
      return {};
    }
    record->stage = retry->stage;
    record->acknowledged = retry->ack;
  }
  if (record->acknowledged) {
    recognize(slot, record->token.record_digest);
    if (!log->has_value()) {
      return std::unexpected(OutboxError::kInvalid);
    }
    const auto removed = cleanup(directory, *record, **log);
    if (!removed.has_value()) {
      return std::unexpected(removed.error());
    }
    --scan.occupied;
    scan.bytes -= (*file)->bytes.size();
    return {};
  }
  scan.records.push_back(std::move(*record));
  return {};
}
template <typename Recognize>
std::expected<OutboxScan, OutboxError> scan_locked(int directory, std::string_view install_id,
                                                   const Recognize& recognize) {
  if (!known_names(directory)) {
    return std::unexpected(OutboxError::kInvalid);
  }
  const auto recovered = recover_temporary(directory, install_id);
  if (!recovered.has_value()) {
    return std::unexpected(recovered.error());
  }
  OutboxScan scan;
  std::set<std::uint64_t> ordinals;
  for (unsigned slot = 0; slot < kOutboxSlots; ++slot) {
    const auto result = scan_slot(directory, slot, install_id, scan, ordinals, recognize);
    if (!result.has_value()) {
      return std::unexpected(result.error());
    }
  }
  if (scan.bytes > kOutboxBytes) {
    return std::unexpected(OutboxError::kFull);
  }
  std::ranges::sort(scan.records, {}, [](const QueuedCycle& item) { return item.token.ordinal; });
  return scan;
}
std::expected<void, OutboxError> initialize_binding(int directory, std::string_view install_id) {
  const auto binding = read_file(directory, "binding", 256, 1, true);
  if (!binding.has_value()) {
    return std::unexpected(binding.error());
  }
  const auto expected_binding = canonical_json(JsonValue(JsonValue::Object{
                                                   {"format", JsonValue(std::uint64_t{1})},
                                                   {"provider_install_id", JsonValue(install_id)},
                                               }),
                                               256);
  if (!expected_binding.has_value()) {
    return std::unexpected(OutboxError::kInvalid);
  }
  if (!binding->has_value()) {
    for (unsigned slot = 0; slot < kOutboxSlots; ++slot) {
      for (const auto* const suffix : {".rec", ".try"}) {
        struct stat existing{};
        if (fstatat(directory, slot_name(slot, suffix).c_str(), &existing, AT_SYMLINK_NOFOLLOW) == 0 ||
            errno != ENOENT) {
          return std::unexpected(OutboxError::kIdentityMismatch);
        }
      }
    }
    const auto saved = publish(directory, *expected_binding, "binding");
    if (!saved.has_value()) {
      return std::unexpected(saved.error());
    }
  } else if ((*binding)->bytes != *expected_binding) {
    return std::unexpected(OutboxError::kIdentityMismatch);
  }
  return {};
}
std::expected<RecordToken, OutboxError> publish_record(int directory, const std::string& bytes,
                                                       std::string_view install_id) {
  for (unsigned slot = 0; slot < kOutboxSlots; ++slot) {
    struct stat entry{};
    if (fstatat(directory, slot_name(slot, ".rec").c_str(), &entry, AT_SYMLINK_NOFOLLOW) == 0) {
      continue;
    }
    if (errno != ENOENT) {
      return std::unexpected(OutboxError::kIo);
    }
    const auto saved = publish(directory, bytes, slot_name(slot, ".rec"));
    if (!saved.has_value()) {
      return std::unexpected(saved.error());
    }
    const auto file = read_file(directory, slot_name(slot, ".rec"), kMaxRecordBytes, 1, true);
    if (!file.has_value() || !file->has_value()) {
      return std::unexpected(OutboxError::kIo);
    }
    const auto record = decode_record(**file, slot, install_id);
    if (!record.has_value()) {
      return std::unexpected(OutboxError::kIo);
    }
    return record->token;
  }
  return std::unexpected(OutboxError::kFull);
}
std::expected<void, OutboxError> append_reservation(int directory, const std::string& name,
                                                    const std::optional<ReadFile>& log, const std::string& bytes,
                                                    unsigned stage) {
  if (stage < 16 || !log.has_value()) {
    Descriptor file(open_file(directory, name, log.has_value() ? 0 : O_CREAT | O_EXCL));
    struct stat info{};
    if (file.get() < 0 || !file_matches(directory, name, file.get(), info)) {
      return std::unexpected(OutboxError::kInvalid);
    }
    if (log.has_value() && (!same_entry(directory, name, log->info) || info.st_dev != log->info.st_dev ||
                            info.st_ino != log->info.st_ino || std::cmp_not_equal(info.st_size, bytes.size()))) {
      return std::unexpected(OutboxError::kChanged);
    }
    if (!log.has_value() && !write_all(file.get(), bytes)) {
      return std::unexpected(OutboxError::kIo);
    }
    if (stage < 16 && !write_all(file.get(), std::string_view(&kStageByte, 1), bytes.size())) {
      return std::unexpected(OutboxError::kIo);
    }
    const bool synced = fsync(file.get()) == 0;
    const bool closed = file.close();
    if (!synced || !closed || fsync(directory) != 0) {
      return std::unexpected(OutboxError::kIo);
    }
  }
  return {};
}
std::expected<void, OutboxError> mark_acknowledged(int directory, const std::string& name,
                                                   std::expected<std::optional<ReadFile>, OutboxError>& log,
                                                   bool acknowledged) {
  if (!log.has_value() || !log->has_value()) {
    return std::unexpected(OutboxError::kInvalid);
  }
  if (!acknowledged) {
    const auto hash = content_hash(std::string(kAckMagic) + (*log)->bytes);
    if (!hash.has_value()) {
      return std::unexpected(OutboxError::kIo);
    }
    const std::string tombstone = std::string(kAckMagic) + digest_bytes(*hash);
    Descriptor file(open_file(directory, name));
    struct stat info{};
    if (file.get() < 0 || !file_matches(directory, name, file.get(), info) ||
        !same_entry(directory, name, (*log)->info) || !write_all(file.get(), tombstone, (*log)->bytes.size())) {
      return std::unexpected(OutboxError::kIo);
    }
    const bool synced = fsync(file.get()) == 0;
    const bool closed = file.close();
    if (!synced || !closed || fsync(directory) != 0) {
      return std::unexpected(OutboxError::kIo);
    }
    log = read_file(directory, name, 144, 1, true);
    if (!log.has_value() || !log->has_value()) {
      return std::unexpected(OutboxError::kIo);
    }
  }
  if (!log.has_value() || !log->has_value()) {
    return std::unexpected(OutboxError::kInvalid);
  }
  return {};
}
}  // namespace
Outbox::Outbox(int provider_directory, std::string install_id)
    : provider_directory_(provider_directory), install_id_(std::move(install_id)) {}
Outbox::~Outbox() { static_cast<void>(close()); }
void Outbox::recognize(unsigned slot, const Digest& record_digest) {
  auto& previous = std::span{recognized_}[slot];
  if (previous.has_value() && *previous == record_digest) {
    return;
  }
  previous = record_digest;
  if (acknowledged_count_ != UINT64_MAX) {
    ++acknowledged_count_;
  }
}
std::expected<void, OutboxError> Outbox::close() {
  const int sender = std::exchange(sender_lock_, -1);
  const int directory = std::exchange(directory_, -1);
  const bool sender_closed = sender < 0 || ::close(sender) == 0;
  const bool directory_closed = directory < 0 || ::close(directory) == 0;
  return sender_closed && directory_closed ? std::expected<void, OutboxError>{} : std::unexpected(OutboxError::kIo);
}
std::expected<void, OutboxError> Outbox::initialize() {
  if (directory_ >= 0) {
    return {};
  }
  if (canonical_uuid(install_id_) != install_id_) {
    return std::unexpected(OutboxError::kIdentityMismatch);
  }
  if (!private_directory(provider_directory_)) {
    return std::unexpected(OutboxError::kInvalid);
  }
  if (mkdirat(provider_directory_, "cycle_outbox_v1", static_cast<mode_t>(0700)) != 0 && errno != EEXIST) {
    return std::unexpected(OutboxError::kIo);
  }
  Descriptor directory(rasp_outbox_open(provider_directory_, "cycle_outbox_v1", kDirectoryFlags, 0));
  struct stat info{};
  struct stat entry{};
  if (directory.get() < 0 || !private_directory(directory.get()) || fstat(directory.get(), &info) != 0 ||
      fstatat(provider_directory_, "cycle_outbox_v1", &entry, AT_SYMLINK_NOFOLLOW) != 0 || !S_ISDIR(entry.st_mode) ||
      info.st_dev != entry.st_dev || info.st_ino != entry.st_ino || fsync(provider_directory_) != 0) {
    return std::unexpected(OutboxError::kInvalid);
  }
  const auto acquired = lock_file(directory.get(), "queue.lock");
  if (!acquired.has_value()) {
    return std::unexpected(acquired.error());
  }
  Descriptor lock(*acquired);
  if (!known_names(directory.get())) {
    return std::unexpected(OutboxError::kInvalid);
  }
  const auto recovered = recover_temporary(directory.get(), install_id_);
  if (!recovered.has_value()) {
    return std::unexpected(recovered.error());
  }
  const auto bound = initialize_binding(directory.get(), install_id_);
  if (!bound.has_value()) {
    return std::unexpected(bound.error());
  }
  if (!lock.close() || fsync(directory.get()) != 0) {
    return std::unexpected(OutboxError::kIo);
  }
  directory_ = directory.release();
  return {};
}
std::expected<void, OutboxError> Outbox::elect_sender() {
  if (directory_ < 0) {
    return std::unexpected(OutboxError::kUnavailable);
  }
  if (sender_lock_ >= 0) {
    return {};
  }
  const auto acquired = lock_file(directory_, "sender.lock");
  if (!acquired.has_value()) {
    return std::unexpected(acquired.error());
  }
  sender_lock_ = *acquired;
  return {};
}
std::expected<OutboxScan, OutboxError> Outbox::scan() {
  if (directory_ < 0) {
    return std::unexpected(OutboxError::kUnavailable);
  }
  const auto acquired = lock_file(directory_, "queue.lock");
  if (!acquired.has_value()) {
    return std::unexpected(acquired.error());
  }
  Descriptor lock(*acquired);
  auto result =
      scan_locked(directory_, install_id_, [this](unsigned slot, const Digest& digest) { recognize(slot, digest); });
  if (!lock.close()) {
    return std::unexpected(OutboxError::kIo);
  }
  return result;
}
std::expected<RecordToken, OutboxError> Outbox::persist(const PreparedCycle& payload, std::string_view authority) {
  if (directory_ < 0) {
    return std::unexpected(OutboxError::kUnavailable);
  }
  if (payload.install_id != install_id_) {
    return std::unexpected(OutboxError::kIdentityMismatch);
  }
  const auto acquired = lock_file(directory_, "queue.lock");
  if (!acquired.has_value()) {
    return std::unexpected(acquired.error());
  }
  Descriptor lock(*acquired);
  const auto state =
      scan_locked(directory_, install_id_, [this](unsigned slot, const Digest& digest) { recognize(slot, digest); });
  if (!state.has_value()) {
    return std::unexpected(state.error());
  }
  for (const auto& record : state->records) {
    if (record.payload->batch_id == payload.batch_id) {
      if (record.payload->canonical != payload.canonical || record.authority != authority) {
        return std::unexpected(OutboxError::kChanged);
      }
      if (!load_record(directory_, record.token, install_id_).has_value() || !lock.close()) {
        return std::unexpected(OutboxError::kIo);
      }
      return record.token;
    }
  }
  if (state->held != 0) {
    return std::unexpected(OutboxError::kInvalid);
  }
  if (state->occupied >= kOutboxSlots) {
    return std::unexpected(OutboxError::kFull);
  }
  const std::uint64_t ordinal = state->records.empty() ? 1 : state->records.back().token.ordinal + 1;
  if (ordinal == 0) {
    return std::unexpected(OutboxError::kOverflow);
  }
  const auto bytes = record_bytes(payload, authority, ordinal);
  if (!bytes.has_value()) {
    return std::unexpected(OutboxError::kInvalid);
  }
  if (bytes->size() > kMaxRecordBytes || bytes->size() > kOutboxBytes - state->bytes) {
    return std::unexpected(OutboxError::kFull);
  }
  const auto published = publish_record(directory_, *bytes, install_id_);
  if (!lock.close()) {
    return std::unexpected(OutboxError::kIo);
  }
  return published;
}
std::expected<unsigned, OutboxError> Outbox::reserve(const RecordToken& token) {
  if (directory_ < 0 || token.slot >= kOutboxSlots) {
    return std::unexpected(OutboxError::kUnavailable);
  }
  const auto acquired = lock_file(directory_, "queue.lock");
  if (!acquired.has_value()) {
    return std::unexpected(acquired.error());
  }
  Descriptor lock(*acquired);
  const auto record = load_record(directory_, token, install_id_);
  if (!record.has_value()) {
    return std::unexpected(record.error());
  }
  const auto name = slot_name(token.slot, ".try");
  const auto log = read_file(directory_, name, 144, 1, true);
  if (!log.has_value()) {
    return std::unexpected(log.error());
  }
  std::string const bytes = log->has_value() ? (*log)->bytes : log_header(*record);
  const auto retry = decode_log(bytes, log_header(*record));
  if (!retry.has_value() || retry->ack) {
    return std::unexpected(OutboxError::kInvalid);
  }
  const auto appended = append_reservation(directory_, name, *log, bytes, retry->stage);
  if (!appended.has_value()) {
    return std::unexpected(appended.error());
  }
  if (!lock.close()) {
    return std::unexpected(OutboxError::kIo);
  }
  return std::min(retry->stage + 1, 16U);
}
std::expected<void, OutboxError> Outbox::acknowledge(const RecordToken& token) {
  if (directory_ < 0 || token.slot >= kOutboxSlots) {
    return std::unexpected(OutboxError::kUnavailable);
  }
  const auto acquired = lock_file(directory_, "queue.lock");
  if (!acquired.has_value()) {
    return std::unexpected(acquired.error());
  }
  Descriptor lock(*acquired);
  const auto record = load_record(directory_, token, install_id_);
  if (!record.has_value()) {
    return std::unexpected(record.error());
  }
  const auto name = slot_name(token.slot, ".try");
  auto log = read_file(directory_, name, 144, 1, true);
  if (!log.has_value() || !log->has_value()) {
    return std::unexpected(OutboxError::kInvalid);
  }
  const auto retry = decode_log((*log)->bytes, log_header(*record));
  if (!retry.has_value() || retry->stage == 0) {
    return std::unexpected(OutboxError::kInvalid);
  }
  const auto marked = mark_acknowledged(directory_, name, log, retry->ack);
  if (!marked.has_value()) {
    return marked;
  }
  if (!log.has_value() || !log->has_value()) {
    return std::unexpected(OutboxError::kInvalid);
  }
  const auto durable_ack = decode_log((*log)->bytes, log_header(*record));
  if (!durable_ack.has_value() || !durable_ack->ack) {
    return std::unexpected(OutboxError::kInvalid);
  }
  recognize(token.slot, token.record_digest);
  const auto removed = cleanup(directory_, *record, **log);
  if (!removed.has_value()) {
    return removed;
  }
  if (!lock.close()) {
    return std::unexpected(OutboxError::kIo);
  }
  return {};
}
}  // namespace rasp::plugins::reporting
