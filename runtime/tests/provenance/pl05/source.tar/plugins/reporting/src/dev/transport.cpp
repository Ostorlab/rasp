#include "reporting/transport_result.h"
/// The development transport, which a development machine builds the plugin with, only for the tests: it sends nothing,
/// so every post fails.

#include <string_view>

#include "config.h"
#include "transport.h"

namespace rasp::plugins::reporting {

TransportResult post(const Config& /*config*/, std::string_view /*body*/, Cancellation cancellation) noexcept {
  return cancellation.requested() ? TransportResult::kCancelled : TransportResult::kConnectFailed;
}

}  // namespace rasp::plugins::reporting
