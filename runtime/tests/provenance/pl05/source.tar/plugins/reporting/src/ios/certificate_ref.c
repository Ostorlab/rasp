#include "certificate_ref.h"

#include <CoreFoundation/CFBase.h>
#include <Security/SecBase.h>
#include <Security/SecCertificate.h>
#include <stddef.h>

SecCertificateRef rasp_reporting_retain_certificate(CFTypeRef value) {
  if (value == NULL || CFGetTypeID(value) != SecCertificateGetTypeID()) {
    return NULL;
  }
  // CoreFoundation values are const void*, while Security's immutable certificates use a non-const opaque handle.
  return (SecCertificateRef)CFRetain(value);
}
