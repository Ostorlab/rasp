#include "peer_key.h"

#include <algorithm>
#include <array>
#include <bit>
#include <cstddef>
#include <optional>
#include <string>
#include <string_view>

#include "hash.h"
#include "security_profile.h"

namespace rasp::plugins::reporting {
namespace {
constexpr std::string_view kRsa("\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x01\x05\x00", 13);
constexpr std::string_view kEc256("\x06\x07\x2a\x86\x48\xce\x3d\x02\x01\x06\x08\x2a\x86\x48\xce\x3d\x03\x01\x07", 19);
constexpr std::string_view kEc384("\x06\x07\x2a\x86\x48\xce\x3d\x02\x01\x06\x05\x2b\x81\x04\x00\x22", 16);
struct Element {
  std::string_view whole;
  std::string_view content;
  std::string_view rest;
};
std::optional<Element> take(std::string_view value, unsigned tag) {
  if (value.size() < 2 || static_cast<unsigned char>(value[0]) != tag) {
    return std::nullopt;
  }
  std::size_t header = 2;
  std::size_t length = static_cast<unsigned char>(value[1]);
  if ((length & 128U) != 0) {
    const std::size_t count = length & 127U;
    if (count == 0 || count > 2 || value.size() - 2 < count || value[2] == 0) {
      return std::nullopt;
    }
    length = 0;
    for (std::size_t index = 0; index < count; ++index) {
      length = (length << 8U) | static_cast<unsigned char>(value[2 + index]);
    }
    if (length < 128 || (count == 2 && length < 256)) {
      return std::nullopt;
    }
    header += count;
  }
  if (length > value.size() - header) {
    return std::nullopt;
  }
  return Element{
      .whole = value.substr(0, header + length),
      .content = value.substr(header, length),
      .rest = value.substr(header + length),
  };
}
std::optional<std::string_view> positive_integer(const Element& value) {
  auto bytes = value.content;
  if (bytes.empty() || (static_cast<unsigned char>(bytes[0]) & 128U) != 0) {
    return std::nullopt;
  }
  if (bytes[0] == 0) {
    if (bytes.size() == 1 || (static_cast<unsigned char>(bytes[1]) & 128U) == 0) {
      return std::nullopt;
    }
    bytes.remove_prefix(1);
  }
  return bytes;
}
std::optional<std::string> key_algorithm(const Element& spki) {
  const auto algorithm = take(spki.content, 0x30);
  const auto bits = algorithm.has_value() ? take(algorithm->rest, 0x03) : std::nullopt;
  if (!algorithm.has_value() || !bits.has_value() || !bits->rest.empty() || bits->content.empty() ||
      bits->content[0] != 0) {
    return std::nullopt;
  }
  const auto key = bits->content.substr(1);
  if (algorithm->content == kEc256 || algorithm->content == kEc384) {
    const bool p256 = algorithm->content == kEc256;
    return key.size() == (p256 ? 65 : 97) && key[0] == 4 ? std::optional<std::string>(p256 ? "ec-p256" : "ec-p384")
                                                         : std::nullopt;
  }
  if (algorithm->content != kRsa) {
    return std::nullopt;
  }
  const auto sequence = take(key, 0x30);
  const auto modulus = sequence.has_value() ? take(sequence->content, 0x02) : std::nullopt;
  const auto exponent = modulus.has_value() ? take(modulus->rest, 0x02) : std::nullopt;
  if (!sequence.has_value() || !sequence->rest.empty() || !modulus.has_value() || !exponent.has_value() ||
      !exponent->rest.empty()) {
    return std::nullopt;
  }
  const auto number = positive_integer(*modulus);
  const auto power = positive_integer(*exponent);
  if (!number.has_value() || !power.has_value() || power->size() > 8 ||
      (static_cast<unsigned char>(power->back()) & 1U) == 0 ||
      (power->size() == 1 && static_cast<unsigned char>((*power)[0]) < 3)) {
    return std::nullopt;
  }
  const auto size =
      ((number->size() - 1) * 8) + static_cast<std::size_t>(std::bit_width(static_cast<unsigned char>((*number)[0])));
  if (size != 2048 && size != 3072 && size != 4096) {
    return std::nullopt;
  }
  return "rsa-" + std::to_string(size);
}
std::optional<std::string> element(unsigned char tag, std::string_view content) {
  if (content.size() > 1024) {
    return std::nullopt;
  }
  std::string result(1, static_cast<char>(tag));
  if (content.size() < 128) {
    result += static_cast<char>(content.size());
  } else if (content.size() < 256) {
    result += static_cast<char>(0x81);
    result += static_cast<char>(content.size());
  } else {
    result += static_cast<char>(0x82);
    result += static_cast<char>(content.size() >> 8U);
    result += static_cast<char>(content.size() & 255U);
  }
  result += content;
  return result;
}
}  // namespace
std::optional<PeerKey> certificate_key(std::string_view certificate) {
  if (certificate.empty() || certificate.size() > 16384) {
    return std::nullopt;
  }
  const auto outer = take(certificate, 0x30);
  const auto tbs = outer.has_value() ? take(outer->content, 0x30) : std::nullopt;
  const auto signature_algorithm = tbs.has_value() ? take(tbs->rest, 0x30) : std::nullopt;
  const auto signature = signature_algorithm.has_value() ? take(signature_algorithm->rest, 0x03) : std::nullopt;
  if (!outer.has_value() || !outer->rest.empty() || !tbs.has_value() || !signature.has_value() ||
      !signature->rest.empty()) {
    return std::nullopt;
  }
  auto fields = tbs->content;
  if (!fields.empty() && static_cast<unsigned char>(fields[0]) == 0xa0) {
    const auto version = take(fields, 0xa0);
    const auto number = version.has_value() ? take(version->content, 0x02) : std::nullopt;
    if (!number.has_value() || !number->rest.empty() || number->content.size() != 1 || number->content[0] < 0 ||
        number->content[0] > 2) {
      return std::nullopt;
    }
    fields = version->rest;
  }
  constexpr std::array<unsigned, 5> kFields{0x02, 0x30, 0x30, 0x30, 0x30};
  for (const auto tag : kFields) {
    const auto field = take(fields, tag);
    if (!field.has_value()) {
      return std::nullopt;
    }
    fields = field->rest;
  }
  const auto spki = take(fields, 0x30);
  const auto algorithm = spki.has_value() ? key_algorithm(*spki) : std::nullopt;
  if (!spki.has_value() || spki->whole.size() > 1024 || !algorithm.has_value()) {
    return std::nullopt;
  }
  return PeerKey{.algorithm = *algorithm, .spki = std::string(spki->whole)};
}
std::optional<std::string> canonical_spki(PublicKeyExport exported) {
  const auto [algorithm, exported_key] = exported;
  if (exported_key.empty() || exported_key.size() > 1024) {
    return std::nullopt;
  }
  std::string_view identifier;
  if (algorithm == "ec-p256") {
    identifier = kEc256;
  } else if (algorithm == "ec-p384") {
    identifier = kEc384;
  } else if (algorithm == "rsa-2048" || algorithm == "rsa-3072" || algorithm == "rsa-4096") {
    identifier = kRsa;
  }
  if (identifier.empty()) {
    return std::nullopt;
  }
  const auto named = element(0x30, identifier);
  const auto bits = element(0x03, std::string(1, '\0') + std::string(exported_key));
  if (!named.has_value() || !bits.has_value()) {
    return std::nullopt;
  }
  auto spki = element(0x30, *named + *bits);
  if (!spki.has_value() || spki->size() > 1024) {
    return std::nullopt;
  }
  const auto parsed = take(*spki, 0x30);
  if (!parsed.has_value() || key_algorithm(*parsed) != algorithm) {
    return std::nullopt;
  }
  return spki;
}
bool matches_leaf(const SecurityProfile& profile, std::string_view certificate) {
  if (!profile.pinned) {
    return true;
  }
  const auto key = certificate_key(certificate);
  const auto digest = key.has_value() ? content_hash(key->spki) : std::nullopt;
  if (!key.has_value() || !digest.has_value()) {
    return false;
  }
  return std::ranges::any_of(profile.pins,
                             [&](const Pin& pin) { return pin.algorithm == key->algorithm && pin.digest == *digest; });
}
}  // namespace rasp::plugins::reporting
