/// Actual single-owner cycle worker, also driven synchronously with external I/O/clock seams in native tests.
#pragma once
#include <array>
#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <expected>
#include <memory>
#include <mutex>
#include <optional>

#include "config.h"
#include "outbox.h"
#include "rasp/cycle.h"
#include "rasp/private_storage.h"
#include "reporting/cancellation.h"
#include "reporting/delivery.h"
#include "sender.h"

namespace rasp::plugins::reporting {
using StorageFunction = std::expected<PrivateStorage, StorageError> (*)();
using ClockFunction = std::int64_t (*)();
/// Worker monotonic nanoseconds, or -1 on clock failure.
[[nodiscard]] std::int64_t delivery_clock();
/// Rate-bounded exponential base, including the saturated live stage16.
[[nodiscard]] std::uint64_t backoff_seconds(unsigned stage);
class CycleDelivery {
 public:
  CycleDelivery(Config config, PostFunction post, StorageFunction acquire = acquire_private_storage,
                ClockFunction clock = delivery_clock);
  ~CycleDelivery() = default;
  CycleDelivery(const CycleDelivery&) = delete;
  CycleDelivery& operator=(const CycleDelivery&) = delete;
  CycleDelivery(CycleDelivery&&) = delete;
  CycleDelivery& operator=(CycleDelivery&&) = delete;
  /// Runtime callback: only try-lock and retain owning immutable pointer; rejects newest on capacity/contention.
  [[nodiscard]] bool admit(std::shared_ptr<const CycleSnapshot> snapshot);
  /// One worker iteration, with bounded slots/I/O and no Context dependency; never invoke concurrently.
  void step();
  /// Detached process-lifetime worker; repeated calls recover a failed thread creation without new plugin init.
  [[nodiscard]] bool start();
  /// Stops future rounds/wakes waits without joining a possibly stalled kernel filesystem call.
  void stop();
  [[nodiscard]] DeliveryHealth health() const;

 private:
  struct Timer {
    std::optional<RecordToken> token;
    std::int64_t due = 0;
    unsigned stage = 0;
    bool dns_wait = false;
    bool authority_held = false;
  };
  struct Counters {
    std::atomic<std::uint64_t> volatile_pending{0}, durable_pending{0}, held_records{0}, authority_held_records{0},
        dns_fallback_held_records{0}, backoff_saturated_records{0};
    std::atomic<std::uint64_t> admission_dropped{0}, serialization_dropped{0}, publication_acknowledged{0},
        https_attempted{0}, dns_attempted{0};
    std::atomic<bool> counter_lower_bound{false}, persistence_uncertain{false};
    std::atomic<DeliveryState> state{DeliveryState::kVolatilePending};
    std::atomic<DeliveryFailure> failure{DeliveryFailure::kNone};
    std::atomic<TransportResult> last_transport_result{TransportResult::kPublicationUnconfirmed};
  };
  void increment(std::atomic<std::uint64_t>& counter, std::uint64_t amount = 1);
  void fail(DeliveryFailure failure, bool held = false);
  [[nodiscard]] bool storage(std::int64_t now, bool check_provider);
  void persist_front(std::int64_t now);
  [[nodiscard]] std::optional<std::string> current_authority() const;
  void send(const QueuedCycle& record, Timer& timer, std::int64_t now);
  void refuse_dns(TransportResult status);
  void offer_dns(const QueuedCycle& record, Timer& timer, TransportResult result);
  [[nodiscard]] bool ready(const QueuedCycle& record, const std::optional<std::string>& current, std::int64_t now);
  [[nodiscard]] bool elect(std::int64_t now);
  void recognize_acknowledged();
  std::uint64_t acknowledged_seen_ = 0;
  void run();
  Config config_;
  PostFunction post_;
  StorageFunction acquire_;
  ClockFunction clock_;
  std::mutex admission_mutex_;
  std::array<std::shared_ptr<const CycleSnapshot>, 4> fifo_{};
  std::size_t head_ = 0;
  std::size_t count_ = 0;
  std::optional<PreparedCycle> prepared_;
  std::string prepared_authority_;
  std::optional<PrivateStorage> storage_;
  std::unique_ptr<Outbox> outbox_;
  std::array<Timer, kOutboxSlots> timers_{};
  FileDevice provider_device_ = 0;
  FileInode provider_inode_ = 0;
  bool leader_ = false;
  bool identity_held_ = false;
  std::int64_t last_now_ = -1;
  std::int64_t next_start_ = 0;
  std::int64_t resource_due_ = 0;
  unsigned resource_stage_ = 0;
  std::int64_t front_due_ = 0;
  unsigned front_stage_ = 0;
  Counters counters_;
  std::atomic<bool> running_{false};
  CancellationSource stopped_ = CancellationSource::create();
  std::mutex wake_mutex_;
  std::condition_variable wake_;
};
/// Registers the process-lifetime instance for diagnostics. The plugin owns its lifetime.
void set_cycle_delivery(CycleDelivery* delivery);
}  // namespace rasp::plugins::reporting
