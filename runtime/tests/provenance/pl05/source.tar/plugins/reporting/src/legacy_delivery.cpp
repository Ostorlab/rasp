#include "legacy_delivery.h"

#include <cstddef>
#include <mutex>
#include <optional>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "json.h"
#include "rasp/observation.h"
#include "reporting/transport_result.h"
#include "reporting/undelivered_run.h"

namespace rasp::plugins::reporting {
namespace {
bool spend(std::size_t& remaining, std::size_t count, std::size_t unit = 1) {
  if (count > remaining / unit) {
    return false;
  }
  remaining -= count * unit;
  return true;
}
std::optional<AuthorizedUndeliveredRun> compact_envelope(AuthorizedUndeliveredRun run) {
  auto owned = std::move(run);
  auto observations = compact_legacy_run(std::move(owned.observations));
  if (!observations.has_value()) {
    return std::nullopt;
  }
  owned.observations = std::move(*observations);
  return owned;
}
}  // namespace
std::optional<std::vector<Observation>> compact_legacy_run(std::vector<Observation> run) {
  const auto owned = std::move(run);
  std::size_t remaining = kMaxRequestSize - kOtherFieldsRoom;
  if (!spend(remaining, owned.size(), sizeof(Observation))) {
    return std::nullopt;
  }
  for (const auto& observation : owned) {
    if (!spend(remaining, observation.signal.size()) || !spend(remaining, observation.source.size())) {
      return std::nullopt;
    }
    if (const auto* text = std::get_if<std::string>(&observation.value); text != nullptr) {
      if (!spend(remaining, text->size())) {
        return std::nullopt;
      }
    } else if (const auto* texts = std::get_if<std::vector<std::string>>(&observation.value); texts != nullptr) {
      if (!spend(remaining, texts->size(), sizeof(std::string))) {
        return std::nullopt;
      }
      for (const auto& item : *texts) {
        if (!spend(remaining, item.size())) {
          return std::nullopt;
        }
      }
    }
  }
  // Copy contents into new storage; never inherit an arbitrarily large caller vector/string capacity.
  return std::vector<Observation>(owned.begin(), owned.end());
}
LegacyDnsAttempt::LegacyDnsAttempt(AuthorizedUndeliveredRun run) : original_(compact_envelope(std::move(run))) {
  if (!original_.has_value()) {
    health_.state = LegacyDnsState::kTooLarge;
  }
}
const AuthorizedUndeliveredRun* LegacyDnsAttempt::original() const {
  return original_.has_value() ? &*original_ : nullptr;
}
LegacyDnsHealth LegacyDnsAttempt::health() const {
  const std::scoped_lock lock(mutex_);
  return health_;
}
void LegacyDnsAttempt::start_query() {
  const std::scoped_lock lock(mutex_);
  health_.state = LegacyDnsState::kSending;
  ++health_.queries_started;
}
void LegacyDnsAttempt::complete_query() {
  const std::scoped_lock lock(mutex_);
  ++health_.queries_completed;
}
void LegacyDnsAttempt::finish(LegacyDnsState state, TransportResult reason) {
  const std::scoped_lock lock(mutex_);
  health_.state = state;
  health_.reason = reason;
}
}  // namespace rasp::plugins::reporting
