#include "trust.h"

#include <Availability.h>
#include <AvailabilityMacros.h>
#include <Block.h>
#include <CoreFoundation/CFArray.h>
#include <CoreFoundation/CFBase.h>
#include <CoreFoundation/CFData.h>
#include <CoreFoundation/CFDictionary.h>
#include <CoreFoundation/CFError.h>
#include <CoreFoundation/CFNumber.h>
#include <CoreFoundation/CFString.h>
#include <MacTypes.h>
#include <Security/SecBase.h>
#include <Security/SecCertificate.h>
#include <Security/SecItem.h>
#include <Security/SecKey.h>
#include <Security/SecPolicy.h>
#include <Security/SecProtocolMetadata.h>
#include <Security/SecProtocolOptions.h>
#include <Security/SecProtocolTypes.h>
#include <Security/SecTrust.h>
#include <TargetConditionals.h>
#include <atomic>
#include <cstddef>
#include <dispatch/dispatch.h>
#include <memory>
#include <mutex>
#include <os/availability.h>
#include <span>
#include <string>
#include <type_traits>
#include <utility>

#include "certificate_ref.h"
#include "peer_key.h"
#include "reporting/transport_result.h"
#include "security_profile.h"
#ifdef RASP_REPORTING_TRANSPORT_TEST
#include <array>
#include <fstream>
#include <vector>

#include "transport_fixture.h"
#include "trust_fixture.h"
#endif

namespace rasp::plugins::reporting {
class IosVerification {
 public:
  IosVerification(sec_trust_t offered, sec_protocol_verify_complete_t completion)
      : completion_(Block_copy(completion)), trust_(sec_trust_copy_ref(offered)) {}
  IosVerification(const IosVerification&) = delete;
  IosVerification& operator=(const IosVerification&) = delete;
  IosVerification(IosVerification&&) = delete;
  IosVerification& operator=(IosVerification&&) = delete;
  ~IosVerification() {
    if (completion_ != nullptr) {
      Block_release(completion_);
    }
    if (trust_ != nullptr) {
      CFRelease(trust_);
    }
  }
  [[nodiscard]] SecTrustRef trust() const { return trust_; }
  [[nodiscard]] bool completed() const { return completed_.load(); }
  bool finish(bool accepted, std::atomic<bool>& verified) {
    if (completed_.exchange(true)) {
      return false;
    }
    verified.store(accepted);
    const auto block = std::exchange(completion_, nullptr);
    if (block != nullptr) {
      block(accepted);
      Block_release(block);
    }
    return true;
  }

 private:
  std::atomic<bool> completed_{false};
  sec_protocol_verify_complete_t completion_;
  SecTrustRef trust_;
};
namespace {
using Certificate = std::unique_ptr<std::remove_pointer_t<SecCertificateRef>, decltype(&CFRelease)>;
/// Return an owned leaf, independent of the copied chain's or trust's lifetime. Never inspect other certificates.
Certificate copy_leaf(SecTrustRef trust) {
  Certificate leaf(nullptr, CFRelease);
  if (trust == nullptr) {
    return leaf;
  }
  if (__builtin_available(iOS 15.0, macOS 12.0, *)) {
    const auto* const chain = SecTrustCopyCertificateChain(trust);
    if (chain == nullptr) {
      return leaf;
    }
    const auto* const value = CFArrayGetCount(chain) > 0 ? CFArrayGetValueAtIndex(chain, 0) : nullptr;
    leaf.reset(rasp_reporting_retain_certificate(value));
    CFRelease(chain);
    return leaf;
  }
#if (TARGET_OS_OSX && MAC_OS_X_VERSION_MIN_REQUIRED < 120000) || \
    (TARGET_OS_IOS && __IPHONE_OS_VERSION_MIN_REQUIRED < 150000)
  auto* const borrowed = SecTrustGetCertificateAtIndex(trust, 0);
  if (borrowed != nullptr) {
    static_cast<void>(CFRetain(borrowed));
    leaf.reset(borrowed);
  }
#endif
  return leaf;
}
std::atomic<bool>& evaluation_slot() {
  static std::atomic<bool> occupied{false};
  return occupied;
}
void fail(const std::shared_ptr<IosTrustState>& state, TransportResult reason) {
  auto expected = TransportResult::kPublicationUnconfirmed;
  static_cast<void>(state->failure.compare_exchange_strong(expected, reason));
}
std::string copy_data(CFDataRef data, std::size_t limit) {
  const auto count = data == nullptr ? 0 : CFDataGetLength(data);
  if (count <= 0 || std::cmp_greater(count, limit)) {
    return {};
  }
  const std::span<const UInt8> bytes(CFDataGetBytePtr(data), static_cast<std::size_t>(count));
  std::string result;
  result.reserve(bytes.size());
  for (const auto byte : bytes) {
    result += static_cast<char>(byte);
  }
  return result;
}
bool policies(SecTrustRef trust, const std::string& host) {
  CFArrayRef original = nullptr;
  if (SecTrustCopyPolicies(trust, &original) != errSecSuccess || original == nullptr) {
    return false;
  }
  auto* const combined = CFArrayCreateMutableCopy(kCFAllocatorDefault, 0, original);
  CFRelease(original);
  const auto* const hostname = CFStringCreateWithCString(kCFAllocatorDefault, host.c_str(), kCFStringEncodingASCII);
  const auto* const ssl = hostname == nullptr ? nullptr : SecPolicyCreateSSL(static_cast<Boolean>(true), hostname);
  if (hostname != nullptr) {
    CFRelease(hostname);
  }
  if (combined == nullptr || ssl == nullptr) {
    if (combined != nullptr) {
      CFRelease(combined);
    }
    if (ssl != nullptr) {
      CFRelease(ssl);
    }
    return false;
  }
  CFArrayAppendValue(combined, ssl);
  CFRelease(ssl);
  const bool accepted = SecTrustSetPolicies(trust, combined) == errSecSuccess;
  CFRelease(combined);
  return accepted;
}
#ifdef RASP_REPORTING_TRANSPORT_TEST
bool fixture_anchor(SecTrustRef trust) {
  const auto& file = transport_fixture().ca_file;
  if (file.empty()) {
    return true;
  }
  std::ifstream input(file, std::ios::binary | std::ios::ate);
  const auto size = input.tellg();
  if (size <= 0 || size > 16384) {
    return false;
  }
  input.seekg(0);
  std::string bytes(static_cast<std::size_t>(size), '\0');
  input.read(bytes.data(), size);
  if (!input) {
    return false;
  }
  std::vector<UInt8> certificate_bytes;
  certificate_bytes.reserve(bytes.size());
  for (const char byte : bytes) {
    certificate_bytes.push_back(static_cast<UInt8>(byte));
  }
  const auto* const data =
      CFDataCreate(kCFAllocatorDefault, certificate_bytes.data(), static_cast<CFIndex>(certificate_bytes.size()));
  auto* const certificate = data == nullptr ? nullptr : SecCertificateCreateWithData(kCFAllocatorDefault, data);
  if (data != nullptr) {
    CFRelease(data);
  }
  if (certificate == nullptr) {
    return false;
  }
  std::array<const void*, 1> values{certificate};
  const auto* const anchors = CFArrayCreate(kCFAllocatorDefault, values.data(), 1, &kCFTypeArrayCallBacks);
  const bool accepted = anchors != nullptr && SecTrustSetAnchorCertificates(trust, anchors) == errSecSuccess &&
                        SecTrustSetAnchorCertificatesOnly(trust, true) == errSecSuccess;
  if (anchors != nullptr) {
    CFRelease(anchors);
  }
  CFRelease(certificate);
  return accepted;
}
#endif
bool exported_matches(const PeerKey& parsed, CFDictionaryRef attributes, CFDataRef exported) {
  if (attributes == nullptr || exported == nullptr || CFDataGetLength(exported) <= 0 ||
      CFDataGetLength(exported) > 1024) {
    return false;
  }
  const auto* const type = CFDictionaryGetValue(attributes, kSecAttrKeyType);
  const auto* const size = CFDictionaryGetValue(attributes, kSecAttrKeySizeInBits);
  int bits = 0;
  if (type == nullptr || size == nullptr || CFGetTypeID(size) != CFNumberGetTypeID() ||
      CFNumberGetValue(static_cast<CFNumberRef>(size), kCFNumberIntType, &bits) == 0) {
    return false;
  }
  int expected = 4096;
  if (parsed.algorithm == "ec-p256") {
    expected = 256;
  } else if (parsed.algorithm == "ec-p384") {
    expected = 384;
  } else if (parsed.algorithm == "rsa-2048") {
    expected = 2048;
  } else if (parsed.algorithm == "rsa-3072") {
    expected = 3072;
  }
  const auto exported_bytes = copy_data(exported, 1024);
  const auto reconstructed = canonical_spki({.algorithm = parsed.algorithm, .key = exported_bytes});
  return reconstructed.has_value() && *reconstructed == parsed.spki && bits == expected &&
         CFEqual(type, parsed.algorithm.starts_with("rsa-") ? kSecAttrKeyTypeRSA : kSecAttrKeyTypeECSECPrimeRandom) !=
             0;
}
TransportResult leaf_status(SecTrustRef trust, const SecurityProfile& profile) {
  if (!profile.pinned) {
    return TransportResult::kPublicationUnconfirmed;
  }
  const auto leaf = copy_leaf(trust);
  if (leaf == nullptr) {
    return TransportResult::kKeyUnavailable;
  }
  const auto* const data = SecCertificateCopyData(leaf.get());
  const auto certificate = copy_data(data, 16384);
  if (data != nullptr) {
    CFRelease(data);
  }
  const auto parsed = certificate_key(certificate);
  if (!parsed.has_value()) {
    return TransportResult::kKeyUnavailable;
  }
  auto* const public_key = SecCertificateCopyKey(leaf.get());
  const auto* const attributes = public_key == nullptr ? nullptr : SecKeyCopyAttributes(public_key);
  const auto* const exported = public_key == nullptr ? nullptr : SecKeyCopyExternalRepresentation(public_key, nullptr);
  if (public_key != nullptr) {
    CFRelease(public_key);
  }
  const bool supported = exported_matches(*parsed, attributes, exported);
  if (attributes != nullptr) {
    CFRelease(attributes);
  }
  if (exported != nullptr) {
    CFRelease(exported);
  }
  if (!supported) {
    return TransportResult::kKeyUnavailable;
  }
  return matches_leaf(profile, certificate) ? TransportResult::kPublicationUnconfirmed
                                            : TransportResult::kPinVerificationFailed;
}
void clear_pending(const std::shared_ptr<IosTrustState>& state, const std::shared_ptr<IosVerification>& invocation) {
  const std::scoped_lock lock(state->mutex);
  if (state->pending == invocation) {
    state->pending.reset();
  }
}
void begin_verification(sec_trust_t offered, sec_protocol_verify_complete_t completion, dispatch_queue_t queue,
                        std::shared_ptr<IosTrustState> state) API_AVAILABLE(ios(13.0), macos(10.15));
void begin_verification(sec_trust_t offered, sec_protocol_verify_complete_t completion, dispatch_queue_t queue,
                        std::shared_ptr<IosTrustState> state) {
  if (state->cancelled.load()) {
    completion(false);
    return;
  }
  bool available = false;
  if (!evaluation_slot().compare_exchange_strong(available, true)) {
    fail(state, TransportResult::kTrustEvaluationBusy);
    completion(false);
    return;
  }
  const auto invocation = std::make_shared<IosVerification>(offered, completion);
  {
    const std::scoped_lock lock(state->mutex);
    state->pending = invocation;
  }
  const bool ready = invocation->trust() != nullptr && policies(invocation->trust(), state->hostname);
  if (!ready ||
#ifdef RASP_REPORTING_TRANSPORT_TEST
      !fixture_anchor(invocation->trust()) ||
#endif
      state->cancelled.load()) {
    fail(state, TransportResult::kTrustVerificationFailed);
    static_cast<void>(invocation->finish(false, state->verified));
    clear_pending(state, invocation);
    evaluation_slot().store(false);
    return;
  }
  const auto retained = std::move(state);
  const dispatch_block_t evaluate = ^{
    const OSStatus status = SecTrustEvaluateAsyncWithError(
        invocation->trust(), queue, ^(SecTrustRef evaluated, bool trusted, CFErrorRef /*error*/) {
          const bool active = profile_active(retained->profile, security_time());
          bool accepted = trusted && !retained->cancelled.load() && active &&
                          retained->failure.load() == TransportResult::kPublicationUnconfirmed;
          TransportResult reason =
              active ? TransportResult::kTrustVerificationFailed : TransportResult::kProfileNotActive;
          if (accepted) {
            reason = leaf_status(evaluated, retained->profile);
            accepted = reason == TransportResult::kPublicationUnconfirmed;
          }
          if (!accepted && !invocation->completed()) {
            fail(retained, reason);
          }
          static_cast<void>(invocation->finish(accepted, retained->verified));
          clear_pending(retained, invocation);
          evaluation_slot().store(false);
        });
    if (status != errSecSuccess) {
      fail(retained, TransportResult::kTrustVerificationFailed);
      static_cast<void>(invocation->finish(false, retained->verified));
      clear_pending(retained, invocation);
      evaluation_slot().store(false);
    }
  };
#ifdef RASP_REPORTING_TRANSPORT_TEST
  const int delay_ms = transport_fixture().verification_delay_ms;
  if (delay_ms > 0) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, static_cast<int64_t>(delay_ms) * 1000000), queue, evaluate);
    return;
  }
#endif
  evaluate();
}
}  // namespace
#ifdef RASP_REPORTING_TRANSPORT_TEST
SecCertificateRef transport_fixture_copy_leaf(SecTrustRef trust) { return copy_leaf(trust).release(); }
#endif
void configure_trust(sec_protocol_options_t options, dispatch_queue_t queue, std::shared_ptr<IosTrustState> state) {
  sec_protocol_options_set_peer_authentication_required(options, true);
  sec_protocol_options_set_tls_server_name(options, state->hostname.c_str());
  sec_protocol_options_set_tls_resumption_enabled(options, false);
  sec_protocol_options_set_tls_tickets_enabled(options, false);
  sec_protocol_options_set_tls_false_start_enabled(options, false);
  sec_protocol_options_set_tls_renegotiation_enabled(options, false);
  const auto retained = std::move(state);
  sec_protocol_options_set_verify_block(
      options,
      ^(sec_protocol_metadata_t /*metadata*/, sec_trust_t trust, sec_protocol_verify_complete_t completion) {
        if (__builtin_available(iOS 13.0, macOS 10.15, *)) {
          begin_verification(trust, completion, queue, retained);
        } else {
          fail(retained, TransportResult::kPlatformPolicyUnavailable);
          completion(false);
        }
      },
      queue);
}
void cancel_trust(const std::shared_ptr<IosTrustState>& state, TransportResult reason) {
  state->cancelled.store(true);
  if (reason != TransportResult::kPublicationAcknowledged) {
    fail(state, reason);
  }
  std::shared_ptr<IosVerification> pending;
  {
    const std::scoped_lock lock(state->mutex);
    pending = state->pending;
  }
  if (pending != nullptr) {
    static_cast<void>(pending->finish(false, state->verified));
  }
}
}  // namespace rasp::plugins::reporting
