/* Narrow entry points kept global inside the isolated reporting TLS object. */
#include <curl/curl.h>
#include <curl/multi.h>
#include <mbedtls/private/sha256.h>
#include <mbedtls/ssl.h>
#include <stddef.h>

#include "tls_island.h"

static int verify_leaf(void* context, mbedtls_x509_crt* certificate, int depth, uint32_t* flags) {
  struct ReportingVerify* verify = context;
  const struct ReportingCertificate leaf = {certificate == NULL ? NULL : certificate->raw.p,
                                            certificate == NULL ? 0 : certificate->raw.len, depth, *flags};
  if (certificate == NULL || verify == NULL || verify->check == NULL || verify->check(verify->context, &leaf) != 0) {
    *flags |= MBEDTLS_X509_BADCERT_OTHER;
  }
  return 0;
}
void rasp_reporting_configure_verify(void* config, struct ReportingVerify* verify) {
  mbedtls_ssl_conf_verify(config, verify_leaf, verify);
}
int rasp_reporting_configure_multi(void* multi) {
  return curl_multi_setopt(multi, CURLMOPT_RESOLVE_THREADS_MAX, 1L) == CURLM_OK &&
                 curl_multi_setopt(multi, CURLMOPT_MAX_TOTAL_CONNECTIONS, 1L) == CURLM_OK
             ? 0
             : -1;
}
int rasp_reporting_sha256(const void* input, size_t length, unsigned char* output) {
  return mbedtls_sha256(input, length, output, 0);
}
static CURLcode configure_tls(CURL* easy, void* config, void* context) {
  (void)easy;
  rasp_reporting_configure_verify(config, context);
  return CURLE_OK;
}
int rasp_reporting_set_verify(void* easy, struct ReportingVerify* verify) {
  return curl_easy_setopt(easy, CURLOPT_SSL_CTX_FUNCTION, configure_tls) == CURLE_OK &&
                 curl_easy_setopt(easy, CURLOPT_SSL_CTX_DATA, verify) == CURLE_OK
             ? 0
             : -1;
}
int rasp_reporting_multi_result(void* multi, int* done) {
  int remaining = 0;
  const CURLMsg* message = curl_multi_info_read(multi, &remaining);
  *done = message != NULL && message->msg == CURLMSG_DONE;
  return *done ? message->data.result : CURLE_OK;
}
int rasp_reporting_set_body(void* easy, const void* body, size_t size) {
  return curl_easy_setopt(easy, CURLOPT_POSTFIELDSIZE, (long)size) == CURLE_OK &&
                 curl_easy_setopt(easy, CURLOPT_POSTFIELDS, body) == CURLE_OK
             ? 0
             : -1;
}
