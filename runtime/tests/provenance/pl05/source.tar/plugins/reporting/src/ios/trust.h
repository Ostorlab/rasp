/// Owned Apple verification state; asynchronous evaluation retains no request body or connection.
#pragma once
#include <Security/SecProtocolOptions.h>
#include <atomic>
#include <dispatch/dispatch.h>
#include <memory>
#include <mutex>
#include <string>

#include "reporting/transport_result.h"
#include "security_profile.h"
namespace rasp::plugins::reporting {
class IosVerification;
struct IosTrustState {
  SecurityProfile profile;
  std::string hostname;
  std::atomic<bool> cancelled{false};
  std::atomic<bool> verified{false};
  std::atomic<TransportResult> failure{TransportResult::kPublicationUnconfirmed};
  std::mutex mutex;
  std::shared_ptr<IosVerification> pending;
};
/// Compose existing trust policies with explicit SSL hostname/server purpose and optional leaf pin.
void configure_trust(sec_protocol_options_t options, dispatch_queue_t queue, std::shared_ptr<IosTrustState> state);
/// Complete a pending invocation false exactly once; its evaluation slot stays occupied until the real callback.
void cancel_trust(const std::shared_ptr<IosTrustState>& state, TransportResult reason);
}  // namespace rasp::plugins::reporting
