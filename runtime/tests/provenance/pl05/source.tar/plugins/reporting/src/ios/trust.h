/// Owned Apple verification state; asynchronous evaluation retains no request body or connection.
#pragma once
#include <Security/SecProtocolOptions.h>
#include <atomic>
#include <dispatch/dispatch.h>
#include <memory>
#include <mutex>
#include <string>
#ifdef RASP_REPORTING_TRANSPORT_TEST
#include <functional>
#endif

#include "reporting/transport_result.h"
#include "security_profile.h"
namespace rasp::plugins::reporting {
class IosVerification;
#ifdef RASP_REPORTING_TRANSPORT_TEST
class VerificationFixture;
#endif
struct IosTrustState {
  SecurityProfile profile;
  std::string hostname;
  std::atomic<bool> cancelled{false};
  std::atomic<bool> verified{false};
  std::atomic<TransportResult> failure{TransportResult::kPublicationUnconfirmed};
  std::mutex mutex;
  /// Guarded by mutex; terminal selection seals cancelled before deciding whether verification never began.
  bool verification_started = false;
  std::shared_ptr<IosVerification> pending;
#ifdef RASP_REPORTING_TRANSPORT_TEST
  std::function<void()> before_setup;
  std::function<void()> on_committed;
  std::function<void()> before_refusal;
  std::shared_ptr<VerificationFixture> fixture;
#endif
};
/// Compose existing trust policies with explicit SSL hostname/server purpose and optional leaf pin.
void configure_trust(sec_protocol_options_t options, dispatch_queue_t queue, std::shared_ptr<IosTrustState> state);
/// Complete a pending invocation false exactly once; its evaluation slot stays occupied until the real callback.
void cancel_trust(const std::shared_ptr<IosTrustState>& state, TransportResult reason);
}  // namespace rasp::plugins::reporting
