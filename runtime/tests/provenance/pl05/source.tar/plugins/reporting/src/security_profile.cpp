#include "security_profile.h"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>

#include "collection_authority.h"
#include "config.h"
#include "http.h"
#include "json_value.h"
#include "reporting/transport_result.h"
#include "reporting_security_build.h"
#include "security_time.h"
#include "transport.h"

namespace rasp::plugins::reporting {
namespace {
constexpr std::string_view kBase64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
constexpr std::array<std::string_view, 5> kAlgorithms{"rsa-2048", "rsa-3072", "rsa-4096", "ec-p256", "ec-p384"};
bool bounded_depth(std::string_view text) {
  unsigned depth = 0;
  bool quoted = false;
  bool escaped = false;
  for (const char byte : text) {
    if (escaped) {
      escaped = false;
    } else if (quoted && byte == '\\') {
      escaped = true;
    } else if (byte == '"') {
      quoted = !quoted;
    } else if (!quoted && (byte == '[' || byte == '{')) {
      if (++depth > 8) {
        return false;
      }
    } else if (!quoted && (byte == ']' || byte == '}')) {
      if (depth == 0) {
        return false;
      }
      --depth;
    }
  }
  return !quoted && depth == 0;
}
std::optional<Pin> parse_pin(const JsonValue& value) {
  if (!keys_are(value, {"key_algorithm", "value"})) {
    return std::nullopt;
  }
  const auto* algorithm = value.get("key_algorithm").text();
  const auto* encoded = value.get("value").text();
  if (algorithm == nullptr || encoded == nullptr || std::ranges::find(kAlgorithms, *algorithm) == kAlgorithms.end() ||
      encoded->size() != 52 || !encoded->starts_with("sha256//") || encoded->back() != '=') {
    return std::nullopt;
  }
  Pin result{.algorithm = *algorithm, .value = *encoded};
  std::uint32_t bits = 0;
  unsigned available = 0;
  std::size_t offset = 0;
  for (const char byte : std::string_view(*encoded).substr(8, 43)) {
    const auto digit = kBase64.find(byte);
    if (digit == std::string_view::npos) {
      return std::nullopt;
    }
    bits = (bits << 6U) | static_cast<std::uint32_t>(digit);
    available += 6;
    if (available >= 8) {
      available -= 8;
      if (offset >= result.digest.size()) {
        return std::nullopt;
      }
      std::span{result.digest}[offset++] = static_cast<std::uint8_t>((bits >> available) & 255U);
    }
  }
  if (offset != 32 || pin_value(result.digest) != *encoded) {
    return std::nullopt;
  }
  return result;
}
}  // namespace
std::optional<SecurityProfile> parse_security_profile(ProfileInput input) {
  const auto [value, endpoint] = input;
  if (value.size() > 1536 || !bounded_depth(value)) {
    return std::nullopt;
  }
  const auto object = parse_json(value, 1536);
  const auto authority =
      collection_authority({.endpoint = endpoint, .policy = "default", .zone = "", .dns_policy = "default"});
  const auto normalized = authority.has_value() ? authority_endpoint(*authority) : std::nullopt;
  const auto origin = normalized.has_value() ? parse_endpoint(*normalized) : std::nullopt;
  if (!object.has_value() || !origin.has_value() ||
      !keys_are(*object, {"version", "mode", "host", "port", "pins", "validity"})) {
    return std::nullopt;
  }
  const auto port = object->get("port").unsigned_number();
  const auto* host = object->get("host").text();
  const auto* mode = object->get("mode").text();
  const auto canonical = canonical_json(*object, 1536);
  if (object->get("version").unsigned_number() != 1 || host == nullptr || *host != origin->host || !port.has_value() ||
      std::to_string(*port) != origin->port || mode == nullptr || !canonical.has_value()) {
    return std::nullopt;
  }
  SecurityProfile profile;
  profile.canonical = *canonical;
  if (*mode == "system") {
    return object->get("pins").null() && object->get("validity").null() ? std::optional(profile) : std::nullopt;
  }
  const auto pins = object->get("pins");
  const auto validity = object->get("validity");
  if (*mode != "leaf-spki-sha256" || !keys_are(pins, {"primary", "backup"}) ||
      !keys_are(validity, {"not_before", "not_after"})) {
    return std::nullopt;
  }
  const auto primary = parse_pin(pins.get("primary"));
  const auto backup = parse_pin(pins.get("backup"));
  const auto start = validity.get("not_before").unsigned_number();
  const auto end = validity.get("not_after").unsigned_number();
  if (!primary.has_value() || !backup.has_value() || primary->digest == backup->digest || !start.has_value() ||
      !end.has_value() || *start >= *end || *end > std::uint64_t{253402300799} ||
      *end - *start > std::uint64_t{31622400}) {
    return std::nullopt;
  }
  profile.pinned = true;
  profile.pins = {*primary, *backup};
  profile.not_before = *start;
  profile.not_after = *end;
  return profile;
}
bool profile_active(const SecurityProfile& profile, std::int64_t now) {
  return !profile.pinned ||
         (now >= 0 && std::cmp_greater_equal(now, profile.not_before) && std::cmp_less(now, profile.not_after));
}
std::optional<std::string> security_descriptor(const SecurityProfile& profile) {
  const auto parsed = parse_json(profile.canonical, 1536);
  if (!parsed.has_value()) {
    return std::nullopt;
  }
  return canonical_json(JsonValue(JsonValue::Object{
                            {"profile", *parsed},
#ifdef __APPLE__
                            {"proxy", JsonValue("apple-reject-proxy-before-post-v1")},
                            {"trust_store", JsonValue("apple-system-ssl-v1")},
#else
                            {"proxy", JsonValue("android-no-proxy-v1")},
                            {"trust_store", JsonValue("android-system-cacerts-path-v1")},
#endif
                            {"tls", JsonValue("tls12-fresh-canonical-rsa-ec-spki-v1")},
                        }),
                        2048);
}
std::string_view compiled_security_profile() { return kCompiledSecurityProfile; }
bool platform_security_available() {
#ifdef __APPLE__
  // Availability builtins must remain in an if condition, not a returned boolean expression.
  bool available = false;
  if (__builtin_available(iOS 13.0, macOS 10.15, *)) {
    available = true;
  }
  return available;
#else
  return true;
#endif
}
std::int64_t security_time() { return rasp_reporting_utc_seconds(); }
TransportResult transport_policy(const Config& config, Cancellation cancellation) {
  if (cancellation.requested()) {
    return TransportResult::kCancelled;
  }
  const auto profile =
      parse_security_profile({.profile = config.security_profile.value_or(""), .endpoint = config.endpoint});
  if (!profile.has_value()) {
    return TransportResult::kProfileInvalid;
  }
  if (!platform_security_available()) {
    return TransportResult::kPlatformPolicyUnavailable;
  }
  if (!profile_active(*profile, security_time())) {
    return TransportResult::kProfileNotActive;
  }
  return cancellation.requested() ? TransportResult::kCancelled : TransportResult::kPublicationUnconfirmed;
}
std::string pin_value(const Digest& digest) {
  std::string result = "sha256//";
  std::uint32_t bits = 0;
  unsigned available = 0;
  for (const auto byte : digest) {
    bits = (bits << 8U) | byte;
    available += 8;
    while (available >= 6) {
      available -= 6;
      result += kBase64[(bits >> available) & 63U];
    }
  }
  result += kBase64[(bits << (6U - available)) & 63U];
  result += '=';
  return result;
}
}  // namespace rasp::plugins::reporting
