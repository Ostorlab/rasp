/// Reporting owns immutable complete-cycle delivery through the private outbox worker. Runtime init only records
/// configuration; on_cycle retains the owning snapshot and starts/retries the worker. Provider acquisition, disk I/O
/// and transports run on workers. Legacy direct on_observations dispatch retains its existing volatile mailbox.

#include <atomic>
#include <memory>
#include <new>
#include <optional>
#include <rasp/cycle.h>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "config.h"
#include "cycle_delivery.h"
#include "rasp/config.h"
#include "rasp/context.h"
#include "rasp/observation.h"
#include "rasp/plugin.h"
#include "rasp/util/logging.h"
#include "security_profile.h"
#include "sender.h"
#include "transport.h"

namespace rasp::plugins::reporting {

namespace {

std::atomic<CycleDelivery*>& cycle_sender() {
  static std::atomic<CycleDelivery*> value{nullptr};
  return value;
}
constexpr Key<Config> kCycleConfig{"reporting.cycle_config"};
constexpr Key<Config> kLegacyConfig{"reporting.legacy_config"};

void cycle(const std::shared_ptr<const CycleSnapshot>& snapshot, const Context& context) {
  CycleDelivery* destination = cycle_sender().load();
  if (destination == nullptr) {
    const auto config = context.get(kCycleConfig);
    if (!config.has_value()) {
      return;
    }
    auto candidate = std::make_unique<CycleDelivery>(*config, post);
    if (candidate == nullptr) {
      return;
    }
    if (!cycle_sender().compare_exchange_strong(destination, candidate.get())) {
      candidate.reset();
    } else {
      destination = candidate.release();
      set_cycle_delivery(destination);
    }
  }
  static_cast<void>(destination->admit(snapshot));
  static_cast<void>(destination->start());
}

/// The sender, which the plugin's init starts.
///
/// @return The sender, which lives as long as the process once it has started. Null before init, or when init could not
/// start it.
[[nodiscard]] std::atomic<Sender*>& started_sender() {
  static std::atomic<Sender*> value{nullptr};
  return value;
}

/// The plugin's init: builds the sender, with the endpoint the build compiled in, the build id and install id the
/// runtime gives and the context the plugins share, and starts its thread. When the sender can't be allocated or its
/// thread doesn't start, the plugin has no sender.
///
/// @param runtime_config The runtime's config.
/// @param context The context the plugins share, where the sender leaves each run it does not deliver.
void start_legacy(const Config& runtime_config, Context& context) {
  // NOLINTNEXTLINE(cppcoreguidelines-owning-memory): the sender's thread uses it until the process exits.
  auto* const started = new (std::nothrow) Sender{
      .config =
          {
              .endpoint = RASP_REPORTING_ENDPOINT,
              .build_id = runtime_config.build_id,
              .install_id = runtime_config.install_id,
              .collection_policy = RASP_REPORTING_COLLECTION_POLICY,
              .security_profile = std::string(compiled_security_profile()),
          },
      .post = post,
      .context = &context,
      .mailbox = {},
  };
  if (started == nullptr) {
    return;
  }
  if (!start_sender(*started)) {
    // NOLINTNEXTLINE(cppcoreguidelines-owning-memory): the thread did not start, so nothing else uses the sender.
    delete started;
    return;
  }
  started_sender() = started;
}

void start(const rasp::Config& runtime_config, Context& context) {
  started_sender().store(nullptr);
  context.put(kCycleConfig, Config{
                                .endpoint = RASP_REPORTING_ENDPOINT,
                                .build_id = runtime_config.build_id,
                                .install_id = std::nullopt,
                                .collection_policy = RASP_REPORTING_COLLECTION_POLICY,
                                .security_profile = std::string(compiled_security_profile()),
                            });
  context.put(kLegacyConfig, Config{
                                 .endpoint = RASP_REPORTING_ENDPOINT,
                                 .build_id = runtime_config.build_id,
                                 .install_id = runtime_config.install_id,
                                 .collection_policy = RASP_REPORTING_COLLECTION_POLICY,
                                 .security_profile = std::string(compiled_security_profile()),
                             });
}

/// The plugin's on_observations: copies all the observations of the run into the sender's mailbox, replacing the run
/// the sender hasn't taken yet. It never waits for the network. When init could not start the sender, it leaves the run
/// in the context under kUndeliveredRun instead.
///
/// @param observations All the observations of the run.
/// @param context The context the plugins share.
void report(std::span<const Observation> observations, Context& context) {
  if (context.get(kCycleSnapshot).has_value()) {
    return;
  }
  if (started_sender().load() == nullptr) {
    const auto config = context.get(kLegacyConfig);
    if (config.has_value()) {
      start_legacy(*config, context);
    }
  }
  std::vector<Observation> run(observations.begin(), observations.end());
  Sender* const sender = started_sender();
  if (sender == nullptr) {
    if constexpr (kLoggingEnabled) {
      rasp::log("reporting: the sender did not start, the run's " + std::to_string(run.size()) +
                " observations are left in the context");
    }
    const auto config = context.get(kLegacyConfig);
    if (config.has_value()) {
      retain_fallback(*config, context, std::move(run), std::make_shared<const std::atomic<bool>>(false));
    }
    return;
  }
  sender->mailbox.put(std::move(run));
}

}  // namespace

/// The reporting plugin.
extern constexpr Plugin kPlugin{
    .init = start,
    .checks = {},
    .on_observations = report,
    .on_cycle = [](const std::shared_ptr<const CycleSnapshot>& snapshot,
                   Context& context) { cycle(snapshot, context); },
};

}  // namespace rasp::plugins::reporting
