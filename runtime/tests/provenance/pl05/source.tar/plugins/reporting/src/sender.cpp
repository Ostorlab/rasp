#include "reporting/transport_result.h"
#include "transport.h"
/// deliver and start_sender: the reporting plugin's sender thread.

#include <atomic>
#include <cstddef>
#include <memory>
#include <optional>
#include <pthread.h>
#include <span>
#include <string>
#include <utility>
#include <vector>

#include "collection_authority.h"
#include "config.h"
#include "json.h"
#include "legacy_delivery.h"
#include "rasp/context.h"
#include "rasp/observation.h"
#include "rasp/util/logging.h"
#include "reporting/delivery.h"
#include "reporting/fallback_authorization.h"
#include "reporting/undelivered_run.h"
#include "security_profile.h"
#include "sender.h"

namespace rasp::plugins::reporting {

namespace {

/// The largest list of observations a request may hold: the largest request, less the room of its other fields.
constexpr std::size_t kMaxObservationsSize = kMaxRequestSize - kOtherFieldsRoom;

void diagnose(Context& context, LegacyDeliveryDiagnostic diagnostic) {
  context.put(kLegacyDeliveryDiagnostic, diagnostic);
  if constexpr (kLoggingEnabled) {
    const auto result = diagnostic.transport.has_value() ? std::to_string(static_cast<unsigned>(*diagnostic.transport))
                                                         : "not_attempted";
    const auto refusal = diagnostic.fallback_refusal.has_value()
                             ? std::to_string(static_cast<unsigned>(*diagnostic.fallback_refusal))
                             : "none";
    rasp::log("reporting: legacy transport=" + result + " fallback_refusal=" + refusal +
              " retention=" + std::to_string(static_cast<unsigned>(diagnostic.retention)));
  }
}
void retain_suppressed(Context& context, std::vector<Observation> run, LegacyDeliveryDiagnostic diagnostic) {
  auto compact = compact_legacy_run(std::move(run));
  if (compact.has_value()) {
    context.put(kSecuritySuppressedRun, std::move(*compact));
    diagnostic.retention = LegacyRetention::kSuppressed;
  } else {
    diagnostic.retention = LegacyRetention::kTooLarge;
  }
  diagnose(context, diagnostic);
}

/// Writes the request that posts a run.
///
/// @param config The plugin's config.
/// @param run All the observations of the run.
/// @return The request. Nothing when it would be larger than kMaxRequestSize.
[[nodiscard]] std::optional<std::string> serialise_run(const Config& config, std::span<const Observation> run) {
  const std::optional<std::string> observations = serialise_observations(run, kMaxObservationsSize);
  if (!observations.has_value()) {
    return std::nullopt;
  }
  return serialise_request(config, *observations, kMaxRequestSize);
}

/// The thread: takes each run from the mailbox and delivers it, until the process exits.
///
/// @param argument The Sender.
/// @return Never returns.
void* send_runs(void* argument) {
  auto* const sender = static_cast<Sender*>(argument);
  while (true) {
    deliver(*sender, sender->mailbox.take());
  }
}

}  // namespace

void deliver(const Sender& sender, std::vector<Observation> run) {
  const std::optional<std::string> request = serialise_run(sender.config, run);
  const bool attempted = request.has_value() && sender.post != nullptr;
  const auto result = attempted ? sender.post(sender.config, *request, Cancellation(sender.cancelled.share().get()))
                                : TransportResult::kResponseInvalid;
  if (result == TransportResult::kPublicationAcknowledged) {
    diagnose(*sender.context, {.transport = result, .retention = LegacyRetention::kAcknowledged});
    if constexpr (kLoggingEnabled) {
      rasp::log("reporting: publication acknowledged");
    }
    return;
  }
  if constexpr (kLoggingEnabled) {
    if (!request.has_value()) {
      rasp::log("reporting: the request would be larger than the limit");
    }
  }
  const auto policy =
      permits_dns(result) ? transport_policy(sender.config, Cancellation(sender.cancelled.share().get())) : result;
  if (permits_dns(result) && policy == TransportResult::kPublicationUnconfirmed) {
    retain_fallback(sender.config, *sender.context, std::move(run), sender.cancelled.share(), result);
  } else {
    retain_suppressed(*sender.context, std::move(run),
                      {.transport = attempted ? std::optional(result) : std::nullopt, .fallback_refusal = policy});
  }
}

void retain_fallback(const Config& config, Context& context, std::vector<Observation> run,
                     std::shared_ptr<const std::atomic<bool>> cancellation, std::optional<TransportResult> result) {
  auto compact = compact_legacy_run(std::move(run));
  if (!compact.has_value()) {
    diagnose(context, {.transport = result, .retention = LegacyRetention::kTooLarge});
    return;
  }
  const auto* selected = selected_dns_fallback();
  const auto profile =
      parse_security_profile({.profile = config.security_profile.value_or(""), .endpoint = config.endpoint});
  const auto descriptor = profile.has_value() ? security_descriptor(*profile) : std::nullopt;
  const auto authority = selected != nullptr && descriptor.has_value() ? collection_authority({
                                                                             .endpoint = config.endpoint,
                                                                             .policy = config.collection_policy,
                                                                             .zone = selected->zone,
                                                                             .dns_policy = selected->collection_policy,
                                                                             .security = *descriptor,
                                                                         })
                                                                       : std::nullopt;
  auto refusal = TransportResult::kProfileInvalid;
  if (authority.has_value()) {
    const auto authorization =
        std::make_shared<const FallbackAuthorization>(config, *authority, std::move(cancellation));
    refusal = authorization->status();
    if (refusal == TransportResult::kPublicationUnconfirmed) {
      context.put(kAuthorizedUndeliveredRun, AuthorizedUndeliveredRun{
                                                 .observations = std::move(*compact),
                                                 .authorization = authorization,
                                                 .https_result = result,
                                             });
      diagnose(context, {.transport = result, .retention = LegacyRetention::kAuthorizedDns});
      return;
    }
  }
  context.put(kSecuritySuppressedRun, std::move(*compact));
  diagnose(context, {.transport = result, .fallback_refusal = refusal, .retention = LegacyRetention::kSuppressed});
}

bool start_sender(Sender& sender) {
  pthread_attr_t attributes{};
  if (pthread_attr_init(&attributes) != 0) {
    return false;
  }
  bool started = false;
  if (pthread_attr_setdetachstate(&attributes, PTHREAD_CREATE_DETACHED) == 0) {
    pthread_t thread{};
    started = pthread_create(&thread, &attributes, send_runs, &sender) == 0;
  }
  static_cast<void>(pthread_attr_destroy(&attributes));
  return started;
}

}  // namespace rasp::plugins::reporting
