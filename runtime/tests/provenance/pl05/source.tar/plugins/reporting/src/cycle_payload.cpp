#include "cycle_payload.h"

#include <algorithm>
#include <array>
#include <charconv>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <rasp/cycle.h>
#include <rasp/observation.h>
#include <ratio>
#include <set>
#include <span>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <variant>
#include <vector>

#include "hash.h"
#include "json.h"
#include "json_value.h"

namespace rasp::plugins::reporting {
namespace {
using Object = JsonValue::Object;
using Array = JsonValue::Array;
constexpr std::array<std::string_view, 4> kStatuses{"ok", "unsupported", "error", "timeout"};
constexpr std::array<std::string_view, 4> kGraphqlStatuses{"OK", "UNSUPPORTED", "ERROR", "TIMEOUT"};
constexpr std::array<std::string_view, 8> kBooleans{
    "config_known",     "catalogue_known",     "execution_finished", "complete",
    "config_truncated", "catalogue_truncated", "overflow",           "serialization_complete",
};
constexpr std::array<std::string_view, 7> kCounters{
    "unknown_groups", "seen", "extra", "dropped", "plugin_observations", "unknown_status", "serialization_dropped",
};
JsonValue number(std::uint64_t value) { return JsonValue(std::to_string(value)); }
JsonValue nullable_number(std::optional<std::uint64_t> value) {
  return value.has_value() ? number(*value) : JsonValue{};
}
JsonValue nullable_text(std::string_view value) { return value.empty() ? JsonValue{} : JsonValue(value); }
std::optional<JsonValue> native_uuid(std::string_view value) {
  if (value.empty() || value == kZeroUuid) {
    return JsonValue{};
  }
  const auto normalized = canonical_uuid(value);
  if (!normalized.has_value()) {
    return std::nullopt;
  }
  return JsonValue(*normalized);
}
bool flag(const JsonValue& value, std::string_view name) { return value.get(name).boolean() == true; }
template <std::size_t length>
std::string padded(unsigned value) {
  std::string text = std::to_string(value);
  if (text.size() < length) {
    text.insert(0, length - text.size(), '0');
  }
  return text;
}
std::optional<JsonValue> observed_time(std::optional<std::int64_t> milliseconds) {
  if (!milliseconds.has_value()) {
    return JsonValue{};
  }
  if (*milliseconds < 946684800000LL || *milliseconds >= 4102444800000LL) {
    return std::nullopt;
  }
  const auto time = std::chrono::sys_time<std::chrono::milliseconds>(std::chrono::milliseconds(*milliseconds));
  const auto day = std::chrono::floor<std::chrono::duration<int, std::ratio<86400>>>(time);
  const std::chrono::year_month_day date(day);
  const std::chrono::hh_mm_ss clock(time - day);
  std::string text = padded<4>(static_cast<unsigned>(static_cast<int>(date.year()))) + "-" +
                     padded<2>(static_cast<unsigned>(date.month())) + "-" +
                     padded<2>(static_cast<unsigned>(date.day())) + "T" +
                     padded<2>(static_cast<unsigned>(clock.hours().count())) + ":" +
                     padded<2>(static_cast<unsigned>(clock.minutes().count())) + ":" +
                     padded<2>(static_cast<unsigned>(clock.seconds().count()));
  if (clock.subseconds().count() != 0) {
    text += "." + padded<6>(static_cast<unsigned>(clock.subseconds().count()) * 1000U);
  }
  return JsonValue(text + "+00:00");
}
bool valid_time(const JsonValue& value) {
  if (value.null()) {
    return true;
  }
  const auto* text = value.text();
  if (text == nullptr || (text->size() != 25 && text->size() != 32) || !text->ends_with("+00:00") ||
      (*text)[4] != '-' || (*text)[7] != '-' || (*text)[10] != 'T' || (*text)[13] != ':' || (*text)[16] != ':') {
    return false;
  }
  const auto part = [text](std::size_t offset, std::size_t count) -> std::optional<unsigned> {
    unsigned output = 0;
    const auto parsed =
        std::from_chars(std::to_address(text->begin() + static_cast<std::ptrdiff_t>(offset)),
                        std::to_address(text->begin() + static_cast<std::ptrdiff_t>(offset + count)), output);
    if (parsed.ec != std::errc{} ||
        parsed.ptr != std::to_address(text->begin() + static_cast<std::ptrdiff_t>(offset + count))) {
      return std::nullopt;
    }
    return output;
  };
  const auto year = part(0, 4);
  const auto month = part(5, 2);
  const auto day = part(8, 2);
  const auto hour = part(11, 2);
  const auto minute = part(14, 2);
  const auto second = part(17, 2);
  if (!year.has_value() || !month.has_value() || !day.has_value() || !hour.has_value() || !minute.has_value() ||
      !second.has_value() || *year < 2000 || *year >= 2100 || *hour > 23 || *minute > 59 || *second > 59) {
    return false;
  }
  const std::chrono::year_month_day date(std::chrono::year(static_cast<int>(*year)), std::chrono::month(*month),
                                         std::chrono::day(*day));
  if (!date.ok()) {
    return false;
  }
  if (text->size() == 32) {
    const auto fraction = part(20, 6);
    return (*text)[19] == '.' && fraction.has_value() && *fraction != 0;
  }
  return true;
}
JsonValue cycle_metadata(const CycleMetadata& meta, std::uint64_t dropped) {
  Array groups;
  for (const auto& group : meta.groups) {
    groups.emplace_back(Object{
        {"name", JsonValue(group.name)},
        {"enabled", group.enabled.has_value() ? JsonValue(*group.enabled) : JsonValue{}},
    });
  }
  Array missing;
  for (const auto& item : meta.missing) {
    missing.emplace_back(Object{{"signal", JsonValue(item.signal)}, {"source", JsonValue(item.source)}});
  }
  Array counts;
  for (const auto count : meta.status_counts) {
    counts.push_back(number(count));
  }
  Object result;
  result.emplace("version", JsonValue(static_cast<std::uint64_t>(meta.version)));
  result.emplace("sequence", nullable_number(meta.sequence));
  result.emplace("duration_ns", nullable_number(meta.duration_ns));
  result.emplace("platform", nullable_text(meta.platform));
  result.emplace("catalogue_id", nullable_text(meta.catalogue_id));
  result.emplace("config_known", JsonValue(meta.config_known));
  result.emplace("catalogue_known", JsonValue(meta.catalogue_known));
  result.emplace("execution_finished", JsonValue(meta.execution_finished));
  result.emplace("complete", JsonValue(meta.complete));
  result.emplace("config_truncated", JsonValue(meta.config_truncated));
  result.emplace("catalogue_truncated", JsonValue(meta.catalogue_truncated));
  result.emplace("overflow", JsonValue(meta.overflow));
  result.emplace("groups", JsonValue(std::move(groups)));
  result.emplace("unknown_groups", number(meta.unknown_groups));
  result.emplace("expected", nullable_number(meta.expected));
  result.emplace("seen", number(meta.seen));
  result.emplace("missing", JsonValue(std::move(missing)));
  result.emplace("extra", number(meta.extra));
  result.emplace("dropped", number(meta.dropped));
  result.emplace("plugin_observations", number(meta.plugin_observations));
  result.emplace("status_counts", JsonValue(std::move(counts)));
  result.emplace("unknown_status", number(meta.unknown_status));
  result.emplace("serialization_complete", JsonValue(dropped == 0 && meta.unknown_status == 0));
  result.emplace("serialization_dropped", number(dropped));
  return JsonValue(std::move(result));
}
std::optional<JsonValue> observation(const Observation& item) {
  const auto status = static_cast<std::size_t>(item.status);
  if (status >= kStatuses.size() || !bounded_text(item.signal, 96, true, true) ||
      !bounded_text(item.source, 64, true, true)) {
    return std::nullopt;
  }
  JsonValue value;
  if (item.status == Status::kOk) {
    if (const auto* boolean = std::get_if<bool>(&item.value); boolean != nullptr) {
      value = JsonValue(Object{{"bool", JsonValue(*boolean)}});
    } else if (const auto* integer = std::get_if<std::int64_t>(&item.value); integer != nullptr) {
      value = JsonValue(Object{{"long", JsonValue(std::to_string(*integer))}});
    } else if (const auto* text = std::get_if<std::string>(&item.value); text != nullptr) {
      if (!bounded_text(*text, 1024)) {
        return std::nullopt;
      }
      value = JsonValue(Object{{"string", JsonValue(*text)}});
    } else if (const auto* list = std::get_if<std::vector<std::string>>(&item.value); list != nullptr) {
      if (list->size() > 64) {
        return std::nullopt;
      }
      Array strings;
      for (const auto& entry : *list) {
        if (!bounded_text(entry, 1024)) {
          return std::nullopt;
        }
        strings.emplace_back(entry);
      }
      value = JsonValue(Object{{"strings", JsonValue(std::move(strings))}});
    } else {
      return std::nullopt;
    }
  }
  return JsonValue(Object{
      {"name", JsonValue(item.signal)},
      {"source", JsonValue(item.source)},
      {"status", JsonValue(std::span{kStatuses}[status])},
      {"value", std::move(value)},
  });
}
std::optional<std::size_t> string_list_bytes(const JsonValue& value) {
  const auto* list = value.array();
  if (list == nullptr || list->size() > 64) {
    return std::nullopt;
  }
  std::size_t size = 0;
  for (const auto& item : *list) {
    const auto* text = item.text();
    if (text == nullptr || !bounded_text(*text, 1024)) {
      return std::nullopt;
    }
    size += text->size();
  }
  return size;
}
bool valid_int(const JsonValue& value) {
  if (const auto* number = value.signed_integer(); number != nullptr) {
    return *number >= INT32_MIN && *number <= INT32_MAX;
  }
  const auto number = value.unsigned_number();
  return number.has_value() && *number <= INT32_MAX;
}
std::optional<std::size_t> value_text_bytes(const JsonValue& value) {
  const auto* object = value.object();
  if (object == nullptr || object->size() != 1) {
    return std::nullopt;
  }
  const auto& [kind, inner] = *object->begin();
  if (kind == "bool" && inner.boolean().has_value()) {
    return 0;
  }
  if (kind == "long" && decimal_long(inner).has_value()) {
    return 0;
  }
  if (kind == "int" && valid_int(inner)) {
    return 0;
  }
  if (kind == "string") {
    const auto* text = inner.text();
    if (text != nullptr && bounded_text(*text, 1024)) {
      return text->size();
    }
  }
  if (kind == "strings") {
    return string_list_bytes(inner);
  }
  return std::nullopt;
}
std::optional<std::size_t> validated_signal_status(const JsonValue& signal, std::size_t& text_bytes) {
  if (!keys_are(signal, {"name", "source", "status", "value"})) {
    return std::nullopt;
  }
  const auto* name = signal.get("name").text();
  const auto* source = signal.get("source").text();
  const auto* status = signal.get("status").text();
  if (name == nullptr || source == nullptr || status == nullptr || !bounded_text(*name, 96, true, true) ||
      !bounded_text(*source, 64, true, true)) {
    return std::nullopt;
  }
  const auto* found = std::ranges::find(kStatuses, *status);
  if (found == kStatuses.end()) {
    return std::nullopt;
  }
  const auto value = signal.get("value");
  const auto inner_size = *status == "ok" ? value_text_bytes(value) : std::optional<std::size_t>(0);
  if (*status != "ok" && !value.null()) {
    return std::nullopt;
  }
  if (!inner_size.has_value()) {
    return std::nullopt;
  }
  const auto size = name->size() + source->size() + *inner_size;
  if (size > 65536 || text_bytes > 65536 - size) {
    return std::nullopt;
  }
  text_bytes += size;
  return static_cast<std::size_t>(found - kStatuses.begin());
}
bool cycle_shape_valid(const JsonValue& cycle) {
  if (!keys_are(cycle,
                {
                    "version",
                    "sequence",
                    "duration_ns",
                    "platform",
                    "catalogue_id",
                    "config_known",
                    "catalogue_known",
                    "execution_finished",
                    "complete",
                    "config_truncated",
                    "catalogue_truncated",
                    "overflow",
                    "groups",
                    "unknown_groups",
                    "expected",
                    "seen",
                    "missing",
                    "extra",
                    "dropped",
                    "plugin_observations",
                    "status_counts",
                    "unknown_status",
                    "serialization_complete",
                    "serialization_dropped",
                }) ||
      cycle.get("version").unsigned_number() != 1 || !canonical_json(cycle, std::size_t{128} * 1024).has_value()) {
    return false;
  }
  for (const auto name : kBooleans) {
    if (!cycle.get(name).boolean().has_value()) {
      return false;
    }
  }
  for (const auto name : kCounters) {
    if (!decimal_uint(cycle.get(name)).has_value()) {
      return false;
    }
  }
  for (const auto* name : {"sequence", "duration_ns", "expected"}) {
    if (!cycle.get(name).null() && !decimal_uint(cycle.get(name)).has_value()) {
      return false;
    }
  }
  return decimal_uint(cycle.get("sequence")) != 0;
}
bool catalogue_valid(const JsonValue& cycle) {
  const auto platform = cycle.get("platform");
  const auto catalogue = cycle.get("catalogue_id");
  return !((!platform.null() &&
            (platform.text() == nullptr || (*platform.text() != "android" && *platform.text() != "ios"))) ||
           (!catalogue.null() && (catalogue.text() == nullptr || !full_digest(*catalogue.text()))) ||
           (flag(cycle, "catalogue_known") && (platform.null() || catalogue.null())) ||
           (flag(cycle, "config_known") && flag(cycle, "config_truncated")) ||
           (flag(cycle, "catalogue_known") && flag(cycle, "catalogue_truncated")));
}
std::optional<bool> groups_known(const JsonValue& value) {
  if (value.null()) {
    return false;
  }
  const auto* groups = value.array();
  if (groups == nullptr || groups->size() > 64) {
    return std::nullopt;
  }
  bool known = true;
  std::set<std::string> names;
  for (const auto& group : *groups) {
    const auto* name = group.get("name").text();
    const auto enabled = group.get("enabled");
    if (!keys_are(group, {"name", "enabled"}) || name == nullptr || !bounded_text(*name, 96, true, true) ||
        (!enabled.null() && !enabled.boolean().has_value()) || !names.insert(*name).second) {
      return std::nullopt;
    }
    known = known && !enabled.null();
  }
  return known;
}
bool missing_valid(const JsonValue& value) {
  const auto* missing = value.array();
  if (missing == nullptr || missing->size() > 256) {
    return false;
  }
  std::set<std::pair<std::string, std::string>> identities;
  for (const auto& item : *missing) {
    const auto* signal = item.get("signal").text();
    const auto* source = item.get("source").text();
    if (!keys_are(item, {"signal", "source"}) || signal == nullptr || source == nullptr ||
        !bounded_text(*signal, 96, true, true) || !bounded_text(*source, 64, true, true) ||
        !identities.emplace(*signal, *source).second) {
      return false;
    }
  }
  return true;
}
bool retained_valid(const JsonValue& cycle, const Array& signals) {
  const auto* counts = cycle.get("status_counts").array();
  const auto unknown = decimal_uint(cycle.get("unknown_status"));
  const auto dropped = decimal_uint(cycle.get("serialization_dropped"));
  if (counts == nullptr || counts->size() != 4 || !unknown.has_value() || *unknown > 256 || !dropped.has_value()) {
    return false;
  }
  std::uint64_t retained = *unknown;
  std::array<std::uint64_t, 4> transmitted{};
  std::size_t text_bytes = 0;
  for (const auto& signal : signals) {
    const auto status = validated_signal_status(signal, text_bytes);
    if (!status.has_value()) {
      return false;
    }
    ++std::span{transmitted}[*status];
  }
  for (std::size_t index = 0; index < 4; ++index) {
    const auto count = decimal_uint((*counts)[index]);
    if (!count.has_value() || *count > 256 - retained || std::span{transmitted}[index] > *count) {
      return false;
    }
    retained += *count;
  }
  return *dropped <= retained && signals.size() == retained - *dropped &&
         flag(cycle, "serialization_complete") == (*dropped == 0) &&
         (!flag(cycle, "serialization_complete") || *unknown == 0);
}
bool complete_valid(const JsonValue& cycle, bool known_groups) {
  if (!flag(cycle, "complete")) {
    return true;
  }
  if (!flag(cycle, "execution_finished") || !flag(cycle, "config_known") || !flag(cycle, "catalogue_known") ||
      flag(cycle, "overflow") || cycle.get("sequence").null() || cycle.get("duration_ns").null() || !known_groups ||
      decimal_uint(cycle.get("expected")) != decimal_uint(cycle.get("seen"))) {
    return false;
  }
  for (const auto* name : {"unknown_groups", "extra", "dropped", "unknown_status"}) {
    if (decimal_uint(cycle.get(name)) != 0) {
      return false;
    }
  }
  const auto* missing = cycle.get("missing").array();
  return missing != nullptr && missing->empty();
}
bool cycle_valid(const JsonValue& cycle, const Array& signals) {
  if (signals.size() > 256 || !cycle_shape_valid(cycle) || !catalogue_valid(cycle)) {
    return false;
  }
  const auto groups = groups_known(cycle.get("groups"));
  const auto seen = decimal_uint(cycle.get("seen"));
  const auto expected = decimal_uint(cycle.get("expected"));
  const auto* missing = cycle.get("missing").array();
  const bool known = flag(cycle, "config_known") && flag(cycle, "catalogue_known");
  if (!groups.has_value() || !seen.has_value() || *seen > 256 || (expected.has_value() && *expected > 256) ||
      known != expected.has_value() || missing == nullptr || !missing_valid(cycle.get("missing"))) {
    return false;
  }
  if (expected.has_value() ? *seen + missing->size() != *expected : *seen != 0 || !missing->empty()) {
    return false;
  }
  return retained_valid(cycle, signals) && complete_valid(cycle, *groups);
}
std::string camel_case(std::string_view key) {
  std::string output;
  bool upper = false;
  for (char const byte : key) {
    if (byte == '_') {
      upper = true;
    } else {
      output += upper ? static_cast<char>(byte - ('a' - 'A')) : byte;
      upper = false;
    }
  }
  return output;
}
std::optional<std::string> graphql_request(const JsonValue& producer) {
  Object graphql_cycle;
  for (const auto& [key, value] : *producer.get("cycle").object()) {
    graphql_cycle.emplace(camel_case(key), value);
  }
  Array observations;
  for (const auto& item : *producer.get("signals").array()) {
    const auto* status = item.get("status").text();
    const auto index = static_cast<std::size_t>(std::ranges::find(kStatuses, *status) - kStatuses.begin());
    observations.emplace_back(Object{
        {"signal", item.get("name")},
        {"source", item.get("source")},
        {"status", JsonValue(std::span{kGraphqlStatuses}[index])},
        {"value", item.get("value")},
    });
  }
  Object batch;
  for (const auto* const name : {"build_id", "install_id", "session_id", "run_id", "batch_id", "observed_at"}) {
    batch.emplace(camel_case(name), producer.get(name));
  }
  batch.emplace("cycle", JsonValue(std::move(graphql_cycle)));
  batch.emplace("observations", JsonValue(std::move(observations)));
  return canonical_json(JsonValue(Object{
                            {"query", JsonValue(kMutation)},
                            {"variables", JsonValue(Object{{"batch", JsonValue(std::move(batch))}})},
                        }),
                        kMaxCycleRequestBytes);
}
std::optional<PreparedCycle> transports(const JsonValue& producer, std::string canonical) {
  const auto* signals = producer.get("signals").array();
  if (signals == nullptr || !cycle_valid(producer.get("cycle"), *signals)) {
    return std::nullopt;
  }
  auto request = graphql_request(producer);
  Object dns_fields;
  for (const auto* const name : {"session_id", "run_id", "batch_id", "observed_at", "cycle", "signals"}) {
    dns_fields.emplace(name, producer.get(name));
  }
  auto dns = canonical_json(JsonValue(std::move(dns_fields)), kMaxCanonicalBytes);
  const auto digest = content_hash(canonical);
  const auto serialization_dropped = decimal_uint(producer.get("cycle").get("serialization_dropped"));
  if (!request.has_value() || !dns.has_value() || !digest.has_value() || !serialization_dropped.has_value()) {
    return std::nullopt;
  }
  return PreparedCycle{
      .canonical = std::move(canonical),
      .request = std::move(*request),
      .dns_json = std::move(*dns),
      .build_id = *producer.get("build_id").text(),
      .install_id = *producer.get("install_id").text(),
      .batch_id = *producer.get("batch_id").text(),
      .digest = *digest,
      .serialization_dropped = *serialization_dropped,
  };
}
}  // namespace
std::optional<PreparedCycle> restore_cycle(std::string_view canonical) {
  const auto producer = parse_json(canonical, kMaxCanonicalBytes);
  if (!producer.has_value() ||
      !keys_are(*producer,
                {
                    "digest_version",
                    "build_id",
                    "install_id",
                    "session_id",
                    "run_id",
                    "batch_id",
                    "observed_at",
                    "cycle",
                    "signals",
                }) ||
      producer->get("digest_version").unsigned_number() != 1 ||
      canonical_json(*producer, kMaxCanonicalBytes) != canonical) {
    return std::nullopt;
  }
  const auto* build = producer->get("build_id").text();
  if (build == nullptr || !full_digest(*build) || !valid_time(producer->get("observed_at"))) {
    return std::nullopt;
  }
  for (const auto* const key : {"install_id", "session_id", "run_id", "batch_id"}) {
    const auto& value = producer->get(key);
    if ((std::string_view(key) == "session_id" || std::string_view(key) == "run_id") && value.null()) {
      continue;
    }
    if (value.text() == nullptr ||
        canonical_uuid(*value.text(), std::string_view(key) == "batch_id") != *value.text()) {
      return std::nullopt;
    }
  }
  return transports(*producer, std::string(canonical));
}
std::optional<PreparedCycle> prepare_cycle(const CycleSnapshot& snapshot, std::string_view build_id,
                                           std::string_view install_id, std::string_view batch_id) {
  if (snapshot.observations.size() > 256 || snapshot.metadata.groups.size() > 64 ||
      snapshot.metadata.missing.size() > 256 || !full_digest(build_id) || canonical_uuid(install_id) != install_id ||
      canonical_uuid(batch_id, true) != batch_id) {
    return std::nullopt;
  }
  if (!bounded_text(snapshot.metadata.platform, 7, true) || !bounded_text(snapshot.metadata.catalogue_id, 64, true)) {
    return std::nullopt;
  }
  for (const auto& group : snapshot.metadata.groups) {
    if (!bounded_text(group.name, 96, true, true)) {
      return std::nullopt;
    }
  }
  for (const auto& identity : snapshot.metadata.missing) {
    if (!bounded_text(identity.signal, 96, true, true) || !bounded_text(identity.source, 64, true, true)) {
      return std::nullopt;
    }
  }
  const auto session = native_uuid(snapshot.metadata.session_id);
  const auto run = native_uuid(snapshot.metadata.run_id);
  const auto time = observed_time(snapshot.metadata.observed_at_unix_ms);
  if (!session.has_value() || !run.has_value() || !time.has_value()) {
    return std::nullopt;
  }
  Array signals;
  std::uint64_t dropped = 0;
  std::size_t text_bytes = 0;
  for (const auto& item : snapshot.observations) {
    auto signal = observation(item);
    auto next_bytes = text_bytes;
    if (!signal.has_value() || !validated_signal_status(*signal, next_bytes).has_value()) {
      ++dropped;
      continue;
    }
    signals.push_back(std::move(*signal));
    if (!canonical_json(JsonValue(signals), static_cast<std::size_t>(96 * 1024)).has_value()) {
      signals.pop_back();
      ++dropped;
      continue;
    }
    text_bytes = next_bytes;
  }
  JsonValue const producer(Object{
      {"digest_version", JsonValue(std::uint64_t{1})},
      {"build_id", JsonValue(build_id)},
      {"install_id", JsonValue(install_id)},
      {"session_id", *session},
      {"run_id", *run},
      {"batch_id", JsonValue(batch_id)},
      {"observed_at", *time},
      {"cycle", cycle_metadata(snapshot.metadata, dropped)},
      {"signals", JsonValue(std::move(signals))},
  });
  const auto canonical = canonical_json(producer, kMaxCanonicalBytes);
  if (!canonical.has_value()) {
    return std::nullopt;
  }
  return restore_cycle(*canonical);
}
}  // namespace rasp::plugins::reporting
