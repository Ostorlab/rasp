/* The reporting TLS island exposes only a bounded leaf callback, never Mbed TLS types. */
#pragma once
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
struct ReportingCertificate {
  const void* bytes;
  size_t length;
  int depth;
  uint32_t flags;
};
struct ReportingVerify {
  void* context;
  int (*check)(void* context, const struct ReportingCertificate* certificate);
};
void rasp_reporting_configure_verify(void* config, struct ReportingVerify* verify);
int rasp_reporting_configure_multi(void* multi);
int rasp_reporting_set_verify(void* easy, struct ReportingVerify* verify);
int rasp_reporting_multi_result(void* multi, int* done);
int rasp_reporting_set_body(void* easy, const void* body, size_t size);
#ifdef __cplusplus
}
#endif
