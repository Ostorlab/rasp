/// Logical legacy retention bound and compaction; the durable cycle outbox has its own independent quota.
#pragma once
#include <optional>
#include <vector>

#include "rasp/observation.h"
namespace rasp::plugins::reporting {
/// Count all statuses/dynamic values and discard caller spare capacities. Nothing when over the legacy budget.
[[nodiscard]] std::optional<std::vector<Observation>> compact_legacy_run(std::vector<Observation> run);
}  // namespace rasp::plugins::reporting
