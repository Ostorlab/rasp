/// Strict bounded JSON used by immutable cycle records; objects retain canonical key order.
#pragma once

#include <cstddef>
#include <cstdint>
#include <initializer_list>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace rasp::plugins::reporting {
/// Owned JSON without floating-point values or borrowed parser storage.
class JsonValue {
 public:
  using Array = std::vector<JsonValue>;
  using Object = std::map<std::string, JsonValue, std::less<>>;
  JsonValue() = default;
  explicit JsonValue(bool item);
  explicit JsonValue(std::int64_t item);
  explicit JsonValue(std::uint64_t item);
  explicit JsonValue(std::string item);
  explicit JsonValue(std::string_view item);
  explicit JsonValue(const char* item);
  explicit JsonValue(Array item);
  explicit JsonValue(Object item);
  /// Returns an owning immutable member handle or null; validate keys before interpreting nullability.
  [[nodiscard]] JsonValue get(std::string_view key) const;
  [[nodiscard]] const std::string* text() const;
  [[nodiscard]] const Array* array() const;
  [[nodiscard]] const Object* object() const;
  [[nodiscard]] std::optional<std::uint64_t> unsigned_number() const;
  [[nodiscard]] std::optional<bool> boolean() const;
  [[nodiscard]] bool null() const;
  [[nodiscard]] const std::int64_t* signed_integer() const;
  [[nodiscard]] const std::uint64_t* unsigned_integer() const;

 private:
  struct Node;
  std::shared_ptr<const Node> node_;
};
/// Parses strict JSON with bounded bytes/depth/node count and duplicate-key rejection.
[[nodiscard]] std::optional<JsonValue> parse_json(std::string_view input, std::size_t limit);
/// Python-compatible sorted-key ASCII compact JSON; invalid UTF8/NUL, excessive depth or size fails.
[[nodiscard]] std::optional<std::string> canonical_json(const JsonValue& value, std::size_t limit);
/// Checks string byte/UTF8/NUL bounds, optionally nonempty ASCII.
[[nodiscard]] bool bounded_text(std::string_view text, std::size_t limit, bool ascii = false, bool nonempty = false);
/// Checks the exact object member set.
[[nodiscard]] bool keys_are(const JsonValue& value, std::initializer_list<std::string_view> keys);
/// Canonical uint64 decimal string, without coercion or leading zeros.
[[nodiscard]] std::optional<std::uint64_t> decimal_uint(const JsonValue& value);
/// Canonical signed64 decimal string, without coercion or leading zeros.
[[nodiscard]] std::optional<std::int64_t> decimal_long(const JsonValue& value);
}  // namespace rasp::plugins::reporting
