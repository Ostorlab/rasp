/// HTTP/1.1 for the transports that speak it themselves: splits the endpoint URL, writes the request of a post, and
/// reads the status line of the answer.

#include "http.h"

#include <algorithm>
#include <cstddef>
#include <optional>
#include <string>
#include <string_view>
#include <utility>

#include "json.h"

namespace rasp::plugins::reporting {

namespace {

/// The scheme of a TLS endpoint, and the port it defaults to.
constexpr std::string_view kHttpsScheme = "https://";
/// The default port of a TLS endpoint.
constexpr std::string_view kHttpsPort = "443";
/// The scheme of a plain endpoint.
constexpr std::string_view kHttpScheme = "http://";
/// The default port of a plain endpoint.
constexpr std::string_view kHttpPort = "80";
/// The highest port number.
constexpr int kMaxPort = 65535;
/// The longest port, in digits.
constexpr std::size_t kMaxPortDigits = 5;

/// Whether a character is a decimal digit.
///
/// @param character The character.
/// @return `true` for `0` to `9`.
[[nodiscard]] bool is_digit(char character) { return character >= '0' && character <= '9'; }

/// Whether a port, as written in a URL, is a number between 1 and 65535.
///
/// @param port The port, without the colon.
/// @return `true` when it is.
[[nodiscard]] bool is_valid_port(std::string_view port) {
  if (port.empty() || port.size() > kMaxPortDigits || !std::ranges::all_of(port, is_digit)) {
    return false;
  }
  int value = 0;
  for (const char digit : port) {
    value = (value * 10) + (digit - '0');
  }
  return value >= 1 && value <= kMaxPort;
}

}  // namespace

std::optional<Endpoint> parse_endpoint(std::string_view url) {
  Endpoint endpoint;
  std::string_view after_scheme;
  std::string_view default_port;
  if (url.starts_with(kHttpsScheme)) {
    endpoint.tls = true;
    after_scheme = url.substr(kHttpsScheme.size());
    default_port = kHttpsPort;
  } else if (url.starts_with(kHttpScheme)) {
    after_scheme = url.substr(kHttpScheme.size());
    default_port = kHttpPort;
  } else {
    return std::nullopt;
  }
  const std::size_t authority_end = std::min(after_scheme.find_first_of("/?#"), after_scheme.size());
  const std::string_view authority = after_scheme.substr(0, authority_end);
  const std::size_t colon = authority.find(':');
  const std::string_view host = authority.substr(0, colon);
  const std::optional<std::string_view> port =
      colon == std::string_view::npos ? std::nullopt : std::optional(authority.substr(colon + 1));
  if (host.empty() || (port.has_value() && !is_valid_port(*port))) {
    return std::nullopt;
  }
  endpoint.host = host;
  endpoint.port = port.value_or(default_port);
  endpoint.authority = authority;
  const std::string_view after_authority = after_scheme.substr(authority_end);
  const std::string_view target = after_authority.substr(0, after_authority.find('#'));
  endpoint.target = target.starts_with('/') ? std::string(target) : "/" + std::string(target);
  return endpoint;
}

std::string make_request(const Endpoint& endpoint, std::string_view body) {
  std::string request = "POST ";
  request.append(endpoint.target);
  request.append(" HTTP/1.1\r\nHost: ");
  request.append(endpoint.authority);
  request.append("\r\nContent-Type: application/json\r\nContent-Length: ");
  request.append(std::to_string(body.size()));
  request.append("\r\nConnection: close\r\n\r\n");
  request.append(body);
  return request;
}

std::optional<int> parse_status(std::string_view status_line) {
  constexpr std::string_view kVersion = "HTTP/1.";
  constexpr std::size_t kCodeStart = kVersion.size() + 2;
  constexpr std::size_t kCodeDigits = 3;
  if (!status_line.starts_with(kVersion) || status_line.size() < kCodeStart + kCodeDigits ||
      !is_digit(status_line[kVersion.size()]) || status_line[kVersion.size() + 1] != ' ') {
    return std::nullopt;
  }
  const std::string_view code = status_line.substr(kCodeStart, kCodeDigits);
  if (!std::ranges::all_of(code, is_digit) ||
      (status_line.size() > kCodeStart + kCodeDigits && status_line[kCodeStart + kCodeDigits] != ' ')) {
    return std::nullopt;
  }
  return ((code[0] - '0') * 100) + ((code[1] - '0') * 10) + (code[2] - '0');
}

namespace {
constexpr std::size_t kMaxHeaderSize = std::size_t{16} * 1024;
constexpr std::size_t kMaxWireSize = std::size_t{96} * 1024;

/// Whether a field name or chunk extension character is an HTTP token character.
[[nodiscard]] bool token_character(char character) {
  return (character >= 'a' && character <= 'z') || (character >= 'A' && character <= 'Z') ||
         (character >= '0' && character <= '9') || std::string_view("!#$%&'*+-.^_`|~").contains(character);
}

/// Normalizes ASCII header names and coding tokens without changing locale.
[[nodiscard]] std::string lowercase(std::string_view text) {
  std::string result(text);
  for (char& character : result) {
    if (character >= 'A' && character <= 'Z') {
      character = static_cast<char>(character + ('a' - 'A'));
    }
  }
  return result;
}

/// Removes optional HTTP whitespace around a header value.
[[nodiscard]] std::string_view trim(std::string_view text) {
  const std::size_t first = text.find_first_not_of(" \t");
  return first == std::string_view::npos ? std::string_view{}
                                         : text.substr(first, text.find_last_not_of(" \t") - first + 1);
}

/// Parses one field line, rejecting folding, whitespace in the name and invalid control bytes.
[[nodiscard]] std::optional<std::pair<std::string, std::string_view>> field(std::string_view line) {
  const std::size_t colon = line.find(':');
  if (colon == std::string_view::npos || colon == 0 || !std::ranges::all_of(line.substr(0, colon), token_character)) {
    return std::nullopt;
  }
  const std::string_view contents = line.substr(colon + 1);
  for (const char character : contents) {
    const auto byte = static_cast<unsigned char>(character);
    if ((byte < 0x20 && byte != '\t') || byte == 0x7F) {
      return std::nullopt;
    }
  }
  return std::pair(lowercase(line.substr(0, colon)), trim(contents));
}

/// Reads a decimal length or hexadecimal chunk size without exceeding the response body limit.
[[nodiscard]] std::optional<std::size_t> bounded_number(std::string_view text, std::size_t base) {
  if (text.empty()) {
    return std::nullopt;
  }
  std::size_t number = 0;
  for (const char character : lowercase(text)) {
    const std::size_t digit = std::string_view("0123456789abcdef").find(character);
    if (digit >= base || number > (kMaxResponseSize - digit) / base) {
      return std::nullopt;
    }
    number = (number * base) + digit;
  }
  return number;
}

/// Consumes one nonempty token from the front of a chunk extension.
[[nodiscard]] bool take_token(std::string_view& text) {
  const std::size_t end =
      text.find_first_not_of("!#$%&'*+-.^_`|~0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
  const std::size_t length = end == std::string_view::npos ? text.size() : end;
  text.remove_prefix(length);
  return length != 0;
}

/// Consumes a quoted extension value, validating escapes and control bytes.
[[nodiscard]] bool take_quoted(std::string_view& text) {
  text.remove_prefix(1);
  while (!text.empty()) {
    char character = text.front();
    text.remove_prefix(1);
    if (character == '"') {
      return true;
    }
    if (character == '\\') {
      if (text.empty()) {
        return false;
      }
      character = text.front();
      text.remove_prefix(1);
    }
    const auto byte = static_cast<unsigned char>(character);
    if ((byte < 0x20 && byte != '\t') || byte == 0x7F) {
      return false;
    }
  }
  return false;
}

/// Validates bounded chunk extensions without interpreting their values.
[[nodiscard]] bool chunk_extensions(std::string_view text) {
  while (!text.empty()) {
    if (text.front() != ';') {
      return false;
    }
    text.remove_prefix(1);
    text = trim(text);
    if (!take_token(text)) {
      return false;
    }
    text = trim(text);
    if (text.empty() || text.front() == ';') {
      continue;
    }
    if (text.front() != '=') {
      return false;
    }
    text.remove_prefix(1);
    text = trim(text);
    if (text.starts_with('"') ? !take_quoted(text) : !take_token(text)) {
      return false;
    }
    text = trim(text);
  }
  return true;
}

/// The framing fields of one response; duplicate or conflicting framing fails.
struct ResponseFields {
  std::optional<std::size_t> length;
  bool chunked = false;
  bool encoding = false;
};

/// Adds one supported framing/coding field, rejecting duplicate or unsupported encodings.
[[nodiscard]] bool read_field(ResponseFields& fields, const std::pair<std::string, std::string_view>& header) {
  const auto& [name, contents] = header;
  if (name == "content-length") {
    if (fields.length.has_value()) {
      return false;
    }
    fields.length = bounded_number(contents, 10);
    return fields.length.has_value();
  }
  if (name == "transfer-encoding") {
    if (fields.chunked || lowercase(contents) != "chunked") {
      return false;
    }
    fields.chunked = true;
  } else if (name == "content-encoding") {
    if (fields.encoding || lowercase(contents) != "identity") {
      return false;
    }
    fields.encoding = true;
  }
  return true;
}

/// Reads the complete header block after its status line.
[[nodiscard]] std::optional<ResponseFields> read_fields(std::string_view block) {
  ResponseFields fields;
  while (!block.empty()) {
    const std::size_t end = block.find("\r\n");
    if (end == std::string_view::npos) {
      return std::nullopt;
    }
    const auto header = field(block.substr(0, end));
    if (!header.has_value() || !read_field(fields, *header)) {
      return std::nullopt;
    }
    block.remove_prefix(end + 2);
  }
  return fields;
}

/// Accepts final HTTP/1.0 or HTTP/1.1 2xx status lines that may carry an acknowledgement body.
[[nodiscard]] bool valid_status(std::string_view line) {
  const std::optional<int> status = parse_status(line);
  if ((!line.starts_with("HTTP/1.0 ") && !line.starts_with("HTTP/1.1 ")) || !status.has_value() || *status < 200 ||
      *status >= 300 || *status == 204 || *status == 205) {
    return false;
  }
  return std::ranges::all_of(line, [](unsigned char byte) { return (byte >= 0x20 && byte != 0x7F) || byte == '\t'; });
}
}  // namespace

bool HttpResponse::headers(std::string_view block) {
  const std::size_t first_end = block.find("\r\n");
  if (first_end == std::string_view::npos || first_end + 2 > kMaxStatusLineSize) {
    return false;
  }
  const std::string_view status_line = block.substr(0, first_end);
  const std::optional<ResponseFields> fields = read_fields(block.substr(first_end + 2));
  if (!valid_status(status_line) || !fields.has_value() ||
      (fields->chunked && (fields->length.has_value() || status_line.starts_with("HTTP/1.0")))) {
    return false;
  }
  if (fields->chunked) {
    framing_ = Framing::kChunkSize;
  } else {
    framing_ = fields->length.has_value() ? Framing::kLength : Framing::kClose;
  }
  remaining_ = fields->length.value_or(0);
  return true;
}

void HttpResponse::read_headers(std::string_view pending) {
  const std::size_t end = pending.find("\r\n\r\n");
  if (end == std::string_view::npos) {
    if (pending.size() >= kMaxHeaderSize) {
      state_ = State::kFailed;
    }
    return;
  }
  if (end + 4 > kMaxHeaderSize || !headers(pending.substr(0, end + 2))) {
    state_ = State::kFailed;
    return;
  }
  position_ += end + 4;
}

void HttpResponse::read_body(std::string_view pending) {
  if ((framing_ == Framing::kLength && pending.size() > remaining_) ||
      append_response(body_, pending.data(), 1, pending.size()) != pending.size()) {
    state_ = State::kFailed;
    return;
  }
  position_ += pending.size();
  if (framing_ == Framing::kLength) {
    remaining_ -= pending.size();
    if (remaining_ == 0) {
      state_ = State::kComplete;
    }
  }
}

void HttpResponse::read_chunk(std::string_view pending) {
  if (pending.size() < remaining_ + 2) {
    return;
  }
  const std::string_view chunk = pending.substr(0, remaining_);
  if (pending.substr(remaining_, 2) != "\r\n" ||
      append_response(body_, chunk.data(), 1, chunk.size()) != chunk.size()) {
    state_ = State::kFailed;
    return;
  }
  position_ += remaining_ + 2;
  framing_ = Framing::kChunkSize;
}

void HttpResponse::read_chunk_size(std::string_view line) {
  const std::size_t extension = line.find(';');
  const std::string_view digits = line.substr(0, extension);
  const std::optional<std::size_t> length =
      bounded_number(extension == std::string_view::npos ? digits : trim(digits), 16);
  if (!length.has_value() || *length > kMaxResponseSize - body_.size() ||
      (extension != std::string_view::npos && !chunk_extensions(line.substr(extension)))) {
    state_ = State::kFailed;
    return;
  }
  remaining_ = *length;
  framing_ = remaining_ == 0 ? Framing::kTrailers : Framing::kChunkData;
}

void HttpResponse::read_trailer(std::string_view line) {
  if (line.empty()) {
    state_ = position_ == wire_.size() ? State::kComplete : State::kFailed;
    return;
  }
  const auto trailer = field(line);
  if (!trailer.has_value() || trailer->first == "content-length" || trailer->first == "transfer-encoding" ||
      trailer->first == "content-encoding") {
    state_ = State::kFailed;
  }
}

void HttpResponse::read_line(std::string_view pending) {
  const std::size_t end = pending.find("\r\n");
  if (end == std::string_view::npos) {
    if (pending.size() >= kMaxHeaderSize) {
      state_ = State::kFailed;
    }
    return;
  }
  if (end + 2 > kMaxHeaderSize) {
    state_ = State::kFailed;
    return;
  }
  position_ += end + 2;
  if (framing_ == Framing::kTrailers) {
    read_trailer(pending.substr(0, end));
  } else {
    read_chunk_size(pending.substr(0, end));
  }
}

void HttpResponse::process() {
  while (state_ == State::kReading) {
    const std::size_t start = position_;
    const std::string_view pending = std::string_view(wire_).substr(position_);
    switch (framing_) {
      case Framing::kHeaders:
        read_headers(pending);
        break;
      case Framing::kClose:
      case Framing::kLength:
        read_body(pending);
        break;
      case Framing::kChunkData:
        read_chunk(pending);
        break;
      case Framing::kChunkSize:
      case Framing::kTrailers:
        read_line(pending);
        break;
    }
    if (position_ == start) {
      return;
    }
  }
}

HttpResponse::State HttpResponse::read(std::string_view bytes, bool eof, bool failed) {
  if (failed || state_ == State::kFailed || (state_ == State::kComplete && !bytes.empty()) ||
      bytes.size() > kMaxWireSize - wire_.size()) {
    state_ = State::kFailed;
    return state_;
  }
  wire_.append(bytes);
  process();
  if (eof && state_ == State::kReading) {
    state_ = framing_ == Framing::kClose ? State::kComplete : State::kFailed;
  }
  return state_;
}

bool HttpResponse::successful() const { return state_ == State::kComplete && acknowledged(body_); }

}  // namespace rasp::plugins::reporting
