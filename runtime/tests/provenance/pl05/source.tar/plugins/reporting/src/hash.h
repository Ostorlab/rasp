/// Platform SHA256 and secure UUID support for immutable records.
#pragma once
#include <array>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <string_view>
namespace rasp::plugins::reporting {
using Digest = std::array<std::uint8_t, 32>;
/// Returns SHA256 bytes or explicit platform failure.
[[nodiscard]] std::optional<Digest> content_hash(std::string_view bytes);
/// Fills at most256 bytes using the checked public OS entropy API; no fallback or retry loop.
[[nodiscard]] bool secure_random(std::span<std::uint8_t> bytes);
/// Returns a fresh secure nonzero RFC4122-v4 batch UUID, or entropy unavailable.
[[nodiscard]] std::optional<std::string> new_batch_id();
/// Canonical UUID normalization; nil is unavailable only when explicitly allowed by the caller.
[[nodiscard]] std::optional<std::string> canonical_uuid(std::string_view text, bool v4 = false);
/// Validates a full lowercase64-character build/digest identifier.
[[nodiscard]] bool full_digest(std::string_view text);
}  // namespace rasp::plugins::reporting
