/// Native integration producer: real CycleMonitor, production serializer/outbox and DNS-v2 encoder; no network.
#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <ios>
#include <limits>
#include <rasp/config.h>
#include <rasp/context.h>
#include <rasp/observation.h>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "collection_authority.h"
#include "cycle_dns.h"
#include "cycle_payload.h"
#include "hash.h"
#include "outbox.h"
#include "rasp/cycle.h"
#include "rasp/plugin.h"
#include "rasp/posix/private_storage.h"

namespace {
using namespace rasp::plugins;
rasp::CycleClockReading fixed_clock() { return {.monotonic_ns = 10, .unix_ms = 1794484800123LL}; }
std::vector<rasp::Observation> outputs(const rasp::Config& /*unused*/, const void* argument) {
  const auto& catalogue = *static_cast<const rasp::CycleCatalogue*>(argument);
  std::vector<rasp::Observation> rows;
  std::size_t index = 0;
  for (const auto& item : catalogue.outputs) {
    const auto status = static_cast<rasp::Status>(index % 4);
    rasp::Value value;
    if (status == rasp::Status::kOk) {
      switch ((index / 4) % 7) {
        case 0:
          value = std::numeric_limits<std::int64_t>::max();
          break;
        case 1:
          value = std::numeric_limits<std::int64_t>::min();
          break;
        case 2:
          value = std::int64_t{0};
          break;
        case 3:
          value = false;
          break;
        case 4:
          value = std::string("é😀\n\t\x7f");
          break;
        case 5:
          value = std::vector<std::string>{"", "é😀"};
          break;
        default:
          value = std::string{};
      }
    }
    rows.push_back({
        .signal = std::string(item.signal),
        .source = std::string(item.source),
        .status = status,
        .value = std::move(value),
    });
    ++index;
  }
  return rows;
}
bool write_file(const std::filesystem::path& path, std::string_view bytes) {
  std::ofstream output(path, std::ios::binary);
  output.write(bytes.data(), static_cast<std::streamsize>(bytes.size()));
  output.close();
  return !output.fail();
}
bool emit(reporting::Outbox& outbox, const std::filesystem::path& root, std::string_view name,
          const rasp::CycleSnapshot& snapshot, std::string_view install_id) {
  const auto batch = reporting::new_batch_id();
  if (!batch.has_value()) {
    return false;
  }
  const auto payload = reporting::prepare_cycle(snapshot, std::string(64, 'b'), install_id, *batch);
  const auto binding = reporting::collection_authority({
      .endpoint = "https://reports.example.com/rasp",
      .policy = "default",
      .zone = "rsp.example.com",
      .dns_policy = "default",
  });
  if (!payload.has_value() || !binding.has_value()) {
    return false;
  }
  const auto saved = outbox.persist(*payload, *binding);
  if (!saved.has_value()) {
    return false;
  }
  const auto scan = outbox.scan();
  if (!scan.has_value()) {
    return false;
  }
  const auto record = std::ranges::find_if(scan->records, [&saved](const auto& item) { return item.token == *saved; });
  if (record == scan->records.end() || record->payload->canonical != payload->canonical) {
    return false;
  }
  const auto binary = dns_reporting::build_cycle_payload(*record->payload, {0x9a, 0x3c, 0x51, 0xe7}, 7560);
  const auto names =
      dns_reporting::build_cycle_report(*record->payload, record->authority, {0x9a, 0x3c, 0x51, 0xe7}, 7560);
  const bool dns_fits = record->payload->dns_json.size() <= 30048;
  if (binary.empty() == dns_fits || names.empty() == dns_fits) {
    return false;
  }
  std::string dns_names;
  for (const auto& query : names) {
    dns_names += query + "\n";
  }
  std::string wire;
  wire.reserve(binary.size());
  for (const auto byte : binary) {
    wire += static_cast<char>(byte);
  }
  const auto destination = root / name;
  std::filesystem::create_directory(destination);
  return write_file(destination / "canonical.json", record->payload->canonical) &&
         write_file(destination / "request.json", record->payload->request) &&
         write_file(destination / "dns.json", record->payload->dns_json) && write_file(destination / "dns.bin", wire) &&
         write_file(destination / "dns.names", dns_names);
}
bool emit_boundary(reporting::Outbox& outbox, const std::filesystem::path& root, const rasp::CycleSnapshot& original,
                   std::string_view install_id, std::size_t size) {
  auto snapshot = original;
  std::vector<std::string> strings(32);
  snapshot.observations[0].value = strings;
  constexpr auto kBatch = "41d9ba09-4fb1-46f0-9a1f-308cf631da1e";
  const auto base = reporting::prepare_cycle(snapshot, std::string(64, 'b'), install_id, kBatch);
  if (!base.has_value() || base->dns_json.size() > size) {
    return false;
  }
  auto padding = size - base->dns_json.size();
  for (auto& text : strings) {
    const auto count = std::min(padding, std::size_t{1024});
    text.assign(count, 'a');
    padding -= count;
  }
  snapshot.observations[0].value = std::move(strings);
  const auto payload = reporting::prepare_cycle(snapshot, std::string(64, 'b'), install_id, kBatch);
  if (padding != 0 || !payload.has_value() || payload->dns_json.size() != size) {
    return false;
  }
  return emit(outbox, root, size == 30048 ? "dns-boundary" : "dns-oversize", snapshot, install_id);
}
}  // namespace
int main(int count, char* const* arguments) {
  if (count != 2) {
    return 2;
  }
  const std::filesystem::path root(std::span(arguments, static_cast<std::size_t>(count))[1]);
  std::filesystem::create_directories(root / "storage");
  std::filesystem::permissions(root / "storage", std::filesystem::perms::owner_all);
  auto storage = rasp::posix::acquire_private_storage_at((root / "storage").string());
  if (!storage.has_value()) {
    return 3;
  }
  reporting::Outbox outbox(storage->native_handle(), std::string(storage->install_id()));
  if (!outbox.initialize().has_value()) {
    return 4;
  }
  rasp::Config config{.build_id = std::string(64, 'b'), .checks = std::vector<std::string>{}};
  const auto catalogue = rasp::cycle_catalogue("android");
  if (catalogue.outputs.size() != 46 ||
      catalogue.catalogue_id != "28b4aec16ad42aacb089d0a7d47fac6468a4d6823641f0713939d2bcd4cc78d4") {
    return 5;
  }
  for (const auto& item : catalogue.outputs) {
    if (std::ranges::find(*config.checks, item.group) == config.checks->end()) {
      config.checks->emplace_back(item.group);
    }
  }
  rasp::CycleMonitor monitor(fixed_clock);
  rasp::plugins::Context context;
  const std::array<const rasp::plugins::Plugin*, 0> plugins{};
  const auto full = monitor.run(config, catalogue, plugins, context, outputs, &catalogue);
  if (!full->metadata.complete || !emit(outbox, root, "complete", *full, storage->install_id())) {
    return 6;
  }
  config.checks->clear();
  const auto empty = monitor.run(config, catalogue, plugins, context,
                                 [](const rasp::Config&, const void*) { return std::vector<rasp::Observation>{}; });
  if (!empty->metadata.complete || !emit(outbox, root, "empty", *empty, storage->install_id())) {
    return 7;
  }
  auto unavailable = *empty;
  unavailable.metadata.session_id.clear();
  unavailable.metadata.run_id.clear();
  unavailable.metadata.observed_at_unix_ms.reset();
  if (!emit(outbox, root, "unavailable-identities", unavailable, storage->install_id())) {
    return 8;
  }
  auto maxima = unavailable;
  maxima.metadata.complete = false;
  maxima.metadata.sequence = UINT64_MAX;
  maxima.metadata.duration_ns = UINT64_MAX;
  maxima.metadata.unknown_groups = UINT64_MAX;
  if (!emit(outbox, root, "uint64-max", maxima, storage->install_id())) {
    return 9;
  }
  const std::array<rasp::CycleOutput, 1> narrow{
      {
          {
              .group = "dbg",
              .signal = "dbg.source_bound",
              .source = std::string_view("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"),
          },
      },
  };
  const rasp::CycleCatalogue narrow_catalogue{
      .platform = "android",
      .catalogue_id = catalogue.catalogue_id,
      .outputs = narrow,
  };
  config.checks = std::vector<std::string>{"dbg"};
  const auto loss = monitor.run(config, narrow_catalogue, plugins, context, outputs, &narrow_catalogue);
  if (!loss->metadata.complete || !emit(outbox, root, "serializer-loss", *loss, storage->install_id())) {
    return 10;
  }
  if (!emit_boundary(outbox, root, *full, storage->install_id(), 30048) ||
      !emit_boundary(outbox, root, *full, storage->install_id(), 30049)) {
    return 12;
  }
  return outbox.close().has_value() && storage->close().has_value() ? 0 : 11;
}
