# The reporting plugin's tests, which run on a development machine. The plugin's CMakeLists.txt includes this file at
# the end of the build's top directory, once the build has fetched GoogleTest and enabled the tests.

include(GoogleTest)
find_package(Python3 3.10 REQUIRED COMPONENTS Interpreter)

# GoogleTest constructs factories defined by the no-RTTI tests. Match their language settings so UBSan does not
# require RTTI from those factories during discovery. This applies to standalone and runtime test builds.
target_link_libraries(gtest PRIVATE rasp_language)
target_link_libraries(gtest_main PRIVATE rasp_language)

foreach(test http json json_value mailbox sender collection_authority cycle_payload outbox cycle_delivery security_profile peer_key)
  add_executable(rasp_reporting_${test}_test ${CMAKE_CURRENT_LIST_DIR}/${test}_test.cpp)
  target_include_directories(rasp_reporting_${test}_test PRIVATE ${CMAKE_CURRENT_LIST_DIR}/../src)
  target_link_libraries(rasp_reporting_${test}_test PRIVATE rasp_plugin_reporting rasp_core rasp_warnings
    rasp_language GTest::gtest_main)
  gtest_discover_tests(rasp_reporting_${test}_test)
endforeach()
target_compile_definitions(rasp_reporting_peer_key_test PRIVATE
  RASP_PEER_KEY_FIXTURES="${CMAKE_CURRENT_LIST_DIR}/../../adr_pin/tests/data")
target_compile_definitions(rasp_reporting_cycle_payload_test PRIVATE
  RASP_CYCLE_FIXTURES="${CMAKE_CURRENT_LIST_DIR}/fixtures")
if(CMAKE_SYSTEM_NAME STREQUAL "Linux")
  add_executable(rasp_reporting_outbox_fault_test ${CMAKE_CURRENT_LIST_DIR}/outbox_fault_test.cpp)
  target_include_directories(rasp_reporting_outbox_fault_test PRIVATE ${CMAKE_CURRENT_LIST_DIR}/../src)
  target_link_libraries(rasp_reporting_outbox_fault_test PRIVATE rasp_plugin_reporting rasp_core rasp_warnings rasp_language GTest::gtest_main)
  target_link_options(rasp_reporting_outbox_fault_test PRIVATE
    -Wl,--wrap=openat -Wl,--wrap=pwrite -Wl,--wrap=fsync -Wl,--wrap=close -Wl,--wrap=linkat -Wl,--wrap=unlinkat)
  gtest_discover_tests(rasp_reporting_outbox_fault_test)
endif()

# reporting_test.cpp defines the transport's `post` itself, so the plugin posts to the test, and the linker leaves the
# development transport, src/dev/transport.cpp, out of the plugin's static library.
add_executable(rasp_reporting_test ${CMAKE_CURRENT_LIST_DIR}/reporting_test.cpp)
target_include_directories(rasp_reporting_test PRIVATE ${CMAKE_CURRENT_LIST_DIR}/../src)
target_link_libraries(rasp_reporting_test PRIVATE rasp_plugin_reporting rasp_core rasp_warnings rasp_language
  GTest::gtest_main)
target_compile_definitions(rasp_reporting_test PRIVATE
  RASP_REPORTING_ENDPOINT="${RASP_REPORTING_ENDPOINT}")
gtest_discover_tests(rasp_reporting_test)

# Compile the production platform transport, replacing only the remote server. On macOS this exercises the same
# Network.framework code as iOS. Other hosts exercise Android's transport with the pinned curl/Mbed TLS build.
if(NOT CMAKE_SYSTEM_NAME STREQUAL "Android" AND NOT CMAKE_SYSTEM_NAME STREQUAL "iOS")
  if(APPLE)
    set(rasp_reporting_native_transport ${CMAKE_CURRENT_LIST_DIR}/../src/ios/transport.cpp
      ${CMAKE_CURRENT_LIST_DIR}/../src/ios/trust.cpp ${CMAKE_CURRENT_LIST_DIR}/../src/ios/certificate_ref.c)
  else()
    set(rasp_reporting_native_transport ${CMAKE_CURRENT_LIST_DIR}/../src/android/transport.cpp)
  endif()
  add_executable(rasp_reporting_transport_test ${CMAKE_CURRENT_LIST_DIR}/transport_test.cpp
    ${rasp_reporting_native_transport})
  target_include_directories(rasp_reporting_transport_test PRIVATE ${CMAKE_CURRENT_LIST_DIR}/../src ${CMAKE_CURRENT_LIST_DIR})
  target_compile_definitions(rasp_reporting_transport_test PRIVATE RASP_REPORTING_TRANSPORT_TEST=1)
  target_link_libraries(rasp_reporting_transport_test PRIVATE rasp_plugin_reporting rasp_core rasp_warnings
    rasp_language GTest::gtest_main)
  if(APPLE)
    target_sources(rasp_reporting_transport_test PRIVATE ${CMAKE_CURRENT_LIST_DIR}/ios_trust_test.cpp)
    target_compile_definitions(rasp_reporting_transport_test PRIVATE
      RASP_PEER_KEY_FIXTURES="${CMAKE_CURRENT_LIST_DIR}/../../adr_pin/tests/data")
    target_compile_options(rasp_reporting_transport_test PRIVATE -fblocks)
    target_link_libraries(rasp_reporting_transport_test PRIVATE "$<LINK_LIBRARY:FRAMEWORK,Network>"
      "$<LINK_LIBRARY:FRAMEWORK,Security>" "$<LINK_LIBRARY:FRAMEWORK,CoreFoundation>")
  else()
    target_link_libraries(rasp_reporting_transport_test PRIVATE libcurl_static)
  endif()
  gtest_discover_tests(rasp_reporting_transport_test)
  # Rename only this separately compiled copy of the actual UTC implementation. The fixture forwards to it until
  # an external handoff clock fault is requested; production libraries keep their original clock implementation.
  add_library(rasp_reporting_test_clock STATIC ${CMAKE_CURRENT_LIST_DIR}/../src/security_time.c)
  target_compile_definitions(rasp_reporting_test_clock PRIVATE
    rasp_reporting_utc_seconds=reporting_test_real_utc_seconds)
  add_executable(rasp_reporting_tls_client ${CMAKE_CURRENT_LIST_DIR}/tls_client.cpp ${CMAKE_CURRENT_LIST_DIR}/fixture_io.c ${rasp_reporting_native_transport})
  target_include_directories(rasp_reporting_tls_client PRIVATE ${CMAKE_CURRENT_LIST_DIR}/../src ${CMAKE_CURRENT_LIST_DIR})
  target_compile_definitions(rasp_reporting_tls_client PRIVATE RASP_REPORTING_TRANSPORT_TEST=1)
  target_link_libraries(rasp_reporting_tls_client PRIVATE rasp_plugin_reporting rasp_core rasp_warnings rasp_language rasp_reporting_test_clock)
  if(APPLE)
    target_compile_options(rasp_reporting_tls_client PRIVATE -fblocks)
    target_link_libraries(rasp_reporting_tls_client PRIVATE "$<LINK_LIBRARY:FRAMEWORK,Network>"
      "$<LINK_LIBRARY:FRAMEWORK,Security>" "$<LINK_LIBRARY:FRAMEWORK,CoreFoundation>")
  else()
    target_link_libraries(rasp_reporting_tls_client PRIVATE libcurl_static)
    target_sources(rasp_reporting_tls_client PRIVATE ${CMAKE_CURRENT_LIST_DIR}/resolver_fixture.c)
    target_link_options(rasp_reporting_tls_client PRIVATE -Wl,--wrap=getaddrinfo)
  endif()
  add_test(NAME ReportingTls.actualSenderOutbox COMMAND ${Python3_EXECUTABLE}
    ${CMAKE_CURRENT_LIST_DIR}/tls_transport_test.py $<TARGET_FILE:rasp_reporting_tls_client>)
  set_tests_properties(ReportingTls.actualSenderOutbox PROPERTIES TIMEOUT 180 RUN_SERIAL TRUE)
endif()
