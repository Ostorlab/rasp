/// Test-only owned phase handoff. These flags never stand in for a Security decision or callback.
#pragma once
#include <chrono>
#include <condition_variable>
#include <mutex>
#include <utility>

namespace rasp::plugins::reporting {
class VerificationFixture {
 public:
  struct Progress {
    bool committed = false;
    bool terminal = false;
    bool api_returned = false;
    bool submitted = false;
    bool retired = false;
    bool callback = false;
    bool early = false;
    unsigned failures = 0;
  };
  explicit VerificationFixture(bool hold) : hold_evaluation_(hold) {}
  [[nodiscard]] bool holds_evaluation() const { return hold_evaluation_; }

  void commit_owned_work() {
    const std::scoped_lock lock(mutex_);
    progress_.committed = true;
    changed_.notify_all();
  }
  void terminal_cleanup() {
    const std::scoped_lock lock(mutex_);
    progress_.terminal = true;
    changed_.notify_all();
  }
  void release() {
    const std::scoped_lock lock(mutex_);
    released_ = true;
    changed_.notify_all();
  }
  void api_returned(bool submitted) {
    const std::scoped_lock lock(mutex_);
    progress_.api_returned = true;
    progress_.submitted = submitted;
    if (!submitted) {
      ++progress_.failures;
      progress_.retired = true;
    }
    changed_.notify_all();
  }
  void callback_retired() {
    const std::scoped_lock lock(mutex_);
    progress_.callback = true;
    progress_.retired = true;
    changed_.notify_all();
  }
  void early_retired() {
    const std::scoped_lock lock(mutex_);
    progress_.early = true;
    progress_.retired = true;
    changed_.notify_all();
  }
  void fail_phase() {
    const std::scoped_lock lock(mutex_);
    ++progress_.failures;
  }
  [[nodiscard]] bool await_committed() {
    return await([this] { return progress_.committed; });
  }
  [[nodiscard]] bool await_terminal() {
    return await([this] { return progress_.terminal; });
  }
  [[nodiscard]] bool await_release() {
    return await([this] { return released_; });
  }
  [[nodiscard]] bool await_retired() {
    return await([this] { return progress_.retired && progress_.api_returned; });
  }
  [[nodiscard]] bool await_early_retirement() {
    return await([this] { return progress_.early; });
  }
  [[nodiscard]] Progress progress() {
    const std::scoped_lock lock(mutex_);
    return progress_;
  }

 private:
  const bool hold_evaluation_;
  template <typename Condition>
  bool await(Condition holds) {
    std::unique_lock lock(mutex_);
    if (!changed_.wait_for(lock, std::chrono::seconds(5), std::move(holds))) {
      ++progress_.failures;
      return false;
    }
    return true;
  }
  std::mutex mutex_;
  std::condition_variable changed_;
  Progress progress_;
  bool released_ = false;
};
}  // namespace rasp::plugins::reporting
