#include "json_value.h"

#include <gtest/gtest.h>

namespace rasp::plugins::reporting {
TEST(JsonValue, canonical_whenUnicodeAndKeysUnsorted_emitsPythonCompatibleAscii) {
  const auto parsed = parse_json("{\"z\":[true,null,-7,\"é😀\"],\"a\":0}", 1024);
  ASSERT_TRUE(parsed.has_value());
  EXPECT_EQ(canonical_json(*parsed, 1024), "{\"a\":0,\"z\":[true,null,-7,\"\\u00e9\\ud83d\\ude00\"]}");
}
TEST(JsonValue, parse_whenDuplicateDeepFloatOrNul_rejectsWithinBounds) {
  for (const auto* value : {R"({"a":1,"a":2})", "1.5", R"("\u0000")", R"("\ud800")"}) {
    EXPECT_FALSE(parse_json(value, 1024).has_value());
  }
  EXPECT_FALSE(parse_json(std::string(18, '[') + "0" + std::string(18, ']'), 1024).has_value());
  const auto parsed = parse_json("[1,2,3]", 1024);
  ASSERT_TRUE(parsed.has_value());
  EXPECT_FALSE(canonical_json(*parsed, 6).has_value());
}
TEST(JsonValue, ownership_whenCallerReplacesChildren_retainsImmutableOwnedMembers) {
  JsonValue::Array source{JsonValue("original")};
  const JsonValue owned(source);
  source[0] = JsonValue("changed");
  EXPECT_EQ(canonical_json(owned, 1024), "[\"original\"]");
}
}  // namespace rasp::plugins::reporting
