/// External process-input and resolver ABI seams, linked only into the TLS fixture executable.
#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
int64_t reporting_test_real_utc_seconds(void);
void reporting_test_advance_clock(int64_t seconds);
void reporting_test_unavailable_clock(void);
const char* reporting_test_environment(const char* name);
unsigned reporting_test_resolver_peak(void);
void reporting_test_resolver_release(void);
#ifdef __cplusplus
}
#endif
