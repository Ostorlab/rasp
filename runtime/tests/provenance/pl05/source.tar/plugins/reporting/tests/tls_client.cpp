/// Actual platform sender through the actual provider-backed outbox; only server, storage root and clock are fixtures.
#include <atomic>
#include <charconv>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <expected>
#include <iostream>
#include <memory>
#include <span>
#include <string>
#include <string_view>
#include <system_error>
#include <thread>
#include <utility>
#include <vector>

#include "collection_authority.h"
#include "config.h"
#include "cycle_delivery.h"
#include "cycle_payload.h"
#include "fixture_io.h"
#include "hash.h"
#include "json_value.h"
#include "outbox.h"
#include "rasp/context.h"
#include "rasp/cycle.h"
#include "rasp/observation.h"
#include "rasp/posix/private_storage.h"
#include "rasp/private_storage.h"
#include "reporting/delivery.h"
#include "reporting/fallback_authorization.h"
#include "reporting/transport_result.h"
#include "reporting/undelivered_run.h"
#include "sender.h"
#include "transport.h"
#include "transport_fixture.h"

namespace rasp::plugins::reporting {
namespace {
struct FixtureState {
  TransportFixture fixture;
  std::string storage_path;
  std::int64_t ticks = 0;
  TransportResult result = TransportResult::kPublicationUnconfirmed;
  std::uint64_t dns_handoffs = 0;
  std::atomic<unsigned> queued_sends{0};
  CycleDelivery* worker = nullptr;
  Sender* legacy = nullptr;
  int clock_at_handoff = 0;
  bool cancel_at_handoff = false;
  int cancel_ms = -1;
  std::int64_t transport_ms = 0;
  std::string posted_request;
  bool mismatch_dns_at_handoff = false;
  std::shared_ptr<const PreparedCycle> dns_payload;
  std::string dns_authority;
  std::shared_ptr<const FallbackAuthorization> dns_authorization;
};
FixtureState& fixture_state() {
  static FixtureState state;
  return state;
}
constexpr auto kFallbackEnqueue = +[](std::shared_ptr<const PreparedCycle> payload,
                                      std::shared_ptr<const FallbackAuthorization> authorization) noexcept {
  if (payload == nullptr || authorization == nullptr || authorization->authority().empty()) {
    return false;
  }
  fixture_state().dns_payload = std::move(payload);
  fixture_state().dns_authority = authorization->authority();
  fixture_state().dns_authorization = std::move(authorization);
  ++fixture_state().dns_handoffs;
  return true;
};
int milliseconds(std::string_view value) {
  int result = -1;
  const auto parsed = std::from_chars(std::to_address(value.begin()), std::to_address(value.end()), result);
  return parsed.ec == std::errc{} && parsed.ptr == std::to_address(value.end()) ? result : -1;
}
std::int64_t fixture_clock() { return fixture_state().ticks; }
std::expected<PrivateStorage, StorageError> acquire() {
  return rasp::posix::acquire_private_storage_at(fixture_state().storage_path);
}
TransportResult capture(const Config& config, std::string_view body, Cancellation cancellation) noexcept {
  auto& state = fixture_state();
  state.posted_request = body;
  std::jthread cancel;
  if (state.cancel_ms >= 0) {
    cancel = std::jthread([worker = state.worker, legacy = state.legacy, delay = state.cancel_ms] {
      std::this_thread::sleep_for(std::chrono::milliseconds(delay));
      if (worker != nullptr) {
        worker->stop();
      } else if (legacy != nullptr) {
        legacy->cancelled.request();
      }
    });
  }
  const auto started = std::chrono::steady_clock::now();
  state.result = post(config, body, cancellation);
  state.transport_ms =
      std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - started).count();
  if (state.clock_at_handoff == 1) {
    reporting_test_advance_clock(7200);
  } else if (state.clock_at_handoff == 2) {
    reporting_test_unavailable_clock();
  }
  if (state.cancel_at_handoff) {
    if (state.worker != nullptr) {
      state.worker->stop();
    }
    if (state.legacy != nullptr) {
      state.legacy->cancelled.request();
    }
  }
  if (state.mismatch_dns_at_handoff) {
    static constexpr DnsFallback kChanged{
        .zone = "changed.test",
        .collection_policy = "default",
        .enqueue = kFallbackEnqueue,
    };
    register_dns_fallback(&kChanged);
  }
  return fixture_state().result;
}
}  // namespace
const TransportFixture& transport_fixture() { return fixture_state().fixture; }
namespace {
int legacy_client(const Config& config, int cancel_ms) {
  auto& state = fixture_state();
  Context context;
  Sender sender;
  sender.config = config;
  sender.post = capture;
  sender.context = &context;
  state.legacy = &sender;
  state.cancel_ms = cancel_ms;
  const std::vector<Observation> original{observed("test.legacy", "fixture", true)};
  deliver(sender, original);
  const auto authorized = context.get(kAuthorizedUndeliveredRun);
  const auto saved = context.get(kSecuritySuppressedRun);
  const bool dns = authorized.has_value();
  const bool suppressed = saved.has_value();
  const bool original_matches =
      (authorized.has_value() && authorized->observations == original) || (saved.has_value() && *saved == original);
  const auto diagnostic = context.get(kLegacyDeliveryDiagnostic);
  const int precise =
      diagnostic.has_value() && diagnostic->transport.has_value() ? static_cast<int>(*diagnostic->transport) : -1;
  const int retention = diagnostic.has_value() ? static_cast<int>(diagnostic->retention) : -1;
  std::cout << "{\"result\":" << static_cast<unsigned>(state.result) << ",\"pending\":" << (dns || suppressed ? 1 : 0)
            << ",\"dns_handoffs\":" << (dns ? 1 : 0) << ",\"legacy_suppressed\":" << (suppressed ? "true" : "false")
            << ",\"legacy_original_matches\":" << (original_matches ? "true" : "false")
            << ",\"legacy_diagnostic\":" << precise << ",\"legacy_retention\":" << retention
            << ",\"transport_ms\":" << state.transport_ms << "}\n";
  return 0;
}
int client(std::span<char* const> arguments) {
  auto& state = fixture_state();
  auto& fixture = state.fixture;
  if (arguments.size() != 7) {
    return 2;
  }
  fixture.ca_file = arguments[3];
  fixture.queued_sends = &state.queued_sends;
  if (reporting_test_environment("RASP_TEST_CLOCK_AT_SEND_QUEUE") != nullptr) {
    fixture.on_send_queue_entered = +[] noexcept { reporting_test_advance_clock(7200); };
  }
  if (const char* delay = reporting_test_environment("RASP_TEST_SEND_QUEUE_DELAY_MS"); delay != nullptr) {
    fixture.send_queue_delay_ms = milliseconds(delay);
  }

#ifdef __APPLE__
  fixture.ca_file += ".der";
  if (const char* delay = reporting_test_environment("RASP_TEST_VERIFY_DELAY_MS"); delay != nullptr) {
    fixture.verification_delay_ms = milliseconds(delay);
  }
  if (const char* port = reporting_test_environment("RASP_TEST_PROXY_PORT"); port != nullptr) {
    fixture.proxy_port = port;
  }
#endif
  fixture.address = "127.0.0.1";
#ifdef __linux__
  if (reporting_test_environment("RASP_TEST_STALL_DNS_MS") != nullptr) {
    fixture.address.clear();
  }
#endif
  if (const char* clock = reporting_test_environment("RASP_TEST_CLOCK_AT_HANDOFF"); clock != nullptr) {
    state.clock_at_handoff = std::string_view(clock) == "expired" ? 1 : 2;
  }
  state.cancel_at_handoff = reporting_test_environment("RASP_TEST_CANCEL_AT_HANDOFF") != nullptr;
  state.mismatch_dns_at_handoff = reporting_test_environment("RASP_TEST_DNS_MISMATCH_AT_HANDOFF") != nullptr;
  state.storage_path = arguments[4];
  const int cancel_ms = milliseconds(arguments[5]);
  const Config config{.endpoint = arguments[1], .build_id = std::string(64, 'b'), .security_profile = arguments[2]};
  static const DnsFallback kFallback{
      .zone = "fallback.test",
      .collection_policy = "default",
      .enqueue = kFallbackEnqueue,
  };
  register_dns_fallback(&kFallback);
  if (std::string_view(arguments[6]) == "legacy") {
    return legacy_client(config, cancel_ms);
  }
  if (std::string_view(arguments[6]).starts_with("direct")) {
    const std::atomic<bool> stop{std::string_view(arguments[6]) == "direct-cancel"};
    const auto direct = post(config, "{}", Cancellation(&stop));
    std::cout << "{\"result\":" << static_cast<unsigned>(direct) << "}\n";
    return 0;
  }
  if (std::string_view(arguments[6]) == "v1") {
    auto storage = acquire();
    const auto batch = new_batch_id();
    if (!storage.has_value() || !batch.has_value()) {
      return 8;
    }
    Outbox original(storage->native_handle(), std::string(storage->install_id()));
    CycleSnapshot snapshot;
    snapshot.metadata.sequence = 1;
    const auto payload = prepare_cycle(snapshot, config.build_id, storage->install_id(), *batch);
    const auto authority = collection_authority(
        {.endpoint = config.endpoint, .policy = "default", .zone = "fallback.test", .dns_policy = "default"});
    if (!original.initialize().has_value() || !payload.has_value() || !authority.has_value() ||
        !original.persist(*payload, *authority).has_value()) {
      return 9;
    }
  }
  CycleDelivery worker(config, capture, acquire, fixture_clock);
  if (std::string_view(arguments[6]) == "admit") {
    const auto snapshot = std::make_shared<CycleSnapshot>();
    snapshot->metadata.sequence = 1;
    snapshot->metadata.execution_finished = true;
    if (!worker.admit(snapshot)) {
      return 3;
    }
  }
  worker.step();
  state.worker = &worker;
  state.cancel_ms = cancel_ms;
  state.ticks = 1000000000000LL;
  const auto started = std::chrono::steady_clock::now();
  worker.step();
  const auto elapsed =
      std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - started).count();
  TransportResult late_busy = TransportResult::kPublicationUnconfirmed;
  TransportResult late_retry = TransportResult::kPublicationUnconfirmed;
  unsigned dns_peak = 0;
#ifdef __linux__
  if (reporting_test_environment("RASP_TEST_STALL_DNS_MS") != nullptr) {
    if (state.transport_ms < 350) {
      for (unsigned attempt = 0; attempt < 5; ++attempt) {
        std::atomic<bool> stopped{false};
        const std::jthread stop([&stopped] {
          std::this_thread::sleep_for(std::chrono::milliseconds(100));
          stopped.store(true);
        });
        late_busy = post(config, "{}", Cancellation(&stopped));
      }
    }
    dns_peak = reporting_test_resolver_peak();
    reporting_test_resolver_release();
    late_retry = post(config, "{}");
  }
#endif
#ifdef __APPLE__
  if (fixture.verification_delay_ms > 0) {
    late_busy = post(config, "{}");
    std::this_thread::sleep_for(std::chrono::milliseconds(fixture.verification_delay_ms + 100));
    fixture.verification_delay_ms = 0;
    late_retry = post(config, "{}");
  }
#endif
  auto storage = acquire();
  if (!storage.has_value()) {
    return 4;
  }
  Outbox outbox(storage->native_handle(), std::string(storage->install_id()));
  if (!outbox.initialize().has_value()) {
    return 5;
  }
  const auto scan = outbox.scan();
  if (!scan.has_value()) {
    return 6;
  }
  const auto summary = canonical_json(
      JsonValue(JsonValue::Object{
          {"result", JsonValue(static_cast<std::uint64_t>(state.result))},
          {"effective_result", JsonValue(static_cast<std::uint64_t>(worker.health().last_transport_result))},
          {"failure", JsonValue(static_cast<std::uint64_t>(worker.health().failure))},
          {"resolver_peak", JsonValue(static_cast<std::uint64_t>(dns_peak))},
          {"queued_sends", JsonValue(static_cast<std::uint64_t>(state.queued_sends.load()))},
          {"late_busy", JsonValue(static_cast<std::uint64_t>(late_busy))},
          {"late_retry", JsonValue(static_cast<std::uint64_t>(late_retry))},
          {"pending", JsonValue(static_cast<std::uint64_t>(scan->records.size()))},
          {
              "original_request_retained",
              JsonValue(!scan->records.empty() && scan->records[0].payload->request == state.posted_request),
          },
          {"elapsed_ms", JsonValue(static_cast<std::int64_t>(elapsed))},
          {"transport_ms", JsonValue(state.transport_ms)},
          {"attempts", JsonValue(worker.health().https_attempted)},
          {"dns_handoffs", JsonValue(state.dns_handoffs)},
          {"batch", scan->records.empty() ? JsonValue{} : JsonValue(scan->records[0].payload->batch_id)},
      }),
      1024);
  if (!summary.has_value()) {
    return 7;
  }
  std::cout << *summary << '\n';
  return 0;
}
}  // namespace
}  // namespace rasp::plugins::reporting
int main(int argc, char** argv) {
  return rasp::plugins::reporting::client(std::span<char* const>(argv, static_cast<std::size_t>(argc)));
}
