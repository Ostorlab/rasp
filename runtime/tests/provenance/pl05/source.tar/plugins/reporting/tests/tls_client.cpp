/// Actual platform sender through the actual provider-backed outbox; only server, storage root and clock are fixtures.
#include <atomic>
#include <cerrno>
#include <charconv>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <expected>
#include <iostream>
#include <memory>
#include <span>
#include <string>
#include <string_view>
#include <system_error>
#include <thread>
#include <utility>
#include <vector>
#ifdef __APPLE__
#include <future>
#endif

#include "collection_authority.h"
#include "config.h"
#include "cycle_delivery.h"
#include "cycle_payload.h"
#include "fixture_io.h"
#include "hash.h"
#include "json_value.h"
#include "outbox.h"
#include "rasp/context.h"
#include "rasp/cycle.h"
#include "rasp/observation.h"
#include "rasp/posix/private_storage.h"
#include "rasp/private_storage.h"
#include "reporting/delivery.h"
#include "reporting/fallback_authorization.h"
#include "reporting/transport_result.h"
#include "reporting/undelivered_run.h"
#include "sender.h"
#include "transport.h"
#include "transport_fixture.h"
#include "verification_fixture.h"

namespace rasp::plugins::reporting {
namespace {
struct FixtureState {
  TransportFixture fixture;
  std::string storage_path;
  std::int64_t ticks = 0;
  TransportResult result = TransportResult::kPublicationUnconfirmed;
  std::uint64_t dns_handoffs = 0;
  std::atomic<unsigned> queued_sends{0};
  std::atomic<unsigned> path_events{0};
  std::atomic<unsigned> network_events{0};
  CycleDelivery* worker = nullptr;
  Sender* legacy = nullptr;
  int clock_at_handoff = 0;
  bool cancel_at_handoff = false;
  int cancel_ms = -1;
  std::int64_t transport_ms = 0;
  std::string posted_request;
  bool contend_pool = false;
  std::atomic<bool> release_pool{false};
  TransportResult pool_owner_result = TransportResult::kPublicationUnconfirmed;
  bool pool_owner_cleaned = false;
  bool mismatch_dns_at_handoff = false;
  std::shared_ptr<const PreparedCycle> dns_payload;
  std::string dns_authority;
  std::shared_ptr<const FallbackAuthorization> dns_authorization;
};
FixtureState& fixture_state() {
  static FixtureState state;
  return state;
}
constexpr auto kFallbackEnqueue = +[](std::shared_ptr<const PreparedCycle> payload,
                                      std::shared_ptr<const FallbackAuthorization> authorization) noexcept {
  if (payload == nullptr || authorization == nullptr || authorization->authority().empty()) {
    return false;
  }
  fixture_state().dns_payload = std::move(payload);
  fixture_state().dns_authority = authorization->authority();
  fixture_state().dns_authorization = std::move(authorization);
  ++fixture_state().dns_handoffs;
  return true;
};
int milliseconds(std::string_view value) {
  int result = -1;
  const auto parsed = std::from_chars(std::to_address(value.begin()), std::to_address(value.end()), result);
  return parsed.ec == std::errc{} && parsed.ptr == std::to_address(value.end()) ? result : -1;
}
std::int64_t fixture_clock() { return fixture_state().ticks; }
std::expected<PrivateStorage, StorageError> acquire() {
  return rasp::posix::acquire_private_storage_at(fixture_state().storage_path);
}
#ifdef __linux__
/// Hold the real curl slot in the other production caller; no transport result is fabricated.
TransportResult contended_post(const Config& config, std::string_view body, Cancellation cancellation) {
  auto& state = fixture_state();
  Context context;
  Sender sender;
  sender.config = config;
  sender.context = &context;
  sender.post = post;
  CycleDelivery worker(config, post, acquire, fixture_clock);
  if (state.worker == nullptr) {
    const auto snapshot = std::make_shared<CycleSnapshot>();
    snapshot->metadata.sequence = 2;
    static_cast<void>(worker.admit(snapshot));
    worker.step();
    state.ticks = 1000000000000LL;
  }
  std::jthread owner([&] {
    if (state.worker != nullptr) {
      deliver(sender, {observed("test.pool-owner", "fixture", true)});
    } else {
      worker.step();
    }
  });
  const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);
  while (state.queued_sends.load() == 0 && std::chrono::steady_clock::now() < deadline) {
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
  }
  const auto result = post(config, body, cancellation);
  state.release_pool.store(true);
  // Join before inspecting producer state or advancing the fixture clock at fallback handoff.
  owner.join();
  if (state.worker != nullptr) {
    const auto diagnostic = context.get(kLegacyDeliveryDiagnostic);
    state.pool_owner_result = diagnostic.has_value() ? diagnostic->transport.value_or(TransportResult::kResponseInvalid)
                                                     : TransportResult::kResponseInvalid;
    state.pool_owner_cleaned = diagnostic.has_value() && diagnostic->retention == LegacyRetention::kAcknowledged &&
                               !context.get(kSecuritySuppressedRun).has_value();
  } else {
    worker.step();
    state.pool_owner_result = worker.health().last_transport_result;
    state.pool_owner_cleaned = worker.health().durable_pending == 0 && worker.health().publication_acknowledged == 1;
  }
  return result;
}
#endif
TransportResult capture(const Config& config, std::string_view body, Cancellation cancellation) noexcept {
  auto& state = fixture_state();
  state.posted_request = body;
  std::jthread cancel;
  if (state.cancel_ms >= 0) {
    cancel = std::jthread([worker = state.worker, legacy = state.legacy, delay = state.cancel_ms] {
      std::this_thread::sleep_for(std::chrono::milliseconds(delay));
      if (worker != nullptr) {
        worker->stop();
      } else if (legacy != nullptr) {
        legacy->cancelled.request();
      }
    });
  }
  const auto started = std::chrono::steady_clock::now();
#ifdef __linux__
  state.result = state.contend_pool ? contended_post(config, body, cancellation) : post(config, body, cancellation);
#else
  state.result = post(config, body, cancellation);
#endif
  state.transport_ms =
      std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - started).count();
  if (state.clock_at_handoff == 1) {
    reporting_test_advance_clock(7200);
  } else if (state.clock_at_handoff == 2) {
    reporting_test_unavailable_clock();
  }
  if (state.cancel_at_handoff) {
    if (state.worker != nullptr) {
      state.worker->stop();
    }
    if (state.legacy != nullptr) {
      state.legacy->cancelled.request();
    }
  }
  if (state.mismatch_dns_at_handoff) {
    static constexpr DnsFallback kChanged{
        .zone = "changed.test",
        .collection_policy = "default",
        .enqueue = kFallbackEnqueue,
    };
    register_dns_fallback(&kChanged);
  }
  return fixture_state().result;
}
}  // namespace
const TransportFixture& transport_fixture() { return fixture_state().fixture; }
namespace {
#ifdef __APPLE__
/// Only fixture probes get a five-second cancellation watchdog; production timeouts are unchanged.
TransportResult bounded_probe(const Config& config, VerificationFixture& fixture) {
  std::atomic<bool> stopped{false};
  std::promise<void> finished;
  auto completion = finished.get_future();
  std::thread watchdog([&] {
    if (completion.wait_for(std::chrono::seconds(5)) == std::future_status::timeout) {
      fixture.fail_phase();
      stopped.store(true);
    }
  });
  const auto result = post(config, "{}", Cancellation(&stopped));
  finished.set_value();
  watchdog.join();
  return result;
}
#endif
int legacy_client(const Config& config, int cancel_ms) {
  auto& state = fixture_state();
  Context context;
  Sender sender;
  sender.config = config;
  sender.post = capture;
  sender.context = &context;
  state.legacy = &sender;
  state.cancel_ms = cancel_ms;
  const std::vector<Observation> original{observed("test.legacy", "fixture", true)};
  deliver(sender, original);
  const auto authorized = context.get(kAuthorizedUndeliveredRun);
  const auto saved = context.get(kSecuritySuppressedRun);
  const bool dns = authorized.has_value();
  const bool suppressed = saved.has_value();
  const bool original_matches =
      (authorized.has_value() && authorized->observations == original) || (saved.has_value() && *saved == original);
  const auto diagnostic = context.get(kLegacyDeliveryDiagnostic);
  const int precise =
      diagnostic.has_value() && diagnostic->transport.has_value() ? static_cast<int>(*diagnostic->transport) : -1;
  const int retention = diagnostic.has_value() ? static_cast<int>(diagnostic->retention) : -1;
  std::cout << "{\"result\":" << static_cast<unsigned>(state.result) << ",\"pending\":" << (dns || suppressed ? 1 : 0)
            << ",\"dns_handoffs\":" << (dns ? 1 : 0) << ",\"legacy_suppressed\":" << (suppressed ? "true" : "false")
            << ",\"legacy_original_matches\":" << (original_matches ? "true" : "false")
            << ",\"legacy_diagnostic\":" << precise << ",\"legacy_retention\":" << retention
            << ",\"pool_owner_result\":" << static_cast<unsigned>(state.pool_owner_result)
            << ",\"pool_owner_cleaned\":" << (state.pool_owner_cleaned ? "true" : "false")
            << ",\"queued_sends\":" << state.queued_sends.load() << ",\"transport_ms\":" << state.transport_ms << "}\n";
  return 0;
}
int client(std::span<char* const> arguments) {
  auto& state = fixture_state();
  auto& fixture = state.fixture;
  if (arguments.size() != 7) {
    return 2;
  }
  fixture.ca_file = arguments[3];
  fixture.queued_sends = &state.queued_sends;
  if (reporting_test_environment("RASP_TEST_CLOCK_AT_SEND_QUEUE") != nullptr) {
    fixture.on_send_queue_entered = +[] noexcept { reporting_test_advance_clock(7200); };
  }
  if (const char* delay = reporting_test_environment("RASP_TEST_SEND_QUEUE_DELAY_MS"); delay != nullptr) {
    fixture.send_queue_delay_ms = milliseconds(delay);
  }

#ifdef __APPLE__
  fixture.network_events = &state.network_events;
  if (const char* event = reporting_test_environment("RASP_TEST_NETWORK_ERROR_AT"); event != nullptr) {
    const std::string_view when(event);
    fixture.posix_error_before_verify = when == "before-reset" ? ECONNRESET : when == "before-timeout" ? ETIMEDOUT : 0;
    fixture.tls_error_before_verify = when == "before-tls";
    fixture.reset_when_verify_pending = when == "pending-reset";
    fixture.reset_before_verify_setup = when == "early-reset";
    fixture.reset_before_trust_refusal = when == "before-refusal";
    if (fixture.reset_when_verify_pending || fixture.reset_before_verify_setup) {
      fixture.verification = std::make_shared<VerificationFixture>(fixture.reset_when_verify_pending);
    }
  }
  fixture.path_events = &state.path_events;
  if (const char* event = reporting_test_environment("RASP_TEST_PATH_CHANGE_AT"); event != nullptr) {
    const std::string_view when(event);
    fixture.path_change_at = when == "before-send" ? TransportFixture::PathChangeAt::kBeforeSend
                             : when == "partial"   ? TransportFixture::PathChangeAt::kIncompleteResponse
                                                   : TransportFixture::PathChangeAt::kCompleteResponse;
  }
  fixture.ca_file += ".der";
  if (const char* delay = reporting_test_environment("RASP_TEST_VERIFY_DELAY_MS"); delay != nullptr) {
    fixture.verification_delay_ms = milliseconds(delay);
  }
  if (const char* port = reporting_test_environment("RASP_TEST_PROXY_PORT"); port != nullptr) {
    fixture.proxy_port = port;
  }
#endif
  fixture.address = "127.0.0.1";
#ifdef __linux__
  if (reporting_test_environment("RASP_TEST_CONTEND_POOL") != nullptr) {
    state.contend_pool = true;
    fixture.send_queue_delay_ms = 1;
    fixture.on_send_queue_entered = +[] noexcept {
      const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);
      while (!fixture_state().release_pool.load() && std::chrono::steady_clock::now() < deadline) {
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
      }
    };
  }
  if (reporting_test_environment("RASP_TEST_STALL_DNS_MS") != nullptr) {
    fixture.address.clear();
  }
#endif
  if (const char* clock = reporting_test_environment("RASP_TEST_CLOCK_AT_HANDOFF"); clock != nullptr) {
    state.clock_at_handoff = std::string_view(clock) == "expired" ? 1 : 2;
  }
  state.cancel_at_handoff = reporting_test_environment("RASP_TEST_CANCEL_AT_HANDOFF") != nullptr;
  state.mismatch_dns_at_handoff = reporting_test_environment("RASP_TEST_DNS_MISMATCH_AT_HANDOFF") != nullptr;
  state.storage_path = arguments[4];
  const int cancel_ms = milliseconds(arguments[5]);
  const Config config{.endpoint = arguments[1], .build_id = std::string(64, 'b'), .security_profile = arguments[2]};
  static const DnsFallback kFallback{
      .zone = "fallback.test",
      .collection_policy = "default",
      .enqueue = kFallbackEnqueue,
  };
  register_dns_fallback(&kFallback);
  if (std::string_view(arguments[6]) == "legacy") {
    return legacy_client(config, cancel_ms);
  }
  if (std::string_view(arguments[6]).starts_with("direct")) {
    const std::atomic<bool> stop{std::string_view(arguments[6]) == "direct-cancel"};
    const auto direct = post(config, "{}", Cancellation(&stop));
    std::cout << "{\"result\":" << static_cast<unsigned>(direct) << "}\n";
    return 0;
  }
  if (std::string_view(arguments[6]) == "v1") {
    auto storage = acquire();
    const auto batch = new_batch_id();
    if (!storage.has_value() || !batch.has_value()) {
      return 8;
    }
    Outbox original(storage->native_handle(), std::string(storage->install_id()));
    CycleSnapshot snapshot;
    snapshot.metadata.sequence = 1;
    const auto payload = prepare_cycle(snapshot, config.build_id, storage->install_id(), *batch);
    const auto authority = collection_authority(
        {.endpoint = config.endpoint, .policy = "default", .zone = "fallback.test", .dns_policy = "default"});
    if (!original.initialize().has_value() || !payload.has_value() || !authority.has_value() ||
        !original.persist(*payload, *authority).has_value()) {
      return 9;
    }
  }
  CycleDelivery worker(config, capture, acquire, fixture_clock);
  if (std::string_view(arguments[6]) == "admit") {
    const auto snapshot = std::make_shared<CycleSnapshot>();
    snapshot->metadata.sequence = 1;
    snapshot->metadata.execution_finished = true;
    if (!worker.admit(snapshot)) {
      return 3;
    }
  }
  worker.step();
  state.worker = &worker;
  state.cancel_ms = cancel_ms;
  state.ticks = 1000000000000LL;
  const auto started = std::chrono::steady_clock::now();
  worker.step();
  const auto elapsed =
      std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - started).count();
  TransportResult late_busy = TransportResult::kPublicationUnconfirmed;
  TransportResult late_retry = TransportResult::kPublicationUnconfirmed;
#ifdef __APPLE__
  VerificationFixture::Progress verification;
#else
  const VerificationFixture::Progress verification;
#endif
  unsigned dns_peak = 0;
#ifdef __linux__
  if (reporting_test_environment("RASP_TEST_STALL_DNS_MS") != nullptr) {
    if (state.transport_ms < 350) {
      for (unsigned attempt = 0; attempt < 5; ++attempt) {
        std::atomic<bool> stopped{false};
        const std::jthread stop([&stopped] {
          std::this_thread::sleep_for(std::chrono::milliseconds(100));
          stopped.store(true);
        });
        late_busy = post(config, "{}", Cancellation(&stopped));
      }
    }
    dns_peak = reporting_test_resolver_peak();
    reporting_test_resolver_release();
    late_retry = post(config, "{}");
  }
#endif
#ifdef __APPLE__
  if (fixture.verification != nullptr) {
    const auto controlled = fixture.verification;
    // Subsequent posts are independent and must never replay the original event or join its handoff.
    fixture.reset_when_verify_pending = false;
    fixture.reset_before_verify_setup = false;
    fixture.verification.reset();
    if (controlled->holds_evaluation()) {
      if (controlled->await_committed()) {
        late_busy = bounded_probe(config, *controlled);
      }
      controlled->release();
      if (controlled->await_retired() && controlled->progress().failures == 0) {
        late_retry = bounded_probe(config, *controlled);
      }
    } else {
      controlled->release();
      if (controlled->await_early_retirement() && controlled->progress().failures == 0) {
        late_retry = bounded_probe(config, *controlled);
      }
    }
    verification = controlled->progress();
  } else if (fixture.verification_delay_ms > 0) {
    late_busy = post(config, "{}");
    std::this_thread::sleep_for(std::chrono::milliseconds(fixture.verification_delay_ms + 100));
    fixture.verification_delay_ms = 0;
    late_retry = post(config, "{}");
  }
#endif
  auto storage = acquire();
  if (!storage.has_value()) {
    return 4;
  }
  Outbox outbox(storage->native_handle(), std::string(storage->install_id()));
  if (!outbox.initialize().has_value()) {
    return 5;
  }
  const auto scan = outbox.scan();
  if (!scan.has_value()) {
    return 6;
  }
  const auto summary = canonical_json(
      JsonValue(JsonValue::Object{
          {"result", JsonValue(static_cast<std::uint64_t>(state.result))},
          {"pool_owner_result", JsonValue(static_cast<std::uint64_t>(state.pool_owner_result))},
          {"pool_owner_cleaned", JsonValue(state.pool_owner_cleaned)},
          {"effective_result", JsonValue(static_cast<std::uint64_t>(worker.health().last_transport_result))},
          {"failure", JsonValue(static_cast<std::uint64_t>(worker.health().failure))},
          {"resolver_peak", JsonValue(static_cast<std::uint64_t>(dns_peak))},
          {"queued_sends", JsonValue(static_cast<std::uint64_t>(state.queued_sends.load()))},
          {"path_events", JsonValue(static_cast<std::uint64_t>(state.path_events.load()))},
          {"network_events", JsonValue(static_cast<std::uint64_t>(state.network_events.load()))},
          {"late_busy", JsonValue(static_cast<std::uint64_t>(late_busy))},
          {"late_retry", JsonValue(static_cast<std::uint64_t>(late_retry))},
          {
              "verification",
              JsonValue(JsonValue::Object{
                  {"committed", JsonValue(verification.committed)},
                  {"terminal", JsonValue(verification.terminal)},
                  {"returned", JsonValue(verification.api_returned)},
                  {"submitted", JsonValue(verification.submitted)},
                  {"retired", JsonValue(verification.retired)},
                  {"callback", JsonValue(verification.callback)},
                  {"early", JsonValue(verification.early)},
                  {"failures", JsonValue(static_cast<std::uint64_t>(verification.failures))},
              }),
          },
          {"pending", JsonValue(static_cast<std::uint64_t>(scan->records.size()))},
          {
              "original_request_retained",
              JsonValue(!scan->records.empty() && scan->records[0].payload->request == state.posted_request),
          },
          {"elapsed_ms", JsonValue(static_cast<std::int64_t>(elapsed))},
          {"transport_ms", JsonValue(state.transport_ms)},
          {"attempts", JsonValue(worker.health().https_attempted)},
          {"dns_handoffs", JsonValue(state.dns_handoffs)},
          {"batch", scan->records.empty() ? JsonValue{} : JsonValue(scan->records[0].payload->batch_id)},
      }),
      1024);
  if (!summary.has_value()) {
    return 7;
  }
  std::cout << *summary << '\n';
  return 0;
}
}  // namespace
}  // namespace rasp::plugins::reporting
int main(int argc, char** argv) {
  return rasp::plugins::reporting::client(std::span<char* const>(argv, static_cast<std::size_t>(argc)));
}
