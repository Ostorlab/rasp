#include "security_profile.h"

#include <gtest/gtest.h>
#include <string>
#include <string_view>

namespace rasp::plugins::reporting {
namespace {
constexpr std::string_view kSystem =
    R"({"host":"collector.example","mode":"system","pins":null,"port":443,"validity":null,"version":1})";
}
TEST(SecurityProfile, parse_whenSystemAndOriginMatch_acceptsCanonicalProfile) {
  const auto profile = parse_security_profile({.profile = kSystem, .endpoint = "https://COLLECTOR.example/path?"});
  ASSERT_TRUE(profile.has_value());
  EXPECT_FALSE(profile->pinned);
  EXPECT_EQ(profile->canonical, kSystem);
}
TEST(SecurityProfile, parse_whenMissingMalformedOrOriginChanges_rejects) {
  for (const auto* const value : {"", "{}", "null", "[]", R"({"version":1,"version":1})"}) {
    EXPECT_FALSE(parse_security_profile({.profile = value, .endpoint = "https://collector.example/"}).has_value());
  }
  EXPECT_FALSE(parse_security_profile({.profile = kSystem, .endpoint = "http://collector.example/"}).has_value());
  EXPECT_FALSE(parse_security_profile({.profile = kSystem, .endpoint = "https://other.example/"}).has_value());
  EXPECT_FALSE(parse_security_profile({.profile = kSystem, .endpoint = "https://collector.example:444/"}).has_value());
}
TEST(SecurityProfile, parse_whenPrimaryBackupAndValidityValid_enforcesFiniteTime) {
  const std::string pins =
      R"({"version":1,"mode":"leaf-spki-sha256","host":"collector.example","port":443,"pins":{"primary":{"key_algorithm":"rsa-2048","value":"sha256//AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="},"backup":{"key_algorithm":"ec-p256","value":"sha256//AQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQE="}},"validity":{"not_before":100,"not_after":200}})";
  const auto profile = parse_security_profile({.profile = pins, .endpoint = "https://collector.example/"});
  ASSERT_TRUE(profile.has_value());
  EXPECT_TRUE(profile->pinned);
  EXPECT_FALSE(profile_active(*profile, 99));
  EXPECT_TRUE(profile_active(*profile, 100));
  EXPECT_FALSE(profile_active(*profile, 200));
  EXPECT_FALSE(profile_active(*profile, -1));
  auto invalid = pins;
  invalid.replace(invalid.find("AQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQE="), 44,
                  "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=");
  EXPECT_FALSE(parse_security_profile({.profile = invalid, .endpoint = "https://collector.example/"}).has_value());
  invalid = pins;
  invalid.replace(invalid.find("rsa-2048"), 8, "rsa-1024");
  EXPECT_FALSE(parse_security_profile({.profile = invalid, .endpoint = "https://collector.example/"}).has_value());
}
}  // namespace rasp::plugins::reporting
