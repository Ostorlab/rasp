/// Fixture routing/anchors exist only in separately linked transport test executables.
#pragma once
#include <array>
#include <atomic>
#include <cstdint>
#include <memory>
#include <string>

#include "verification_fixture.h"
namespace rasp::plugins::reporting {
#ifdef __APPLE__
__attribute__((used, section("__TEXT,__rasp_test")))
#else
__attribute__((used, retain, section(".rasp_tls_test")))
#endif
inline const std::array<char, 19>
    kTestTransportMarker = {
        82, 83, 80, 84, 76, 83, 95, 84, 69, 83, 84, 95, 79, 78, 76, 89, 95, 86, 49,
};
struct TransportFixture {
  std::string ca_file;
  std::string address;
  bool http_fixture = false;
  int verification_delay_ms = 0;
  int send_queue_delay_ms = 0;
  void (*on_send_queue_entered)() noexcept = nullptr;
  std::atomic<unsigned>* queued_sends = nullptr;
  std::string proxy_port;
  enum class PathChangeAt : std::uint8_t { kNone, kBeforeSend, kIncompleteResponse, kCompleteResponse };
  PathChangeAt path_change_at = PathChangeAt::kNone;
  std::atomic<unsigned>* path_events = nullptr;
  int posix_error_before_verify = 0;
  bool tls_error_before_verify = false;
  bool reset_when_verify_pending = false;
  bool reset_before_verify_setup = false;
  bool reset_before_trust_refusal = false;
  std::atomic<unsigned>* network_events = nullptr;
  std::shared_ptr<VerificationFixture> verification;
};
[[nodiscard]] const TransportFixture& transport_fixture();
}  // namespace rasp::plugins::reporting
