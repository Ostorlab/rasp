/// Fixture routing/anchors exist only in separately linked transport test executables.
#pragma once
#include <array>
#include <atomic>
#include <string>
namespace rasp::plugins::reporting {
#ifdef __APPLE__
__attribute__((used, section("__TEXT,__rasp_test")))
#else
__attribute__((used, retain, section(".rasp_tls_test")))
#endif
inline const std::array<char, 19>
    kTestTransportMarker = {
        82, 83, 80, 84, 76, 83, 95, 84, 69, 83, 84, 95, 79, 78, 76, 89, 95, 86, 49,
};
struct TransportFixture {
  std::string ca_file;
  std::string address;
  bool http_fixture = false;
  int verification_delay_ms = 0;
  int send_queue_delay_ms = 0;
  void (*on_send_queue_entered)() noexcept = nullptr;
  std::atomic<unsigned>* queued_sends = nullptr;
  std::string proxy_port;
};
[[nodiscard]] const TransportFixture& transport_fixture();
}  // namespace rasp::plugins::reporting
