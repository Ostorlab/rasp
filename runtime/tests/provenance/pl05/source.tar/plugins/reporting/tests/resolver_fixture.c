/* The linker requires the reserved __wrap/__real names. Only external getaddrinfo is replaced. */
#include <netdb.h>
#include <stdatomic.h>
#include <time.h>

#include "fixture_io.h"
static atomic_uint active = 0;
static atomic_uint peak = 0;
static atomic_bool released = 0;
int __real_getaddrinfo(const char* host, const char* service, const struct addrinfo* hints, struct addrinfo** result);
int __wrap_getaddrinfo(const char* host, const char* service, const struct addrinfo* hints, struct addrinfo** result);
int __wrap_getaddrinfo(const char* host, const char* service, const struct addrinfo* hints, struct addrinfo** result) {
  if (reporting_test_environment("RASP_TEST_STALL_DNS_MS") == NULL) {
    return __real_getaddrinfo(host, service, hints, result);
  }
  const unsigned count = atomic_fetch_add(&active, 1) + 1;
  unsigned maximum = atomic_load(&peak);
  while (maximum < count && !atomic_compare_exchange_weak(&peak, &maximum, count)) {
  }
  const struct timespec pause = {0, 10000000};
  for (unsigned attempt = 0; attempt < 500 && !atomic_load(&released); ++attempt) {
    nanosleep(&pause, NULL);
  }
  atomic_fetch_sub(&active, 1);
  return atomic_load(&released) ? __real_getaddrinfo("127.0.0.1", service, hints, result) : EAI_AGAIN;
}
unsigned reporting_test_resolver_peak(void) { return atomic_load(&peak); }
void reporting_test_resolver_release(void) {
  atomic_store(&released, 1);
  const struct timespec pause = {0, 10000000};
  for (unsigned attempt = 0; attempt < 200 && atomic_load(&active) != 0; ++attempt) {
    nanosleep(&pause, NULL);
  }
}
