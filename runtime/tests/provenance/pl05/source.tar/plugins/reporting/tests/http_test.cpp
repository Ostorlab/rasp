/// Tests for HTTP/1.1: the parts of an endpoint URL, the request of a post, and the status line of an answer.

#include "http.h"

#include <cstddef>
#include <gtest/gtest.h>
#include <optional>
#include <string>
#include <string_view>

namespace rasp::plugins::reporting {
namespace {

TEST(Http, parseEndpoint_whenHttpsWithPath_givesTlsAndPort443) {
  const std::optional<Endpoint> endpoint = parse_endpoint("https://adr.ostorlab.app/apis/graphql");

  ASSERT_TRUE(endpoint.has_value());
  EXPECT_TRUE(endpoint->tls);
  EXPECT_EQ(endpoint->host, "adr.ostorlab.app");
  EXPECT_EQ(endpoint->port, "443");
  EXPECT_EQ(endpoint->authority, "adr.ostorlab.app");
  EXPECT_EQ(endpoint->target, "/apis/graphql");
}

TEST(Http, parseEndpoint_whenHttpWithPort_givesThePortAndKeepsItInTheAuthority) {
  const std::optional<Endpoint> endpoint = parse_endpoint("http://10.0.2.2:8000/apis/graphql");

  ASSERT_TRUE(endpoint.has_value());
  EXPECT_FALSE(endpoint->tls);
  EXPECT_EQ(endpoint->host, "10.0.2.2");
  EXPECT_EQ(endpoint->port, "8000");
  EXPECT_EQ(endpoint->authority, "10.0.2.2:8000");
}

TEST(Http, parseEndpoint_whenNoPath_givesTheRootTarget) {
  const std::optional<Endpoint> endpoint = parse_endpoint("http://example.com");

  ASSERT_TRUE(endpoint.has_value());
  EXPECT_EQ(endpoint->port, "80");
  EXPECT_EQ(endpoint->target, "/");
}

TEST(Http, parseEndpoint_whenQueryAndFragment_keepsTheQueryAndDropsTheFragment) {
  const std::optional<Endpoint> with_path = parse_endpoint("https://example.com/rasp?a=1#top");
  const std::optional<Endpoint> without_path = parse_endpoint("https://example.com?a=1");

  ASSERT_TRUE(with_path.has_value());
  ASSERT_TRUE(without_path.has_value());
  EXPECT_EQ(with_path->target, "/rasp?a=1");
  EXPECT_EQ(without_path->target, "/?a=1");
}

TEST(Http, parseEndpoint_whenNotAnHttpUrl_givesNothing) {
  for (const char* url : {
           "ftp://example.com",
           "https://",
           "https:///rasp",
           "https://example.com:",
           "https://example.com:0",
           "https://example.com:65536",
           "https://example.com:8a",
           "https://a:b:c",
       }) {
    EXPECT_FALSE(parse_endpoint(url).has_value()) << url;
  }
}

TEST(Http, makeRequest_whenGivenABody_postsItWithItsLengthAndClosesTheConnection) {
  const Endpoint endpoint{
      .tls = true,
      .host = "example.com",
      .port = "443",
      .authority = "example.com",
      .target = "/rasp",
  };

  const std::string request = make_request(endpoint, R"({"a":1})");

  EXPECT_EQ(request,
            "POST /rasp HTTP/1.1\r\nHost: example.com\r\nContent-Type: application/json\r\nContent-Length: 7\r\n"
            "Connection: close\r\n\r\n{\"a\":1}");
}

TEST(Http, parseStatus_whenAStatusLine_givesTheCode) {
  EXPECT_EQ(parse_status("HTTP/1.1 200 OK"), 200);
  EXPECT_EQ(parse_status("HTTP/1.0 404 Not Found"), 404);
  EXPECT_EQ(parse_status("HTTP/1.1 204"), 204);
}

TEST(Http, parseStatus_whenNotAStatusLine_givesNothing) {
  for (const char* line : {
           "",
           "HTTP/2 200 OK",
           "HTTP/1.1 20 OK",
           "HTTP/1.1 2000 OK",
           "HTTP/1.1 2x0 OK",
           "HTTP/1.1  200 OK",
           "http/1.1 200 OK",
           "HTTP/1.x 200 OK",
       }) {
    EXPECT_FALSE(parse_status(line).has_value()) << line;
  }
}

}  // namespace
}  // namespace rasp::plugins::reporting

namespace rasp::plugins::reporting {
namespace {
constexpr std::string_view kAck = R"({"data":{"submitObservations":true}})";

/// Frames a complete fixture body with its exact Content-Length.
std::string length_response(std::string_view body) {
  return "HTTP/1.1 200 OK\r\nContent-Length: " + std::to_string(body.size()) + "\r\n\r\n" + std::string(body);
}

TEST(HttpResponse, read_whenContentLengthSplitAtEveryByte_acceptsOnlyCompleteBody) {
  const std::string wire = length_response(kAck);
  HttpResponse response;
  for (std::size_t index = 0; index < wire.size(); ++index) {
    EXPECT_FALSE(response.successful());
    EXPECT_EQ(response.read(std::string_view(wire).substr(index, 1)),
              index + 1 == wire.size() ? HttpResponse::State::kComplete : HttpResponse::State::kReading);
  }
  EXPECT_TRUE(response.successful());
}

TEST(HttpResponse, read_whenChunkedSplitAtEveryByte_acceptsCompleteBodyAndTrailers) {
  const std::string wire =
      "HTTP/1.1 200 OK\r\ntRaNsFeR-EnCoDiNg: Chunked\r\n\r\n"
      "a ; foo = \"a\\\"b\" ; next = token\r\n" +
      std::string(kAck.substr(0, 10)) + "\r\n1a\r\n" + std::string(kAck.substr(10)) +
      "\r\n0\r\nX-Trace: ignored\r\n\r\n";
  HttpResponse response;
  for (std::size_t index = 0; index < wire.size(); ++index) {
    EXPECT_EQ(response.read(std::string_view(wire).substr(index, 1)),
              index + 1 == wire.size() ? HttpResponse::State::kComplete : HttpResponse::State::kReading)
        << index;
  }
  EXPECT_TRUE(response.successful());
}

TEST(HttpResponse, read_whenCloseDelimited_requiresExplicitOrderlyEof) {
  HttpResponse response;
  EXPECT_EQ(response.read("HTTP/1.0 200 OK\r\n\r\n" + std::string(kAck)), HttpResponse::State::kReading);
  EXPECT_FALSE(response.successful());
  EXPECT_EQ(response.read("", true), HttpResponse::State::kComplete);
  EXPECT_TRUE(response.successful());
}

TEST(HttpResponse, read_whenTruncatedAtEveryPosition_rejectsEof) {
  const std::string wire = length_response(kAck);
  for (std::size_t cut = 0; cut < wire.size(); ++cut) {
    HttpResponse response;
    EXPECT_EQ(response.read(std::string_view(wire).substr(0, cut), true), HttpResponse::State::kFailed) << cut;
    EXPECT_FALSE(response.successful());
  }
}

TEST(HttpResponse, read_whenTransportTimesOutOrFailsAtEof_rejectsResponse) {
  const std::string wire = length_response(kAck);
  HttpResponse timeout;
  EXPECT_EQ(timeout.read("HTTP/1.1 200 OK\r\n\r\n" + std::string(kAck), false, true), HttpResponse::State::kFailed);
  EXPECT_FALSE(timeout.successful());
  HttpResponse error_at_eof;
  EXPECT_EQ(error_at_eof.read(wire, true, true), HttpResponse::State::kFailed);
  EXPECT_FALSE(error_at_eof.successful());
}

TEST(HttpResponse, read_whenInvalidFraming_rejectsResponse) {
  for (const std::string_view wire : {
           "HTTP/1.1 302 Found\r\nContent-Length: 0\r\n\r\n",
           "HTTP/1.1 100 Continue\r\n\r\n",
           "HTTP/1.1 103 Early Hints\r\n\r\n",
           "HTTP/1.1 200 OK\nInjected\r\nContent-Length: 0\r\n\r\n",
           "HTTP/1.1 200 OK\r\nContent-Length: 36\r\nContent-Length: 36\r\n\r\n",
           "HTTP/1.1 200 OK\r\nContent-Length: 34\r\nContent-Length: 35\r\n\r\n",
           "HTTP/1.1 200 OK\r\nContent-Length: 34, 34\r\n\r\n",
           "HTTP/1.1 200 OK\r\nContent-Length: -1\r\n\r\n",
           "HTTP/1.1 200 OK\r\nContent-Length: 999999999999999999999999999\r\n\r\n",
           "HTTP/1.1 200 OK\r\nContent-Length: 34\r\nTransfer-Encoding: chunked\r\n\r\n",
           "HTTP/1.1 200 OK\r\nTransfer-Encoding: gzip, chunked\r\n\r\n",
           "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\nTransfer-Encoding: chunked\r\n\r\n",
           "HTTP/1.1 200 OK\r\nContent-Encoding: gzip\r\n\r\n",
           "HTTP/1.1 200 OK\r\n Bad: folded\r\n\r\n",
           "HTTP/1.1 200 OK\r\nBad : space\r\n\r\n",
           "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\nx\r\n",
           "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n1\r\nx!\r\n0\r\n\r\n",
           "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n0\r\nContent-Length: 0\r\n\r\n",
           "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\nextra",
       }) {
    HttpResponse response;
    EXPECT_EQ(response.read(wire, true), HttpResponse::State::kFailed) << wire;
    EXPECT_FALSE(response.successful());
  }
}

TEST(HttpResponse, read_whenChunkedTruncatedAtEveryPosition_rejectsResponse) {
  const std::string wire =
      "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n24\r\n" + std::string(kAck) + "\r\n0\r\n\r\n";
  for (std::size_t cut = 0; cut < wire.size(); ++cut) {
    HttpResponse response;
    EXPECT_EQ(response.read(std::string_view(wire).substr(0, cut), true), HttpResponse::State::kFailed) << cut;
  }
}

TEST(HttpResponse, read_whenBodyOrHeaderOrWireTooLarge_rejectsResponse) {
  for (const std::string& wire : {
           "HTTP/1.1 200 OK\r\nContent-Length: 65537\r\n\r\n" + std::string(65537, ' '),
           "HTTP/1.1 200 OK\r\nX: " + std::string(16384, 'x') + "\r\n\r\n",
           "HTTP/1.1 200 OK\r\n\r\n" + std::string(65537, ' '),
           std::string(100000, ' '),
       }) {
    HttpResponse response;
    EXPECT_EQ(response.read(wire, true), HttpResponse::State::kFailed);
  }
}

TEST(HttpResponse, read_whenExtraBytesOrLateError_invalidatesCompletedResponse) {
  HttpResponse response;
  EXPECT_EQ(response.read(length_response(kAck)), HttpResponse::State::kComplete);
  EXPECT_EQ(response.read("extra"), HttpResponse::State::kFailed);
  EXPECT_FALSE(response.successful());
  HttpResponse error;
  EXPECT_EQ(error.read(length_response(kAck)), HttpResponse::State::kComplete);
  EXPECT_EQ(error.read("", false, true), HttpResponse::State::kFailed);
  EXPECT_FALSE(error.successful());
}

TEST(HttpResponse, read_whenGraphqlFailure_neverAcknowledgesDelivery) {
  for (const std::string_view body : {
           R"({"data":{"submitObservations":false}})",
           R"({"data":{"submitObservations":true},"errors":[{}]})",
           "null",
           "{",
           "{}",
       }) {
    HttpResponse response;
    EXPECT_EQ(response.read(length_response(body)), HttpResponse::State::kComplete);
    EXPECT_FALSE(response.successful());
  }
}
}  // namespace
}  // namespace rasp::plugins::reporting
