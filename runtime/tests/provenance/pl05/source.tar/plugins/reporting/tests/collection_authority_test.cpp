#include "collection_authority.h"

#include <gtest/gtest.h>

#include "security_profile.h"

namespace rasp::plugins::reporting {
TEST(CollectionAuthority, equivalent_whenProfileChangesOrV1BecomesV2_holdsOriginal) {
  const auto legacy = collection_authority(
      {.endpoint = "https://collector.example/", .policy = "default", .zone = "", .dns_policy = "default"});
  const auto profile = parse_security_profile({
      .profile = R"({"version":1,"mode":"system","host":"collector.example","port":443,"pins":null,"validity":null})",
      .endpoint = "https://collector.example/",
  });
  ASSERT_TRUE(profile.has_value());
  const auto security = security_descriptor(*profile);
  ASSERT_TRUE(security.has_value());
  const auto current = collection_authority({
      .endpoint = "https://collector.example/",
      .policy = "default",
      .zone = "",
      .dns_policy = "default",
      .security = *security,
  });
  ASSERT_TRUE(current.has_value());
  ASSERT_TRUE(legacy.has_value());
  EXPECT_TRUE(valid_authority(*current));
  EXPECT_FALSE(same_https_authority({.original = *legacy, .current = *current}));
  EXPECT_EQ(authority_endpoint(*current), "https://collector.example:443/");
}
TEST(CollectionAuthority, equivalent_whenHostCaseAndDefaultPortDiffer_matches) {
  const auto first = collection_authority({
      .endpoint = "https://ADR.example/apis/graphql",
      .policy = "default",
      .zone = "r.example",
      .dns_policy = "default",
  });
  const auto second = collection_authority({
      .endpoint = "https://adr.example:443/apis/graphql",
      .policy = "default",
      .zone = "r.example",
      .dns_policy = "default",
  });
  ASSERT_TRUE(first.has_value());
  ASSERT_TRUE(second.has_value());
  EXPECT_EQ(first, second);
  EXPECT_EQ(authority_endpoint(*first), "https://adr.example:443/apis/graphql");
}
TEST(CollectionAuthority, equivalent_whenRoutePortOrPolicyChanges_holds) {
  const auto original = collection_authority({
      .endpoint = "https://adr.example/apis/graphql?a=1&b=2",
      .policy = "default",
      .zone = "r.example",
      .dns_policy = "default",
  });
  ASSERT_TRUE(original.has_value());
  for (const auto* endpoint : {
           "https://adr.example/other?a=1&b=2",
           "https://adr.example:444/apis/graphql?a=1&b=2",
           "https://adr.example/apis/graphql?b=2&a=1",
           "https://other.example/apis/graphql?a=1&b=2",
       }) {
    const auto changed =
        collection_authority({.endpoint = endpoint, .policy = "default", .zone = "r.example", .dns_policy = "default"});
    ASSERT_TRUE(changed.has_value());
    EXPECT_FALSE(same_https_authority({.original = *original, .current = *changed}));
  }
  const auto policy = collection_authority({
      .endpoint = "https://adr.example/apis/graphql?a=1&b=2",
      .policy = "other",
      .zone = "r.example",
      .dns_policy = "default",
  });
  ASSERT_TRUE(policy.has_value());
  EXPECT_FALSE(same_https_authority({.original = *original, .current = *policy}));
}
TEST(CollectionAuthority, fallback_whenZoneChanges_preservesHttpsAndHoldsDns) {
  const auto first = collection_authority(
      {.endpoint = "https://adr.example/", .policy = "default", .zone = "r.example", .dns_policy = "default"});
  const auto changed = collection_authority(
      {.endpoint = "https://adr.example/", .policy = "default", .zone = "new.example", .dns_policy = "default"});
  const auto absent = collection_authority(
      {.endpoint = "https://adr.example/", .policy = "default", .zone = "", .dns_policy = "default"});
  ASSERT_TRUE(first.has_value());
  ASSERT_TRUE(changed.has_value());
  ASSERT_TRUE(absent.has_value());
  EXPECT_TRUE(same_https_authority({.original = *first, .current = *changed}));
  EXPECT_FALSE(same_dns_authority({.original = *first, .current = *changed}));
  EXPECT_FALSE(same_dns_authority({.original = *absent, .current = *first}));
}
TEST(CollectionAuthority, parse_whenAmbiguousOrUnsafe_rejects) {
  for (const auto* endpoint : {
           "http://adr.example/",
           "https://adr.example/#x",
           "https://user@adr.example/",
           "https://adr.example:0443/",
           "https://127.1/",
           "https://adr.example./",
           "https://adr.example/%xx",
           "https://adr.example/\n",
           "https://[::1]/",
       }) {
    EXPECT_FALSE(
        collection_authority({.endpoint = endpoint, .policy = "default", .zone = "r.example", .dns_policy = "default"})
            .has_value())
        << endpoint;
  }
}
}  // namespace rasp::plugins::reporting
