/// Exercise actual public Apple references, releasing every input owner before reading the selected leaf.
#include <CoreFoundation/CFArray.h>
#include <CoreFoundation/CFBase.h>
#include <CoreFoundation/CFData.h>
#include <MacTypes.h>
#include <Security/SecBase.h>
#include <Security/SecCertificate.h>
#include <Security/SecPolicy.h>
#include <Security/SecTrust.h>
#include <array>
#include <fstream>
#include <gtest/gtest.h>
#include <ios>
#include <iterator>
#include <memory>
#include <string>
#include <type_traits>
#include <vector>

#include "ios/certificate_ref.h"
#include "peer_key.h"
#include "trust_fixture.h"

namespace rasp::plugins::reporting {
namespace {
template <typename Reference>
using Owned = std::unique_ptr<std::remove_pointer_t<Reference>, decltype(&CFRelease)>;

std::string fixture(const std::string& name) {
  std::ifstream input(std::string(RASP_PEER_KEY_FIXTURES) + "/" + name, std::ios::binary);
  return {std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>()};
}
Owned<SecCertificateRef> certificate(const std::string& der) {
  std::vector<UInt8> bytes;
  for (const auto byte : der) {
    bytes.push_back(static_cast<UInt8>(byte));
  }
  const Owned<CFDataRef> data(CFDataCreate(kCFAllocatorDefault, bytes.data(), static_cast<CFIndex>(bytes.size())),
                              CFRelease);
  return {data == nullptr ? nullptr : SecCertificateCreateWithData(kCFAllocatorDefault, data.get()), CFRelease};
}
}  // namespace
TEST(AppleLeaf, copy_whenTrustIsAbsent_returnsNoCertificate) {
  EXPECT_EQ(transport_fixture_copy_leaf(nullptr), nullptr);
}
TEST(AppleLeaf, retain_whenValueIsNotACertificate_returnsNoReference) {
  const Owned<CFDataRef> value(CFDataCreate(kCFAllocatorDefault, nullptr, 0), CFRelease);
  ASSERT_NE(value, nullptr);
  EXPECT_EQ(rasp_reporting_retain_certificate(value.get()), nullptr);
  EXPECT_EQ(rasp_reporting_retain_certificate(nullptr), nullptr);
}
TEST(AppleLeaf, copy_whenEveryInputOwnerIsReleased_keepsOnlyTheOriginalRsaOrEcLeaf) {
  for (const auto* kind : {"rsa", "ec"}) {
    const auto expected = fixture(std::string(kind) + ".der");
    ASSERT_FALSE(expected.empty());
    Owned<SecCertificateRef> leaf(nullptr, CFRelease);
    {
      const auto first = certificate(expected);
      const auto other = certificate(fixture(std::string(kind) == "rsa" ? "ec.der" : "rsa.der"));
      ASSERT_NE(first, nullptr);
      ASSERT_NE(other, nullptr);
      std::array<const void*, 2> values{first.get(), other.get()};
      const Owned<CFArrayRef> chain(CFArrayCreate(kCFAllocatorDefault, values.data(), 2, &kCFTypeArrayCallBacks),
                                    CFRelease);
      const Owned<SecPolicyRef> policy(SecPolicyCreateBasicX509(), CFRelease);
      ASSERT_NE(chain, nullptr);
      ASSERT_NE(policy, nullptr);
      SecTrustRef created = nullptr;
      const auto status = SecTrustCreateWithCertificates(chain.get(), policy.get(), &created);
      const Owned<SecTrustRef> trust(created, CFRelease);
      ASSERT_EQ(status, errSecSuccess);
      ASSERT_NE(trust, nullptr);
      // Offline extraction fixtures never initiate trust fetches or authorize a request.
      ASSERT_EQ(SecTrustSetNetworkFetchAllowed(trust.get(), static_cast<Boolean>(false)), errSecSuccess);
      static_cast<void>(SecTrustEvaluateWithError(trust.get(), nullptr));
      leaf.reset(transport_fixture_copy_leaf(trust.get()));
      ASSERT_NE(leaf, nullptr);
    }
    const Owned<CFDataRef> actual(SecCertificateCopyData(leaf.get()), CFRelease);
    const auto original = certificate(expected);
    ASSERT_NE(original, nullptr);
    const Owned<CFDataRef> expected_data(SecCertificateCopyData(original.get()), CFRelease);
    ASSERT_NE(actual, nullptr);
    ASSERT_NE(expected_data, nullptr);
    EXPECT_NE(CFEqual(actual.get(), expected_data.get()), 0);
    const auto parsed = certificate_key(expected);
    ASSERT_TRUE(parsed.has_value());
    EXPECT_EQ(parsed->spki, fixture(std::string(kind) + ".spki.der"));
  }
}
}  // namespace rasp::plugins::reporting
