#include "reporting/transport_result.h"
#include "transport.h"
/// Tests for the sender, with a fake post: deliver wraps a run in a request and posts it once, a run that is not
/// delivered is left in the context, and the sender's thread posts the newest run.

#include <chrono>
#include <condition_variable>
#include <gtest/gtest.h>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "config.h"
#include "json.h"
#include "rasp/context.h"
#include "rasp/observation.h"
#include "reporting/delivery.h"
#include "reporting/undelivered_run.h"
#include "sender.h"

namespace rasp::plugins::reporting {
namespace {

/// How long a test waits for the sender's thread.
constexpr std::chrono::seconds kWait{10};

/// What the fake post saw, shared with the sender's thread.
struct Posts {
  /// Guards every other field.
  std::mutex mutex;
  /// Signalled when a post starts and when `hold` changes.
  std::condition_variable changed;
  /// The body of every post, in order.
  std::vector<std::string> bodies;
  /// The endpoint of every post, in order.
  std::vector<std::string> endpoints;
  /// What the fake post answers.
  bool accept = true;
  TransportResult failure = TransportResult::kConnectFailed;
  /// While `true`, a post waits before it answers.
  bool hold = false;
};

/// The posts the fake saw, shared by every test.
///
/// @return The posts.
[[nodiscard]] Posts& posts() {
  static Posts value;
  return value;
}

/// Forgets every post and resets the fake's answers.
void reset_posts() {
  Posts& seen = posts();
  const std::scoped_lock lock(seen.mutex);
  seen.bodies.clear();
  seen.endpoints.clear();
  seen.accept = true;
  seen.failure = TransportResult::kConnectFailed;
  seen.hold = false;
}

/// The fake post: records the post, waits while `hold` is set, and answers `accept`.
///
/// @param config The plugin's config.
/// @param body The request.
/// @return `accept`.
TransportResult fake_post(const Config& config, std::string_view body, Cancellation /*cancellation*/) noexcept {
  Posts& seen = posts();
  std::unique_lock lock(seen.mutex);
  seen.bodies.emplace_back(body);
  seen.endpoints.push_back(config.endpoint);
  seen.changed.notify_all();
  seen.changed.wait(lock, [&seen] { return !seen.hold; });
  return seen.accept ? TransportResult::kPublicationAcknowledged : seen.failure;
}

/// A sender that posts with the fake.
///
/// @param sender The sender to fill.
/// @param context The context the plugins share, where the sender leaves each run it does not deliver.
void configure(Sender& sender, Context& context) {
  sender.config = {
      .endpoint = "https://reports.example.com/rasp",
      .build_id = "build-7",
      .security_profile =
          R"({"version":1,"mode":"system","host":"reports.example.com","port":443,"pins":null,"validity":null})",
  };
  static constexpr DnsFallback kSelected{.zone = "fallback.test", .collection_policy = "default"};
  register_dns_fallback(&kSelected);
  sender.post = fake_post;
  sender.context = &context;
}

/// A run of one observation.
///
/// @param signal The signal of the observation.
/// @return One observation of `signal`, true, read through test.
[[nodiscard]] std::vector<Observation> run_of(std::string_view signal) { return {observed(signal, "test", true)}; }

/// The context of the sender whose thread a test starts.
///
/// @return The context, which lives as long as the test process, as that thread does.
[[nodiscard]] Context& thread_context() {
  // Match the detached production sender's process lifetime. A static value can be destroyed during its final write.
  static Context* const kContext = std::make_unique<Context>().release();
  return *kContext;
}

TEST(Sender, deliver_whenPostAccepts_postsOneRequestToTheEndpointAndLeavesNothingInTheContext) {
  reset_posts();
  Context context;
  Sender sender;
  configure(sender, context);

  deliver(sender, run_of("test.ping"));

  EXPECT_EQ(context.get(kAuthorizedUndeliveredRun), std::nullopt);
  Posts& seen = posts();
  const std::scoped_lock lock(seen.mutex);
  ASSERT_EQ(seen.bodies.size(), 1U);
  EXPECT_EQ(seen.endpoints.front(), "https://reports.example.com/rasp");
  EXPECT_EQ(seen.bodies.front(),
            serialise_request(sender.config,
                              R"([{"signal":"test.ping","source":"test","status":"OK","value":{"bool":true}}])",
                              kMaxRequestSize));
}

TEST(Sender, deliver_whenPostFails_leavesTheRunInTheContextAfterOneAttempt) {
  reset_posts();
  {
    const std::scoped_lock lock(posts().mutex);
    posts().accept = false;
  }
  Context context;
  Sender sender;
  configure(sender, context);

  deliver(sender, run_of("test.ping"));

  const auto saved = context.get(kAuthorizedUndeliveredRun);
  ASSERT_TRUE(saved.has_value());
  EXPECT_EQ(saved->observations, run_of("test.ping"));
  const std::scoped_lock lock(posts().mutex);
  EXPECT_EQ(posts().bodies.size(), 1U);
}

TEST(Sender, deliver_whenTheRequestWouldBeTooLarge_keepsPreviousEvidenceWithoutPosting) {
  reset_posts();
  Context context;
  Sender sender;
  configure(sender, context);
  const auto previous = run_of("test.previous");
  context.put(kSecuritySuppressedRun, previous);
  const std::vector<Observation> run{observed("test.large", "test", std::string(kMaxRequestSize, 'a'))};

  deliver(sender, run);

  EXPECT_EQ(context.get(kSecuritySuppressedRun), previous);
  const auto diagnostic = context.get(kLegacyDeliveryDiagnostic);
  ASSERT_TRUE(diagnostic.has_value());
  EXPECT_EQ(diagnostic->transport, std::nullopt);
  EXPECT_EQ(diagnostic->fallback_refusal, TransportResult::kResponseInvalid);
  EXPECT_EQ(diagnostic->retention, LegacyRetention::kTooLarge);
  const std::scoped_lock lock(posts().mutex);
  EXPECT_TRUE(posts().bodies.empty());
}

TEST(Sender, deliver_whenTrustPinProxyProtocolOrCancellationFails_suppressesDnsAndRetainsVolatileRun) {
  for (const auto failure : {
           TransportResult::kTrustVerificationFailed,
           TransportResult::kPinVerificationFailed,
           TransportResult::kProxyRejected,
           TransportResult::kCancelled,
           TransportResult::kRedirectRejected,
           TransportResult::kHttpRejected,
           TransportResult::kPublicationUnconfirmed,
           TransportResult::kResponseInvalid,
           TransportResult::kTrustEvaluationBusy,
       }) {
    reset_posts();
    posts().accept = false;
    posts().failure = failure;
    Context context;
    Sender sender;
    configure(sender, context);
    const auto run = run_of("test.security");
    deliver(sender, run);
    EXPECT_EQ(context.get(kAuthorizedUndeliveredRun), std::nullopt);
    EXPECT_EQ(context.get(kSecuritySuppressedRun), run);
    const auto diagnostic = context.get(kLegacyDeliveryDiagnostic);
    ASSERT_TRUE(diagnostic.has_value());
    EXPECT_EQ(diagnostic->transport, failure);
    EXPECT_EQ(diagnostic->fallback_refusal, failure);
    EXPECT_EQ(diagnostic->retention, LegacyRetention::kSuppressed);
    const std::scoped_lock lock(posts().mutex);
    EXPECT_EQ(posts().bodies.size(), 1U);
  }
}

TEST(Sender, deliver_whenUnknownStatusOrNestedStorageExceedsRetentionBound_keepsPreviousAuthorizedEvidence) {
  for (const bool nested : {false, true}) {
    reset_posts();
    posts().accept = false;
    Context context;
    Sender sender;
    configure(sender, context);
    const auto previous = run_of("test.previous");
    deliver(sender, previous);
    const auto saved = context.get(kAuthorizedUndeliveredRun);
    ASSERT_TRUE(saved.has_value());
    std::vector<Observation> run;
    if (nested) {
      run.push_back(observed("test.nested", "fixture", std::vector<std::string>(kMaxRequestSize / 8, "")));
    } else {
      run.push_back({
          .signal = "test.unknown",
          .source = "fixture",
          .status = static_cast<Status>(255),
          .value = std::string(kMaxRequestSize, 'x'),
      });
    }
    deliver(sender, std::move(run));
    const auto after = context.get(kAuthorizedUndeliveredRun);
    ASSERT_TRUE(after.has_value());
    EXPECT_EQ(after->observations, previous);
    EXPECT_EQ(after->authorization, saved->authorization);
    EXPECT_EQ(after->https_result, TransportResult::kConnectFailed);
    EXPECT_EQ(context.get(kSecuritySuppressedRun), std::nullopt);
    const auto diagnostic = context.get(kLegacyDeliveryDiagnostic);
    ASSERT_TRUE(diagnostic.has_value());
    EXPECT_EQ(diagnostic->transport, TransportResult::kConnectFailed);
    EXPECT_EQ(diagnostic->retention, LegacyRetention::kTooLarge);
    const std::scoped_lock lock(posts().mutex);
    EXPECT_EQ(posts().bodies.size(),
              2U);  // Both fit on the wire; omitted statuses/nested storage must still be bounded.
  }
}

TEST(Sender, deliver_whenCallerHasLargeSpareCapacity_retainsOnlyOriginalContents) {
  reset_posts();
  posts().accept = false;
  Context context;
  Sender sender;
  configure(sender, context);
  auto run = run_of("test.small");
  run.reserve(kMaxRequestSize / sizeof(Observation));
  run.front().signal.reserve(kMaxRequestSize);
  deliver(sender, std::move(run));
  const auto saved = context.get(kAuthorizedUndeliveredRun);
  ASSERT_TRUE(saved.has_value());
  EXPECT_EQ(saved->observations, run_of("test.small"));
  EXPECT_LT(saved->observations.capacity(), kMaxRequestSize / sizeof(Observation));
  EXPECT_LT(saved->observations.front().signal.capacity(), kMaxRequestSize);
}

TEST(Sender, startSender_whenRunsArriveDuringAPost_postsOnlyTheNewestNext) {
  reset_posts();
  Posts& seen = posts();
  {
    const std::scoped_lock lock(seen.mutex);
    seen.hold = true;
  }
  // NOLINTNEXTLINE(cppcoreguidelines-owning-memory): the sender's thread uses it until the process exits.
  auto* const sender = new Sender();
  configure(*sender, thread_context());
  ASSERT_TRUE(start_sender(*sender));

  sender->mailbox.put(run_of("test.first"));
  {
    std::unique_lock lock(seen.mutex);
    ASSERT_TRUE(seen.changed.wait_for(lock, kWait, [&seen] { return seen.bodies.size() == 1; }));
  }
  sender->mailbox.put(run_of("test.second"));
  sender->mailbox.put(run_of("test.third"));
  {
    const std::scoped_lock lock(seen.mutex);
    seen.hold = false;
  }
  seen.changed.notify_all();

  std::unique_lock lock(seen.mutex);
  ASSERT_TRUE(seen.changed.wait_for(lock, kWait, [&seen] { return seen.bodies.size() == 2; }));
  EXPECT_TRUE(seen.bodies.front().contains(R"("signal":"test.first")"));
  EXPECT_TRUE(seen.bodies.back().contains(R"("signal":"test.third")"));
}

}  // namespace
}  // namespace rasp::plugins::reporting
