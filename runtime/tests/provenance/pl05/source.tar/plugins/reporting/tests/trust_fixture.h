/// Test-only access to actual owned Apple leaf selection; no trust decision is replaced.
#pragma once
#include <Security/SecBase.h>
#include <Security/SecTrust.h>

namespace rasp::plugins::reporting {
/// Caller owns the returned certificate independently of trust and must CFRelease it.
[[nodiscard]] SecCertificateRef transport_fixture_copy_leaf(SecTrustRef trust);
}  // namespace rasp::plugins::reporting
