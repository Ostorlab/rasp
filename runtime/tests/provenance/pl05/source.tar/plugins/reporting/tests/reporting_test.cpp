#include "reporting/transport_result.h"
/// Tests for kPlugin, the reporting plugin, through its init and its on_observations. The test defines the transport's
/// `post`, so the plugin's sender posts to it, and the test reads what it received and what the plugin left in the
/// context.

#include <algorithm>
#include <array>
#include <chrono>
#include <condition_variable>
#include <expected>
#include <filesystem>
#include <gtest/gtest.h>
#include <mutex>
#include <optional>
#include <rasp/config.h>
#include <rasp/private_storage.h>
#include <string>
#include <string_view>
#include <thread>
#include <vector>

#include "config.h"
#include "json.h"
#include "rasp/context.h"
#include "rasp/cycle.h"
#include "rasp/observation.h"
#include "rasp/plugin.h"
#include "rasp/posix/private_storage.h"
#include "reporting/delivery.h"
#include "reporting/undelivered_run.h"
#include "transport.h"

namespace {
std::mutex& provider_mutex() {
  static std::mutex value;
  return value;
}
std::string& provider_root() {
  static std::string value;
  return value;
}
}  // namespace
namespace rasp {
std::expected<PrivateStorage, StorageError> acquire_private_storage() {
  std::string root;
  {
    const std::scoped_lock lock(provider_mutex());
    root = provider_root();
  }
  return root.empty() ? std::unexpected(StorageError::kUnavailable) : posix::acquire_private_storage_at(root);
}
}  // namespace rasp

namespace rasp::plugins::reporting {

/// The reporting plugin, which the plugin's sources define.
extern const Plugin kPlugin;

namespace {

/// How long a test waits for the plugin's sender.
constexpr std::chrono::seconds kWait{10};
/// How long a test sleeps between two reads of the context while it waits for the plugin's sender.
constexpr std::chrono::milliseconds kPollInterval{10};

/// What the transport received, shared with the plugin's sender thread.
struct Received {
  /// Guards every other field.
  std::mutex mutex;
  /// Signalled after each post.
  std::condition_variable posted;
  /// The config of every post, in order.
  std::vector<Config> configs;
  /// The body of every post, in order.
  std::vector<std::string> bodies;
  /// What the transport answers.
  bool accept = true;
};

/// What the transport received in this process.
///
/// @return What it received.
[[nodiscard]] Received& received() {
  static Received value;
  return value;
}

/// Forgets every post, and sets what the transport answers.
///
/// @param accept What the transport answers from now on.
void reset_received(bool accept) {
  static constexpr DnsFallback kSelected{.zone = "fallback.test", .collection_policy = "default"};
  register_dns_fallback(&kSelected);
  Received& seen = received();
  const std::scoped_lock lock(seen.mutex);
  seen.configs.clear();
  seen.bodies.clear();
  seen.accept = accept;
}

/// A new context the plugins share, for one test. It is never destroyed, because the plugin's sender keeps it until
/// the process exits.
///
/// @return The context.
[[nodiscard]] Context& new_context() {
  // NOLINTNEXTLINE(cppcoreguidelines-owning-memory): the plugin's sender uses it until the process exits.
  return *new Context();
}

/// Waits until the context holds the run the plugin did not deliver, for at most kWait.
///
/// @param context The context the plugins share.
/// @return All the observations of the run. Nothing when kWait passed first.
[[nodiscard]] std::optional<std::vector<Observation>> wait_for_undelivered_run(const Context& context) {
  const auto deadline = std::chrono::steady_clock::now() + kWait;
  auto run = context.get(kAuthorizedUndeliveredRun);
  while (!run.has_value() && std::chrono::steady_clock::now() < deadline) {
    std::this_thread::sleep_for(kPollInterval);
    run = context.get(kAuthorizedUndeliveredRun);
  }
  return run.has_value() ? std::optional(run->observations) : std::nullopt;
}

}  // namespace

/// The transport of the tests: it records each post and answers `accept`.
///
/// @param config The plugin's config.
/// @param body The request.
/// @return `accept`.
TransportResult post(const Config& config, std::string_view body, Cancellation /*cancellation*/) noexcept {
  Received& seen = received();
  const std::scoped_lock lock(seen.mutex);
  seen.configs.push_back(config);
  seen.bodies.emplace_back(body);
  seen.posted.notify_all();
  return seen.accept ? TransportResult::kPublicationAcknowledged : TransportResult::kConnectFailed;
}

namespace {

TEST(ReportingPlugin, kPlugin_hasAnInitNoCheckAndAnOnObservations) {
  EXPECT_NE(kPlugin.init, nullptr);
  EXPECT_TRUE(kPlugin.checks.empty());
  EXPECT_NE(kPlugin.on_observations, nullptr);
}

TEST(ReportingPlugin, onObservations_whenInitialisedThenGivenARun_postsItsObservationsToTheCompiledInEndpoint) {
  reset_received(true);
  Context& context = new_context();
  kPlugin.init({.build_id = "build-7"}, context);
  {
    const std::vector<Observation> run{observed("jb.fork_ok", "fork", false), failed("dbg.tracer_pid", "proc")};
    kPlugin.on_observations(run, context);
  }

  Received& seen = received();
  std::unique_lock lock(seen.mutex);
  ASSERT_TRUE(seen.posted.wait_for(lock, kWait, [&seen] { return !seen.bodies.empty(); }));
  ASSERT_EQ(seen.bodies.size(), 1U);
  EXPECT_EQ(seen.configs.front().endpoint, RASP_REPORTING_ENDPOINT);
  const std::string_view body = seen.bodies.front();
  EXPECT_EQ(body, R"({"query":")" + std::string(kMutation) +
                      R"(","variables":{"batch":{"installId":"00000000-0000-0000-0000-000000000000",)"
                      R"("sessionId":"00000000-0000-0000-0000-000000000000","buildId":"build-7","observations":[)"
                      R"({"signal":"jb.fork_ok","source":"fork","status":"OK","value":{"bool":false}},)"
                      R"({"signal":"dbg.tracer_pid","source":"proc","status":"ERROR","value":null}]}}})");
}

TEST(ReportingPlugin, init_whenGivenAnInstallId_givesItToTheSender) {
  reset_received(true);
  Context& context = new_context();
  kPlugin.init({.build_id = "build-7", .install_id = "0f8e5b8e-6c1a-4b7e-9d3a-2a4c5e6f7a8b"}, context);

  kPlugin.on_observations(std::vector<Observation>{observed("jb.fork_ok", "fork", false)}, context);

  Received& seen = received();
  std::unique_lock lock(seen.mutex);
  ASSERT_TRUE(seen.posted.wait_for(lock, kWait, [&seen] { return !seen.configs.empty(); }));
  EXPECT_EQ(seen.configs.front().install_id, "0f8e5b8e-6c1a-4b7e-9d3a-2a4c5e6f7a8b");
}

TEST(ReportingPlugin, onObservations_whenThePostFails_leavesTheRunInTheContext) {
  reset_received(false);
  Context& context = new_context();
  const std::vector<Observation> run{observed("jb.fork_ok", "fork", false), failed("dbg.tracer_pid", "proc")};
  kPlugin.init({.build_id = "build-7"}, context);

  kPlugin.on_observations(run, context);

  EXPECT_EQ(wait_for_undelivered_run(context), run);
}

}  // namespace
TEST(Reporting, registration_whenCycleContractAvailable_hasOwningCallback) { EXPECT_NE(kPlugin.on_cycle, nullptr); }
TEST(Reporting, onCycle_whenRealMonitorAndContextDestroyed_postsOwningImmutableSnapshot) {
  std::array<char, 40> pattern{};
  const std::string text = "/tmp/pl03-registration-XXXXXX";
  std::ranges::copy(text, pattern.begin());
  const auto* temporary = mkdtemp(pattern.data());
  ASSERT_NE(temporary, nullptr);
  const std::string root(temporary);
  {
    const std::scoped_lock lock(provider_mutex());
    provider_root() = root;
  }
  reset_received(true);
  {
    Context context;
    rasp::Config const config{
        .build_id = std::string(64, 'b'),
        .checks = std::vector<std::string>{},
        .install_id = std::string(kZeroUuid),
    };
    kPlugin.init(config, context);
    const std::array<const Plugin*, 1> plugins{&kPlugin};
    CycleMonitor monitor;
    const auto snapshot = monitor.run(config, cycle_catalogue("android"), plugins, context,
                                      [](const rasp::Config&, const void*) { return std::vector<Observation>{}; });
    ASSERT_TRUE(snapshot->metadata.complete);
    EXPECT_FALSE(context.get(kAuthorizedUndeliveredRun).has_value());
  }
  Received& seen = received();
  {
    std::unique_lock lock(seen.mutex);
    ASSERT_TRUE(seen.posted.wait_for(lock, kWait, [&seen] { return !seen.bodies.empty(); }));
    ASSERT_EQ(seen.bodies.size(), 1);
    EXPECT_NE(seen.bodies[0].find("\"cycle\""), std::string::npos);
    EXPECT_NE(seen.bodies[0].find("\"complete\":true"), std::string::npos);
    EXPECT_EQ(seen.bodies[0].find(std::string(kZeroUuid)), std::string::npos);
  }
  const auto deadline = std::chrono::steady_clock::now() + kWait;
  while (delivery_health().publication_acknowledged == 0 && std::chrono::steady_clock::now() < deadline) {
    std::this_thread::sleep_for(kPollInterval);
  }
  EXPECT_EQ(delivery_health().publication_acknowledged, 1);
  {
    const std::scoped_lock lock(provider_mutex());
    provider_root().clear();
  }
  std::filesystem::remove_all(root);
}

}  // namespace rasp::plugins::reporting
