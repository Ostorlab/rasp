"""Exercise actual sender/outbox over local TLS; generate disposable keys without any external connection."""

from __future__ import annotations

import base64
import contextlib
import hashlib
import json
import os
import pathlib
import selectors
import socket
import ssl
import subprocess
import sys
import tempfile
import threading
import time
from typing import Any

ACK = b'{"data":{"submitObservations":true}}'


def openssl(folder: pathlib.Path, *arguments: str) -> bytes:
    try:
        return subprocess.run(["openssl", *arguments], cwd=folder, capture_output=True, check=True, timeout=20).stdout
    except subprocess.CalledProcessError as error:
        # These commands use disposable fixture files. Never print stdout, which may contain key material.
        diagnostic = error.stderr.decode(errors="replace")[-4096:]
        raise RuntimeError(f"openssl {arguments[0]} failed ({error.returncode}): {diagnostic}") from error


def certificates(folder: pathlib.Path) -> dict[str, dict[str, str]]:
    (folder / "ca.cnf").write_text(
        "[req]\ndistinguished_name=subject\n[subject]\nCN=Disposable-fixture\n"
        "[ca]\nbasicConstraints=critical,CA:TRUE,pathlen:0\nkeyUsage=critical,keyCertSign,cRLSign\n"
        "subjectKeyIdentifier=hash\nauthorityKeyIdentifier=keyid:always\n"
    )
    for authority in ("ca", "other"):
        openssl(
            folder,
            "req",
            "-x509",
            "-sha256",
            "-config",
            "ca.cnf",
            "-extensions",
            "ca",
            "-newkey",
            "rsa:2048",
            "-nodes",
            "-keyout",
            authority + ".key",
            "-out",
            authority + ".pem",
            "-days",
            "2",
            "-subj",
            "/CN=Disposable-" + authority,
        )
        openssl(folder, "x509", "-in", authority + ".pem", "-outform", "DER", "-out", authority + ".pem.der")
    pins: dict[str, dict[str, str]] = {}
    for role in ("primary", "backup", "outside"):
        if role == "backup":
            openssl(folder, "genpkey", "-algorithm", "EC", "-pkeyopt", "ec_paramgen_curve:P-256", "-out", role + ".key")
        else:
            openssl(folder, "genpkey", "-algorithm", "RSA", "-pkeyopt", "rsa_keygen_bits:2048", "-out", role + ".key")
        openssl(folder, "req", "-new", "-key", role + ".key", "-out", role + ".csr", "-subj", "/CN=collector.test")
        spki = openssl(folder, "pkey", "-in", role + ".key", "-pubout", "-outform", "DER")
        pins[role] = {
            "key_algorithm": "ec-p256" if role == "backup" else "rsa-2048",
            "value": "sha256//" + base64.b64encode(hashlib.sha256(spki).digest()).decode(),
        }
    for name, role, authority, host in (
        ("primary", "primary", "ca", "collector.test"),
        ("backup", "backup", "ca", "collector.test"),
        ("outside", "outside", "ca", "collector.test"),
        ("wrong-ca", "primary", "other", "collector.test"),
        ("wrong-host", "primary", "ca", "other.test"),
    ):
        usage = "digitalSignature" if role == "backup" else "digitalSignature,keyEncipherment"
        (folder / "extensions").write_text(
            "subjectAltName=DNS:"
            + host
            + "\nbasicConstraints=CA:FALSE\nextendedKeyUsage=serverAuth\nkeyUsage=critical,"
            + usage
            + "\nsubjectKeyIdentifier=hash\nauthorityKeyIdentifier=keyid:always\n"
        )
        openssl(
            folder,
            "x509",
            "-sha256",
            "-req",
            "-in",
            role + ".csr",
            "-CA",
            authority + ".pem",
            "-CAkey",
            authority + ".key",
            "-set_serial",
            str(100 + len(name)),
            "-days",
            "2",
            "-extfile",
            "extensions",
            "-out",
            name + ".pem",
        )
    # x509 -days -1 is rejected by some OpenSSL/LibreSSL versions. CA signing accepts explicit past dates.
    # Its config, database, serial and generated certificates stay inside the disposable fixture directory.
    (folder / "expired-index").write_text("")
    (folder / "expired-serial").write_text("6B\n")
    (folder / "expired-ca.cnf").write_text(
        "[ca]\ndefault_ca=fixture_ca\n"
        "[fixture_ca]\ndatabase=expired-index\nserial=expired-serial\nnew_certs_dir=.\n"
        "certificate=ca.pem\nprivate_key=ca.key\ndefault_md=sha256\npolicy=fixture_subject\n"
        "[fixture_subject]\ncommonName=supplied\n"
        "[leaf]\nsubjectAltName=DNS:collector.test\nbasicConstraints=CA:FALSE\n"
        "extendedKeyUsage=serverAuth\nkeyUsage=critical,digitalSignature,keyEncipherment\n"
        "subjectKeyIdentifier=hash\nauthorityKeyIdentifier=keyid:always\n"
    )
    openssl(
        folder,
        "ca",
        "-batch",
        "-notext",
        "-config",
        "expired-ca.cnf",
        "-extensions",
        "leaf",
        "-startdate",
        "200101000000Z",
        "-enddate",
        "200102000000Z",
        "-in",
        "primary.csr",
        "-out",
        "expired.pem",
    )
    dates = openssl(folder, "x509", "-in", "expired.pem", "-noout", "-dates").decode().splitlines()
    validity = dict(line.split("=", 1) for line in dates)
    assert ssl.cert_time_to_seconds(validity["notBefore"]) == 1577836800
    assert ssl.cert_time_to_seconds(validity["notAfter"]) == 1577923200 < time.time()
    print("PASS disposable expired leaf validity 2020-01-01T00:00:00Z..2020-01-02T00:00:00Z")
    return pins


class Server:
    """Bounded single-request TLS fixture; failed TLS never becomes a successful HTTP control."""

    def __init__(
        self,
        folder: pathlib.Path,
        certificate: str,
        body: bytes = ACK,
        status: int = 200,
        port: int = 0,
        delay: float = 0,
        handshake_stall: bool = False,
        connections: int = 1,
        connect_proxy: bool = False,
        raw_response: bytes | None = None,
        drop_response: bool = False,
        accept_timeout: float = 15,
        read_timeout: float = 2,
        redirect_location: str = "http://127.0.0.1:1/forbidden",
    ) -> None:
        self.listener = socket.socket()
        self.listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.listener.bind(("127.0.0.1", port))
        self.listener.listen(2)
        self.listener.setblocking(False)
        self.accept_timeout = accept_timeout
        self.wake_reader, self.wake_writer = socket.socketpair()
        self.stopped = threading.Event()
        self.accept_waiting = threading.Event()
        self.port = int(self.listener.getsockname()[1])
        self.read_timeout = read_timeout
        self.request = b""
        self.requests: list[bytes] = []
        self.accepted = 0
        self.proxy_connects = 0
        self.proxy_invalid_prefaces = 0
        self.proxy_invalid_tls_headers: list[str] = []
        self.proxy_authorities: list[bytes] = []
        self.tls_handshakes = 0
        self.redirect_location = redirect_location
        self.body = body
        self.status = status
        self.delay = delay
        self.handshake_stall = handshake_stall
        self.connections = connections
        self.connect_proxy = connect_proxy
        self.raw_response = raw_response
        self.drop_response = drop_response
        self.context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        role = "primary" if certificate in ("wrong-ca", "wrong-host", "expired") else certificate
        self.context.load_cert_chain(folder / (certificate + ".pem"), folder / (role + ".key"))
        self.thread = threading.Thread(target=self.serve)

    def serve(self) -> None:
        with selectors.DefaultSelector() as ready:
            ready.register(self.listener, selectors.EVENT_READ)
            ready.register(self.wake_reader, selectors.EVENT_READ)
            for _ in range(self.connections):
                if self.stopped.is_set() is True:
                    return
                self.accept_waiting.set()
                events = ready.select(self.accept_timeout)
                if self.stopped.is_set() is True or len(events) == 0:
                    return
                if any(key.fileobj is self.wake_reader for key, _ in events):
                    return
                self.request = b""
                self.serve_one()

    def serve_one(self) -> None:
        try:
            connection, _ = self.listener.accept()
            self.accepted += 1
            with connection:
                connection.settimeout(self.read_timeout)
                if self.connect_proxy is True:
                    connect = b""
                    while b"\r\n\r\n" not in connect and len(connect) < 4096:
                        # Stop exactly at the CONNECT header boundary; a client may already send tunnel TLS bytes.
                        data = connection.recv(1)
                        if data == b"":
                            return
                        connect += data
                        if len(connect) == 1 and data != b"C":
                            self.proxy_invalid_prefaces += 1
                            # At most the TLS record header, never ClientHello random/SNI or plaintext payload.
                            prefix = data
                            with contextlib.suppress(OSError):
                                prefix += connection.recv(4, socket.MSG_PEEK | socket.MSG_DONTWAIT)
                            if len(prefix) >= 3 and prefix[0] == 22 and prefix[1] == 3:
                                self.proxy_invalid_tls_headers.append(prefix[:5].hex())
                            return
                    if not connect.startswith(b"CONNECT ") or not connect.endswith(b"\r\n\r\n"):
                        self.proxy_invalid_prefaces += 1
                        return
                    self.proxy_connects += 1
                    parts = connect.split(b"\r\n", 1)[0].split(b" ")
                    if len(parts) != 3:
                        self.proxy_invalid_prefaces += 1
                        return
                    self.proxy_authorities.append(parts[1])
                    connection.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
                if self.handshake_stall is True:
                    time.sleep(self.delay if self.delay > 0 else 1)
                    return
                with self.context.wrap_socket(connection, server_side=True) as tls:
                    self.tls_handshakes += 1
                    while len(self.request) <= 262144:
                        data = tls.recv(4096)
                        if data == b"":
                            return
                        self.request += data
                        headers, separator, payload = self.request.partition(b"\r\n\r\n")
                        if separator != b"":
                            lengths = [
                                line.split(b":", 1)[1].strip()
                                for line in headers.split(b"\r\n")
                                if line.lower().startswith(b"content-length:")
                            ]
                            if len(lengths) == 1 and len(payload) >= int(lengths[0]):
                                break
                    self.requests.append(self.request)
                    time.sleep(self.delay)
                    if self.drop_response is True:
                        return
                    if self.raw_response is not None:
                        tls.sendall(self.raw_response)
                        return
                    redirect = (
                        ("Location: " + self.redirect_location + "\r\n").encode() if 300 <= self.status < 400 else b""
                    )
                    tls.sendall(
                        f"HTTP/1.1 {self.status} Fixture\r\nContent-Length: {len(self.body)}\r\n".encode()
                        + redirect
                        + b"Connection: close\r\n\r\n"
                        + self.body
                    )
        except OSError:
            return

    def __enter__(self) -> Server:
        self.thread.start()
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def close(self) -> None:
        # Cross-thread close/shutdown of a listening socket need not wake accept on macOS. A dedicated socketpair
        # wakes the selector without creating a fake accepted connection or altering request counters.
        self.stopped.set()
        with contextlib.suppress(OSError):
            self.wake_writer.send(b"\0")
        if self.thread.ident is not None:
            self.thread.join(timeout=4)
        try:
            assert self.thread.is_alive() is False
        finally:
            self.listener.close()
            self.wake_reader.close()
            self.wake_writer.close()


def strict_context(folder: pathlib.Path, authority: str = "ca") -> ssl.SSLContext:
    context = ssl.create_default_context(cafile=str(folder / (authority + ".pem")))
    context.verify_flags |= ssl.VERIFY_X509_STRICT
    assert context.verify_mode == ssl.CERT_REQUIRED
    assert context.check_hostname is True
    return context


def strict_chain_control(folder: pathlib.Path) -> None:
    request = b"POST /strict-ca HTTP/1.1\r\nHost: collector.test\r\nContent-Length: 2\r\n\r\n{}"
    for certificate, authority in (("primary", "ca"), ("backup", "ca"), ("wrong-ca", "other")):
        context = strict_context(folder, authority)
        assert (context.verify_flags & ssl.VERIFY_X509_STRICT) == ssl.VERIFY_X509_STRICT
        with (
            Server(folder, certificate) as server,
            socket.create_connection(("127.0.0.1", server.port), timeout=2) as connection,
            context.wrap_socket(connection, server_hostname="collector.test") as tls,
        ):
            tls.sendall(request)
            response = b""
            while b"\r\n\r\n" not in response and len(response) < 4096:
                data = tls.recv(4096)
                assert data != b""
                response += data
            assert response.startswith(b"HTTP/1.1 200 ")
        assert server.requests == [request]
        assert server.tls_handshakes == 1
        print(f"PASS VERIFY_X509_STRICT actual TLS chain/hostname/POST {certificate} authority={authority}")


def server_shutdown(folder: pathlib.Path) -> None:
    for awaiting_accept in (False, True):
        for _ in range(4):
            with Server(folder, "primary", accept_timeout=120) as server:
                if awaiting_accept is True:
                    assert server.accept_waiting.wait(timeout=2) is True
            assert server.accepted == 0
            assert server.request == b""
            assert server.requests == []
            assert server.listener.fileno() == server.wake_reader.fileno() == server.wake_writer.fileno() == -1
    print("PASS no-request server shutdown before/during accept: zero accepted/POST, joined thread, all sockets closed")


def run(
    client: str,
    folder: pathlib.Path,
    server: Server,
    profile: dict[str, Any],
    store: pathlib.Path,
    action: str = "admit",
    cancel_ms: int = -1,
    environment: dict[str, str] | None = None,
    scheme: str = "https",
    origin_port: int | None = None,
) -> dict[str, Any]:
    port = server.port if origin_port is None else origin_port
    value = dict(profile, port=port)
    store.mkdir(mode=0o700, exist_ok=True)
    command = [
        client,
        f"{scheme}://collector.test:{port}/a/../ingest/%2f?",
        json.dumps(value, separators=(",", ":")),
        str(folder / "ca.pem"),
        str(store),
        str(cancel_ms),
        action,
    ]
    result = subprocess.run(command, capture_output=True, text=True, timeout=25, env=environment, check=True)
    # Private Apple callback evidence contains only numeric domain/code/result, never peer/request text.
    for line in result.stderr.splitlines():
        if line.startswith(("RASP_TEST_NW_WAITING ", "RASP_TEST_NW_PROXY ", "RASP_TEST_NW_PROXY_SETUP ")):
            print(line[:256])
    return json.loads(result.stdout)


def main() -> None:
    client = sys.argv[1]
    with tempfile.TemporaryDirectory(prefix="reporting-tls-") as directory:
        folder = pathlib.Path(directory)
        pins = certificates(folder)
        strict_chain_control(folder)
        server_shutdown(folder)
        now = int(time.time())
        profile: dict[str, Any] = {
            "version": 1,
            "mode": "leaf-spki-sha256",
            "host": "collector.test",
            "port": 443,
            "pins": {"primary": pins["primary"], "backup": pins["backup"]},
            "validity": {"not_before": now - 3600, "not_after": now + 3600},
        }
        for certificate in ("primary", "backup"):
            with Server(folder, certificate) as server:
                summary = run(client, folder, server, profile, folder / ("valid-" + certificate))
            assert summary["result"] == 0, summary
            assert summary["pending"] == 0, summary
            assert summary["attempts"] == 1, summary
            assert server.request.startswith(b"POST /a/../ingest/%2f? HTTP/1.1\r\n")
            assert b"Authorization:" not in server.request
            print("PASS actual TLS primary/backup", certificate)
        system = dict(profile, mode="system", pins=None, validity=None)
        # The actual transport returns a real connect failure; only the external handoff clock/cancel instant is
        # controlled. Both real callers must revalidate, while an unchanged valid policy retains opt-in fallback.
        for action in ("admit", "legacy"):
            faults = ["valid", "expired", "unavailable", "cancel"]
            if action == "admit":
                faults.append("dns-mismatch")
            for fault in faults:
                unavailable = Server(folder, "primary")
                unavailable.close()
                environment = dict(os.environ)
                if fault in ("expired", "unavailable"):
                    environment["RASP_TEST_CLOCK_AT_HANDOFF"] = fault
                elif fault == "cancel":
                    environment["RASP_TEST_CANCEL_AT_HANDOFF"] = "1"
                elif fault == "dns-mismatch":
                    environment["RASP_TEST_DNS_MISMATCH_AT_HANDOFF"] = "1"
                summary = run(
                    client,
                    folder,
                    unavailable,
                    profile,
                    folder / (action + "-handoff-" + fault),
                    action=action,
                    environment=environment,
                )
                assert summary["result"] == 11, summary
                assert summary["pending"] == 1, summary
                assert summary["dns_handoffs"] == (1 if fault == "valid" else 0), summary
                if action == "admit" and fault == "valid":
                    assert summary["failure"] == 13, summary  # kNetwork, an actual connection failure.
                if action == "admit":
                    assert summary["original_request_retained"] is True, summary
                if action == "admit" and fault == "dns-mismatch":
                    assert summary["failure"] == 6, summary  # Actual original DNS authority mismatch.
                    assert summary["effective_result"] == 11, summary
                if action == "admit" and fault not in ("valid", "dns-mismatch"):
                    assert summary["failure"] == 14, summary  # Current matched-authority transport policy refused.
                    assert summary["effective_result"] == (8 if fault == "cancel" else 2), summary
                if action == "legacy":
                    assert summary["legacy_suppressed"] == (fault != "valid"), summary
                print("PASS actual caller fallback boundary", action, fault)
            for fault in ("expired", "unavailable"):
                environment = dict(os.environ, RASP_TEST_CLOCK_AT_HANDOFF=fault)
                with Server(folder, "primary") as server:
                    summary = run(
                        client,
                        folder,
                        server,
                        profile,
                        folder / (action + "-ack-" + fault),
                        action=action,
                        environment=environment,
                    )
                assert summary["result"] == 0, summary
                assert summary["pending"] == 0, summary
                assert summary["dns_handoffs"] == 0, summary
                assert len(server.requests) == 1
                print("PASS true acknowledgement preserves cleanup", action, fault)
        clock = int(time.time())
        response_expiry = dict(profile, validity={"not_before": clock - 60, "not_after": clock + 4})
        with Server(folder, "primary", delay=5) as server:
            summary = run(client, folder, server, response_expiry, folder / "response-expiry")
        assert summary["result"] == 2, summary
        assert summary["pending"] == 1, summary
        assert summary["dns_handoffs"] == 0, summary
        assert len(server.requests) == 1
        print("PASS actual profile expiry while awaiting TLS response suppresses DNS")
        for action, scheme, expected in (("direct", "http", 15), ("direct-cancel", "https", 8)):
            with Server(folder, "primary") as server:
                summary = run(client, folder, server, profile, folder / action, action=action, scheme=scheme)
            assert summary["result"] == expected, summary
            assert server.request == b""
            assert server.accepted == 0
        expired_profile = dict(profile, validity={"not_before": 100, "not_after": 200})
        with Server(folder, "primary") as server:
            summary = run(client, folder, server, expired_profile, folder / "profile-expired", action="direct")
        assert summary["result"] == 2, summary
        assert server.request == b""
        assert server.accepted == 0
        print("PASS actual transport rejects HTTP, pre-cancel and expired profile before connection")
        with Server(folder, "primary") as server:
            summary = run(client, folder, server, system, folder / "system")
        assert summary["result"] == 0, summary
        assert summary["pending"] == 0, summary
        print("PASS actual TLS system CA+hostname")
        for certificate, expected in (("wrong-ca", 4), ("wrong-host", 4), ("outside", 5), ("expired", 4)):
            store = folder / certificate
            with Server(folder, certificate) as server:
                summary = run(client, folder, server, profile, store)
            assert summary["result"] == expected, summary
            assert summary["pending"] == 1, summary
            assert summary["dns_handoffs"] == 0, summary
            assert server.request == b"", certificate
            assert summary["failure"] == 14, summary  # kTransportRefused, not a network outage.
            original = {path.name: path.read_bytes() for path in store.rglob("*.rec")}
            assert len(original) == 1
            with Server(folder, "backup", port=server.port) as retry:
                summary = run(client, folder, retry, profile, store, "resume")
            assert summary["result"] == 0, summary
            assert summary["pending"] == 0, summary
            print("PASS actual TLS rejection + exact-record retry", certificate)
        with Server(folder, "primary") as server:
            summary = run(client, folder, server, profile, folder / "v1-held", action="v1")
        assert summary["attempts"] == 0, summary
        assert summary["pending"] == 1, summary
        assert summary["dns_handoffs"] == 0, summary
        assert server.request == b""
        store = folder / "rotation-held"
        with Server(folder, "outside") as server:
            summary = run(client, folder, server, profile, store)
        before = {
            str(path.relative_to(store)): path.read_bytes()
            for path in store.rglob("*")
            if path.suffix in (".rec", ".try")
        }
        changed = json.loads(json.dumps(profile))
        changed["pins"]["backup"] = pins["outside"]
        with Server(folder, "primary", port=server.port) as held:
            summary = run(client, folder, held, changed, store, "resume")
        assert summary["attempts"] == 0, summary
        assert summary["pending"] == 1, summary
        assert held.request == b""
        after = {
            str(path.relative_to(store)): path.read_bytes()
            for path in store.rglob("*")
            if path.suffix in (".rec", ".try")
        }
        assert before == after
        with Server(folder, "backup", port=server.port) as restored:
            summary = run(client, folder, restored, profile, store, "resume")
        assert summary["result"] == 0, summary
        assert summary["pending"] == 0, summary
        print("PASS actual outbox v1/v2 and pin-rotation holds preserve record/retry bytes")
        wrong_metadata = json.loads(json.dumps(profile))
        wrong_metadata["pins"]["primary"]["key_algorithm"] = "ec-p256"
        with Server(folder, "primary") as server:
            summary = run(client, folder, server, wrong_metadata, folder / "wrong-algorithm")
        assert summary["result"] == 5, summary
        assert summary["failure"] == 14, summary
        assert summary["pending"] == 1, summary
        assert server.request == b"", summary
        print("PASS actual TLS matched pin algorithm association")
        with contextlib.closing(socket.socket()) as redirect_sink:
            redirect_sink.bind(("127.0.0.1", 0))
            redirect_sink.listen(8)
            redirect_sink.settimeout(0.1)
            for status in (301, 302, 303, 307, 308, 204, 205, 500):
                redirect_scheme = "https" if status in (302, 307) else "http"
                location = f"{redirect_scheme}://127.0.0.1:{redirect_sink.getsockname()[1]}/forbidden"
                with Server(folder, "primary", status=status, redirect_location=location) as server:
                    summary = run(client, folder, server, profile, folder / str(status))
                assert summary["pending"] == 1, summary
                assert summary["dns_handoffs"] == 0, summary
                assert summary["result"] == (14 if status < 400 and status not in (204, 205) else 15), summary
                assert summary["failure"] == 14, summary
                assert server.accepted == 1
                assert len(server.requests) == 1
                assert server.request.startswith(b"POST /a/../ingest/%2f? HTTP/1.1\r\n")
                print(f"PASS actual HTTPS origin status={status} result={summary['result']} captured_requests=1")
            with contextlib.suppress(TimeoutError):
                connection, _ = redirect_sink.accept()
                connection.close()
                raise AssertionError("Redirect destination received a connection")
        with Server(folder, "primary", status=302, redirect_location="/second", connections=2) as server:
            summary = run(client, folder, server, profile, folder / "same-origin-redirect")
        assert summary["result"] == 14, summary
        assert summary["pending"] == 1, summary
        assert server.accepted == 1
        assert len(server.requests) == 1
        for body in (
            b"not json",
            b'{"data":{"submitObservations":false}}',
            b'{"data":{"submitObservations":true},"errors":[]}',
            ACK + b" trailing",
            ACK + b" " * 65536,
        ):
            with Server(folder, "primary", body=body) as server:
                summary = run(
                    client, folder, server, profile, folder / ("body-" + hashlib.sha256(body).hexdigest()[:8])
                )
            assert summary["pending"] == 1, summary
            assert summary["result"] != 0, summary
            assert summary["failure"] == 14, summary
        print("PASS actual TLS redirect/status/malformed/oversize acknowledgement retention")
        for label, status, body, expected in (
            ("unconfirmed", 200, b'{"data":{"submitObservations":false}}', 17),
            ("http-rejected", 503, ACK, 15),
            ("redirect", 302, ACK, 14),
        ):
            with Server(folder, "primary", status=status, body=body) as server:
                summary = run(client, folder, server, profile, folder / ("legacy-" + label), action="legacy")
            assert summary["result"] == expected, summary
            assert summary["legacy_diagnostic"] == expected, summary
            assert summary["legacy_retention"] == 2, summary
            assert summary["legacy_original_matches"] is True, summary
            assert summary["legacy_suppressed"] is True, summary
            assert summary["pending"] == 1, summary
            assert summary["dns_handoffs"] == 0, summary
            assert len(server.requests) == 1
            print(f"PASS actual legacy one-shot {label} result={expected} original retained/typed suppression/no DNS")
        for label, raw in (
            ("truncated", b"HTTP/1.1 200 OK\r\nContent-Length: 1000\r\n\r\n" + ACK),
            ("malformed-http", b"invalid status\r\n\r\n" + ACK),
        ):
            with Server(folder, "primary", raw_response=raw) as server:
                summary = run(client, folder, server, profile, folder / label)
            assert summary["result"] == 16, summary
            assert summary["failure"] == 14, summary
            assert summary["pending"] == 1, summary
            assert summary["dns_handoffs"] == 0, summary
        print("PASS actual TLS truncated/malformed HTTP suppresses DNS")
        store = folder / "lost-ack"
        with Server(folder, "primary", drop_response=True) as lost:
            first = run(client, folder, lost, profile, store)
        assert first["pending"] == 1, first
        original = {path.name: path.read_bytes() for path in store.rglob("*.rec")}
        assert len(original) == 1
        with Server(folder, "backup", port=lost.port) as retried:
            second = run(client, folder, retried, profile, store, "resume")
        assert second["result"] == 0, second
        assert second["pending"] == 0, second
        assert lost.request == retried.request
        capture = os.environ.get("PL05_TLS_CAPTURE")
        if capture is not None:
            output = pathlib.Path(capture)
            output.mkdir(parents=True, exist_ok=True)
            (output / "first-request.json").write_bytes(lost.request.partition(b"\r\n\r\n")[2])
            (output / "retry-request.json").write_bytes(retried.request.partition(b"\r\n\r\n")[2])
            (output / "original.rec").write_bytes(next(iter(original.values())))
            (output / "summaries.json").write_text(json.dumps([first, second]))
        print(
            "PASS actual TLS lost acknowledgement replays byte-identical original request and cleans only on true ack"
        )
        for stall in (False, True):
            with Server(folder, "primary", delay=0.5, handshake_stall=stall) as server:
                summary = run(client, folder, server, profile, folder / ("cancel-" + str(stall)), cancel_ms=100)
            assert summary["result"] == 8, summary
            assert summary["pending"] == 1, summary
            assert summary["transport_ms"] < 350, summary
            assert summary["dns_handoffs"] == 0, summary
            print("MEASURE cancellation_ms", stall, summary["transport_ms"])
        print("PASS actual TLS cancellation during handshake/read and late response retention")
        for handshake in (False, True):
            with Server(folder, "primary", delay=11, handshake_stall=handshake) as server:
                summary = run(client, folder, server, profile, folder / ("timeout-" + str(handshake)))
            assert summary["result"] == 12, summary
            assert summary["pending"] == 1, summary
            assert summary["elapsed_ms"] < 21000, summary
            print("MEASURE timeout_ms", handshake, summary["elapsed_ms"])
        print("PASS actual TLS handshake/response timeout retains original record")
        if sys.platform == "linux":
            environment = dict(os.environ, RASP_TEST_STALL_DNS_MS="5000", CURL_DBG_RESOLV_MAX_THREADS="64")
            with Server(folder, "primary", accept_timeout=8) as server:
                summary = run(
                    client, folder, server, profile, folder / "stalled-resolver", cancel_ms=100, environment=environment
                )
            assert summary["result"] == 8, summary
            assert summary["pending"] == 1, summary
            assert summary["dns_handoffs"] == 0, summary
            assert summary["transport_ms"] < 350, summary
            assert summary["resolver_peak"] == 1, summary
            assert summary["late_busy"] == 8, summary
            assert summary["late_retry"] == 0, summary
            print("MEASURE stalled_resolver_cancel_ms", summary["transport_ms"], "peak", summary["resolver_peak"])
            print("PASS actual curl resolver cancellation/stress retains one thread and permits valid retry")
        for label, delay, cancel, expected in (
            ("queued-expiry-deadline", 11000, -1, 2),
            ("queued-expiry", 2500, -1, 2),
            ("queued-cancel", 800, 300, 8),
            ("queued-deadline", 11000, -1, 12),
        ):
            with Server(folder, "primary", read_timeout=(delay / 1000) + 3) as server:
                environment = dict(os.environ, RASP_TEST_SEND_QUEUE_DELAY_MS=str(delay))
                if label.startswith("queued-expiry"):
                    environment["RASP_TEST_CLOCK_AT_SEND_QUEUE"] = "expired"
                summary = run(
                    client,
                    folder,
                    server,
                    profile,
                    folder / label,
                    cancel_ms=cancel,
                    environment=environment,
                )
            assert summary["queued_sends"] == 1, summary
            assert summary["attempts"] == 1, summary
            assert summary["result"] == expected, summary
            assert summary["pending"] == 1, summary
            if expected in (2, 8):
                assert summary["dns_handoffs"] == 0, summary
            assert server.request == b"", label
            print("PASS actual TLS pre-send delay releases no POST", label, summary["transport_ms"])
        if sys.platform == "darwin":
            environment = dict(os.environ, RASP_TEST_VERIFY_DELAY_MS="1000")
            with Server(folder, "primary", connections=3) as server:
                summary = run(
                    client, folder, server, profile, folder / "late-trust", cancel_ms=100, environment=environment
                )
            assert summary["result"] == 8, summary
            assert summary["pending"] == 1, summary
            assert summary["late_busy"] == 9, summary
            assert summary["late_retry"] == 0, summary
            print("PASS actual Apple delayed trust callback keeps slot occupied and cannot acknowledge original")
            control_request = b"POST /control HTTP/1.1\r\nHost: collector.test\r\nContent-Length: 2\r\n\r\n{}"
            origin_port = 443
            authority = f"collector.test:{origin_port}".encode("ascii")
            with Server(folder, "primary", connections=2, connect_proxy=True) as proxy:
                # Prove this exact proxy endpoint/CA/SNI/tunnel works before the native refusal assertion can fail.
                control = strict_context(folder)
                with socket.create_connection(("127.0.0.1", proxy.port), timeout=2) as connection:
                    connection.sendall(b"CONNECT " + authority + b" HTTP/1.1\r\nHost: " + authority + b"\r\n\r\n")
                    assert b"200" in connection.recv(512)
                    with control.wrap_socket(connection, server_hostname="collector.test") as tls:
                        tls.sendall(control_request)
                        assert b"200" in tls.recv(512)
                print("PASS independent CONNECT/TLS control on the exact native proxy endpoint")
                environment = dict(os.environ, RASP_TEST_PROXY_PORT=str(proxy.port))
                summary = run(
                    client,
                    folder,
                    proxy,
                    profile,
                    folder / "apple-explicit-proxy",
                    environment=environment,
                    origin_port=origin_port,
                )
            print(
                "MEASURE actual proxy CONNECT/TLS/POST/invalid-preface",
                proxy.proxy_connects,
                proxy.tls_handshakes,
                len(proxy.requests),
                proxy.proxy_invalid_prefaces,
            )
            print(
                "MEASURE proxy logical authority match/TLS record headers",
                proxy.proxy_authorities == [authority, authority],
                proxy.proxy_invalid_tls_headers,
            )
            assert summary["result"] == 7, summary
            assert summary["pending"] == 1, summary
            assert summary["dns_handoffs"] == 0, summary
            assert proxy.request == b""
            assert proxy.requests == [control_request]
            assert proxy.accepted == proxy.proxy_connects == 2
            assert proxy.tls_handshakes >= 1  # The independent control completes TLS; refusal can interrupt the peer.
            assert proxy.proxy_invalid_prefaces == 0
            assert proxy.proxy_authorities == [authority, authority]
            print("PASS actual Apple configured CONNECT proxy releases no POST, independent TLS control succeeds")
        with contextlib.closing(socket.socket()) as proxy:
            proxy.bind(("127.0.0.1", 0))
            proxy.listen(4)
            proxy.settimeout(0.1)
            proxy_url = "http://127.0.0.1:" + str(proxy.getsockname()[1])
            environment = dict(os.environ)
            for name in ("http_proxy", "https_proxy", "all_proxy", "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY"):
                environment[name] = proxy_url
            environment["no_proxy"] = environment["NO_PROXY"] = ""
            with Server(folder, "primary") as server:
                summary = run(client, folder, server, profile, folder / "proxy", environment=environment)
            assert summary["result"] == 0, summary
            unavailable = Server(folder, "primary")
            unavailable.close()
            summary = run(client, folder, unavailable, profile, folder / "proxy-no-direct", environment=environment)
            assert summary["result"] == 11, summary
            assert summary["pending"] == 1, summary
            try:
                connection, _ = proxy.accept()
            except TimeoutError:
                connection = None
            assert connection is None, "Reporting contacted the environment proxy"
        print("PASS actual TLS ignores hostile Android proxy environment")


if __name__ == "__main__":
    main()
