#include "fixture_io.h"

#include <stdatomic.h>
#include <stdlib.h>

#include "security_time.h"
const char* reporting_test_environment(const char* name) { return getenv(name); }

static atomic_int_fast64_t offset_seconds = 0;
static atomic_bool unavailable_clock = 0;
void reporting_test_advance_clock(int64_t seconds) { atomic_store(&offset_seconds, seconds); }
void reporting_test_unavailable_clock(void) { atomic_store(&unavailable_clock, 1); }
int64_t rasp_reporting_utc_seconds(void) {
  const int64_t real = reporting_test_real_utc_seconds();
  const int64_t offset = atomic_load(&offset_seconds);
  return atomic_load(&unavailable_clock) || real < 0 || offset < 0 || real > INT64_MAX - offset ? -1 : real + offset;
}
