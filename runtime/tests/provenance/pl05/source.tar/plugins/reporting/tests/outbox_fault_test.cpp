/// Linux syscall-boundary fault tests execute the actual production outbox and provider.
#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdarg>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <gtest/gtest.h>
#include <ios>
#include <iterator>
#include <memory>
#include <optional>
#include <rasp/cycle.h>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <utility>

#include "collection_authority.h"
#include "cycle_payload.h"
#include "hash.h"
#include "outbox.h"
#include "posix_file.h"
#include "rasp/posix/private_storage.h"

namespace {
enum class Fault : std::uint8_t {
  kNone,
  kReplaceRetry,
  kShortWrite,
  kZeroWrite,
  kDiskFull,
  kFileSync,
  kDirectorySync,
  kClose,
  kLink,
  kUnlink,
  kCrashAfterLink,
  kCrashAfterAckSync,
  kCrashAfterRecordUnlink,
  kCrashPartialTemporary,
};
struct FaultState {
  Fault kind = Fault::kNone;
  unsigned retry_opens = 0;
};
FaultState& fault() {
  thread_local FaultState value;
  return value;
}
}  // namespace
extern "C" {
int real_openat(int directory, const char* name, int flags, ...) __asm__("__real_openat");
int wrap_openat(int directory, const char* name, int flags, ...) __asm__("__wrap_openat");
ssize_t real_pwrite(int descriptor, const void* bytes, std::size_t size, off_t offset) __asm__("__real_pwrite");
ssize_t wrap_pwrite(int descriptor, const void* bytes, std::size_t size, off_t offset) __asm__("__wrap_pwrite");
int real_fsync(int descriptor) __asm__("__real_fsync");
int wrap_fsync(int descriptor) __asm__("__wrap_fsync");
int real_close(int descriptor) __asm__("__real_close");
int wrap_close(int descriptor) __asm__("__wrap_close");
int real_linkat(int source, const char* source_name, int target, const char* target_name,
                int flags) __asm__("__real_linkat");
int wrap_linkat(int source, const char* source_name, int target, const char* target_name,
                int flags) __asm__("__wrap_linkat");
int real_unlinkat(int directory, const char* name, int flags) __asm__("__real_unlinkat");
int wrap_unlinkat(int directory, const char* name, int flags) __asm__("__wrap_unlinkat");
int wrap_openat(int directory, const char* name, int flags, ...) {
  mode_t mode = 0;
  if ((static_cast<unsigned>(flags) & static_cast<unsigned>(O_CREAT)) != 0) {
    va_list values;
    va_start(values, flags);
    mode = static_cast<mode_t>(va_arg(values, int));
    va_end(values);
  }
  if (fault().kind == Fault::kReplaceRetry && std::string_view(name) == "slot00.try" && ++fault().retry_opens == 2) {
    if (real_unlinkat(directory, name, 0) != 0) {
      return -1;
    }
    const int replacement = real_openat(directory, name, O_CREAT | O_EXCL | O_RDWR | O_CLOEXEC, 0600);
    constexpr std::string_view kReplacement = "replacement must remain unchanged";
    if (replacement >= 0) {
      static_cast<void>(real_pwrite(replacement, kReplacement.data(), kReplacement.size(), 0));
      static_cast<void>(real_fsync(replacement));
      static_cast<void>(real_close(replacement));
    }
  }
  return (static_cast<unsigned>(flags) & static_cast<unsigned>(O_CREAT)) != 0
             ? real_openat(directory, name, flags, mode)
             : real_openat(directory, name, flags);
}
ssize_t wrap_pwrite(int descriptor, const void* bytes, std::size_t size, off_t offset) {
  if (fault().kind == Fault::kCrashPartialTemporary && size > 17) {
    static_cast<void>(real_pwrite(descriptor, bytes, 17, offset));
    _exit(77);
  }
  if (fault().kind == Fault::kDiskFull) {
    errno = ENOSPC;
    return -1;
  }
  if (fault().kind == Fault::kZeroWrite) {
    return 0;
  }
  if (fault().kind == Fault::kShortWrite && size > 1) {
    return real_pwrite(descriptor, bytes, size / 2, offset);
  }
  return real_pwrite(descriptor, bytes, size, offset);
}
int wrap_fsync(int descriptor) {
  struct stat info{};
  if (fstat(descriptor, &info) == 0 && ((fault().kind == Fault::kFileSync && S_ISREG(info.st_mode)) ||
                                        (fault().kind == Fault::kDirectorySync && S_ISDIR(info.st_mode)))) {
    errno = EIO;
    return -1;
  }
  const int result = real_fsync(descriptor);
  if (result == 0 && fault().kind == Fault::kCrashAfterAckSync && S_ISREG(info.st_mode) && info.st_size >= 129 &&
      info.st_size <= 144) {
    _exit(77);
  }
  return result;
}
int wrap_close(int descriptor) {
  const int result = real_close(descriptor);
  if (fault().kind == Fault::kClose) {
    errno = EIO;
    return -1;
  }
  return result;
}
int wrap_linkat(int source, const char* source_name, int target, const char* target_name, int flags) {
  if (fault().kind == Fault::kLink) {
    errno = ENOSPC;
    return -1;
  }
  const int result = real_linkat(source, source_name, target, target_name, flags);
  if (result == 0 && fault().kind == Fault::kCrashAfterLink) {
    _exit(77);
  }
  return result;
}
int wrap_unlinkat(int directory, const char* name, int flags) {
  if (fault().kind == Fault::kUnlink) {
    errno = EIO;
    return -1;
  }
  const int result = real_unlinkat(directory, name, flags);
  if (result == 0 && fault().kind == Fault::kCrashAfterRecordUnlink && std::string_view(name).ends_with(".rec")) {
    _exit(77);
  }
  return result;
}
}
namespace rasp::plugins::reporting {
namespace {
class OutboxFaultTest : public testing::Test {
 protected:
  void SetUp() override {
    fault() = {};
    std::array<char, 40> pattern{};
    std::ranges::copy(std::string_view("/tmp/pl03-fault-XXXXXX"), pattern.begin());
    const auto* path = mkdtemp(pattern.data());
    ASSERT_NE(path, nullptr);
    root_ = path;
    auto acquired = rasp::posix::acquire_private_storage_at(root_);
    ASSERT_TRUE(acquired.has_value());
    storage_.emplace(std::move(*acquired));
    binding_ = *collection_authority(
        {.endpoint = "https://collector.example/", .policy = "default", .zone = "", .dns_policy = "default"});
    CycleSnapshot snapshot;
    snapshot.metadata.execution_finished = true;
    snapshot.metadata.sequence = 1;
    snapshot.metadata.duration_ns = 0;
    payload_ = *prepare_cycle(snapshot, std::string(64, 'b'), storage_->install_id(), *new_batch_id());
    box_ = std::make_unique<Outbox>(storage_->native_handle(), std::string(storage_->install_id()));
    ASSERT_TRUE(box_->initialize().has_value());
  }
  void TearDown() override {
    fault() = {};
    box_.reset();
    storage_.reset();
    std::filesystem::remove_all(root_);
  }
  std::string contents(const std::string& name) {
    std::ifstream file(root_ + "/rasp_private/cycle_outbox_v1/" + name, std::ios::binary);
    return {(std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>()};
  }
  std::string root_;
  std::optional<PrivateStorage> storage_;
  std::unique_ptr<Outbox> box_;
  PreparedCycle payload_;
  std::string binding_;
};
TEST_F(OutboxFaultTest, reserve_whenRetryFileReplacedBetweenReadAndOpen_preservesReplacement) {
  const auto saved = box_->persist(payload_, binding_);
  ASSERT_TRUE(saved.has_value());
  ASSERT_TRUE(box_->reserve(*saved).has_value());
  fault() = {.kind = Fault::kReplaceRetry};
  const auto reservation = box_->reserve(*saved);
  fault() = {};
  EXPECT_FALSE(reservation.has_value());
  EXPECT_EQ(contents("slot00.try"), "replacement must remain unchanged");
}
TEST_F(OutboxFaultTest, persist_whenShortWrites_loopsWithinBoundAndReplaysExactBytes) {
  fault() = {.kind = Fault::kShortWrite};
  const auto saved = box_->persist(payload_, binding_);
  fault() = {};
  ASSERT_TRUE(saved.has_value());
  const auto scan = box_->scan();
  ASSERT_TRUE(scan.has_value());
  ASSERT_EQ(scan->records.size(), 1);
  EXPECT_EQ(scan->records[0].payload->canonical, payload_.canonical);
}
TEST_F(OutboxFaultTest, persist_whenDiskOrSyncOrCloseOrLinkFails_neverClaimsSuccessAndCanReconcile) {
  for (const auto kind :
       {Fault::kZeroWrite, Fault::kDiskFull, Fault::kFileSync, Fault::kDirectorySync, Fault::kClose, Fault::kLink}) {
    fault() = {.kind = kind};
    EXPECT_FALSE(box_->persist(payload_, binding_).has_value());
    fault() = {};
    const auto saved = box_->persist(payload_, binding_);
    ASSERT_TRUE(saved.has_value());
    ASSERT_TRUE(box_->reserve(*saved).has_value());
    ASSERT_TRUE(box_->acknowledge(*saved).has_value());
  }
}
TEST_F(OutboxFaultTest, acknowledge_whenUnlinkFails_keepsHashedAckAndRecoveryNeverReplays) {
  const auto saved = box_->persist(payload_, binding_);
  ASSERT_TRUE(saved.has_value());
  ASSERT_TRUE(box_->reserve(*saved).has_value());
  fault() = {.kind = Fault::kUnlink};
  EXPECT_FALSE(box_->acknowledge(*saved).has_value());
  EXPECT_EQ(box_->acknowledged_count(), 1);
  fault() = {};
  EXPECT_EQ(contents("slot00.try").size(), 129);
  const auto scan = box_->scan();
  ASSERT_TRUE(scan.has_value());
  EXPECT_TRUE(scan->records.empty());
  EXPECT_EQ(box_->acknowledged_count(), 1);
  EXPECT_TRUE(box_->scan().has_value());
  EXPECT_EQ(box_->acknowledged_count(), 1);
}
TEST_F(OutboxFaultTest, restart_whenProcessCrashesAfterAtomicLink_recoversExactTwoLinkRecord) {
  const pid_t child = fork();
  ASSERT_GE(child, 0);
  if (child == 0) {
    fault() = {.kind = Fault::kCrashAfterLink};
    static_cast<void>(box_->persist(payload_, binding_));
    _exit(2);
  }
  int status = 0;
  ASSERT_EQ(waitpid(child, &status, 0), child);
  ASSERT_TRUE(WIFEXITED(status));
  ASSERT_EQ(WEXITSTATUS(status), 77);
  const auto scan = box_->scan();
  ASSERT_TRUE(scan.has_value());
  ASSERT_EQ(scan->records.size(), 1);
  EXPECT_EQ(scan->records[0].payload->canonical, payload_.canonical);
  EXPECT_FALSE(std::filesystem::exists(root_ + "/rasp_private/cycle_outbox_v1/publish.tmp"));
}
TEST_F(OutboxFaultTest, restart_whenProcessCrashesAfterAckOrDelete_completesCleanupWithoutReplay) {
  for (const auto kind : {Fault::kCrashAfterAckSync, Fault::kCrashAfterRecordUnlink}) {
    const auto saved = box_->persist(payload_, binding_);
    ASSERT_TRUE(saved.has_value());
    ASSERT_TRUE(box_->reserve(*saved).has_value());
    const pid_t child = fork();
    ASSERT_GE(child, 0);
    if (child == 0) {
      fault() = {.kind = kind};
      static_cast<void>(box_->acknowledge(*saved));
      _exit(2);
    }
    int status = 0;
    ASSERT_EQ(waitpid(child, &status, 0), child);
    ASSERT_TRUE(WIFEXITED(status));
    ASSERT_EQ(WEXITSTATUS(status), 77);
    const auto scan = box_->scan();
    ASSERT_TRUE(scan.has_value());
    EXPECT_TRUE(scan->records.empty());
    EXPECT_EQ(box_->acknowledged_count(), 1);
    EXPECT_TRUE(box_->scan().has_value());
    EXPECT_EQ(box_->acknowledged_count(), 1);
  }
}
TEST_F(OutboxFaultTest, restart_whenProcessLeavesPartialUnknownTemporary_preservesBytesAndReportsUnavailable) {
  const pid_t child = fork();
  ASSERT_GE(child, 0);
  if (child == 0) {
    fault() = {.kind = Fault::kCrashPartialTemporary};
    static_cast<void>(box_->persist(payload_, binding_));
    _exit(2);
  }
  int status = 0;
  ASSERT_EQ(waitpid(child, &status, 0), child);
  ASSERT_TRUE(WIFEXITED(status));
  ASSERT_EQ(WEXITSTATUS(status), 77);
  const auto before = contents("publish.tmp");
  ASSERT_EQ(before.size(), 17);
  EXPECT_FALSE(box_->scan().has_value());
  EXPECT_EQ(contents("publish.tmp"), before);
}
}  // namespace
}  // namespace rasp::plugins::reporting
