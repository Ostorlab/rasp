"""Run inside a task-owned BE10 checkout with its actual schema, UBJSON/DNS decoders and database worker.

PL03_NATIVE_EMITTED names output from the production C++ rasp_cycle_emitter executable.
Only the external queue publication call is replaced; no native producer/schema/decoder/worker is mocked.
"""

from __future__ import annotations

import hashlib
import json
import os
import pathlib
from unittest import mock

import pytest
from apis.schemas import runtime
from django.conf import settings
from dns_collector import qname
from dns_collector import reassembler_service
from rasp import client_batches
from rasp import events
from rasp import messages
from rasp import models
from rasp import pubsub

CASES = ("complete", "empty", "unavailable-identities", "uint64-max", "serializer-loss", "dns-boundary")


@pytest.mark.django_db
@pytest.mark.parametrize("case", CASES)
def testNativeProducer_whenActualHttpsAndDnsDecodedAndRetried_storesOneImmutableBatch(
    build: models.Build, case: str
) -> None:
    path = pathlib.Path(os.environ["PL03_NATIVE_EMITTED"]) / case
    canonical = (path / "canonical.json").read_bytes()
    producer = json.loads(canonical)
    request = json.loads((path / "request.json").read_text())
    with (
        mock.patch.object(pubsub, "publish") as publish,
        mock.patch.object(settings, "EVENTS_TOPIC", "projects/test/topics/events"),
    ):
        result = runtime.schema.execute(request["query"], variable_values=request["variables"])
    assert result.errors is None
    assert result.data == {"submitObservations": True}
    assert publish.call_count == 1
    https_wire = publish.call_args.args[1]
    https = messages.decode(https_wire)
    assert len(https_wire) <= 256 * 1024
    digest = hashlib.sha256(canonical).hexdigest()
    assert client_batches.digest(https, build.pk) == digest

    report = qname.parse_payload(
        qname.FORMAT_PLAIN,
        bytes.fromhex("9a3c51e7"),
        (path / "dns.bin").read_bytes(),
    )
    assert report is not None
    if case == "dns-boundary":
        assert len((path / "dns.json").read_bytes()) == 30048
        assert len((path / "dns.bin").read_bytes()) == 30090
        assert len((path / "dns.names").read_text().splitlines()) == 255
    queued = reassembler_service._message_of(report, 1794484800)
    dns = messages.decode(queued.data)
    assert client_batches.digest(dns, build.pk) == digest
    assert https.envelope is not None
    assert dns.envelope is not None
    assert https.envelope.batch_id == dns.envelope.batch_id
    assert https.envelope.run_id == dns.envelope.run_id
    assert https.envelope.session_id == dns.envelope.session_id
    assert https.signals == dns.signals
    assert https.envelope.cycle == dns.envelope.cycle

    assert events.store_event(https, delivery=("pl03", f"{case}-https")) is not None
    assert events.store_event(dns, delivery=("pl03", f"{case}-dns")) is None
    assert events.store_event(https, delivery=("pl03", f"{case}-lost-ack-retry")) is None
    assert models.TelemetryBatch.objects.count() == 1
    assert models.Signal.objects.count() == len(https.signals)
    assert models.ClientBatchReceipt.objects.count() == 1
    assert models.ClientBatchReceipt.objects.get().producer_digest == digest
    assert models.EventReceipt.objects.count() == 3
    if case == "serializer-loss":
        assert producer["cycle"]["complete"] is True
        assert producer["cycle"]["serialization_complete"] is False
        assert producer["cycle"]["serialization_dropped"] == "1"
        assert models.Signal.objects.count() == 0
    if case == "unavailable-identities":
        assert https.envelope.session_id is None
        assert https.envelope.run_id is None
        assert https.envelope.observed_at is None
    if case == "uint64-max":
        assert https.envelope.cycle is not None
        assert https.envelope.cycle["duration_ns"] == "18446744073709551615"
        assert https.envelope.cycle["sequence"] == "18446744073709551615"
    if case == "complete":
        assert {signal.status for signal in https.signals} == {"ok", "unsupported", "error", "timeout"}
        assert any(signal.value == {"long": -(2**63)} for signal in https.signals)
        assert any(signal.value == {"long": 2**63 - 1} for signal in https.signals)
        assert any(signal.value == {"bool": False} for signal in https.signals)


@pytest.mark.parametrize("field", ["sessionId", "runId", "batchId"])
def testNativeProducer_whenV2UuidIsZero_rejectsWithoutQueuePublication(field: str) -> None:
    path = pathlib.Path(os.environ["PL03_NATIVE_EMITTED"]) / "empty" / "request.json"
    request = json.loads(path.read_text())
    request["variables"]["batch"][field] = "00000000-0000-0000-0000-000000000000"
    with mock.patch.object(pubsub, "publish") as publish:
        result = runtime.schema.execute(request["query"], variable_values=request["variables"])
    assert result.errors is None
    assert result.data == {"submitObservations": False}
    assert publish.call_count == 0


@pytest.mark.django_db
def testNativeProducer_whenDnsWholeBatchExceedsBudget_preservesHttpsContentAndQueuesNoFallback(
    build: models.Build,
) -> None:
    path = pathlib.Path(os.environ["PL03_NATIVE_EMITTED"]) / "dns-oversize"
    assert len((path / "dns.json").read_bytes()) == 30049
    assert (path / "dns.bin").read_bytes() == b""
    assert (path / "dns.names").read_bytes() == b""
    request = json.loads((path / "request.json").read_text())
    with (
        mock.patch.object(pubsub, "publish") as publish,
        mock.patch.object(settings, "EVENTS_TOPIC", "projects/test/topics/events"),
    ):
        result = runtime.schema.execute(request["query"], variable_values=request["variables"])
    assert result.errors is None
    assert result.data == {"submitObservations": True}
    assert publish.call_count == 1
    https = messages.decode(publish.call_args.args[1])
    digest = hashlib.sha256((path / "canonical.json").read_bytes()).hexdigest()
    assert client_batches.digest(https, build.pk) == digest
    assert events.store_event(https, delivery=("pl03", "dns-oversize-https")) is not None
    assert events.store_event(https, delivery=("pl03", "dns-oversize-lost-ack")) is None
    assert models.ClientBatchReceipt.objects.get().producer_digest == digest
    assert models.TelemetryBatch.objects.count() == 1
    assert models.Signal.objects.count() == len(https.signals)


@pytest.mark.django_db
def test_tls_lost_ack_replays_original_batch_and_stores_one_receipt(build: models.Build) -> None:
    capture = os.environ.get("PL05_TLS_CAPTURE")
    if capture is None:
        pytest.skip("Set PL05_TLS_CAPTURE to ReportingTls.actualSenderOutbox capture output")
    root = pathlib.Path(capture)
    first = (root / "first-request.json").read_bytes()
    retry = (root / "retry-request.json").read_bytes()
    assert first == retry
    request = json.loads(first)
    decoded = []
    for name in ("first-tls-publish", "actual-tls-retry"):
        with (
            mock.patch.object(pubsub, "publish") as publish,
            mock.patch.object(settings, "EVENTS_TOPIC", "projects/test/topics/events"),
        ):
            result = runtime.schema.execute(request["query"], variable_values=request["variables"])
        assert result.errors is None
        assert result.data == {"submitObservations": True}
        assert publish.call_count == 1
        decoded.append(messages.decode(publish.call_args.args[1]))
        stored = events.store_event(decoded[-1], delivery=("pl05", name))
        assert (stored is not None) == (name == "first-tls-publish")
    assert decoded[0].envelope.batch_id == decoded[1].envelope.batch_id
    assert models.TelemetryBatch.objects.count() == 1
    assert models.ClientBatchReceipt.objects.count() == 1
    assert models.EventReceipt.objects.count() == 2
    assert client_batches.digest(decoded[0], build.pk) == client_batches.digest(decoded[1], build.pk)
    assert models.ClientBatchReceipt.objects.get().producer_digest == client_batches.digest(decoded[0], build.pk)
