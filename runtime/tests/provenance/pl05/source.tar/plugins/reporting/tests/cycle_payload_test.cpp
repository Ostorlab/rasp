#include "cycle_payload.h"

#include <cstddef>
#include <cstdint>
#include <fstream>
#include <gtest/gtest.h>
#include <iterator>
#include <limits>
#include <rasp/observation.h>
#include <string>
#include <variant>

#include "rasp/cycle.h"

namespace rasp::plugins::reporting {
namespace {
constexpr auto kBuild = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
constexpr auto kInstall = "0f8b3c1e-6d2a-4c5b-9e7f-1a2b3c4d5e6f";
constexpr auto kBatch = "41d9ba09-4fb1-46f0-9a1f-308cf631da1e";
CycleSnapshot fixture() {
  CycleSnapshot snapshot;
  auto& meta = snapshot.metadata;
  meta.session_id = "e690f6cc-e9ad-43cd-b15a-d47a3fbaaa36";
  meta.run_id = "a02d567e-c23e-40b4-8302-a84e9a009fdc";
  meta.sequence = 9007199254740993ULL;
  meta.duration_ns = std::numeric_limits<std::uint64_t>::max();
  meta.observed_at_unix_ms = 1794484800123LL;
  meta.platform = "android";
  meta.catalogue_id = std::string(64, 'a');
  meta.config_known = true;
  meta.catalogue_known = true;
  meta.execution_finished = true;
  meta.complete = true;
  meta.groups = {{.name = "dbg", .enabled = true}};
  meta.expected = 4;
  meta.seen = 4;
  meta.status_counts = {1, 1, 1, 1};
  for (std::size_t index = 0; index < 4; ++index) {
    snapshot.observations.push_back({
        .signal = "dbg.example" + std::to_string(index),
        .source = "syscall",
        .status = static_cast<Status>(index),
        .value = std::monostate{},
    });
  }
  snapshot.observations[0].value = std::int64_t{9007199254740993LL};
  return snapshot;
}
}  // namespace
TEST(CyclePayload, prepare_whenExactBackendFixture_matchesCanonicalBytesAndDigest) {
  const auto payload = prepare_cycle(fixture(), kBuild, kInstall, kBatch);
  ASSERT_TRUE(payload.has_value());
  std::ifstream file(std::string(RASP_CYCLE_FIXTURES) + "/producer-canonical.json");
  std::string expected((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
  while (!expected.empty() && expected.back() == '\n') {
    expected.pop_back();
  }
  EXPECT_EQ(payload->canonical, expected);
  EXPECT_TRUE(restore_cycle(payload->canonical).has_value());
  EXPECT_NE(payload->request.find("9007199254740993"), std::string::npos);
  EXPECT_EQ(payload->serialization_dropped, 0);
}
TEST(CyclePayload, prepare_whenSourceTooWide_dropsWholeRowWithoutChangingNativeClaim) {
  auto snapshot = fixture();
  snapshot.observations[0].source = std::string(65, 'x');
  const auto payload = prepare_cycle(snapshot, kBuild, kInstall, kBatch);
  ASSERT_TRUE(payload.has_value());
  EXPECT_EQ(payload->serialization_dropped, 1);
  EXPECT_NE(payload->canonical.find(R"("status_counts":["1","1","1","1"])"), std::string::npos);
  EXPECT_NE(payload->canonical.find("\"complete\":true"), std::string::npos);
  EXPECT_NE(payload->canonical.find("\"serialization_complete\":false"), std::string::npos);
  EXPECT_EQ(payload->canonical.find(std::string(65, 'x')), std::string::npos);
}
TEST(CyclePayload, restore_whenUnknownDuplicateOrInconsistent_rejects) {
  const auto payload = prepare_cycle(fixture(), kBuild, kInstall, kBatch);
  ASSERT_TRUE(payload.has_value());
  EXPECT_FALSE(restore_cycle("{\"batch_id\":1,\"batch_id\":2}").has_value());
  EXPECT_FALSE(restore_cycle(payload->canonical + "x").has_value());
  auto changed = payload->canonical;
  const auto where = changed.find(R"("serialization_dropped":"0")");
  ASSERT_NE(where, std::string::npos);
  changed.replace(where, 27, R"("serialization_dropped":"1")");
  EXPECT_FALSE(restore_cycle(changed).has_value());
}
TEST(CyclePayload, prepare_whenUnicodeAndSignedExtremes_preservesExactTypedValues) {
  auto snapshot = fixture();
  for (const auto integer :
       {std::numeric_limits<std::int64_t>::min(), std::numeric_limits<std::int64_t>::max(), std::int64_t{0}}) {
    snapshot.observations[0].value = integer;
    const auto payload = prepare_cycle(snapshot, kBuild, kInstall, kBatch);
    ASSERT_TRUE(payload.has_value());
    EXPECT_NE(payload->canonical.find("\"long\":\"" + std::to_string(integer) + "\""), std::string::npos);
  }
  snapshot.observations[0].value = std::string("é😀\x7f");
  const auto unicode = prepare_cycle(snapshot, kBuild, kInstall, kBatch);
  ASSERT_TRUE(unicode.has_value());
  EXPECT_NE(unicode->canonical.find("\\u00e9\\ud83d\\ude00\\u007f"), std::string::npos);
  snapshot.observations[0].value = std::string("\xed\xa0\x80");
  const auto invalid = prepare_cycle(snapshot, kBuild, kInstall, kBatch);
  ASSERT_TRUE(invalid.has_value());
  EXPECT_EQ(invalid->serialization_dropped, 1);
}
TEST(CyclePayload, prepare_whenUnknownIdsAndZeroDuration_preservesNullAndZeroDistinctly) {
  auto snapshot = fixture();
  snapshot.metadata.session_id.clear();
  snapshot.metadata.run_id.clear();
  snapshot.metadata.observed_at_unix_ms.reset();
  snapshot.metadata.duration_ns = 0;
  const auto payload = prepare_cycle(snapshot, kBuild, kInstall, kBatch);
  ASSERT_TRUE(payload.has_value());
  EXPECT_NE(payload->canonical.find("\"duration_ns\":\"0\""), std::string::npos);
  EXPECT_NE(payload->canonical.find("\"observed_at\":null"), std::string::npos);
  EXPECT_NE(payload->canonical.find("\"session_id\":null"), std::string::npos);
  snapshot.metadata.duration_ns.reset();
  EXPECT_FALSE(prepare_cycle(snapshot, kBuild, kInstall, kBatch).has_value());
}
TEST(CyclePayload, prepare_whenNonOkCarriesRawValue_emitsOnlyNull) {
  auto snapshot = fixture();
  snapshot.observations[2].value = std::string("never retain this non-ok value");
  const auto payload = prepare_cycle(snapshot, kBuild, kInstall, kBatch);
  ASSERT_TRUE(payload.has_value());
  EXPECT_EQ(payload->serialization_dropped, 0);
  EXPECT_EQ(payload->canonical.find("never retain this"), std::string::npos);
}
TEST(CyclePayload, prepare_whenRetainedStatusUnknown_accountsWholeRowLoss) {
  auto snapshot = fixture();
  snapshot.observations[0].status = static_cast<Status>(255);
  snapshot.metadata.status_counts[0] = 0;
  snapshot.metadata.unknown_status = 1;
  snapshot.metadata.complete = false;
  const auto payload = prepare_cycle(snapshot, kBuild, kInstall, kBatch);
  ASSERT_TRUE(payload.has_value());
  EXPECT_EQ(payload->serialization_dropped, 1);
  EXPECT_NE(payload->canonical.find("\"unknown_status\":\"1\""), std::string::npos);
}
TEST(CyclePayload, prepare_whenTransmittedStatusExceedsNativeDistribution_rejectsEvenWhenTotalsMatch) {
  auto snapshot = fixture();
  snapshot.metadata.status_counts = {0, 2, 1, 1};
  EXPECT_FALSE(prepare_cycle(snapshot, kBuild, kInstall, kBatch).has_value());
}
}  // namespace rasp::plugins::reporting
