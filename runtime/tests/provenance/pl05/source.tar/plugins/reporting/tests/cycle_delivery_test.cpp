#include "cycle_delivery.h"

#include <algorithm>
#include <array>
#include <cstdint>
#include <expected>
#include <filesystem>
#include <gtest/gtest.h>
#include <memory>
#include <rasp/cycle.h>
#include <rasp/private_storage.h>
#include <stop_token>
#include <string>
#include <string_view>
#include <thread>
#include <vector>

#include "config.h"
#include "fixture_io.h"
#include "outbox.h"
#include "rasp/posix/private_storage.h"
#include "reporting/delivery.h"
#include "reporting/transport_result.h"
#include "transport.h"

namespace rasp::plugins::reporting {
namespace {
std::string& root() {
  static std::string value;
  return value;
}
std::int64_t& ticks() {
  static std::int64_t value = 0;
  return value;
}
std::vector<std::string>& posts() {
  static std::vector<std::string> value;
  return value;
}
bool& accepting() {
  static bool value = false;
  return value;
}
std::int64_t clock() { return ticks(); }
int& policy_on_acquire() {
  static int value = 0;
  return value;
}
CycleDelivery*& stop_on_acquire() {
  static CycleDelivery* value = nullptr;
  return value;
}
unsigned& dns_enqueued() {
  static unsigned value = 0;
  return value;
}
std::expected<PrivateStorage, StorageError> acquire() {
  if (policy_on_acquire() == 1) {
    reporting_test_advance_clock(7200);
  } else if (policy_on_acquire() == 2) {
    reporting_test_unavailable_clock();
  } else if (stop_on_acquire() != nullptr) {
    stop_on_acquire()->stop();
  }
  policy_on_acquire() = 0;
  stop_on_acquire() = nullptr;
  return root().empty() ? std::unexpected(StorageError::kUnavailable) : rasp::posix::acquire_private_storage_at(root());
}
TransportResult post_cycle(const Config& /*unused*/, std::string_view body, Cancellation /*cancellation*/) noexcept {
  posts().emplace_back(body);
  return accepting() ? TransportResult::kPublicationAcknowledged : TransportResult::kConnectFailed;
}
TransportResult& terminal_result() {
  static TransportResult result = TransportResult::kPublicationUnconfirmed;
  return result;
}
TransportResult post_terminal(const Config& /*unused*/, std::string_view body, Cancellation /*unused*/) noexcept {
  posts().emplace_back(body);
  return terminal_result();
}
class CycleDeliveryTest : public testing::Test {
 protected:
  void SetUp() override {
    reporting_test_restore_clock();
    policy_on_acquire() = 0;
    stop_on_acquire() = nullptr;
    dns_enqueued() = 0;
    std::array<char, 40> pattern{};
    const std::string text = "/tmp/pl03-worker-XXXXXX";
    std::ranges::copy(text, pattern.begin());
    const auto* directory = mkdtemp(pattern.data());
    ASSERT_NE(directory, nullptr);
    path_ = directory;
    root() = path_;
    ticks() = 0;
    posts().clear();
    accepting() = false;
    register_dns_fallback(nullptr);
  }
  void TearDown() override {
    reporting_test_restore_clock();
    policy_on_acquire() = 0;
    stop_on_acquire() = nullptr;
    register_dns_fallback(nullptr);
    std::filesystem::remove_all(path_);
    root().clear();
  }
  static std::shared_ptr<const CycleSnapshot> snapshot(std::uint64_t sequence) {
    auto value = std::make_shared<CycleSnapshot>();
    value->metadata.sequence = sequence;
    value->metadata.execution_finished = true;
    value->metadata.duration_ns = 0;
    return value;
  }
  static Config config(char build = 'b') {
    return {
        .endpoint = "https://collector.example/apis/graphql",
        .build_id = std::string(64, build),
        .security_profile =
            R"({"version":1,"mode":"system","host":"collector.example","port":443,"pins":null,"validity":null})",
    };
  }
  static void at(CycleDelivery& worker, std::int64_t seconds) {
    ticks() = seconds * 1000000000LL;
    worker.step();
  }
  static void expect_policy_race(int fault) {
    auto selected = config();
    const auto utc = reporting_test_real_utc_seconds();
    ASSERT_GT(utc, 60);
    selected.security_profile =
        R"({"version":1,"mode":"leaf-spki-sha256","host":"collector.example","port":443,"pins":{"primary":{"key_algorithm":"rsa-2048","value":"sha256//AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="},"backup":{"key_algorithm":"ec-p256","value":"sha256//AQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQE="}},"validity":{"not_before":)" +
        std::to_string(utc - 60) + R"(,"not_after":)" + std::to_string(utc + 3600) + "}}";
    static const DnsFallback kFallback{
        .zone = "fallback.test",
        .collection_policy = "default",
        .enqueue =
            +[](std::shared_ptr<const PreparedCycle> payload,
                std::shared_ptr<const FallbackAuthorization> authorization) noexcept {
              payload.reset();
              authorization.reset();
              ++dns_enqueued();
              return true;
            },
    };
    register_dns_fallback(&kFallback);
    CycleDelivery worker(selected, post_cycle, acquire, clock);
    ASSERT_TRUE(worker.admit(snapshot(1)));
    at(worker, 0);
    auto storage = acquire();
    ASSERT_TRUE(storage.has_value());
    Outbox box(storage->native_handle(), std::string(storage->install_id()));
    ASSERT_TRUE(box.initialize().has_value());
    const auto before = box.scan();
    ASSERT_TRUE(before.has_value());
    ASSERT_EQ(before->records.size(), 1);
    if (fault == 3) {
      stop_on_acquire() = &worker;
    } else {
      policy_on_acquire() = fault;
    }
    at(worker, 1);
    const auto health = worker.health();
    EXPECT_EQ(health.last_transport_result,
              fault == 3 ? TransportResult::kCancelled : TransportResult::kProfileNotActive);
    EXPECT_EQ(health.failure, DeliveryFailure::kTransportRefused);
    EXPECT_EQ(health.state == DeliveryState::kHeld, fault != 3);
    EXPECT_EQ(health.https_attempted, 0);
    EXPECT_EQ(health.dns_attempted, 0);
    EXPECT_EQ(health.publication_acknowledged, 0);
    EXPECT_EQ(dns_enqueued(), 0);
    EXPECT_TRUE(posts().empty());
    const auto after = box.scan();
    ASSERT_TRUE(after.has_value());
    ASSERT_EQ(after->records.size(), 1);
    EXPECT_EQ(after->records[0].token, before->records[0].token);
    EXPECT_EQ(after->records[0].stage, 0);
    EXPECT_EQ(after->records[0].authority, before->records[0].authority);
    EXPECT_EQ(after->records[0].payload->request, before->records[0].payload->request);
    reporting_test_restore_clock();
    accepting() = true;
    at(worker, 2);
    EXPECT_TRUE(posts().empty());
    at(worker, 3);
    EXPECT_EQ(posts().size(), fault == 3 ? 0U : 1U);
    if (fault != 3) {
      EXPECT_EQ(posts()[0], before->records[0].payload->request);
      const auto cleaned = box.scan();
      ASSERT_TRUE(cleaned.has_value());
      EXPECT_TRUE(cleaned->records.empty());
    }
  }
  std::string path_;
};
TEST_F(CycleDeliveryTest, send_whenSameAuthorityExpiresAfterReady_refusesBeforeReservationAndRecovers) {
  expect_policy_race(1);
}
TEST_F(CycleDeliveryTest, send_whenSameAuthorityLosesUtcAfterReady_refusesBeforeReservationAndRecovers) {
  expect_policy_race(2);
}
TEST_F(CycleDeliveryTest, send_whenCancelledDuringProviderRevalidation_refusesWithoutHoldingOrEffects) {
  expect_policy_race(3);
}
TEST_F(CycleDeliveryTest, ready_whenHttpsAuthorityReallyDiffers_holdsOriginalWithoutEffects) {
  {
    CycleDelivery original(config(), post_cycle, acquire, clock);
    ASSERT_TRUE(original.admit(snapshot(1)));
    at(original, 0);
  }
  auto storage = acquire();
  ASSERT_TRUE(storage.has_value());
  Outbox box(storage->native_handle(), std::string(storage->install_id()));
  ASSERT_TRUE(box.initialize().has_value());
  const auto before = box.scan();
  ASSERT_TRUE(before.has_value());
  ASSERT_EQ(before->records.size(), 1);
  auto changed = config();
  changed.collection_policy = "changed";
  CycleDelivery worker(changed, post_cycle, acquire, clock);
  at(worker, 0);
  at(worker, 1000);
  EXPECT_EQ(worker.health().failure, DeliveryFailure::kAuthorityMismatch);
  EXPECT_EQ(worker.health().state, DeliveryState::kHeld);
  EXPECT_EQ(worker.health().https_attempted, 0);
  EXPECT_EQ(worker.health().dns_attempted, 0);
  EXPECT_TRUE(posts().empty());
  const auto after = box.scan();
  ASSERT_TRUE(after.has_value());
  ASSERT_EQ(after->records.size(), 1);
  EXPECT_EQ(after->records[0].token, before->records[0].token);
  EXPECT_EQ(after->records[0].stage, 0);
  EXPECT_EQ(after->records[0].authority, before->records[0].authority);
  EXPECT_EQ(after->records[0].payload->request, before->records[0].payload->request);
}
TEST_F(CycleDeliveryTest, admit_whenProviderUnavailable_keepsFourAndRejectsNewestUntilLateAttachment) {
  CycleDelivery worker(config(), post_cycle, acquire, clock);
  root().clear();
  for (std::uint64_t index = 1; index <= 4; ++index) {
    EXPECT_TRUE(worker.admit(snapshot(index)));
  }
  EXPECT_FALSE(worker.admit(snapshot(5)));
  at(worker, 0);
  EXPECT_TRUE(posts().empty());
  EXPECT_EQ(worker.health().volatile_pending, 4);
  root() = path_;
  at(worker, 2);
  accepting() = true;
  for (std::int64_t second = 3; second < 12; ++second) {
    at(worker, second);
  }
  EXPECT_EQ(posts().size(), 4);
  EXPECT_EQ(worker.health().volatile_pending, 0);
  EXPECT_EQ(worker.health().admission_dropped, 1);
}
TEST_F(CycleDeliveryTest, send_whenFailedThenNewCycle_retainsOriginalBatchAndDistinctNewPayload) {
  CycleDelivery worker(config(), post_cycle, acquire, clock);
  ASSERT_TRUE(worker.admit(snapshot(1)));
  at(worker, 0);
  at(worker, 1);
  ASSERT_EQ(posts().size(), 1);
  const auto first = posts()[0];
  ASSERT_TRUE(worker.admit(snapshot(2)));
  at(worker, 2);
  accepting() = true;
  for (std::int64_t second = 3; second < 20; ++second) {
    at(worker, second);
  }
  EXPECT_GE(std::ranges::count(posts(), first), 2);
  EXPECT_TRUE(std::ranges::any_of(posts(), [&first](const std::string& value) { return value != first; }));
  EXPECT_EQ(worker.health().durable_pending, 0);
}
TEST_F(CycleDeliveryTest, send_whenTransportRefuses_classifiesFailureAndRetainsTheExactRecord) {
  for (const auto result : {
           TransportResult::kProfileInvalid,
           TransportResult::kProfileNotActive,
           TransportResult::kPlatformPolicyUnavailable,
           TransportResult::kTrustVerificationFailed,
           TransportResult::kPinVerificationFailed,
           TransportResult::kKeyUnavailable,
           TransportResult::kProxyRejected,
           TransportResult::kCancelled,
           TransportResult::kTrustEvaluationBusy,
           TransportResult::kResolutionFailed,
           TransportResult::kConnectFailed,
           TransportResult::kTimeout,
           TransportResult::kIoFailed,
           TransportResult::kRedirectRejected,
           TransportResult::kHttpRejected,
           TransportResult::kResponseInvalid,
           TransportResult::kPublicationUnconfirmed,
           TransportResult::kTransportBusy,
       }) {
    root() = path_ + "/" + std::to_string(static_cast<unsigned>(result));
    std::filesystem::create_directory(root());
    std::filesystem::permissions(root(), std::filesystem::perms::owner_all);
    ticks() = 0;
    posts().clear();
    terminal_result() = result;
    CycleDelivery worker(config(), post_terminal, acquire, clock);
    ASSERT_TRUE(worker.admit(snapshot(1)));
    at(worker, 0);
    at(worker, 1);
    ASSERT_EQ(posts().size(), 1);
    const auto health = worker.health();
    EXPECT_EQ(health.last_transport_result, result);
    if (permits_dns(result)) {
      EXPECT_EQ(health.failure, DeliveryFailure::kNetwork);
    } else {
      EXPECT_EQ(health.failure, DeliveryFailure::kTransportRefused) << static_cast<unsigned>(result);
    }
    EXPECT_EQ(health.durable_pending, 1);
    EXPECT_EQ(health.publication_acknowledged, 0);
    EXPECT_EQ(health.dns_attempted, 0);
    auto storage = acquire();
    ASSERT_TRUE(storage.has_value());
    Outbox outbox(storage->native_handle(), std::string(storage->install_id()));
    ASSERT_TRUE(outbox.initialize().has_value());
    const auto scan = outbox.scan();
    ASSERT_TRUE(scan.has_value());
    ASSERT_EQ(scan->records.size(), 1);
    EXPECT_EQ(scan->records[0].payload->request, posts()[0]);
  }
}
TEST_F(CycleDeliveryTest, restart_whenSaturatedAndBuildUpgraded_waitsFullBackoffAndSendsOriginalBuild) {
  {
    CycleDelivery worker(config(), post_cycle, acquire, clock);
    ASSERT_TRUE(worker.admit(snapshot(1)));
    at(worker, 0);
  }
  auto capability = acquire();
  ASSERT_TRUE(capability.has_value());
  {
    Outbox box(capability->native_handle(), std::string(capability->install_id()));
    ASSERT_TRUE(box.initialize().has_value());
    auto scan = box.scan();
    ASSERT_TRUE(scan.has_value());
    ASSERT_EQ(scan->records.size(), 1);
    for (unsigned attempt = 0; attempt < 40; ++attempt) {
      ASSERT_TRUE(box.reserve(scan->records[0].token).has_value());
    }
  }
  for (unsigned restart = 0; restart < 20; ++restart) {
    CycleDelivery worker(config('c'), post_cycle, acquire, clock);
    const auto base = static_cast<std::int64_t>(restart) * 1000;
    at(worker, base);
    at(worker, base + 299);
    EXPECT_TRUE(posts().empty());
  }
  CycleDelivery final_worker(config('c'), post_cycle, acquire, clock);
  accepting() = true;
  at(final_worker, 20000);
  at(final_worker, 20300);
  ASSERT_EQ(posts().size(), 1);
  EXPECT_NE(posts()[0].find(std::string(64, 'b')), std::string::npos);
  EXPECT_EQ(posts()[0].find(std::string(64, 'c')), std::string::npos);
}
TEST_F(CycleDeliveryTest, persist_whenAdmissionContendsAndAckIsImmediate_neverResurrectsOriginalSnapshot) {
  CycleDelivery worker(config(), post_cycle, acquire, clock);
  accepting() = true;
  ASSERT_TRUE(worker.admit(snapshot(1)));
  std::jthread producer([&worker](const std::stop_token& stopped) {
    std::uint64_t sequence = 2;
    while (!stopped.stop_requested()) {
      static_cast<void>(worker.admit(snapshot(sequence++)));
      std::this_thread::yield();
    }
  });
  for (std::int64_t second = 0; second < 30; ++second) {
    at(worker, second);
  }
  producer.request_stop();
  producer.join();
  for (std::int64_t second = 30; second < 45; ++second) {
    at(worker, second);
  }
  EXPECT_EQ(std::ranges::count_if(posts(), [](const std::string& body) { return body.contains("\"sequence\":\"1\""); }),
            1);
  EXPECT_EQ(worker.health().volatile_pending, 0);
  EXPECT_EQ(worker.health().durable_pending, 0);
}
}  // namespace
}  // namespace rasp::plugins::reporting
