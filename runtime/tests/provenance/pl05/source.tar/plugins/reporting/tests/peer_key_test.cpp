#include "peer_key.h"

#include <cstddef>
#include <fstream>
#include <gtest/gtest.h>
#include <ios>
#include <iterator>
#include <string>

#include "hash.h"
#include "security_profile.h"

namespace rasp::plugins::reporting {
namespace {
std::string fixture(const std::string& name) {
  std::ifstream input(std::string(RASP_PEER_KEY_FIXTURES) + "/" + name, std::ios::binary);
  return {std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>()};
}
}  // namespace
TEST(PeerKey, parse_whenRsaAndEcCertificate_matchesIndependentOpensslSpki) {
  for (const auto* kind : {"rsa", "ec"}) {
    const auto key = certificate_key(fixture(std::string(kind) + ".der"));
    ASSERT_TRUE(key.has_value());
    EXPECT_EQ(key->spki, fixture(std::string(kind) + ".spki.der"));
    EXPECT_EQ(key->algorithm, std::string(kind) == "rsa" ? "rsa-2048" : "ec-p256");
  }
}
TEST(PeerKey, matches_whenDigestCorrectButAlgorithmWrong_rejectsAssociation) {
  const auto der = fixture("rsa.der");
  const auto key = certificate_key(der);
  ASSERT_TRUE(key.has_value());
  const auto digest = content_hash(key->spki);
  ASSERT_TRUE(digest.has_value());
  SecurityProfile profile;
  profile.pinned = true;
  profile.pins[0] = {.algorithm = "ec-p256", .value = pin_value(*digest), .digest = *digest};
  EXPECT_FALSE(matches_leaf(profile, der));
  profile.pins[0].algorithm = key->algorithm;
  EXPECT_TRUE(matches_leaf(profile, der));
  profile.pins[1] = profile.pins[0];
  profile.pins[0].digest[0] ^= 1U;
  EXPECT_TRUE(matches_leaf(profile, der));
}
TEST(PeerKey, canonical_whenPublicExportProvided_matchesIndependentSpki) {
  const auto rsa = fixture("rsa.spki.der");
  const auto ec = fixture("ec.spki.der");
  EXPECT_EQ(canonical_spki({.algorithm = "rsa-2048", .key = std::string_view(rsa).substr(24)}), rsa);
  EXPECT_EQ(canonical_spki({.algorithm = "ec-p256", .key = std::string_view(ec).substr(26)}), ec);
  EXPECT_FALSE(canonical_spki({.algorithm = "unknown", .key = "x"}).has_value());
  EXPECT_FALSE(canonical_spki({.algorithm = "rsa-2048", .key = std::string(1025, 'x')}).has_value());
}
TEST(PeerKey, parse_whenTruncatedOversizedOrTrailing_rejects) {
  const auto der = fixture("rsa.der");
  for (std::size_t size = 0; size < der.size(); ++size) {
    EXPECT_FALSE(certificate_key(std::string_view(der).substr(0, size)).has_value());
  }
  EXPECT_FALSE(certificate_key(der + "x").has_value());
  EXPECT_FALSE(certificate_key(std::string(16385, 'x')).has_value());
}
}  // namespace rasp::plugins::reporting
