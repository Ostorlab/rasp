"""Verify pristine actual Apple CI frameworks and mutate only in-memory copies of their real reporting marker."""

import argparse
import hashlib
import json
import os
import pathlib
import platform

from publish_packer import artifacts
from publish_packer import security


def intended_settings(endpoint: str, profile: str) -> str:
    return json.dumps(
        [
            {"name": "RASP_REPORTING_ENDPOINT", "value": endpoint},
            {"name": "RASP_REPORTING_SECURITY_PROFILE", "value": profile},
        ]
    )


def reject(binary: bytes, settings: str, case: str) -> None:
    try:
        security.verify_native_profile(binary, "ios", settings)
    except security.InvalidProfileError:
        print(f"PASS actual Apple marker negative: {case}")
    else:
        raise AssertionError(f"Actual Apple marker negative accepted: {case}")


def verify(runtime: pathlib.Path, binary: pathlib.Path, settings: str, mismatch: str) -> dict[str, str]:
    original = binary.read_bytes()
    sidecar = binary.with_name(binary.name + artifacts.SIDECAR_SUFFIX)
    original_sidecar = sidecar.read_bytes()
    # The released-runtime validator first verifies native digest, catalogue, arm64/iOS and deployment floor12.
    # Neither this test nor the profile validator emits/repairs a native sidecar or writes a mutated native file.
    artifacts.verify_native(runtime, binary, "ios", "arm64", settings)
    descriptor = security.read_marker(original)
    offset = original.index(security.MAGIC)
    frame_size = len(security.MAGIC) + 7 + len(descriptor.encode("ascii")) + 1 + 64 + 1
    frame = original[offset : offset + frame_size]
    assert len(frame) == frame_size  # read_marker already checked this exact original frame's digest/encoding.
    print(f"PASS actual Apple native digest and intended reporting profile: {binary}")

    reject(original, "[]", "unexpected reporting without intended settings")
    reject(original, mismatch, "different valid origin/profile intent")
    reject(original + frame, settings, "duplicate actual marker")
    corrupted = bytearray(original)
    corrupted[offset + len(security.MAGIC) + 7] ^= 1  # Keep ASCII; change body while preserving the original digest.
    reject(bytes(corrupted), settings, "actual marker body/digest mismatch")
    reject(original[:offset] + original[offset + frame_size :], settings, "missing actual marker")

    assert binary.read_bytes() == original
    assert sidecar.read_bytes() == original_sidecar
    return {
        "binary": binary.as_posix(),
        "native_sha256": hashlib.sha256(original).hexdigest(),
        "capability_sidecar_sha256": hashlib.sha256(original_sidecar).hexdigest(),
        "native_marker_sha256": hashlib.sha256(frame).hexdigest(),
        "profile_match": "passed",
        "negative_cases": "unexpected-intent,valid-mismatch,duplicate,digest,missing",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runtime", type=pathlib.Path)
    parser.add_argument("binaries", type=pathlib.Path, nargs="+")
    parser.add_argument("--evidence", type=pathlib.Path, required=True)
    args = parser.parse_args()
    if platform.system() != "Darwin":
        raise RuntimeError("This gate requires actual Apple CI source-built frameworks")
    endpoint = os.environ["RASP_REPORTING_ENDPOINT"]
    profile = security.validate(os.environ["RASP_REPORTING_SECURITY_PROFILE"], endpoint)
    settings = intended_settings(endpoint, profile)
    other = json.loads(profile)
    other["host"] = "profile-mismatch.invalid"
    other_endpoint = f"https://profile-mismatch.invalid:{other['port']}/"
    other_profile = security.validate(json.dumps(other), other_endpoint)
    mismatch = intended_settings(other_endpoint, other_profile)
    evidence = {
        "source_commit": os.environ["GITHUB_SHA"],
        "runtime_commit": os.environ["RASP_REF"],
        "frameworks": [verify(args.runtime, binary, settings, mismatch) for binary in args.binaries],
    }
    args.evidence.write_text(json.dumps(evidence, indent=2) + "\n")
    print(json.dumps(evidence, sort_keys=True))


if __name__ == "__main__":
    main()
