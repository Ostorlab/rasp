#include "outbox.h"

#include <algorithm>
#include <array>
#include <fcntl.h>
#include <filesystem>
#include <fstream>
#include <gtest/gtest.h>
#include <ios>
#include <optional>
#include <rasp/cycle.h>
#include <rasp/observation.h>
#include <string>
#include <sys/file.h>
#include <sys/stat.h>
#include <unistd.h>
#include <utility>

#include "collection_authority.h"
#include "cycle_payload.h"
#include "hash.h"
#include "rasp/posix/private_storage.h"

namespace rasp::plugins::reporting {
namespace {
class OutboxTest : public testing::Test {
 protected:
  void SetUp() override {
    std::array<char, 40> pattern{};
    const std::string text = "/tmp/pl03-outbox-XXXXXX";
    std::ranges::copy(text, pattern.begin());
    const auto* directory = mkdtemp(pattern.data());
    ASSERT_NE(directory, nullptr);
    root_ = directory;
    auto acquired = rasp::posix::acquire_private_storage_at(root_);
    ASSERT_TRUE(acquired.has_value());
    storage_.emplace(std::move(*acquired));
    binding_ = *collection_authority({
        .endpoint = "https://collector.example/apis/graphql",
        .policy = "default",
        .zone = "r.example",
        .dns_policy = "default",
    });
    CycleSnapshot snapshot;
    snapshot.metadata.execution_finished = true;
    snapshot.metadata.sequence = 1;
    snapshot.metadata.duration_ns = 0;
    auto prepared = prepare_cycle(snapshot, std::string(64, 'b'), storage_->install_id(), *new_batch_id());
    ASSERT_TRUE(prepared.has_value());
    payload_ = std::move(*prepared);
  }
  void TearDown() override {
    storage_.reset();
    std::filesystem::remove_all(root_);
  }
  std::string root_;
  std::optional<PrivateStorage> storage_;
  std::string binding_;
  PreparedCycle payload_;
};
TEST_F(OutboxTest, persist_whenRestarted_replaysExactContentAndIdentity) {
  RecordToken token;
  {
    Outbox box(storage_->native_handle(), std::string(storage_->install_id()));
    ASSERT_TRUE(box.initialize().has_value());
    const auto saved = box.persist(payload_, binding_);
    ASSERT_TRUE(saved.has_value());
    token = *saved;
  }
  Outbox restarted(storage_->native_handle(), std::string(storage_->install_id()));
  ASSERT_TRUE(restarted.initialize().has_value());
  const auto scan = restarted.scan();
  ASSERT_TRUE(scan.has_value());
  ASSERT_EQ(scan->records.size(), 1);
  EXPECT_EQ(scan->records[0].token, token);
  EXPECT_EQ(scan->records[0].payload->canonical, payload_.canonical);
  EXPECT_EQ(scan->records[0].authority, binding_);
}
TEST_F(OutboxTest, retry_whenMoreThanSixteenRestarts_saturatesStageAndStillAcknowledges) {
  RecordToken token;
  {
    Outbox box(storage_->native_handle(), std::string(storage_->install_id()));
    ASSERT_TRUE(box.initialize().has_value());
    const auto saved = box.persist(payload_, binding_);
    ASSERT_TRUE(saved.has_value());
    token = *saved;
  }
  for (unsigned round = 1; round <= 40; ++round) {
    Outbox box(storage_->native_handle(), std::string(storage_->install_id()));
    ASSERT_TRUE(box.initialize().has_value());
    const auto stage = box.reserve(token);
    ASSERT_TRUE(stage.has_value());
    EXPECT_EQ(*stage, std::min(round, 16U));
  }
  Outbox box(storage_->native_handle(), std::string(storage_->install_id()));
  ASSERT_TRUE(box.initialize().has_value());
  EXPECT_EQ(std::filesystem::file_size(root_ + "/rasp_private/cycle_outbox_v1/slot00.try"), 104);
  ASSERT_TRUE(box.acknowledge(token).has_value());
  const auto scan = box.scan();
  ASSERT_TRUE(scan.has_value());
  EXPECT_TRUE(scan->records.empty());
}
TEST_F(OutboxTest, reserve_whenTokenReplaced_refusesToAcknowledgeOtherItem) {
  Outbox box(storage_->native_handle(), std::string(storage_->install_id()));
  ASSERT_TRUE(box.initialize().has_value());
  const auto token = box.persist(payload_, binding_);
  ASSERT_TRUE(token.has_value());
  auto wrong = *token;
  ++wrong.ordinal;
  EXPECT_FALSE(box.reserve(wrong).has_value());
  EXPECT_FALSE(box.acknowledge(wrong).has_value());
  ASSERT_TRUE(box.scan().has_value());
  EXPECT_EQ(box.scan()->records.size(), 1);
}
TEST_F(OutboxTest, initialize_whenSymlinkOrFifoOrDevice_refusesWithoutBlocking) {
  const auto path = root_ + "/rasp_private/cycle_outbox_v1";
  ASSERT_EQ(mkdir(path.c_str(), 0700), 0);
  for (const bool fifo : {false, true}) {
    const auto file = path + "/queue.lock";
    if (fifo) {
      ASSERT_EQ(mkfifo(file.c_str(), 0600), 0);
    } else {
      ASSERT_EQ(symlink("/dev/null", file.c_str()), 0);
    }
    Outbox box(storage_->native_handle(), std::string(storage_->install_id()));
    EXPECT_FALSE(box.initialize().has_value());
    ASSERT_EQ(unlink(file.c_str()), 0);
  }
}
TEST_F(OutboxTest, persist_whenOldBuildAndAuthorityUnchanged_keepsOriginalBody) {
  Outbox box(storage_->native_handle(), std::string(storage_->install_id()));
  ASSERT_TRUE(box.initialize().has_value());
  ASSERT_TRUE(box.persist(payload_, binding_).has_value());
  const auto scan = box.scan();
  ASSERT_TRUE(scan.has_value());
  ASSERT_EQ(scan->records.size(), 1);
  EXPECT_EQ(scan->records[0].payload->build_id, std::string(64, 'b'));
  EXPECT_TRUE(same_https_authority({.original = scan->records[0].authority, .current = binding_}));
}
TEST_F(OutboxTest, persist_whenThirtyTwoSlotsOccupied_rejectsNewestWithoutEviction) {
  Outbox box(storage_->native_handle(), std::string(storage_->install_id()));
  ASSERT_TRUE(box.initialize().has_value());
  for (unsigned index = 0; index < 32; ++index) {
    CycleSnapshot snapshot;
    snapshot.metadata.sequence = index + 1;
    snapshot.metadata.execution_finished = true;
    const auto payload = prepare_cycle(snapshot, std::string(64, 'b'), storage_->install_id(), *new_batch_id());
    ASSERT_TRUE(payload.has_value());
    ASSERT_TRUE(box.persist(*payload, binding_).has_value());
  }
  const auto original = box.scan();
  ASSERT_TRUE(original.has_value());
  ASSERT_EQ(original->records.size(), 32);
  EXPECT_FALSE(box.persist(payload_, binding_).has_value());
  const auto retained = box.scan();
  ASSERT_TRUE(retained.has_value());
  ASSERT_EQ(retained->records.size(), 32);
  EXPECT_EQ(retained->records.front().token, original->records.front().token);
}
TEST_F(OutboxTest, lock_whenContended_returnsBusyAndAnotherSenderCanTakeOverAfterClose) {
  Outbox first(storage_->native_handle(), std::string(storage_->install_id()));
  Outbox second(storage_->native_handle(), std::string(storage_->install_id()));
  ASSERT_TRUE(first.initialize().has_value());
  ASSERT_TRUE(second.initialize().has_value());
  ASSERT_TRUE(first.elect_sender().has_value());
  const auto busy = second.elect_sender();
  ASSERT_FALSE(busy.has_value());
  EXPECT_EQ(busy.error(), OutboxError::kBusy);
  ASSERT_TRUE(first.close().has_value());
  ASSERT_TRUE(second.elect_sender().has_value());
  const int lock = open((root_ + "/rasp_private/cycle_outbox_v1/queue.lock").c_str(), O_RDWR | O_CLOEXEC);
  ASSERT_GE(lock, 0);
  ASSERT_EQ(flock(lock, LOCK_EX | LOCK_NB), 0);
  const auto pending = second.persist(payload_, binding_);
  ASSERT_FALSE(pending.has_value());
  EXPECT_EQ(pending.error(), OutboxError::kBusy);
  ASSERT_EQ(close(lock), 0);
  EXPECT_TRUE(second.persist(payload_, binding_).has_value());
}
TEST_F(OutboxTest, initialize_whenActualDeviceDescriptor_refusesCapability) {
  const int device = open("/dev/null", O_RDWR | O_NONBLOCK | O_CLOEXEC);
  ASSERT_GE(device, 0);
  Outbox box(device, std::string(storage_->install_id()));
  EXPECT_FALSE(box.initialize().has_value());
  ASSERT_EQ(close(device), 0);
}
TEST_F(OutboxTest, scan_whenRecordCorruptOrRetryUsesOneByteAck_preservesHeldBytes) {
  Outbox box(storage_->native_handle(), std::string(storage_->install_id()));
  ASSERT_TRUE(box.initialize().has_value());
  const auto saved = box.persist(payload_, binding_);
  ASSERT_TRUE(saved.has_value());
  ASSERT_TRUE(box.reserve(*saved).has_value());
  const auto log = root_ + "/rasp_private/cycle_outbox_v1/slot00.try";
  {
    std::ofstream file(log, std::ios::app | std::ios::binary);
    file.put(static_cast<char>(0x5a));
  }
  const auto held = box.scan();
  ASSERT_TRUE(held.has_value());
  EXPECT_TRUE(held->records.empty());
  EXPECT_EQ(held->held, 1);
  EXPECT_TRUE(std::filesystem::exists(root_ + "/rasp_private/cycle_outbox_v1/slot00.rec"));
  EXPECT_EQ(std::filesystem::file_size(log), 90);
}
TEST_F(OutboxTest, persist_whenByteQuotaReachedBeforeSlotLimit_keepsEveryExistingRecord) {
  Outbox box(storage_->native_handle(), std::string(storage_->install_id()));
  ASSERT_TRUE(box.initialize().has_value());
  CycleSnapshot snapshot;
  auto& meta = snapshot.metadata;
  meta.platform = "android";
  meta.catalogue_id = std::string(64, 'a');
  meta.config_known = true;
  meta.catalogue_known = true;
  meta.expected = 256;
  meta.groups = {{.name = "dbg", .enabled = true}};
  meta.execution_finished = true;
  meta.sequence = 1;
  for (unsigned index = 0; index < 256; ++index) {
    meta.missing.push_back(
        {.signal = std::string(93, 'x') + std::to_string(100 + index), .source = std::string(64, 's')});
  }
  for (unsigned index = 0; index < 63; ++index) {
    snapshot.observations.push_back(observed("p" + std::to_string(index), "p", std::string(1024, '\x01')));
  }
  meta.status_counts[0] = 63;
  meta.plugin_observations = 63;
  unsigned saved = 0;
  for (; saved < 32; ++saved) {
    const auto payload = prepare_cycle(snapshot, std::string(64, 'b'), storage_->install_id(), *new_batch_id());
    ASSERT_TRUE(payload.has_value());
    const auto result = box.persist(*payload, binding_);
    if (!result.has_value()) {
      EXPECT_EQ(result.error(), OutboxError::kFull);
      break;
    }
  }
  EXPECT_GT(saved, 0);
  EXPECT_LT(saved, 32);
  const auto retained = box.scan();
  ASSERT_TRUE(retained.has_value());
  EXPECT_EQ(retained->records.size(), saved);
  EXPECT_LE(retained->bytes, kOutboxBytes);
}
}  // namespace
}  // namespace rasp::plugins::reporting
