#include "reporting/transport_result.h"
/// Exercises the actual native transport and sender against a bounded loopback HTTP server.
#include <bit>
#include <charconv>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <gtest/gtest.h>
#include <memory>
#include <netinet/in.h>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <sys/poll.h>
#include <sys/socket.h>
#include <system_error>
#include <thread>
#include <unistd.h>
#include <vector>

#include "config.h"
#include "json.h"
#include "rasp/context.h"
#include "rasp/observation.h"
#include "reporting/undelivered_run.h"
#include "sender.h"
#include "transport.h"
#include "transport_fixture.h"
#include "verification_fixture.h"

namespace rasp::plugins::reporting {
const TransportFixture& transport_fixture() {
  static const TransportFixture kValue{
      .ca_file = "",
      .address = "",
      .http_fixture = true,
      .proxy_port = "",
      .verification = nullptr,
  };
  return kValue;
}
namespace {

constexpr std::string_view kTrue = R"({"data":{"submitObservations":true}})";

/// Owns a fixture socket and closes it when the test scope ends.
class Socket {
 public:
  explicit Socket(int descriptor) : descriptor_(descriptor) {}
  ~Socket() {
    if (descriptor_ >= 0) {
      static_cast<void>(close(descriptor_));
    }
  }
  Socket(const Socket&) = delete;
  Socket& operator=(const Socket&) = delete;
  Socket(Socket&&) = delete;
  Socket& operator=(Socket&&) = delete;
  [[nodiscard]] int get() const { return descriptor_; }

 private:
  int descriptor_;
};

/// Reads the full bounded request before replying, so closing the fixture does not reset unread request data.
[[nodiscard]] bool read_request(int socket, std::string* captured = nullptr) {
  std::string request;
  while (request.size() < kMaxRequestSize) {
    pollfd descriptor{.fd = socket, .events = POLLIN, .revents = 0};
    if (poll(&descriptor, 1, 5000) <= 0) {
      return false;
    }
    std::string bytes(4096, '\0');
    const ssize_t count = recv(socket, bytes.data(), bytes.size(), 0);
    if (count <= 0) {
      return false;
    }
    request.append(bytes.data(), static_cast<std::size_t>(count));
    const std::size_t end = request.find("\r\n\r\n");
    const std::size_t length = request.find("Content-Length: ");
    if (end != std::string::npos && length != std::string::npos) {
      const std::size_t start = length + std::string_view("Content-Length: ").size();
      std::size_t size = 0;
      const std::string_view digits = std::string_view(request).substr(start, request.find("\r\n", start) - start);
      const std::span<const char> length_bytes(digits);
      const auto parsed =
          std::from_chars(std::to_address(length_bytes.begin()), std::to_address(length_bytes.end()), size);
      if (parsed.ec != std::errc{} || size > kMaxRequestSize) {
        return false;
      }
      if (request.size() >= end + 4 + size) {
        if (captured != nullptr) {
          *captured = request;
        }
        return true;
      }
    }
  }
  return false;
}

/// Serves one request with optional split writes or a deliberate stall; socket waits are bounded.
void serve(int listener, std::string_view response, std::chrono::milliseconds delay, bool split,
           std::string* captured = nullptr) {
  pollfd descriptor{.fd = listener, .events = POLLIN, .revents = 0};
  if (poll(&descriptor, 1, 5000) <= 0) {
    return;
  }
  const Socket client(accept(listener, nullptr, nullptr));
  if (client.get() < 0 || !read_request(client.get(), captured)) {
    return;
  }
#ifdef __APPLE__
  const int enabled = 1;
  static_cast<void>(setsockopt(client.get(), SOL_SOCKET, SO_NOSIGPIPE, &enabled, sizeof(enabled)));
  constexpr int kSendFlags = 0;
#else
  constexpr int kSendFlags = MSG_NOSIGNAL;
#endif
  std::this_thread::sleep_for(delay);
  std::size_t position = 0;
  while (position < response.size()) {
    const std::string_view remaining = response.substr(position, split ? 1 : std::string_view::npos);
    const ssize_t count = send(client.get(), remaining.data(), remaining.size(), kSendFlags);
    if (count <= 0) {
      return;
    }
    position += static_cast<std::size_t>(count);
  }
}

/// Joins the bounded server on every scope exit, including on toolchains without std::jthread.
class Server {
 public:
  Server(int listener, std::string_view response, std::chrono::milliseconds delay, bool split,
         std::string* captured = nullptr)
      : thread_([listener, response, delay, split, captured] { serve(listener, response, delay, split, captured); }) {}
  ~Server() { thread_.join(); }
  Server(const Server&) = delete;
  Server& operator=(const Server&) = delete;
  Server(Server&&) = delete;
  Server& operator=(Server&&) = delete;

 private:
  std::thread thread_;
};

/// Frames one fixture body with its exact Content-Length.
[[nodiscard]] std::string framed(std::string_view body) {
  return "HTTP/1.1 200 OK\r\nContent-Length: " + std::to_string(body.size()) + "\r\nConnection: close\r\n\r\n" +
         std::string(body);
}

/// Binds an ephemeral loopback listener; a zero port means setup failed.
class Listener {
 public:
  Listener() : socket_(socket(AF_INET, SOCK_STREAM, 0)) {
    if (socket_.get() < 0) {
      return;
    }
    sockaddr_in address{};
    address.sin_family = AF_INET;
#ifdef __APPLE__
    address.sin_len = static_cast<std::uint8_t>(sizeof(address));
#endif
    address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    auto generic_address = std::bit_cast<sockaddr>(address);
    if (bind(socket_.get(), &generic_address, sizeof(generic_address)) != 0 || listen(socket_.get(), 1) != 0) {
      return;
    }
    socklen_t size = sizeof(address);
    if (getsockname(socket_.get(), &generic_address, &size) == 0) {
      port_ = ntohs(std::bit_cast<sockaddr_in>(generic_address).sin_port);
    }
  }
  [[nodiscard]] int get() const { return socket_.get(); }
  [[nodiscard]] std::uint16_t port() const { return port_; }

 private:
  Socket socket_;
  std::uint16_t port_ = 0;
};

/// Drives the production transport through deliver and checks the original run's fallback handoff.
void expect_delivery(const std::string& response, bool accepted, bool split = false,
                     std::chrono::milliseconds delay = std::chrono::milliseconds(0)) {
  const Listener listener;
  ASSERT_NE(listener.port(), 0);
  const Server server(listener.get(), response, delay, split);
  Context context;
  Sender sender;
  sender.context = &context;
  sender.config.endpoint = "http://127.0.0.1:" + std::to_string(listener.port()) + "/graphql";
  sender.config.build_id = "loopback";
  sender.post = post;
  const std::vector<Observation> run{observed("test.publication", "test", true)};
  deliver(sender, run);
  if (accepted) {
    EXPECT_EQ(context.get(kUndeliveredRun), std::nullopt);
  } else {
    const auto network = context.get(kUndeliveredRun);
    const auto suppressed = context.get(kSecuritySuppressedRun);
    EXPECT_TRUE(network == run || suppressed == run);
  }
}

TEST(Transport, deliver_whenPublicationTrue_acceptsCompletedResponse) { expect_delivery(framed(kTrue), true, true); }
TEST(Transport, post_whenExactTargetIncludesDotSegmentsAndEmptyQuery_preservesBytes) {
  const Listener listener;
  ASSERT_NE(listener.port(), 0);
  std::string captured;
  const auto response = framed(kTrue);
  {
    const Server server(listener.get(), response, std::chrono::milliseconds(0), false, &captured);
    const Config config{
        .endpoint = "http://127.0.0.1:" + std::to_string(listener.port()) + "/a/../b/%2f?",
        .build_id = "fixture",
    };
    EXPECT_EQ(post(config, "{}"), TransportResult::kPublicationAcknowledged);
  }
  EXPECT_TRUE(captured.starts_with("POST /a/../b/%2f? HTTP/1.1\r\n"));
}
TEST(Transport, post_when204Or205EvenWithTrueBody_refusesPublicationAck) {
  for (const auto code : {204, 205}) {
    expect_delivery("HTTP/1.1 " + std::to_string(code) + " Empty\r\nContent-Length: " + std::to_string(kTrue.size()) +
                        "\r\nConnection: close\r\n\r\n" + std::string(kTrue),
                    false);
  }
}

TEST(Transport, deliver_whenPublicationUnconfirmed_preservesRun) {
  for (const std::string_view body : {
           R"({"data":{"submitObservations":false}})",
           R"({"data":{"submitObservations":null}})",
           R"({"data":{"submitObservations":"true"}})",
           R"({"data":{"submitObservations":1}})",
           R"({"data":{}})",
           R"({"data":null})",
           "null",
           "{}",
           "not json",
           R"({"data":{"submitObservations":true},"errors":[{"message":"failed"}]})",
           R"({"data":{"submitObservations":false,"submitObservations":true}})",
           R"({"data":{"submitObservations":true}} trailing)",
       }) {
    expect_delivery(framed(body), false);
  }
}

TEST(Transport, deliver_whenInvalidOrOversizedJson_preservesRun) {
  expect_delivery(framed(R"({"data":{"submitObservations":true},"x":"\ud800"})"), false);
  expect_delivery(framed(std::string(kTrue) + std::string(kMaxResponseSize, ' ')), false);
  expect_delivery(
      framed(R"({"data":{"submitObservations":true},"x":)" + std::string(40, '[') + "0" + std::string(40, ']') + "}"),
      false);
  expect_delivery(framed(R"({"data":{"submitObservations":true},"x":")" + std::string("\xc0\xaf") + "\"}"), false);
}

TEST(Transport, deliver_whenChunkedOrCloseDelimited_acceptsCompleteResponse) {
  expect_delivery("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n24\r\n" + std::string(kTrue) + "\r\n0\r\n\r\n",
                  true, true);
  expect_delivery("HTTP/1.0 200 OK\r\n\r\n" + std::string(kTrue), true, true);
}

TEST(Transport, deliver_whenTruncatedOrNon2xx_preservesRun) {
  expect_delivery("HTTP/1.1 200 OK\r\nContent-Length: 100\r\n\r\n" + std::string(kTrue), false);
  expect_delivery("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n24\r\n" + std::string(kTrue), false);
  expect_delivery("HTTP/1.1 500 Error\r\nContent-Length: 36\r\n\r\n" + std::string(kTrue), false);
  expect_delivery(
      "HTTP/1.1 302 Found\r\nLocation: http://127.0.0.1/other\r\nContent-Length: 36\r\n\r\n" + std::string(kTrue),
      false);
  expect_delivery("HTTP/1.1 200 OK\r\n", false);
  expect_delivery("", false);
}

TEST(Transport, deliver_whenResponseTimesOut_preservesRun) {
  expect_delivery(framed(kTrue), false, false, kPostTimeout + std::chrono::seconds(1));
}
// Coordinator-only checks: no Security invocation, API submission or callback retirement is simulated here.
TEST(VerificationCoordination, release_whenSignalledBeforeWait_preservesWakeupWithoutClaimingSubmission) {
  VerificationFixture fixture(true);
  fixture.release();
  EXPECT_TRUE(fixture.await_release());
  const auto progress = fixture.progress();
  EXPECT_EQ(progress.failures, 0);
  EXPECT_FALSE(progress.committed);
  EXPECT_FALSE(progress.submitted);
  EXPECT_FALSE(progress.callback);
  EXPECT_FALSE(progress.retired);
}
TEST(VerificationCoordination, wait_whenCommitNeverArrives_recordsFiniteFailureAndStillAllowsRelease) {
  VerificationFixture fixture(true);
  EXPECT_FALSE(fixture.await_committed());
  fixture.release();
  EXPECT_TRUE(fixture.await_release());
  const auto progress = fixture.progress();
  EXPECT_EQ(progress.failures, 1);
  EXPECT_FALSE(progress.submitted);
  EXPECT_FALSE(progress.callback);
  EXPECT_FALSE(progress.retired);
}
}  // namespace
}  // namespace rasp::plugins::reporting
