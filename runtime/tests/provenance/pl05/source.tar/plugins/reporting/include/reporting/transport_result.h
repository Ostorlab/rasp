/// Bounded reporting transport diagnostics; no peer-controlled text.
#pragma once
#include <cstdint>
namespace rasp::plugins::reporting {
/// Internal terminal result: only the explicit publication acknowledgement authorizes outbox cleanup.
enum class TransportResult : std::uint8_t {
  kPublicationAcknowledged,
  kProfileInvalid,
  kProfileNotActive,
  kPlatformPolicyUnavailable,
  kTrustVerificationFailed,
  kPinVerificationFailed,
  kKeyUnavailable,
  kProxyRejected,
  kCancelled,
  kTrustEvaluationBusy,
  kResolutionFailed,
  kConnectFailed,
  kTimeout,
  kIoFailed,
  kRedirectRejected,
  kHttpRejected,
  kResponseInvalid,
  kPublicationUnconfirmed,
  kTransportBusy,
};
}  // namespace rasp::plugins::reporting
