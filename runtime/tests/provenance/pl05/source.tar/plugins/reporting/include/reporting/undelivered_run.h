/// kUndeliveredRun: the key of the run the reporting plugin did not deliver, in the context the plugins share.

#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <mutex>
#include <optional>
#include <vector>

#include "rasp/context.h"
#include "rasp/observation.h"
#include "reporting/fallback_authorization.h"
#include "reporting/transport_result.h"

namespace rasp::plugins::reporting {

/// Existing raw channel for separately selected standalone DNS-only clients. Reporting-enabled DNS refuses it;
/// profile-governed reporting uses the atomic authorized envelope below.
inline constexpr Key<std::vector<Observation>> kUndeliveredRun{.name = "reporting.undelivered_run"};

/// Profile-governed legacy data and its exact authorization are one atomic context value.
struct AuthorizedUndeliveredRun {
  std::vector<Observation> observations;
  std::shared_ptr<const FallbackAuthorization> authorization;
  std::optional<TransportResult> https_result = std::nullopt;
};
inline constexpr Key<AuthorizedUndeliveredRun> kAuthorizedUndeliveredRun{"reporting.authorized_undelivered_run"};
/// Ineligible for plaintext fallback; retained as the latest volatile diagnostic run only.
inline constexpr Key<std::vector<Observation>> kSecuritySuppressedRun{"reporting.security_suppressed_run"};

enum class LegacyRetention : std::uint8_t { kAcknowledged, kAuthorizedDns, kSuppressed, kTooLarge };
/// Volatile last HTTPS decision; an absent result means no transport was attempted. Contains no request/peer text.
struct LegacyDeliveryDiagnostic {
  std::optional<TransportResult> transport = std::nullopt;
  std::optional<TransportResult> fallback_refusal = std::nullopt;
  LegacyRetention retention = LegacyRetention::kSuppressed;
};
inline constexpr Key<LegacyDeliveryDiagnostic> kLegacyDeliveryDiagnostic{"reporting.legacy_delivery"};

enum class LegacyDnsState : std::uint8_t {
  kQueued,
  kSending,
  kSuppressed,
  kFailed,
  kQueriesFinished,
  kReplaced,
  kTooLarge,
};
struct LegacyDnsHealth {
  LegacyDnsState state = LegacyDnsState::kQueued;
  TransportResult reason = TransportResult::kPublicationUnconfirmed;
  std::size_t queries_started = 0;
  std::size_t queries_completed = 0;
};
/// Owns one bounded immutable original envelope and its mutable, synchronized diagnostics. No parent pointer.
class LegacyDnsAttempt {
 public:
  explicit LegacyDnsAttempt(AuthorizedUndeliveredRun run);
  [[nodiscard]] const AuthorizedUndeliveredRun* original() const;
  [[nodiscard]] LegacyDnsHealth health() const;
  void start_query();
  void complete_query();
  void finish(LegacyDnsState state, TransportResult reason);

 private:
  const std::optional<AuthorizedUndeliveredRun> original_;
  mutable std::mutex mutex_;
  LegacyDnsHealth health_;
};
/// Latest admitted attempt, retained even after worker refusal/completion. Replaced by the next admitted handoff.
inline constexpr Key<std::shared_ptr<LegacyDnsAttempt>> kLegacyDnsAttempt{"reporting.legacy_dns_attempt"};
/// Last handoff admission only; oversized input does not evict the latest admitted original.
inline constexpr Key<LegacyDnsHealth> kLegacyDnsAdmission{"reporting.legacy_dns_admission"};

}  // namespace rasp::plugins::reporting
