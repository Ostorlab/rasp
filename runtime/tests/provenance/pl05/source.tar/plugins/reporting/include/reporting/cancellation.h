/// Owned process-local cancellation, independent of the parent actor's lifetime.
#pragma once
#include <atomic>
#include <memory>
#include <utility>
namespace rasp::plugins::reporting {
class CancellationSource {
 public:
  [[nodiscard]] static CancellationSource create() {
    return CancellationSource(std::make_shared<std::atomic<bool>>(false));
  }
  ~CancellationSource() { request(); }
  CancellationSource(const CancellationSource&) = delete;
  CancellationSource& operator=(const CancellationSource&) = delete;
  CancellationSource(CancellationSource&&) = delete;
  CancellationSource& operator=(CancellationSource&&) = delete;
  void request() const { state_->store(true); }
  [[nodiscard]] bool requested() const { return state_->load(); }
  [[nodiscard]] std::shared_ptr<const std::atomic<bool>> share() const { return state_; }

 private:
  explicit CancellationSource(std::shared_ptr<std::atomic<bool>> state) : state_(std::move(state)) {}
  std::shared_ptr<std::atomic<bool>> state_;
};
}  // namespace rasp::plugins::reporting
