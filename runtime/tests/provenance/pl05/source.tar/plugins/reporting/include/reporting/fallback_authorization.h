/// Immutable original DNS authority/profile and an owned cancellation flag. Contains no actor or callback.
#pragma once
#include <atomic>
#include <memory>
#include <string>
#include <string_view>

#include "reporting/transport_result.h"
namespace rasp::plugins::reporting {
struct Config;
struct DnsSelection {
  std::string_view zone;
  std::string_view policy;
};
class FallbackAuthorization {
 public:
  FallbackAuthorization(const Config& config, std::string authority,
                        std::shared_ptr<const std::atomic<bool>> cancellation);
  /// Fresh UTC/platform/cancel validation; PublicationUnconfirmed means still authorized, never an ack.
  [[nodiscard]] TransportResult status() const;
  /// Compare selected DNS policy; never rebind the saved authority to a later epoch.
  [[nodiscard]] bool matches_dns(DnsSelection selection) const;
  [[nodiscard]] std::string_view authority() const { return authority_; }

 private:
  std::shared_ptr<const Config> config_;
  std::string authority_;
  std::shared_ptr<const std::atomic<bool>> cancellation_;
  bool bound_ = false;
};
}  // namespace rasp::plugins::reporting
