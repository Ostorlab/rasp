/// Process-local delivery diagnostics and the optional DNS transport registration seam.
#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <string_view>

#include "reporting/transport_result.h"

namespace rasp::plugins::reporting {
struct PreparedCycle;
class FallbackAuthorization;
enum class DeliveryState : std::uint8_t {
  kVolatilePending,
  kPreparedPending,
  kDurableReady,
  kDurableBackoff,
  kHeld,
  kAckCleanupPending,
  kPublicationAcknowledged,
};
enum class DeliveryFailure : std::uint8_t {
  kNone,
  kStorageUnavailable,
  kBusy,
  kInvalidRecord,
  kIdentityMismatch,
  kAuthorityMismatch,
  kFallbackAuthorityMismatch,
  kClockUnavailable,
  kEntropyUnavailable,
  kSerialization,
  kIo,
  kCapacity,
  kWorkerUnavailable,
  kNetwork,
  /// Non-availability security/protocol/cancellation/busy/missing-ack outcome; last_transport_result is precise.
  kTransportRefused,
};
/// Best-effort atomic-field snapshot, never a trusted check-health or database delivery claim.
struct DeliveryHealth {
  std::uint64_t volatile_pending = 0;
  std::uint64_t durable_pending = 0;
  std::uint64_t held_records = 0;
  std::uint64_t authority_held_records = 0;
  std::uint64_t dns_fallback_held_records = 0;
  std::uint64_t backoff_saturated_records = 0;
  std::uint64_t admission_dropped = 0;
  std::uint64_t serialization_dropped = 0;
  std::uint64_t publication_acknowledged = 0;
  std::uint64_t https_attempted = 0;
  std::uint64_t dns_attempted = 0;
  bool counter_lower_bound = false;
  bool persistence_uncertain = false;
  DeliveryState state = DeliveryState::kVolatilePending;
  DeliveryFailure failure = DeliveryFailure::kNone;
  TransportResult last_transport_result = TransportResult::kPublicationUnconfirmed;
};
/// Complete-cycle diagnostics only. Legacy direct dispatch is one-shot best effort: suppressed response/security
/// outcomes have no retry or consumer and their bounded volatile evidence is lost on replacement or teardown.
/// Its precise typed result/retention diagnostics are kLegacyDeliveryDiagnostic and kLegacyDnsAttempt in
/// reporting/undelivered_run.h; DNS query completion is never an acknowledgement.
/// Read diagnostics without taking a filesystem/admission lock; no raw values or authority strings are returned.
[[nodiscard]] DeliveryHealth delivery_health();
/// Lifetime-static optional transport; accepted work must retain both immutable payload and original binding.
struct DnsFallback {
  std::string_view zone;
  std::string_view collection_policy;
  bool (*enqueue)(std::shared_ptr<const PreparedCycle> payload,
                  std::shared_ptr<const FallbackAuthorization> authorization) noexcept = nullptr;
  bool (*busy)(std::string_view batch_id) noexcept = nullptr;
};
/// Registers an explicitly selected DNS plugin; nullptr disables future handoffs, without acknowledging any record.
void register_dns_fallback(const DnsFallback* fallback);
/// Lifetime-static selection; snapshots copy its values before leaving the producer.
[[nodiscard]] const DnsFallback* selected_dns_fallback();
}  // namespace rasp::plugins::reporting
