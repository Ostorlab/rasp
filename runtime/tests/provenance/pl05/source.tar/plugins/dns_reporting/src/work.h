/// One atomic newest-only legacy batch and its owned original reporting attempt; null only in standalone DNS.
#pragma once
#include <memory>
#include <string>
#include <vector>
namespace rasp::plugins::reporting {
class LegacyDnsAttempt;
}
namespace rasp::plugins::dns_reporting {
struct Work {
  std::vector<std::string> names;
  std::shared_ptr<reporting::LegacyDnsAttempt> attempt;
};
}  // namespace rasp::plugins::dns_reporting
