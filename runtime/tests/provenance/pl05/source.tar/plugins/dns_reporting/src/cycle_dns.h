/// Immutable DNS-v2 producer and optional process-lifetime fallback worker.
#pragma once
#include <array>
#include <chrono>
#include <cstdint>
#include <string>
#include <vector>

#include "cycle_payload.h"

namespace rasp::plugins::dns_reporting {
/// Exact bounded version2 binary frame used before DNS-name chunking.
[[nodiscard]] std::vector<std::uint8_t> build_cycle_payload(const reporting::PreparedCycle& payload,
                                                            const std::array<std::uint8_t, 4>& message_id,
                                                            std::uint16_t hour);
/// Encodes original build/install/batch/content; oversized v2 returns empty, never truncates or downgrades.
[[nodiscard]] std::vector<std::string> build_cycle_report(const reporting::PreparedCycle& payload,
                                                          std::string_view authority,
                                                          const std::array<std::uint8_t, 4>& message_id,
                                                          std::uint16_t hour);
/// Registers the explicitly selected immutable fallback. No I/O/thread starts until an HTTPS worker hands off work.
void register_cycle_dns();
/// Platform cycle query with explicit worker deadline; host builds do not send.
[[nodiscard]] bool resolve_until(const std::string& name, std::chrono::steady_clock::time_point deadline) noexcept;
}  // namespace rasp::plugins::dns_reporting
