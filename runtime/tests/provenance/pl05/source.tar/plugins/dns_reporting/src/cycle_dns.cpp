#include "cycle_dns.h"

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <ctime>
#include <memory>
#include <mutex>
#include <new>
#include <optional>
#include <pthread.h>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "cbor.h"
#include "collection_authority.h"
#include "cycle_payload.h"
#include "dns_frame.h"
#include "hash.h"
#include "reporting/delivery.h"
#include "reporting/fallback_authorization.h"
#include "reporting/transport_result.h"
#ifdef RASP_DNS_WORKER_TEST
#include "dns_worker_fixture.h"
#endif

namespace rasp::plugins::dns_reporting {
namespace {
struct CycleDnsWorker {
  std::mutex mutex;
  std::condition_variable wake;
  std::shared_ptr<const reporting::PreparedCycle> payload;
  std::shared_ptr<const reporting::FallbackAuthorization> authorization;
  std::atomic<bool> active{false};
};
std::atomic<CycleDnsWorker*>& cycle_worker() {
  static std::atomic<CycleDnsWorker*> value{nullptr};
  return value;
}
std::optional<std::vector<std::uint8_t>> from_hex(std::string_view text) {
  constexpr std::string_view kHex = "0123456789abcdef";
  std::vector<std::uint8_t> bytes;
  std::optional<unsigned> high;
  for (const char byte : text) {
    if (byte == '-') {
      continue;
    }
    const auto value = kHex.find(byte);
    if (value == std::string_view::npos) {
      return std::nullopt;
    }
    if (!high.has_value()) {
      high = static_cast<unsigned>(value);
    } else {
      bytes.push_back(static_cast<std::uint8_t>((*high << 4U) | value));
      high.reset();
    }
  }
  if (high.has_value()) {
    return std::nullopt;
  }
  return bytes;
}
void* run_cycles(void* argument) noexcept {
  auto& worker = *static_cast<CycleDnsWorker*>(argument);
  while (true) {
    std::shared_ptr<const reporting::PreparedCycle> payload;
    std::shared_ptr<const reporting::FallbackAuthorization> authorization;
#ifdef RASP_DNS_WORKER_TEST
    fixture_before_dequeue();
#endif
    {
      std::unique_lock lock(worker.mutex);
      worker.wake.wait(lock, [&worker] { return worker.payload != nullptr; });
      payload = std::move(worker.payload);
      authorization = std::move(worker.authorization);
    }
    std::array<std::uint8_t, 4> message_id{};
    if (authorization != nullptr && authorization->status() == reporting::TransportResult::kPublicationUnconfirmed &&
        reporting::secure_random(message_id)) {
      const auto names = build_cycle_report(*payload, authorization->authority(), message_id,
                                            hour_of(static_cast<std::int64_t>(std::time(nullptr))));
      const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(30);
      for (const auto& name : names) {
        const auto now = std::chrono::steady_clock::now();
        if (authorization->status() != reporting::TransportResult::kPublicationUnconfirmed || now >= deadline ||
            !resolve_until(name, std::min(deadline, now + std::chrono::seconds(2)))) {
          break;
        }
      }
    }
    worker.active.store(false);
#ifdef RASP_DNS_WORKER_TEST
    fixture_after_batch();
#endif
  }
}
CycleDnsWorker* create_worker() {
  if (auto* existing = cycle_worker().load(); existing != nullptr) {
    return existing;
  }
  auto candidate = std::unique_ptr<CycleDnsWorker>(new (std::nothrow) CycleDnsWorker{});
  if (candidate == nullptr) {
    return nullptr;
  }
  pthread_attr_t attributes{};
  if (pthread_attr_init(&attributes) != 0) {
    return nullptr;
  }
  pthread_t thread{};
  const bool started = pthread_attr_setdetachstate(&attributes, PTHREAD_CREATE_DETACHED) == 0 &&
                       pthread_create(&thread, &attributes, run_cycles, candidate.get()) == 0;
  static_cast<void>(pthread_attr_destroy(&attributes));
  if (!started) {
    return nullptr;
  }
  auto* created = candidate.release();
  cycle_worker().store(created);
  return created;
}
CycleDnsWorker* worker() {
  static std::atomic_flag creating;
  if (creating.test_and_set()) {
    return nullptr;
  }
  auto* destination = create_worker();
  creating.clear();
  return destination;
}
bool enqueue(std::shared_ptr<const reporting::PreparedCycle> payload,
             std::shared_ptr<const reporting::FallbackAuthorization> authorization) noexcept {
  if (authorization == nullptr ||
      !authorization->matches_dns({.zone = RASP_DNS_REPORTING_ZONE, .policy = RASP_DNS_REPORTING_COLLECTION_POLICY}) ||
      authorization->status() != reporting::TransportResult::kPublicationUnconfirmed) {
    return false;
  }
  auto* destination = worker();
  if (destination == nullptr) {
    return false;
  }
  std::unique_lock const lock(destination->mutex, std::try_to_lock);
  if (!lock.owns_lock() || destination->active.load()) {
    return false;
  }
  destination->active.store(true);
  destination->payload = std::move(payload);
  destination->authorization = std::move(authorization);
  destination->wake.notify_one();
  return true;
}
bool busy(std::string_view /*unused*/) noexcept {
  const auto* destination = cycle_worker().load();
  return destination != nullptr && destination->active.load();
}
constexpr reporting::DnsFallback kFallback{
    .zone = RASP_DNS_REPORTING_ZONE,
    .collection_policy = RASP_DNS_REPORTING_COLLECTION_POLICY,
    .enqueue = enqueue,
    .busy = busy,
};
}  // namespace
std::vector<std::uint8_t> build_cycle_payload(const reporting::PreparedCycle& payload,
                                              const std::array<std::uint8_t, 4>& message_id, std::uint16_t hour) {
  const auto original = reporting::restore_cycle(payload.canonical);
  if (!original.has_value()) {
    return {};
  }
  const auto cbor = encode_cycle_text(original->dns_json);
  if (cbor.empty()) {
    return {};
  }
  const auto build = from_hex(original->build_id);
  const auto install = from_hex(original->install_id);
  if (!build.has_value() || build->size() != 32 || !install.has_value() || install->size() != 16) {
    return {};
  }
  return write_payload(std::span<const std::uint8_t, 16>(build->data(), 16), hour,
                       std::span<const std::uint8_t, 16>(install->data(), 16), cbor, message_id, 2);
}
std::vector<std::string> build_cycle_report(const reporting::PreparedCycle& payload, std::string_view authority,
                                            const std::array<std::uint8_t, 4>& message_id, std::uint16_t hour) {
  const auto zone = reporting::authority_zone(authority);
  if (!zone.has_value()) {
    return {};
  }
  const auto framed = build_cycle_payload(payload, message_id, hour);
  if (framed.size() > kMaxPayloadBytes) {
    return {};
  }
  return write_names(framed, message_id, *zone);
}
void register_cycle_dns() { reporting::register_dns_fallback(&kFallback); }
}  // namespace rasp::plugins::dns_reporting
