#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <dns_sd.h>
#include <string>

#include "cycle_dns.h"
#include "posix_poll.h"

namespace rasp::plugins::dns_reporting {
namespace {
struct Answer {
  bool finished = false;
  bool accepted = false;
};
void answered(DNSServiceRef /*service*/, DNSServiceFlags /*flags*/, std::uint32_t /*interface_index*/,
              DNSServiceErrorType error, const char* /*full_name*/, std::uint16_t type, std::uint16_t record_class,
              std::uint16_t length, const void* /*data*/, std::uint32_t /*ttl*/, void* context) noexcept {
  auto& answer = *static_cast<Answer*>(context);
  answer.finished = true;
  answer.accepted = error == kDNSServiceErr_NoError && type == kDNSServiceType_A &&
                    record_class == kDNSServiceClass_IN && length == 4;
}
}  // namespace
bool resolve_until(const std::string& name, std::chrono::steady_clock::time_point deadline) noexcept {
  if (name.size() > 253 || std::chrono::steady_clock::now() >= deadline) {
    return false;
  }
  Answer answer;
  DNSServiceRef service = nullptr;
  const std::string absolute = name + ".";
  if (DNSServiceQueryRecord(&service, 0, 0, absolute.c_str(), kDNSServiceType_A, kDNSServiceClass_IN, answered,
                            &answer) != kDNSServiceErr_NoError ||
      service == nullptr) {
    return false;
  }
  const int descriptor = DNSServiceRefSockFD(service);
  constexpr unsigned kErrors =
      static_cast<unsigned>(POLLERR) | static_cast<unsigned>(POLLHUP) | static_cast<unsigned>(POLLNVAL);
  while (descriptor >= 0 && !answer.finished && std::chrono::steady_clock::now() < deadline) {
    const auto remaining =
        std::chrono::duration_cast<std::chrono::milliseconds>(deadline - std::chrono::steady_clock::now()).count();
    struct pollfd ready{.fd = descriptor, .events = POLLIN, .revents = 0};
    const int status = poll(&ready, 1, static_cast<int>(std::clamp<std::int64_t>(remaining, 1, 100)));
    if (status < 0 && errno == EINTR) {
      continue;
    }
    if (status < 0 || (static_cast<unsigned>(ready.revents) & kErrors) != 0) {
      break;
    }
    if (status > 0 && (static_cast<unsigned>(ready.revents) & static_cast<unsigned>(POLLIN)) != 0 &&
        DNSServiceProcessResult(service) != kDNSServiceErr_NoError) {
      break;
    }
  }
  DNSServiceRefDeallocate(service);
  return answer.finished && answer.accepted;
}
}  // namespace rasp::plugins::dns_reporting
