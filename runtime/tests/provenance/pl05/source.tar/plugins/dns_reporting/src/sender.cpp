/// deliver and start_sender: the DNS reporting plugin's sender thread.

#include "sender.h"

#include <algorithm>
#include <chrono>
#include <cstddef>

#include "work.h"
#ifdef RASP_DNS_CYCLE_ENABLED
#include "reporting/fallback_authorization.h"
#include "reporting/transport_result.h"
#include "reporting/undelivered_run.h"
#endif
#ifdef RASP_DNS_WORKER_TEST
#include "dns_worker_fixture.h"
#endif
#include <pthread.h>
#include <string>
#include <vector>

#include "rasp/util/logging.h"

namespace rasp::plugins::dns_reporting {

namespace {

/// The stack size of the sender's thread.
constexpr std::size_t kStackSize = std::size_t{512} * 1024;

/// The thread: takes each batch from the mailbox and delivers it.
void* run(void* argument) {
  auto* const sender = static_cast<Sender*>(argument);
  while (true) {
#ifdef RASP_DNS_WORKER_TEST
    fixture_before_dequeue();
#endif
    const Work work = sender->mailbox.take_work();
    static_cast<void>(deliver_work(*sender, work));
#ifdef RASP_DNS_WORKER_TEST
    fixture_after_batch();
#endif
  }
}

}  // namespace

bool deliver(const Sender& sender, const std::vector<std::string>& names) {
  if (sender.resolve == nullptr) {
    return false;
  }
  for (const std::string& name : names) {
    if (!sender.resolve(name)) {
      if constexpr (kLoggingEnabled) {
        rasp::log("dns_reporting: resolve failed, remaining names dropped");
      }
      return false;
    }
  }
  if constexpr (kLoggingEnabled) {
    rasp::log("dns_reporting: resolved " + std::to_string(names.size()) + " DNS names");
  }
  return true;
}

bool deliver_work(const Sender& sender, const Work& work) {
#ifdef RASP_DNS_CYCLE_ENABLED
  if (work.attempt == nullptr) {
    return false;
  }
  const auto* original = work.attempt->original();
  if (original == nullptr || original->authorization == nullptr || sender.resolve_bounded == nullptr) {
    work.attempt->finish(reporting::LegacyDnsState::kSuppressed, reporting::TransportResult::kProfileInvalid);
    return false;
  }
  const auto& authorization = *original->authorization;
  const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(30);
  for (const auto& name : work.names) {
    const auto status = authorization.status();
    if (status != reporting::TransportResult::kPublicationUnconfirmed) {
      work.attempt->finish(reporting::LegacyDnsState::kSuppressed, status);
      return false;
    }
    const auto now = std::chrono::steady_clock::now();
    if (now >= deadline) {
      work.attempt->finish(reporting::LegacyDnsState::kFailed, reporting::TransportResult::kTimeout);
      return false;
    }
    work.attempt->start_query();
    if (!sender.resolve_bounded(name, std::min(deadline, now + std::chrono::seconds(2)))) {
      work.attempt->finish(reporting::LegacyDnsState::kFailed, reporting::TransportResult::kResolutionFailed);
      return false;
    }
    work.attempt->complete_query();
  }
  work.attempt->finish(reporting::LegacyDnsState::kQueriesFinished,
                       reporting::TransportResult::kPublicationUnconfirmed);
  return true;
#else
  return deliver(sender, work.names);
#endif
}

bool start_sender(Sender& sender) {
  pthread_attr_t attributes{};  // NOLINT(misc-include-cleaner)
  if (pthread_attr_init(&attributes) != 0) {
    return false;
  }
  bool started = false;
  if (pthread_attr_setdetachstate(&attributes, PTHREAD_CREATE_DETACHED) == 0 &&
      pthread_attr_setstacksize(&attributes, kStackSize) == 0) {
    pthread_t thread{};  // NOLINT(misc-include-cleaner)
    started = pthread_create(&thread, &attributes, run, &sender) == 0;
  }
  static_cast<void>(pthread_attr_destroy(&attributes));
  return started;
}

}  // namespace rasp::plugins::dns_reporting
