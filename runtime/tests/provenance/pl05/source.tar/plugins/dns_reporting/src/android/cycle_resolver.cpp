#include <algorithm>
#include <android/multinetwork.h>
#include <array>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <string>

#include "cycle_dns.h"
#include "posix_poll.h"

namespace rasp::plugins::dns_reporting {
bool resolve_until(const std::string& name, std::chrono::steady_clock::time_point deadline) noexcept {
  if (name.size() > 253 || std::chrono::steady_clock::now() >= deadline) {
    return false;
  }
  const std::string absolute = name + ".";
  const int descriptor = android_res_nquery(NETWORK_UNSPECIFIED, absolute.c_str(), 1, 1,
                                            ANDROID_RESOLV_NO_RETRY | ANDROID_RESOLV_NO_CACHE_STORE);
  if (descriptor < 0) {
    return false;
  }
  constexpr unsigned kErrors =
      static_cast<unsigned>(POLLERR) | static_cast<unsigned>(POLLHUP) | static_cast<unsigned>(POLLNVAL);
  while (std::chrono::steady_clock::now() < deadline) {
    const auto remaining =
        std::chrono::duration_cast<std::chrono::milliseconds>(deadline - std::chrono::steady_clock::now()).count();
    struct pollfd ready{.fd = descriptor, .events = POLLIN, .revents = 0};
    const int status = poll(&ready, 1, static_cast<int>(std::clamp<std::int64_t>(remaining, 1, 100)));
    if (status < 0 && errno == EINTR) {
      continue;
    }
    if (status < 0 || (static_cast<unsigned>(ready.revents) & kErrors) != 0) {
      break;
    }
    if (status > 0 && (static_cast<unsigned>(ready.revents) & static_cast<unsigned>(POLLIN)) != 0) {
      std::array<std::uint8_t, 512> answer{};
      int response_code = -1;
      const int length = android_res_nresult(descriptor, &response_code, answer.data(), answer.size());
      return length >= 0 && response_code == 0;
    }
  }
  android_res_cancel(descriptor);
  return false;
}
}  // namespace rasp::plugins::dns_reporting
