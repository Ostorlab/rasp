/// Mailbox: the one-batch hand-off between the runtime's thread and the plugin's sender.

#include "mailbox.h"

#include <mutex>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "work.h"
#ifdef RASP_DNS_CYCLE_ENABLED
#include "reporting/transport_result.h"
#include "reporting/undelivered_run.h"
#endif

namespace rasp::plugins::dns_reporting {

void Mailbox::put(std::vector<std::string> names) { put_work(Work{.names = std::move(names), .attempt = nullptr}); }
void Mailbox::put_work(Work work) {
  std::optional<Work> dropped;
  {
    const std::scoped_lock lock(mutex_);
    dropped.swap(batch_);
    batch_ = std::move(work);
  }
#ifdef RASP_DNS_CYCLE_ENABLED
  if (dropped.has_value() && dropped->attempt != nullptr) {
    dropped->attempt->finish(reporting::LegacyDnsState::kReplaced, reporting::TransportResult::kPublicationUnconfirmed);
  }
#endif
  ready_.notify_one();
}

std::vector<std::string> Mailbox::take() { return take_work().names; }
Work Mailbox::take_work() {
  std::unique_lock lock(mutex_);
  ready_.wait(lock, [this] { return batch_.has_value(); });
  Work work = std::move(batch_).value_or(Work{});
  batch_.reset();
  return work;
}

}  // namespace rasp::plugins::dns_reporting
