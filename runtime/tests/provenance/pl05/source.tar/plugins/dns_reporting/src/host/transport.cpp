/// The transport on a development machine: it sends nothing, so every resolve fails and every batch is dropped.

#include "transport.h"

#include <chrono>
#ifdef RASP_DNS_CYCLE_ENABLED
#include "cycle_dns.h"
#endif

#include <string>

namespace rasp::plugins::dns_reporting {

bool resolve(const std::string& /*name*/) noexcept { return false; }
#ifdef RASP_DNS_CYCLE_ENABLED
bool resolve_until(const std::string& /*unused*/, std::chrono::steady_clock::time_point /*unused*/) noexcept {
  return false;
}
#endif

}  // namespace rasp::plugins::dns_reporting
