/// Public polling API, including platform-forwarded descriptor/event declarations.
#pragma once
#include <poll.h>  // IWYU pragma: export
#ifdef __ANDROID__
#include <asm-generic/poll.h>  // IWYU pragma: export
#elifdef __APPLE__
#include <sys/poll.h>  // IWYU pragma: export
#endif
