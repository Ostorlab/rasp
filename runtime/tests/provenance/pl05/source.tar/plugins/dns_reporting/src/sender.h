/// The DNS reporting plugin's sender: its own thread, which resolves the DNS query names of the newest run.

#pragma once

#include <chrono>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "mailbox.h"
#include "work.h"

namespace rasp::plugins::dns_reporting {

/// A function that resolves one DNS name, with the shape of the platform's `resolve`.
using ResolveFunction = bool (*)(const std::string& name) noexcept;

/// Everything the sender's thread needs. It lives as long as the process once the thread has started.
struct Sender {
  /// The function that resolves a DNS name: the platform's `resolve`.
  ResolveFunction resolve = nullptr;
  /// Authorized work uses the existing bounded resolver instead of the standalone legacy OS call.
  bool (*resolve_bounded)(const std::string&, std::chrono::steady_clock::time_point) noexcept = nullptr;
  /// The batch of DNS names waiting to be resolved.
  Mailbox mailbox;
  /// Serializes Context take/retain/enqueue only; the network worker never borrows the Context.
  std::mutex handoff;
};

/// Resolves all the DNS query names of one batch. Stops on the first failure.
///
/// @param sender The sender.
/// @param names The DNS names to resolve.
/// @return `true` when every name resolved.
[[nodiscard]] bool deliver(const Sender& sender, const std::vector<std::string>& names);
/// Actual authorized batch boundary; callers must retain the same snapshot through dequeue and every query.
[[nodiscard]] bool deliver_work(const Sender& sender, const Work& work);

/// Starts the sender's thread: a detached thread with a 512 KiB stack that takes each batch from the mailbox and
/// delivers it, until the process exits.
///
/// @param sender The sender. It must live as long as the process.
/// @return Whether the thread started.
[[nodiscard]] bool start_sender(Sender& sender);

}  // namespace rasp::plugins::dns_reporting
