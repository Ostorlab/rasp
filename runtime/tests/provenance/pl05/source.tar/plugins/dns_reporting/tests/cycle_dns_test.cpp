#include "cycle_dns.h"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <fstream>
#include <gtest/gtest.h>
#include <iterator>
#include <string>
#include <vector>

#include "cbor.h"
#include "collection_authority.h"
#include "cycle_payload.h"
#include "dns_frame.h"

namespace rasp::plugins::dns_reporting {
TEST(CycleDns, encode_whenBackendFixture_preservesV2PayloadAndOriginalIdentity) {
  std::ifstream input(std::string(RASP_CYCLE_FIXTURES) + "/producer-canonical.json");
  std::string canonical((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
  while (!canonical.empty() && canonical.back() == '\n') {
    canonical.pop_back();
  }
  const auto payload = reporting::restore_cycle(canonical);
  ASSERT_TRUE(payload.has_value());
  const auto binding = reporting::collection_authority({
      .endpoint = "https://adr.example/apis/graphql",
      .policy = "default",
      .zone = "rsp.example.com",
      .dns_policy = "default",
  });
  ASSERT_TRUE(binding.has_value());
  const auto names = build_cycle_report(*payload, *binding, {0x9a, 0x3c, 0x51, 0xe7}, 7560);
  ASSERT_FALSE(names.empty());
  EXPECT_TRUE(names[0].ends_with(".rsp.example.com"));
  EXPECT_EQ(payload->canonical, canonical);
}
TEST(CycleDns, encode_whenAuthorityHasNoDns_emitsNoQueries) {
  reporting::PreparedCycle const payload;
  const auto binding = reporting::collection_authority(
      {.endpoint = "https://adr.example/", .policy = "default", .zone = "", .dns_policy = "default"});
  ASSERT_TRUE(binding.has_value());
  EXPECT_TRUE(build_cycle_report(payload, *binding, {}, 0).empty());
}
TEST(CycleDns, encode_whenTextReachesFrameBoundary_accountsForActualCborHead) {
  const std::array<std::uint8_t, 16> identity{};
  const std::array<std::uint8_t, 4> message{};
  for (const std::size_t size : {30047U, 30048U}) {
    const auto encoded = encode_cycle_text(std::string(size, 'a'));
    ASSERT_EQ(encoded.size(), size + 3);
    const auto frame = write_payload(identity, 1, identity, encoded, message, 2);
    EXPECT_EQ(frame.size(), size + 42);
  }
  for (const std::size_t size : {30049U, 30050U, 30051U, 30052U}) {
    const auto encoded = encode_cycle_text(std::string(size, 'a'));
    EXPECT_TRUE(encoded.empty());
    EXPECT_TRUE(write_payload(identity, 1, identity, encoded, message, 2).empty());
  }
}
TEST(CycleDns, encode_whenCborLengthHeadChanges_preservesShortestHeadAndText) {
  for (const std::size_t size : {0U, 23U, 24U, 255U, 256U}) {
    const std::string text(size, 'a');
    const auto encoded = encode_cycle_text(text);
    const std::size_t head = size < 24 ? 1 : 2 + static_cast<std::size_t>(size >= 256);
    ASSERT_EQ(encoded.size(), head + size);
    EXPECT_TRUE(std::equal(text.begin(), text.end(), encoded.begin() + static_cast<std::ptrdiff_t>(head)));
  }
}
TEST(CycleDns, frame_whenV2CborIsEmptyOrExceedsFrameBudget_rejectsWithoutChangingLegacyVersion) {
  const std::array<std::uint8_t, 16> identity{};
  const std::array<std::uint8_t, 4> message{};
  EXPECT_TRUE(write_payload(identity, 1, identity, {}, message, 2).empty());
  EXPECT_FALSE(write_payload(identity, 1, identity, {}, message, 1).empty());
  EXPECT_TRUE(write_payload(identity, 1, identity, std::vector<std::uint8_t>(30052, 0), message, 2).empty());
}
}  // namespace rasp::plugins::dns_reporting
