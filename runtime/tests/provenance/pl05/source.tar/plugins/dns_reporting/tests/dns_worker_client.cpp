/// Actual process-lifetime queues/consumer/frame builders; only scheduling, UTC and OS resolver are external seams.
#include <chrono>
#include <condition_variable>
#include <cstddef>
#include <fstream>
#include <iostream>
#include <iterator>
#include <memory>
#include <mutex>
#include <span>
#include <string>
#include <string_view>
#include <thread>
#include <utility>
#include <vector>

#include "collection_authority.h"
#include "config.h"
#include "cycle_dns.h"
#include "cycle_payload.h"
#include "dns_worker_fixture.h"
#include "fixture_io.h"
#include "json.h"
#include "rasp/config.h"
#include "rasp/context.h"
#include "rasp/cycle.h"
#include "rasp/observation.h"
#include "rasp/plugin.h"
#include "reporting/cancellation.h"
#include "reporting/delivery.h"
#include "reporting/fallback_authorization.h"
#include "reporting/transport_result.h"
#include "reporting/undelivered_run.h"
#include "security_profile.h"
#include "sender.h"
#include "transport.h"
namespace rasp::plugins::dns_reporting {
extern const Plugin kPlugin;
namespace {
constexpr auto kWait = std::chrono::seconds(10);
struct State {
  std::mutex mutex;
  std::condition_variable changed;
  bool release_dequeue = false;
  bool block_query = false;
  bool release_query = false;
  bool fixture_ok = true;
  bool query_returned_true = false;
  unsigned fail_query = 0;
  unsigned entered = 0;
  unsigned completed = 0;
  std::vector<std::string> names;
  std::unique_ptr<Sender> raw_sender;
};
State& state() {
  static State* const kState = std::make_unique<State>().release();
  return *kState;
}
template <typename Condition>
bool await(Condition condition) {
  auto& current = state();
  std::unique_lock lock(current.mutex);
  return current.changed.wait_for(lock, kWait, condition);
}
void release_dequeue() {
  const std::scoped_lock lock(state().mutex);
  state().release_dequeue = true;
  state().changed.notify_all();
}
bool query(const std::string& name, std::chrono::steady_clock::time_point deadline) {
  auto& current = state();
  std::unique_lock lock(current.mutex);
  current.fixture_ok = current.fixture_ok && deadline > std::chrono::steady_clock::now() &&
                       deadline <= std::chrono::steady_clock::now() + std::chrono::seconds(3);
  current.names.push_back(name);
  current.changed.notify_all();
  if (current.block_query && current.names.size() == 1) {
    current.fixture_ok =
        current.changed.wait_for(lock, kWait, [&current] { return current.release_query; }) && current.fixture_ok;
  }
  const bool succeeded = current.fail_query == 0 || current.names.size() != current.fail_query;
  current.query_returned_true = current.query_returned_true || succeeded;
  return succeeded;
}
reporting::Config config() {
  const auto now = reporting::security_time();
  return {
      .endpoint = "https://collector.example/",
      .build_id = std::string(64, 'b'),
      .security_profile =
          std::string(
              R"({"version":1,"mode":"leaf-spki-sha256","host":"collector.example","port":443,"pins":{"primary":{"key_algorithm":"rsa-2048","value":"sha256//AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="},"backup":{"key_algorithm":"ec-p256","value":"sha256//AQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQE="}},"validity":{"not_before":)") +
          std::to_string(now - 60) + ",\"not_after\":" + std::to_string(now + 3600) + "}}",
  };
}
std::shared_ptr<const reporting::FallbackAuthorization> authorize(const reporting::Config& settings,
                                                                  const reporting::CancellationSource& stop) {
  const auto profile = reporting::parse_security_profile(
      {.profile = settings.security_profile.value_or(""), .endpoint = settings.endpoint});
  if (!profile.has_value()) {
    return nullptr;
  }
  const auto descriptor = reporting::security_descriptor(*profile);
  if (!descriptor.has_value()) {
    return nullptr;
  }
  const auto binding = reporting::collection_authority({
      .endpoint = settings.endpoint,
      .policy = settings.collection_policy,
      .zone = RASP_DNS_REPORTING_ZONE,
      .dns_policy = RASP_DNS_REPORTING_COLLECTION_POLICY,
      .security = *descriptor,
  });
  return binding.has_value()
             ? std::make_shared<const reporting::FallbackAuthorization>(settings, *binding, stop.share())
             : nullptr;
}
std::shared_ptr<const reporting::PreparedCycle> payload() {
  std::ifstream input(std::string(RASP_CYCLE_FIXTURES) + "/producer-canonical.json");
  std::string canonical((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
  while (!canonical.empty() && canonical.back() == '\n') {
    canonical.pop_back();
  }
  auto prepared = reporting::restore_cycle(canonical);
  return prepared.has_value() ? std::make_shared<const reporting::PreparedCycle>(std::move(*prepared)) : nullptr;
}
void fault(std::string_view scenario, const reporting::CancellationSource& stop) {
  if (scenario.contains("expiry")) {
    reporting_test_advance_clock(7200);
  } else if (scenario.contains("unavailable")) {
    reporting_test_unavailable_clock();
  } else if (scenario.contains("cancel")) {
    stop.request();
  }
}
void initialize(Context& context) {
  kPlugin.init(rasp::Config{.build_id = std::string(64, 'b'), .install_id = "0f8e5b8e-6c1a-4b7e-9d3a-2a4c5e6f7a8b"},
               context);
}
std::vector<Observation> legacy_run(std::string_view signal = "test.dns") {
  return {observed(signal, "fixture", std::string(4000, 'a'))};
}
bool consume_legacy(Context& context, const std::shared_ptr<const reporting::FallbackAuthorization>& authorization,
                    std::string_view signal = "test.dns") {
  context.put(reporting::kAuthorizedUndeliveredRun, reporting::AuthorizedUndeliveredRun{
                                                        .observations = legacy_run(signal),
                                                        .authorization = authorization,
                                                        .https_result = reporting::TransportResult::kConnectFailed,
                                                    });
  kPlugin.on_observations({}, context);
  return !context.get(reporting::kAuthorizedUndeliveredRun).has_value();
}
int replace_legacy(Context& context, const reporting::Config& settings,
                   const std::shared_ptr<const reporting::FallbackAuthorization>& authorization,
                   const reporting::CancellationSource& stop, bool concurrent) {
  auto& current = state();
  current.block_query = concurrent;
  if (!consume_legacy(context, authorization, "test.first") || !await([&current] { return current.entered > 0; })) {
    return 20;
  }
  auto first = context.get(reporting::kLegacyDnsAttempt).value_or(nullptr);
  if (first == nullptr) {
    return 21;
  }
  const auto next_stop = reporting::CancellationSource::create();
  const auto next_grant = authorize(settings, next_stop);
  if (concurrent) {
    release_dequeue();
    if (!await([&current] { return current.names.size() == 1; })) {
      return 22;
    }
    context.put(reporting::kAuthorizedUndeliveredRun, reporting::AuthorizedUndeliveredRun{
                                                          .observations = legacy_run("test.second"),
                                                          .authorization = next_grant,
                                                          .https_result = reporting::TransportResult::kConnectFailed,
                                                      });
    // Two real callbacks race for one envelope while the real worker is in its first OS query.
    std::thread producer([&context] { kPlugin.on_observations({}, context); });
    std::thread other([&context] { kPlugin.on_observations({}, context); });
    producer.join();
    other.join();
  } else if (!consume_legacy(context, next_grant, "test.second")) {
    return 23;
  }
  const auto second = context.get(reporting::kLegacyDnsAttempt).value_or(nullptr);
  const auto* first_original = first->original();
  const auto* second_original = second != nullptr ? second->original() : nullptr;
  if (second == first || first_original == nullptr || second_original == nullptr ||
      first_original->observations != legacy_run("test.first") || first_original->authorization != authorization ||
      second_original->observations != legacy_run("test.second") || second_original->authorization != next_grant ||
      context.get(reporting::kAuthorizedUndeliveredRun).has_value()) {
    return 24;
  }
  if (concurrent) {
    stop.request();
    const std::scoped_lock lock(current.mutex);
    current.release_query = true;
    current.changed.notify_all();
  } else {
    const auto replaced = first->health();
    if (replaced.state != reporting::LegacyDnsState::kReplaced || replaced.queries_started != 0) {
      return 25;
    }
    const std::weak_ptr<reporting::LegacyDnsAttempt> released = first;
    first.reset();
    if (!released.expired()) {
      return 26;
    }
    release_dequeue();
  }
  if (!await([&current, concurrent] { return current.completed >= (concurrent ? 2U : 1U); })) {
    return 27;
  }
  const auto final = second->health();
  if (context.get(reporting::kLegacyDnsAttempt).value_or(nullptr) != second ||
      final.state != reporting::LegacyDnsState::kQueriesFinished ||
      final.reason != reporting::TransportResult::kPublicationUnconfirmed || final.queries_completed < 2 ||
      final.queries_started != final.queries_completed) {
    return 28;
  }
  if (concurrent) {
    const auto old = first->health();
    if (old.state != reporting::LegacyDnsState::kSuppressed || old.reason != reporting::TransportResult::kCancelled ||
        old.queries_started != 1 || old.queries_completed != 1 ||
        first->original()->observations != legacy_run("test.first")) {
      return 29;
    }
  }
  const std::scoped_lock lock(current.mutex);
  std::cout << "legacy replacement original_evidence_retained=1 concurrent=" << concurrent
            << " resolver_calls=" << current.names.size() << '\n';
  return current.fixture_ok && current.names.size() == final.queries_completed + (concurrent ? 1U : 0U) ? 0 : 30;
}
int run(std::string_view mode, std::string_view scenario) {
  auto& current = state();
  if (scenario == "raw-mailbox") {
    current.raw_sender = std::make_unique<Sender>();
    current.raw_sender->resolve = resolve;
    current.raw_sender->resolve_bounded = resolve_until;
    if (!start_sender(*current.raw_sender)) {
      return 2;
    }
    current.raw_sender->mailbox.put({"raw.fixture.test"});
    if (!await([&current] { return current.entered > 0; })) {
      return 3;
    }
    release_dequeue();
    if (!await([&current] { return current.completed > 0; })) {
      return 4;
    }
    std::cout << "raw_mailbox_resolver_calls=" << current.names.size() << '\n';
    return current.names.empty() ? 0 : 5;
  }
  auto context_owner = std::make_unique<Context>();
  Context& context = *context_owner;
  initialize(context);
  auto settings = config();
  const auto stop = reporting::CancellationSource::create();
  auto authorization = authorize(settings, stop);
  if (authorization == nullptr || authorization->status() != reporting::TransportResult::kPublicationUnconfirmed) {
    std::cerr << "authorization=" << (authorization == nullptr ? -1 : static_cast<int>(authorization->status()))
              << " profile=" << settings.security_profile.value_or("") << " utc=" << reporting::security_time() << "\n";
    return 6;
  }
  const auto prepared = payload();
  if (prepared == nullptr) {
    return 7;
  }
  if (mode == "legacy" && (scenario == "queued-replacement" || scenario == "concurrent-handoff")) {
    return replace_legacy(context, settings, authorization, stop, scenario == "concurrent-handoff");
  }
  if (mode == "legacy" && scenario == "oversize-admission") {
    if (!consume_legacy(context, authorization) || !await([&current] { return current.entered > 0; })) {
      return 31;
    }
    const auto previous = context.get(reporting::kLegacyDnsAttempt).value_or(nullptr);
    context.put(reporting::kAuthorizedUndeliveredRun,
                reporting::AuthorizedUndeliveredRun{
                    .observations =
                        {
                            {
                                .signal = "test.oversize",
                                .source = "fixture",
                                .status = static_cast<Status>(255),
                                .value = std::string(reporting::kMaxRequestSize, 'x'),
                            },
                        },
                    .authorization = authorization,
                });
    kPlugin.on_observations({}, context);
    const auto admission = context.get(reporting::kLegacyDnsAdmission);
    if (previous == nullptr || context.get(reporting::kLegacyDnsAttempt).value_or(nullptr) != previous ||
        !admission.has_value() || admission->state != reporting::LegacyDnsState::kTooLarge ||
        previous->original() == nullptr || previous->original()->observations != legacy_run()) {
      return 32;
    }
    release_dequeue();
    if (!await([&current] { return current.completed > 0; })) {
      return 33;
    }
    const auto health = previous->health();
    const std::scoped_lock lock(current.mutex);
    std::cout << "legacy oversize_admission previous_original_retained=1 resolver_calls=" << current.names.size()
              << '\n';
    return health.state == reporting::LegacyDnsState::kQueriesFinished &&
                   health.queries_started == current.names.size() && health.queries_completed == current.names.size() &&
                   current.fixture_ok && current.names.size() > 1
               ? 0
               : 34;
  }
  if (mode == "legacy" && (scenario == "raw-context" || scenario == "wrong-type" || scenario == "missing")) {
    if (scenario == "raw-context") {
      context.put(reporting::kUndeliveredRun, std::vector<Observation>{observed("test.raw", "fixture", true)});
    } else if (scenario == "wrong-type") {
      context.put(Key<std::vector<Observation>>{reporting::kAuthorizedUndeliveredRun.name},
                  std::vector<Observation>{observed("test.raw", "fixture", true)});
    } else {
      context.put(reporting::kAuthorizedUndeliveredRun, reporting::AuthorizedUndeliveredRun{
                                                            .observations = {observed("test.raw", "fixture", true)},
                                                            .authorization = nullptr,
                                                        });
    }
    kPlugin.on_observations({}, context);
    const bool no_sender = !context.get(Key<Sender*>{"dns_reporting.sender"}).has_value();
    bool retained = context.get(reporting::kAuthorizedUndeliveredRun).has_value();
    if (scenario == "raw-context") {
      retained = context.get(reporting::kUndeliveredRun).has_value();
    } else if (scenario == "wrong-type") {
      retained = context.get(Key<std::vector<Observation>>{reporting::kAuthorizedUndeliveredRun.name}).has_value();
    }
    return no_sender && current.names.empty() && retained ? 0 : 8;
  }
  if (scenario == "consume-expiry") {
    context.put(reporting::kAuthorizedUndeliveredRun, reporting::AuthorizedUndeliveredRun{
                                                          .observations = {observed("test.dns", "fixture", true)},
                                                          .authorization = authorization,
                                                      });
    reporting_test_advance_clock(7200);
    kPlugin.on_observations({}, context);
    return context.get(reporting::kAuthorizedUndeliveredRun).has_value() && current.names.empty() ? 0 : 9;
  }
  const bool between = scenario.starts_with("between") || scenario == "context-destroyed";
  current.block_query = between;
  if (scenario == "resolver-failure") {
    current.fail_query = 1;
  } else if (scenario == "partial-failure") {
    current.fail_query = 2;
  }
  const auto queue = [&](const std::shared_ptr<const reporting::FallbackAuthorization>& grant) {
    if (mode == "legacy") {
      return consume_legacy(context, grant);
    }
    const auto* fallback = reporting::selected_dns_fallback();
    return fallback != nullptr && fallback->enqueue != nullptr && fallback->enqueue(prepared, grant);
  };
  if (scenario == "owner-destroyed") {
    {
      const auto owner = reporting::CancellationSource::create();
      authorization = authorize(settings, owner);
      if (!queue(authorization) || !await([&current] { return current.entered > 0; })) {
        return 10;
      }
    }
  } else {
    if (!queue(authorization) || !await([&current] { return current.entered > 0; })) {
      return 11;
    }
  }
  const auto saved = context.get(reporting::kLegacyDnsAttempt).value_or(nullptr);
  // Verify Config strings are snapshots, not borrowed/reinterpreted current fields.
  settings.endpoint = "https://changed.example/";
  settings.security_profile.reset();
  if (!between) {
    fault(scenario, stop);
  }
  release_dequeue();
  if (between) {
    if (!await([&current] { return current.names.size() == 1; })) {
      return 12;
    }
    fault(scenario, stop);
    if (scenario == "context-destroyed") {
      stop.request();
      context_owner.reset();
    }
    {
      const std::scoped_lock lock(current.mutex);
      current.release_query = true;
      current.changed.notify_all();
    }
  }
  if (!await([&current] { return current.completed > 0; })) {
    return 13;
  }
  const std::scoped_lock lock(current.mutex);
  const bool valid = scenario == "valid";
  if (mode == "legacy") {
    const auto* original = saved != nullptr ? saved->original() : nullptr;
    if (original == nullptr || original->observations != legacy_run() || original->authorization != authorization ||
        original->https_result != reporting::TransportResult::kConnectFailed ||
        (context_owner != nullptr && context.get(reporting::kLegacyDnsAttempt).value_or(nullptr) != saved)) {
      std::cout << "legacy original_evidence_retained=0\n";
      return 15;
    }
    const auto health = saved->health();
    const bool resolver_failure = current.fail_query != 0;
    auto reason = reporting::TransportResult::kCancelled;
    auto disposition = reporting::LegacyDnsState::kSuppressed;
    if (valid) {
      reason = reporting::TransportResult::kPublicationUnconfirmed;
      disposition = reporting::LegacyDnsState::kQueriesFinished;
    } else if (resolver_failure) {
      reason = reporting::TransportResult::kResolutionFailed;
      disposition = reporting::LegacyDnsState::kFailed;
    } else if (scenario.contains("expiry") || scenario.contains("unavailable")) {
      reason = reporting::TransportResult::kProfileNotActive;
    }
    if (health.state != disposition || health.reason != reason || health.queries_started != current.names.size() ||
        health.queries_completed != current.names.size() - (resolver_failure ? 1U : 0U)) {
      return 16;
    }
    std::cout << "legacy original_evidence_retained=1 reason=" << static_cast<unsigned>(health.reason)
              << " queries_started=" << health.queries_started << " queries_completed=" << health.queries_completed
              << '\n';
  }
  auto expected_calls = current.fail_query;
  if (expected_calls == 0 && between) {
    expected_calls = 1;
  }
  const bool count_ok = valid ? current.names.size() > 1 : current.names.size() == expected_calls;
  const bool queries_ok = current.fixture_ok && (!between || current.query_returned_true);
  const auto zone = reporting::authority_zone(authorization->authority());
  bool original = zone.has_value();
  for (const auto& name : current.names) {
    original = original && name.ends_with("." + zone.value_or("invalid"));
  }
  std::cout << mode << ' ' << scenario << " resolver_calls=" << current.names.size()
            << " original_authority=" << original << " fixture_ok=" << queries_ok << '\n';
  return count_ok && queries_ok && original ? 0 : 14;
}
}  // namespace
void fixture_before_dequeue() {
  auto& current = state();
  std::unique_lock lock(current.mutex);
  ++current.entered;
  current.changed.notify_all();
  current.fixture_ok =
      current.changed.wait_for(lock, kWait, [&current] { return current.release_dequeue; }) && current.fixture_ok;
}
void fixture_after_batch() {
  const std::scoped_lock lock(state().mutex);
  ++state().completed;
  state().changed.notify_all();
}
bool resolve(const std::string& name) noexcept {
  return query(name, std::chrono::steady_clock::now() + std::chrono::seconds(2));
}
bool resolve_until(const std::string& name, std::chrono::steady_clock::time_point deadline) noexcept {
  return query(name, deadline);
}
}  // namespace rasp::plugins::dns_reporting
int main(int argc, char** argv) {
  const std::span<char* const> arguments(argv, static_cast<std::size_t>(argc));
  return arguments.size() == 3 ? rasp::plugins::dns_reporting::run(arguments[1], arguments[2]) : 1;
}
