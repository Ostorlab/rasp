# The DNS reporting plugin's tests, which run on a development machine. The plugin's CMakeLists.txt includes this file
# at the end of the runtime's top directory, once the runtime's tests have fetched GoogleTest and enabled the tests.

include(GoogleTest)

foreach(test base32hex cbor dns_frame dns_report dns_reporting mailbox sender)
  add_executable(rasp_dns_reporting_${test}_test ${CMAKE_CURRENT_LIST_DIR}/${test}_test.cpp)
  target_include_directories(rasp_dns_reporting_${test}_test PRIVATE ${CMAKE_CURRENT_LIST_DIR}/../src
    ${CMAKE_CURRENT_LIST_DIR}/../../reporting/include)
  target_link_libraries(rasp_dns_reporting_${test}_test PRIVATE rasp_plugin_dns_reporting rasp_core rasp_warnings
    rasp_language GTest::gtest_main)
  gtest_discover_tests(rasp_dns_reporting_${test}_test)
endforeach()
get_target_property(rasp_dns_test_cycles rasp_plugin_dns_reporting RASP_DNS_CYCLE_ENABLED)
if(rasp_dns_test_cycles)
  get_target_property(rasp_dns_test_zone rasp_plugin_dns_reporting RASP_DNS_REPORTING_ZONE)
  get_target_property(rasp_dns_test_policy rasp_plugin_dns_reporting RASP_DNS_REPORTING_COLLECTION_POLICY)
  target_compile_definitions(rasp_dns_reporting_sender_test PRIVATE RASP_DNS_TEST_PROFILED=1)
  target_compile_definitions(rasp_dns_reporting_dns_reporting_test PRIVATE RASP_DNS_TEST_PROFILED=1
    RASP_TEST_DNS_ZONE="${rasp_dns_test_zone}" RASP_TEST_DNS_POLICY="${rasp_dns_test_policy}")
  target_include_directories(rasp_dns_reporting_dns_reporting_test PRIVATE ${CMAKE_CURRENT_LIST_DIR}/../../reporting/src)
  add_executable(rasp_dns_cycle_test ${CMAKE_CURRENT_LIST_DIR}/cycle_dns_test.cpp)
  target_include_directories(rasp_dns_cycle_test PRIVATE ${CMAKE_CURRENT_LIST_DIR}/../src ${CMAKE_CURRENT_LIST_DIR}/../../reporting/src)
  target_compile_definitions(rasp_dns_cycle_test PRIVATE RASP_CYCLE_FIXTURES="${CMAKE_CURRENT_LIST_DIR}/../../reporting/tests/fixtures")
  target_link_libraries(rasp_dns_cycle_test PRIVATE rasp_plugin_dns_reporting rasp_plugin_reporting rasp_core rasp_warnings rasp_language GTest::gtest_main)
  gtest_discover_tests(rasp_dns_cycle_test)
  add_executable(rasp_cycle_emitter ${CMAKE_CURRENT_LIST_DIR}/../../reporting/tests/cycle_emitter.cpp)
  target_include_directories(rasp_cycle_emitter PRIVATE ${CMAKE_CURRENT_LIST_DIR}/../src ${CMAKE_CURRENT_LIST_DIR}/../../reporting/src)
  target_link_libraries(rasp_cycle_emitter PRIVATE rasp_plugin_dns_reporting rasp_plugin_reporting rasp_core rasp_warnings rasp_language)
  add_executable(rasp_dns_worker_client ${CMAKE_CURRENT_LIST_DIR}/dns_worker_client.cpp
    ${CMAKE_CURRENT_LIST_DIR}/../src/cycle_dns.cpp ${CMAKE_CURRENT_LIST_DIR}/../src/sender.cpp
    ${CMAKE_CURRENT_LIST_DIR}/../../reporting/tests/fixture_io.c)
  target_include_directories(rasp_dns_worker_client PRIVATE ${CMAKE_CURRENT_LIST_DIR}
    ${CMAKE_CURRENT_LIST_DIR}/../src ${CMAKE_CURRENT_LIST_DIR}/../../reporting/src
    ${CMAKE_CURRENT_LIST_DIR}/../../reporting/tests)
  target_compile_definitions(rasp_dns_worker_client PRIVATE RASP_DNS_CYCLE_ENABLED=1 RASP_DNS_WORKER_TEST=1
    RASP_CYCLE_FIXTURES="${CMAKE_CURRENT_LIST_DIR}/../../reporting/tests/fixtures"
    RASP_DNS_REPORTING_ZONE="${rasp_dns_test_zone}"
    RASP_DNS_REPORTING_COLLECTION_POLICY="${rasp_dns_test_policy}")
  target_link_libraries(rasp_dns_worker_client PRIVATE rasp_plugin_dns_reporting rasp_plugin_reporting rasp_core
    rasp_warnings rasp_language rasp_reporting_test_clock)
  foreach(mode cycle legacy)
    foreach(scenario valid dequeue-expiry dequeue-unavailable dequeue-cancel owner-destroyed between-expiry between-cancel)
      add_test(NAME DnsWorker.${mode}.${scenario} COMMAND rasp_dns_worker_client ${mode} ${scenario})
      set_tests_properties(DnsWorker.${mode}.${scenario} PROPERTIES TIMEOUT 30)
    endforeach()
  endforeach()
  foreach(scenario raw-mailbox raw-context wrong-type missing consume-expiry resolver-failure partial-failure context-destroyed queued-replacement concurrent-handoff oversize-admission)
    add_test(NAME DnsWorker.legacy.${scenario} COMMAND rasp_dns_worker_client legacy ${scenario})
    set_tests_properties(DnsWorker.legacy.${scenario} PROPERTIES TIMEOUT 30)
  endforeach()
endif()
