/// Controlled scheduling only, linked into a separate actual-worker test executable.
#pragma once
#include "transport_fixture.h"
namespace rasp::plugins::dns_reporting {
void fixture_before_dequeue();
void fixture_after_batch();
}  // namespace rasp::plugins::dns_reporting
