# rasp-plugins

Ostorlab's plugins for the RASP runtime of [Ostorlab/rasp](https://github.com/Ostorlab/rasp). A plugin is compiled into the runtime (`librasp.so`, `RaspRuntime.framework`) when the runtime is built. It can add checks, and it sees the observations of every pass, through the API in `rasp/plugin.h`.

## Plugins

- `reporting`: retains each original immutable measurement-cycle snapshot through shared ownership while preparing a bounded private outbox record. Its payload stays alive until publication through GraphQL to `-DRASP_REPORTING_ENDPOINT=<https-url>`. Retries preserve the original build, installation, batch, metadata and ordered values. Android and iOS.
- `dns_reporting`: optional DNS-v2 fallback through `-DRASP_DNS_REPORTING_ZONE=<zone>`, using the same immutable cycle. DNS queries leave the HTTPS item pending. Explicit legacy direct-run clients retain DNS-v1 compatibility. Android and iOS.
- `adr_pin`: on each pass, opens a TLS connection to port 443 of the host set with `-DRASP_ADR_PIN_HOST=<host>`, reads the certificate chain the host presents, then stops the handshake without sending anything. It reports two signals, and the server decides what they mean:
  - `mitm.adr_pin` (source `network_framework`): the Subject Public Key Info (SPKI) pin of each certificate, leaf first, at most 10, as `sha256/<base64>`. A pin that differs from the host's real keys means a proxy or an attacker terminated the connection and presented its own certificate.
  - `mitm.adr_trusted` (source `sec_trust`): whether the system trusted the chain. Unknown pins with `true` mean a user-installed, trusted certificate authority is intercepting the connection.

  It probes only on an iPhone for now; elsewhere both signals are `unsupported`. To get a host's expected pins, fetch its chain with `openssl s_client -connect <host>:443 -servername <host> -showcerts </dev/null`. Then, for each PEM block of that output, hash its public key with `openssl x509 -pubkey -noout | openssl pkey -pubin -outform der | openssl dgst -sha256 -binary | base64`. That base64 is the value after the `sha256/` prefix, so `sha256/` plus that value is the pin `mitm.adr_pin` reports for that certificate.

## Build

[docs/building.md](docs/building.md) explains how to test the plugins, and how to build the runtime with the plugins
and a packer with that runtime, for development and for production.

[Durable cycle delivery](docs/durable-delivery.md) documents storage/overflow limits, destination policy binding,
upgrade/restart behavior and diagnostics. [Reporting HTTPS security](docs/transport-security.md) defines the explicit TLS profile, pin rotation, old-profile queue holds and iOS 12 unavailable state. Cycle delivery requires `on_cycle` (the plugin retains the shared snapshot while preparing its immutable payload) and worker-only
`acquire_private_storage` runtime APIs. Source compatibility CI uses the exact reviewed development runtime;
production publication continues to require an explicitly released compatible runtime.

## Plugin config

Each plugin has a `plugin.yml` next to its `CMakeLists.txt`, which the [Publish packer](#publish-the-packer) workflow
reads to build it into the runtime:

```yaml
description: "What the plugin does."
active: true                    # built into the packer of each release, or not
platforms: ["android"]          # the runtimes it is built into: android, ios, or both
settings:                       # the CMake settings it needs, -D<NAME>=<value>
  RASP_REPORTING_ENDPOINT:
    description: "What the setting is."
    value: "https://adr.ostorlab.app/apis/graphql"
  RASP_REPORTING_SECURITY_PROFILE:
    description: "Explicit reporting TLS profile matching the endpoint origin."
    value: '{"host":"adr.ostorlab.app","mode":"system","pins":null,"port":443,"validity":null,"version":1}'
```

Every string is quoted; `active` is `true` or `false`, and `platforms` is a list of `"android"` and `"ios"`.
`description`, `active` and `platforms` are required, and each setting has exactly a `description` and a `value`, and
the plugin's `CMakeLists.txt` must declare each setting as a cache variable (`set(<NAME> ... CACHE ...)`) or an
`option`. The values are written in this repository and compiled into the runtime as they are, so they are the
production ones and none is private. The workflow stops on:

- an unknown field;
- a platform other than `android` and `ios`;
- two active plugins of a platform with the same setting;
- a `plugin.yml` with no `CMakeLists.txt` next to it;
- a plugin name that does not start with `a-z` and continue with `a-z`, `0-9` and `_`;
- a setting name that does not start with `A-Z` and continue with `A-Z`, `0-9` and `_`.

An inactive plugin is checked the same way, but not built. A folder of `plugins/` without a `plugin.yml` is not a plugin
yet, and is ignored. A plugin that gains a platform or a setting, or changes a value, changes only its own files (its
`plugin.yml`, and its CMake for a new platform or setting), in a release of this repository, and never the workflow.

## Publish the packer

The **Publish packer** workflow (`.github/workflows/publish-packer.yml`) builds the packer of the latest Ostorlab/rasp
release with the plugins of a release of this repository compiled into its runtime, and publishes it to the
`rasp-packer` repository of Artifact Registry, where the ADR server installs it from. Ostorlab/rasp is open source and
these plugins are not, so this build lives here and nothing it builds is committed to either repository. The workflow
creates no tag and no release.

It runs when a release of this repository is published: it builds the latest release of Ostorlab/rasp (the one GitHub
marks Latest) with the active plugins of that release's tag compiled into its runtime, and publishes the packer. A run
with no active plugin stops.

The packer and its runtime take the version of the plugins release: `v1.2.0` gives `rasp-packer` 1.2.0, whatever the
Ostorlab/rasp version. A new plugins release must therefore be higher than every packer already published (0.3.0 is the
highest in the registry today), or the ADR server, which installs the highest version, keeps the older one. A new
Ostorlab/rasp release reaches the ADR server only with the next release of this repository. The workflow refuses an
Ostorlab/rasp release whose runtime takes no plugins.

### Runtime capability verification

The **RT05 capability contract** is the schema-1 capability metadata contract: a deterministic capability catalogue,
a native sidecar producer/validator, and packer resource discovery and public result bindings. The selected runtime
release must include this minimum support; it is not inferred from a version string. Until that support is released,
a Latest release that predates it fails with an instruction to release a newer Ostorlab/rasp first. Both repositories'
release commits remain resolved once and reused by every build job.

Each pristine Android library travels with its exact `librasp.so.capabilities.json`; the iOS framework archive keeps
`RaspRuntime.capabilities.json` beside its binary. The publisher verifies:

- Before upload and again after download: deterministic catalogue identity/revision, native SHA-256, platform, ABI and
  OS floor, using the selected runtime's validator.
- After installing the wheel: its exact catalogue, binary, sidecar and stub bytes against the verified staging inputs.
- Through the public packer: returned capability bindings and exact injected Android bytes, plus an iOS config
  round-trip through the installed consumer.

Missing metadata, a foreign catalogue revision (even with a self-consistent hash), corrupt metadata or mismatched bytes
stop publication. The publisher never generates replacement sidecars. Legacy **local** packing still reports unknown
capabilities as RT05 specifies; it cannot satisfy this stricter release contract.

Capability metadata is release provenance inside the trusted distribution. It is not a signature, attestation, proof
of execution or a model of plugin outputs/delivery. A new catalogue needs coordinated producer, packer and backend
support. Native Apple build/import/export/OS-floor checks require the Xcode CI runner; Linux fixture checks do not
establish native iOS build or device behavior.

### Publishing configuration

Publishing needs the tag of the release on `main`, and two repository secrets: `RASP_PACKER_REPOSITORY_URL` (the publish
URL of the `rasp-packer` repository, with or without the final `/`) and `GCP_RASP_PACKER_REGISTRY_WRITER_KEY` (the key
of a Google service account that can write to it). Only the `publish` job reads them, and no other job loads them:
GitHub registers every line of a multi-line secret as a mask and drops any job output that contains a masked line. The
writer key is a JSON file whose first and last lines are `{` and `}`, and the settings outputs contain those characters.
Ostorlab/rasp is public, so the workflow's own token reads its latest release and checks it out. There is no manual run:
to run it again after a failure, use Re-run jobs on the failed run. If an earlier attempt already published the same
wheel, a re-run succeeds without uploading it again.

Its jobs:

1. `version` picks the plugins tag and the latest Ostorlab/rasp release, checks them out, and resolves them to the two
   commits every other job builds from. It reads the `plugin.yml` of each plugin, and checks that the plugins tag is on
   `main`. Its summary lists both releases, the packer version, and the plugins and settings of each platform.
2. `ios-framework` builds and checks `RaspRuntime.framework` on a Mac, with the plugins that list `ios`, verifies its
   capability sidecar, and archives the complete framework.
3. `android-runtime` builds and checks `librasp.so` for arm64-v8a, armeabi-v7a, x86_64 and x86 with the plugins that
   list `android`, stages each verified library/sidecar pair, and builds the stub.
4. `wheel` replaces the runtimes of the Ostorlab/rasp release with both new ones, sets the packer's version, builds its
   wheel, checks that it installs with that version, the framework, the stub and the four libraries, and packs
   `packer/tests/apps/android/InsecureBankv2.aab` with it. Strict pre-wheel and installed-wheel gates refuse unknown
   bindings, compare the exact pristine resources, round-trip iOS config, and compare public Android pack results and
   injected bytes. Installed-wheel regression tests also exercise missing/corrupt/swapped/changed metadata and bytes.
5. `publish` publishes the wheel of the `wheel` job. If that version is already in the repository, it succeeds when the
   file is the same, and stops when it differs.

Its Python steps run the scripts of `scripts/publish_packer/` (reading the plugins, configuring the runtime, setting the
versions, staging and verifying capability resources, and checking the registry), from the plugins release, on Python 3.14
with `uv`. The **Scripts** workflow
(`.github/workflows/scripts.yml`) checks them on every pull request and on `main`: `ruff`, `mypy` in strict mode, and
their tests in `tests/scripts/`. To run the same checks locally:

```
uvx ruff@0.16.10 format --check . && uvx ruff@0.16.10 check .
uvx --with pytest==9.1.1 mypy@2.4.0
RASP_CAPABILITY_SOURCE=/path/to/rasp uvx pytest@9.1.1
```

The native-validator tests use a read-only checkout of approved RT05 commit
`bb5dc352aaa2583a4fe87b55369618047931a922`; only this **test reference** is pinned in the Scripts workflow.
It reads with `RASP_READ_TOKEN` when configured, otherwise the workflow token. No native build is needed for these
tests: fixture bytes and sidecars go through the actual standard-library validator. Without `RASP_CAPABILITY_SOURCE`
those integration tests skip explicitly.

On every pull request and push to main, Scripts CI also builds that pinned runtime for all four Android ABIs. It uses
the release publisher's staging helper and artifact resource layout, then downloads and merges those exact library,
sidecar and compiled-stub outputs into the reference packer. It builds and installs a real wheel before running the
full script suite, including all eight installed-wheel positive/negative cases and the actual public AAB packer/native
dex splitter. Missing fixture variables fail in GitHub Actions. These builds upload test artifacts only and never
publish a package. Linux iOS checks use the checked-in Mach-O config fixture with test-generated metadata; real Apple
build and artifact gates remain in the release workflow.

Installed-wheel tests also run in the publisher's `wheel` job. To run them locally after building and installing a
wheel into a disposable environment:

```
RASP_RELEASE_VENV=/absolute/path/to/venv \
RASP_RELEASE_SOURCE=/absolute/path/to/rasp/packer/src/rasp_packer \
RASP_RELEASE_APP=/absolute/path/to/rasp/packer/tests/apps/android/InsecureBankv2.aab \
uvx pytest@9.1.1 tests/scripts/publish_packer/installed_test.py -q
```

The source resource tree must be the verified pristine tree used to build that wheel. Tests copy the environment once
per module and retain the copied environment's associated distribution metadata. Before and after each case, they
restore the installed package from a hash-verified pristine baseline. They clean up the copy and never mutate the
original install.

Without these variables the installed-wheel tests skip explicitly outside GitHub Actions. Their positive path uses
the installed public packer and native dex splitter, with no consumer mocks.

To publish a packer:

1. If the runtime or the packer changed, release Ostorlab/rasp first, so its release is the latest.
2. Merge the changes of this repository, then create and publish a release `v<version>` on `main`. The workflow
   builds and publishes the packer `<version>`.
3. Release the ADR server, whose image installs the newest `rasp-packer` when it is built, and deploy it, so the build
   worker packs with the new packer.
