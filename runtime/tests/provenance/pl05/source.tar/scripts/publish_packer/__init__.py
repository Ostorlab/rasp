"""The scripts the Publish packer workflow runs: reading the plugins, configuring the runtime, versions and registry."""
