"""Configures the runtime with the plugins and settings of its platform.

    python3 configure.py <preset> <plugins folder> <plugins> <settings> [<extra cmake argument> ...]

<plugins> are the names separated by spaces, and <settings> the JSON list of {"name", "value"} that plugins.py
outputs. Each setting is passed as one -D<name>=<value> argument, so a value is never split or interpreted by a shell.
"""

import json
import pathlib
import subprocess
import sys
from collections import abc

if __name__ == "__main__":
    sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from publish_packer import security


class Error(Exception):
    """Base error of the configuring."""


class InvalidSettingsError(Error):
    """The settings are not the JSON list of {"name", "value"} that plugins.py outputs."""


def cmake_command(
    preset: str,
    plugins_folder: pathlib.Path,
    plugin_names: abc.Sequence[str],
    settings_json: str,
    extra_arguments: abc.Sequence[str],
) -> list[str]:
    """Gives the command that configures the runtime.

    Args:
        preset: The CMake preset of the runtime, such as android or ios.
        plugins_folder: The absolute plugins folder.
        plugin_names: The names of the plugins to compile in.
        settings_json: The JSON list of {"name", "value"} of the CMake settings.
        extra_arguments: More CMake arguments, such as -DANDROID_ABI=x86.

    Returns:
        The cmake command and its arguments.

    Raises:
        InvalidSettingsError: The settings are not a JSON list of {"name", "value"}.
    """
    command = ["cmake", "--preset", preset, *extra_arguments]
    if len(plugin_names) > 0:
        command.append("-DRASP_PLUGINS=" + ";".join(str(plugins_folder / name) for name in plugin_names))
    try:
        settings = json.loads(settings_json)
    except json.JSONDecodeError as error:
        raise InvalidSettingsError("The settings are not JSON") from error
    if not isinstance(settings, list):
        raise InvalidSettingsError("The settings are not a list")
    values: dict[str, str] = {}
    for setting in settings:
        if not isinstance(setting, dict) or set(setting) != {"name", "value"}:
            raise InvalidSettingsError("A setting must contain exactly a string name and value")
        if not isinstance(setting["name"], str) or not isinstance(setting["value"], str) or setting["name"] in values:
            raise InvalidSettingsError("Settings must have unique string names and values")
        values[setting["name"]] = setting["value"]
        command.append(f"-D{setting['name']}={setting['value']}")
    if "reporting" in plugin_names:
        try:
            security.validate(
                values.get("RASP_REPORTING_SECURITY_PROFILE", ""), values.get("RASP_REPORTING_ENDPOINT", "")
            )
        except security.InvalidProfileError as error:
            raise InvalidSettingsError("Invalid reporting TLS profile or endpoint") from error
    return command


def main(argv: abc.Sequence[str]) -> int:
    """Runs cmake to configure the runtime.

    Args:
        argv: The preset, the plugins folder, the plugins, the settings, then any extra CMake arguments.

    Returns:
        cmake's exit code, or 1 when the settings are invalid.
    """
    preset, plugins_folder, plugins_argument, settings_json, *extra_arguments = argv
    plugin_names = plugins_argument.split()
    try:
        command = cmake_command(
            preset, pathlib.Path(plugins_folder).absolute(), plugin_names, settings_json, extra_arguments
        )
    except InvalidSettingsError as error:
        print(error)
        return 1
    print(f"Plugins: {' '.join(plugin_names) if len(plugin_names) > 0 else 'none'}", flush=True)
    return subprocess.run(command, check=False).returncode


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
