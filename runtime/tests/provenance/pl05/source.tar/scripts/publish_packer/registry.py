"""Decides whether the wheel needs publishing, from the rasp-packer simple index of the repository.

    python3 registry.py <index html> <wheel>

It prints `publish` when the index does not list the wheel, and `published` when it lists it with the wheel's
SHA-256, so a re-run after an upload that did go through succeeds. It exits 1 when the index lists the wheel with
other content or without a hash: that version cannot be published again.
"""

import enum
import hashlib
import html
import pathlib
import re
import sys
import urllib.parse
from collections import abc

_HREF = re.compile(r'href="([^"]*)"')


class Error(Exception):
    """Base error of the registry check."""


class ConflictError(Error):
    """The index lists the wheel's name with other content, or without a hash to compare."""


class PublishAction(enum.StrEnum):
    """What the publish job does with the wheel."""

    PUBLISH = "publish"
    PUBLISHED = "published"


def publish_action(index_html: str, wheel: pathlib.Path) -> PublishAction:
    """Compares the wheel with the file of the same name in the index.

    Args:
        index_html: The HTML of the rasp-packer simple index, or anything else when the repository has no such page yet.
        wheel: The wheel to publish.

    Returns:
        PUBLISH when the index does not list the wheel, PUBLISHED when it lists the same content.

    Raises:
        ConflictError: The index lists the wheel with another SHA-256, or with none.
    """
    for href in _HREF.findall(index_html):
        link, _separator, fragment = html.unescape(href).partition("#")
        if urllib.parse.unquote(urllib.parse.urlsplit(link).path.rsplit("/", 1)[-1]) != wheel.name:
            continue
        if not fragment.startswith("sha256="):
            raise ConflictError(
                f"{wheel.name} is already in the repository without a sha256 hash to compare: make a new release of "
                "this repository"
            )
        wheel_sha256 = hashlib.sha256(wheel.read_bytes()).hexdigest()
        if fragment == f"sha256={wheel_sha256}":
            return PublishAction.PUBLISHED
        raise ConflictError(
            f"{wheel.name} is already in the repository with other content: make a new release of this repository"
        )
    return PublishAction.PUBLISH


def main(argv: abc.Sequence[str]) -> int:
    """Prints what to do with the wheel.

    Args:
        argv: The index file and the wheel.

    Returns:
        0 with the action printed, 1 on a conflict.
    """
    index_path, wheel_path = argv
    index_html = pathlib.Path(index_path).read_text(encoding="utf-8", errors="replace")
    try:
        action = publish_action(index_html, pathlib.Path(wheel_path))
    except ConflictError as error:
        print(error, file=sys.stderr)
        return 1
    print(action)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
