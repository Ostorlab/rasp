"""Strict release staging using the selected runtime's standard-library validator.

Never emit or repair metadata here: only the native source build may produce it.
"""

import argparse
import os
import pathlib
import re
import shutil
import subprocess
import sys

ANDROID_ABIS = ("arm64-v8a", "armeabi-v7a", "x86", "x86_64")
SIDECAR_SUFFIX = ".capabilities.json"


class Error(Exception):
    """A release resource cannot satisfy the capability contract."""


def check_runtime(runtime: pathlib.Path) -> None:
    """Require RT05 capability support from the selected released runtime, before building."""
    for relative in (
        "runtime/tools/capabilities.py",
        "runtime/cmake/capabilities.cmake",
        "packer/src/rasp_packer/capabilities.py",
        "packer/src/rasp_packer/checks_manifest.json",
    ):
        if (runtime / relative).is_file() is False:
            raise Error(
                f"Selected runtime lacks capability-bound release support ({relative}); "
                "release a newer Ostorlab/rasp with RT05 schema-1 producer and consumer support first"
            )


def verify_native(runtime: pathlib.Path, binary: pathlib.Path, platform: str, abi: str, settings: str = "[]") -> None:
    """Validate exact pristine digest, catalogue, target, floor and deterministic encoding."""
    check_runtime(runtime)
    if platform == "android" and abi in ANDROID_ABIS:
        floor = "31"
    elif platform == "ios" and abi == "arm64":
        floor = "12.0"
    else:
        raise Error(f"Unsupported release target: {platform}/{abi}")
    sidecar = binary.with_name(binary.name + SIDECAR_SUFFIX)
    if sidecar.is_file() is False:
        raise Error(f"Release artifact has missing capability sidecar: {sidecar}; unknown releases cannot publish")
    result = subprocess.run(
        [sys.executable, str(runtime / "runtime/tools/capabilities.py"), "verify", str(binary), platform, abi, floor],
        capture_output=True,
        text=True,
        errors="replace",
        check=False,
    )
    if result.returncode != 0:
        # The terminal exception carries the reason; omit traceback frames, source text and stdout.
        reason = result.stderr.strip().rsplit("\n", 1)[-1]
        # Duplicate keys are arbitrary sidecar input, not safe diagnostic text.
        if "InvalidRuntimeError: duplicate manifest key:" in result.stderr:
            reason = "InvalidRuntimeError: duplicate manifest key: [redacted]"
        for name, value in os.environ.items():
            if len(value) >= 4 and re.search(r"TOKEN|PASSWORD|SECRET|CREDENTIAL|KEY", name, re.IGNORECASE) is not None:
                reason = reason.replace(value, "[redacted]")
        reason = "".join(character if character.isprintable() else "?" for character in reason)
        reason = reason[:1024] if reason != "" else "without diagnostics"
        raise Error(f"Native capability validator failed (status {result.returncode}): {reason}")
    verify_profile(binary, platform, settings)


def verify_profile(binary: pathlib.Path, platform: str, settings: str) -> None:
    """Check the native marker against intended settings, after exact capability digest validation."""
    result = subprocess.run(
        [
            sys.executable,
            str(pathlib.Path(__file__).with_name("security.py")),
            "verify",
            str(binary),
            platform,
            settings,
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise Error("Native reporting profile/provenance does not match intended settings")


def stage_android(
    runtime: pathlib.Path, binary: pathlib.Path, abi: str, destination: pathlib.Path, settings: str = "[]"
) -> None:
    """Copy the verified exact library/sidecar pair into the artifact upload tree."""
    verify_native(runtime, binary, "android", abi, settings)
    target = destination / "lib" / abi / "librasp.so"
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(binary, target)
    shutil.copyfile(binary.with_name(binary.name + SIDECAR_SUFFIX), target.with_name(target.name + SIDECAR_SUFFIX))
    verify_native(runtime, target, "android", abi, settings)


def verify_resources(
    runtime: pathlib.Path, package: pathlib.Path, android_settings: str = "[]", ios_settings: str = "[]"
) -> None:
    """Check the complete downloaded resource tree before it becomes a wheel."""
    android = package / "android/resources"
    actual = sorted(path.name for path in (android / "lib").iterdir() if path.is_dir() is True)
    if actual != list(ANDROID_ABIS):
        raise Error(f"Expected four release Android ABIs {ANDROID_ABIS}, found {actual}")
    if (android / "stub.dex").stat().st_size == 0:
        raise Error("Release stub.dex is empty")
    for abi in ANDROID_ABIS:
        verify_native(runtime, android / "lib" / abi / "librasp.so", "android", abi, android_settings)
    verify_native(runtime, package / "ios/resources/RaspRuntime.framework/RaspRuntime", "ios", "arm64", ios_settings)


def main() -> int:
    """Run the release support, staging or validation step requested by the workflow."""
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="action", required=True)
    support = commands.add_parser("check-runtime")
    support.add_argument("runtime", type=pathlib.Path)
    stage = commands.add_parser("stage-android")
    stage.add_argument("runtime", type=pathlib.Path)
    stage.add_argument("binary", type=pathlib.Path)
    stage.add_argument("abi")
    stage.add_argument("destination", type=pathlib.Path)
    stage.add_argument("--settings", default="[]")
    native = commands.add_parser("verify-native")
    native.add_argument("runtime", type=pathlib.Path)
    native.add_argument("binary", type=pathlib.Path)
    native.add_argument("platform", choices=("android", "ios"))
    native.add_argument("abi")
    native.add_argument("--settings", default="[]")
    resources = commands.add_parser("verify-resources")
    resources.add_argument("runtime", type=pathlib.Path)
    resources.add_argument("package", type=pathlib.Path)
    resources.add_argument("--android-settings", default="[]")
    resources.add_argument("--ios-settings", default="[]")
    args = parser.parse_args()
    try:
        match args.action:
            case "check-runtime":
                check_runtime(args.runtime)
            case "stage-android":
                stage_android(args.runtime, args.binary, args.abi, args.destination, args.settings)
            case "verify-native":
                verify_native(args.runtime, args.binary, args.platform, args.abi, args.settings)
            case "verify-resources":
                verify_resources(args.runtime, args.package, args.android_settings, args.ios_settings)
    except (Error, OSError) as error:
        print(f"Capability-bound release validation failed: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
