"""Reads the plugin.yml of every plugin and gives the active plugins and settings of each platform.

    python3 plugins.py <plugins folder> <output file> <summary file>

It appends `<platform>_plugins` (the names, separated by spaces) and `<platform>_settings` (a JSON list of
{"name", "value"}) for android and ios to the output file, and a table of them to the summary file. A folder without a
plugin.yml is ignored. Any other mistake in a plugin's config stops it, inactive plugins included.
"""

import dataclasses
import json
import pathlib
import re
import subprocess
import sys
from collections import abc

_PLUGIN_NAME = re.compile(r"[a-z][a-z0-9_]*")
_SETTING_NAME = re.compile(r"[A-Z][A-Z0-9_]*")

PLATFORMS = ("android", "ios")
PLUGIN_FIELDS = frozenset({"description", "active", "platforms", "settings"})
SETTING_FIELDS = frozenset({"description", "value"})


class Error(Exception):
    """Base error of the plugins reading."""


class InvalidPluginError(Error):
    """A plugin's folder or config breaks a rule, and nothing is built."""


@dataclasses.dataclass(frozen=True)
class BuildPlan:
    """What the runtime of each platform is built with.

    Attributes:
        plugins: The names of the active plugins of each platform, in folder order.
        settings: The CMake settings of each platform, by name.
    """

    plugins: dict[str, list[str]]
    settings: dict[str, dict[str, str]]


def _add_plugin(plan: BuildPlan, config_path: pathlib.Path) -> None:
    plugin_name = config_path.parent.name
    if _PLUGIN_NAME.fullmatch(plugin_name) is None:
        raise InvalidPluginError(
            f"The plugin name {plugin_name} does not start with a-z and continue with a-z, 0-9 and _"
        )
    cmake_path = config_path.parent / "CMakeLists.txt"
    if cmake_path.is_file() is False:
        raise InvalidPluginError(f"The plugin {plugin_name} has a plugin.yml but no CMakeLists.txt")
    plugin_config = read_yaml(config_path)
    if not isinstance(plugin_config, dict):
        raise InvalidPluginError(f"{config_path} must be a mapping")
    unknown = set(plugin_config) - PLUGIN_FIELDS
    if len(unknown) > 0:
        raise InvalidPluginError(f"{config_path} has unknown fields: {', '.join(sorted(unknown))}")
    _require_text(plugin_config.get("description"), f"{config_path}: description")
    active = plugin_config.get("active")
    if not isinstance(active, bool):
        raise InvalidPluginError(f"{config_path}: active must be true or false")
    platforms = _read_platforms(plugin_config.get("platforms"), config_path)
    settings = _read_settings(plugin_config.get("settings", {}), config_path, cmake_path)
    if active is False:
        print(f"{plugin_name}: not active, not built")
        return
    for platform in platforms:
        plan.plugins[platform].append(plugin_name)
        for setting, setting_value in settings.items():
            if setting in plan.settings[platform]:
                raise InvalidPluginError(
                    f"{config_path}: settings.{setting}: another active plugin built for {platform} sets it too"
                )
            plan.settings[platform][setting] = setting_value


def _require_text(candidate: object, location: str) -> str:
    if not isinstance(candidate, str) or candidate.strip() == "":
        raise InvalidPluginError(f"{location} must be a non-empty quoted string")
    return candidate


def _read_platforms(raw_platforms: object, config_path: pathlib.Path) -> list[str]:
    if not isinstance(raw_platforms, list) or len(raw_platforms) == 0:
        raise InvalidPluginError(f"{config_path}: platforms must be a list of {' and '.join(PLATFORMS)}")
    for platform in raw_platforms:
        if platform not in PLATFORMS or raw_platforms.count(platform) > 1:
            raise InvalidPluginError(
                f"{config_path}: platforms has {platform!r}, which is not one of {', '.join(PLATFORMS)} once"
            )
    return [str(platform) for platform in raw_platforms]


def _read_settings(raw_settings: object, config_path: pathlib.Path, cmake_path: pathlib.Path) -> dict[str, str]:
    if not isinstance(raw_settings, dict):
        raise InvalidPluginError(f"{config_path}: settings must be a mapping of CMake settings")
    cmake_source = cmake_path.read_text(encoding="utf-8")
    settings: dict[str, str] = {}
    for setting, setting_config in raw_settings.items():
        location = f"{config_path}: settings.{setting}"
        if _SETTING_NAME.fullmatch(setting) is None:
            raise InvalidPluginError(f"{location}: the name must be made of A-Z, 0-9 and _")
        declaration = rf"\b((?i:set)\(\s*{setting}\s[^)]*\bCACHE\b|(?i:option)\(\s*{setting}\s)"
        if re.search(declaration, cmake_source) is None:
            raise InvalidPluginError(f"{location}: {cmake_path} declares no cache variable or option {setting}")
        if not isinstance(setting_config, dict) or set(setting_config) != SETTING_FIELDS:
            raise InvalidPluginError(f"{location} must have exactly a description and a value")
        _require_text(setting_config["description"], f"{location}.description")
        settings[setting] = _require_text(setting_config["value"], f"{location}.value")
    return settings


def _join_or(names: list[str], fallback: str, separator: str = " ") -> str:
    if len(names) == 0:
        return fallback
    return separator.join(names)


def read_yaml(path: pathlib.Path) -> object:
    """Reads a YAML file with yq, which every runner of the workflow has, as the JSON it converts it to.

    Args:
        path: The YAML file.

    Returns:
        The file's value: JSON keys are always strings, whatever the YAML has.

    Raises:
        InvalidPluginError: The file is not valid YAML.
    """
    yq_result = subprocess.run(["yq", "-o=json", ".", str(path)], capture_output=True, text=True, check=False)
    if yq_result.returncode != 0:
        raise InvalidPluginError(f"{path} is not valid YAML: {yq_result.stderr.strip()}")
    converted: object = json.loads(yq_result.stdout)
    return converted


def read_plugins(plugins_folder: pathlib.Path) -> BuildPlan:
    """Reads and checks the plugin.yml of every plugin of the folder.

    Args:
        plugins_folder: The plugins folder, with one folder per plugin.

    Returns:
        The active plugins and settings of each platform.

    Raises:
        InvalidPluginError: A plugin breaks a rule, or no plugin is active.
    """
    plan = BuildPlan(
        plugins={platform: [] for platform in PLATFORMS},
        settings={platform: {} for platform in PLATFORMS},
    )
    for config_path in sorted(plugins_folder.glob("*/plugin.yml")):
        _add_plugin(plan, config_path)
    if all(len(plugin_names) == 0 for plugin_names in plan.plugins.values()):
        raise InvalidPluginError("No plugin is active: set active: true in the plugin.yml of the plugins to build")
    return plan


def write_step_outputs(plan: BuildPlan, output_path: pathlib.Path, summary_path: pathlib.Path) -> None:
    """Appends the plugins and settings of each platform to the step's outputs and its summary.

    Args:
        plan: The active plugins and settings of each platform.
        output_path: The step's output file, GITHUB_OUTPUT.
        summary_path: The step's summary file, GITHUB_STEP_SUMMARY.
    """
    with output_path.open("a", encoding="utf-8") as output_file:
        for platform in PLATFORMS:
            setting_entries = [
                {"name": setting, "value": setting_value} for setting, setting_value in plan.settings[platform].items()
            ]
            output_file.write(f"{platform}_plugins={' '.join(plan.plugins[platform])}\n")
            output_file.write(f"{platform}_settings={json.dumps(setting_entries)}\n")
    with summary_path.open("a", encoding="utf-8") as summary_file:
        summary_file.write("| Platform | Plugins | Settings |\n|---|---|---|\n")
        for platform in PLATFORMS:
            setting_pairs = [f"{setting}={setting_value}" for setting, setting_value in plan.settings[platform].items()]
            plugin_names = _join_or(plan.plugins[platform], "none")
            summary_file.write(f"| {platform} | {plugin_names} | {_join_or(setting_pairs, 'none', ', ')} |\n")


def main(argv: abc.Sequence[str]) -> int:
    """Reads the plugins and writes the outputs.

    Args:
        argv: The plugins folder, the output file and the summary file.

    Returns:
        0 when the plugins are valid, 1 when a plugin breaks a rule.
    """
    plugins_folder, output_path, summary_path = (pathlib.Path(argument) for argument in argv)
    try:
        plan = read_plugins(plugins_folder)
    except InvalidPluginError as error:
        print(error)
        return 1
    write_step_outputs(plan, output_path, summary_path)
    for platform in PLATFORMS:
        print(f"{platform}: {_join_or(plan.plugins[platform], 'no plugin')}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
