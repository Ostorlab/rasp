"""Strict reporting TLS profile validation and native provenance generation."""

from __future__ import annotations

import argparse
import base64
import binascii
import hashlib
import ipaddress
import json
import pathlib
import re
import sys
import time
import urllib.parse
from typing import Any

MAX_PROFILE = 1536
ALGORITHMS = frozenset({"rsa-2048", "rsa-3072", "rsa-4096", "ec-p256", "ec-p384"})
MAGIC = b"RSPTLS1\n"


class InvalidProfileError(ValueError):
    """Profile or provenance is missing, ambiguous or unsupported."""


def _object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise InvalidProfileError("Duplicate profile key")
        result[key] = value
    return result


def _keys(value: Any, names: set[str]) -> bool:
    return isinstance(value, dict) and set(value) == names


def _integer(value: Any) -> bool:
    return type(value) is int


def origin(endpoint: str) -> tuple[str, int]:
    """Return the strict PL03 HTTPS origin; never resolve or normalize a target."""
    if (
        len(endpoint) > 2048
        or endpoint.startswith("https://") is False
        or re.fullmatch(r"[!-~]+", endpoint) is None
        or any(character in endpoint for character in '\\"#')
        or re.search(r"%(?![0-9A-Fa-f]{2})", endpoint) is not None
    ):
        raise InvalidProfileError("Reporting requires an unambiguous HTTPS endpoint")
    parsed = urllib.parse.urlsplit(endpoint)
    authority = parsed.netloc
    parts = authority.split(":")
    host = parts[0].lower()
    if len(parts) > 2 or len(host) > 253 or host == "":
        raise InvalidProfileError("Invalid reporting origin")
    if any(re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label) is None for label in host.split(".")):
        raise InvalidProfileError("Invalid reporting host")
    if re.fullmatch(r"[0-9.]+", host) is not None:
        try:
            if str(ipaddress.IPv4Address(host)) != host:
                raise InvalidProfileError("Ambiguous reporting address")
        except ipaddress.AddressValueError as error:
            raise InvalidProfileError("Ambiguous reporting address") from error
    port = 443
    if len(parts) == 2:
        if re.fullmatch(r"[1-9][0-9]{0,4}", parts[1]) is None or int(parts[1]) > 65535:
            raise InvalidProfileError("Invalid reporting port")
        port = int(parts[1])
    return host, port


def validate(value: str, endpoint: str, now: int | None = None) -> str:
    """Return canonical validated bytes, without echoing untrusted configuration."""
    try:
        if len(value.encode("utf-8")) > MAX_PROFILE:
            raise InvalidProfileError("Reporting profile exceeds its bound")
        profile = json.loads(value, object_pairs_hook=_object)
        if _keys(profile, {"version", "mode", "host", "port", "pins", "validity"}) is False:
            raise InvalidProfileError("Reporting profile fields are invalid")
        host, port = origin(endpoint)
        if (
            _integer(profile["version"]) is False
            or profile["version"] != 1
            or _integer(profile["port"]) is False
            or profile["host"] != host
            or profile["port"] != port
        ):
            raise InvalidProfileError("Reporting profile origin/version mismatch")
        if profile["mode"] == "system":
            if profile["pins"] is not None or profile["validity"] is not None:
                raise InvalidProfileError("System profile must not contain pins or validity")
        elif profile["mode"] == "leaf-spki-sha256":
            pins = profile["pins"]
            validity = profile["validity"]
            if _keys(pins, {"primary", "backup"}) is False or _keys(validity, {"not_before", "not_after"}) is False:
                raise InvalidProfileError("Pinned profile requires primary, backup and finite validity")
            for role in ("primary", "backup"):
                pin = pins[role]
                if (
                    _keys(pin, {"key_algorithm", "value"}) is False
                    or not isinstance(pin["key_algorithm"], str)
                    or pin["key_algorithm"] not in ALGORITHMS
                    or not isinstance(pin["value"], str)
                    or len(pin["value"]) != 52
                    or pin["value"].startswith("sha256//") is False
                ):
                    raise InvalidProfileError("Invalid pin algorithm or encoding")
                digest = base64.b64decode(pin["value"][8:], validate=True)
                if len(digest) != 32 or base64.b64encode(digest).decode("ascii") != pin["value"][8:]:
                    raise InvalidProfileError("Noncanonical SHA256 pin")
            if pins["primary"]["value"] == pins["backup"]["value"]:
                raise InvalidProfileError("Backup pin must be independent")
            start, end = validity["not_before"], validity["not_after"]
            current = int(time.time()) if now is None else now
            if (
                _integer(start) is False
                or _integer(end) is False
                or not 0 <= start < end <= 253402300799
                or end - start > 366 * 86400
                or not start <= current < end
            ):
                raise InvalidProfileError("Reporting pin profile is outside its validity interval")
        else:
            raise InvalidProfileError("Unsupported reporting profile mode")
        canonical = json.dumps(profile, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
        if len(canonical) > MAX_PROFILE:
            raise InvalidProfileError("Reporting profile exceeds its bound")
        return canonical
    except InvalidProfileError:
        raise
    except (ValueError, TypeError, KeyError, UnicodeError, binascii.Error) as error:
        raise InvalidProfileError("Invalid reporting TLS profile") from error


def descriptor(profile: str, platform: str) -> str:
    """Bind the platform's actual trust/proxy/TLS semantics to the profile."""
    if platform not in ("android", "ios"):
        raise InvalidProfileError("Unsupported reporting platform")
    return json.dumps(
        {
            "profile": json.loads(profile),
            "proxy": "android-no-proxy-v1" if platform == "android" else "apple-reject-proxy-before-post-v1",
            "tls": "tls12-fresh-canonical-rsa-ec-spki-v1",
            "trust_store": "android-system-cacerts-path-v1" if platform == "android" else "apple-system-ssl-v1",
        },
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    )


def marker(security: str) -> bytes:
    """Return a bounded, self-checking native marker; the native digest binds its provenance."""
    body = security.encode("ascii")
    return (
        MAGIC + f"{len(body):06d}\n".encode("ascii") + body + b"\n" + hashlib.sha256(body).hexdigest().encode() + b"\n"
    )


def read_marker(binary: bytes) -> str:
    """Require one intact native reporting marker, never a sidecar-only declaration."""
    offset = binary.find(MAGIC)
    if offset < 0 or binary.find(MAGIC, offset + len(MAGIC)) >= 0:
        raise InvalidProfileError("Missing or duplicate reporting provenance")
    offset += len(MAGIC)
    length = binary[offset : offset + 7]
    if re.fullmatch(rb"[0-9]{6}\n", length) is None:
        raise InvalidProfileError("Invalid reporting provenance length")
    size = int(length)
    if size > 2048:
        raise InvalidProfileError("Reporting provenance exceeds bound")
    start = offset + 7
    body = binary[start : start + size]
    expected = marker(body.decode("ascii"))
    if binary[offset - len(MAGIC) : offset - len(MAGIC) + len(expected)] != expected:
        raise InvalidProfileError("Reporting provenance digest mismatch")
    return body.decode("ascii")


def generate(profile: str, endpoint: str, platform: str, destination: pathlib.Path) -> None:
    """Generate C++ literals from validated bytes; raw settings never become source syntax."""
    canonical = validate(profile, endpoint)
    security = descriptor(canonical, platform)

    provenance = marker(security)
    destination.write_text(
        "#pragma once\n#include <array>\n#include <string_view>\nnamespace rasp::plugins::reporting {\n"
        + 'inline constexpr std::string_view kCompiledSecurityProfile = R"RSPSEC('
        + canonical
        + ')RSPSEC";\n'
        + '#ifdef __APPLE__\n__attribute__((used,section("__TEXT,__rasp_tls")))\n'
        + '#else\n__attribute__((used,retain,section(".rasp_tls")))\n#endif\n'
        + f"inline const std::array<char, {len(provenance)}> kReportingSecurityProvenance = {{"
        + ",".join(str(byte) for byte in provenance)
        + "};\n}\n",
        encoding="ascii",
    )


def verify_native_profile(binary: bytes, platform: str, settings: str) -> None:
    """Bind native reporting provenance to the intended publisher settings."""
    if b"RSPTLS_TEST_ONLY_V1" in binary:
        raise InvalidProfileError("Test transport cannot be published")
    try:
        supplied = json.loads(settings, object_pairs_hook=_object)
        if not isinstance(supplied, list):
            raise InvalidProfileError("Invalid intended settings")
        values: dict[str, str] = {}
        for setting in supplied:
            if (
                _keys(setting, {"name", "value"}) is False
                or not isinstance(setting["name"], str)
                or not isinstance(setting["value"], str)
                or setting["name"] in values
            ):
                raise InvalidProfileError("Invalid intended settings")
            values[setting["name"]] = setting["value"]
        endpoint = values.get("RASP_REPORTING_ENDPOINT")
        if endpoint is None:
            if "RASP_REPORTING_SECURITY_PROFILE" in values:
                raise InvalidProfileError("Incomplete reporting profile intent")
            if MAGIC in binary:
                raise InvalidProfileError("Unexpected reporting plugin without intended settings")
            return
        profile = validate(values.get("RASP_REPORTING_SECURITY_PROFILE", ""), endpoint)
        if read_marker(binary) != descriptor(profile, platform):
            raise InvalidProfileError("Native reporting profile differs from intended settings")
    except (ValueError, TypeError, KeyError, UnicodeError) as error:
        raise InvalidProfileError("Native reporting provenance validation failed") from error


def main() -> int:
    """Validate a CMake file input and emit the private header."""
    if len(sys.argv) > 1 and sys.argv[1] == "verify":
        verification = argparse.ArgumentParser(description="Verify native reporting profile against intended settings")
        verification.add_argument("action")
        verification.add_argument("binary", type=pathlib.Path)
        verification.add_argument("platform", choices=("android", "ios"))
        verification.add_argument("settings")
        args = verification.parse_args()
        try:
            verify_native_profile(args.binary.read_bytes(), args.platform, args.settings)
        except (InvalidProfileError, OSError) as error:
            print("Native reporting provenance validation failed: " + type(error).__name__, file=sys.stderr)
            return 1
        return 0
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("profile", type=pathlib.Path)
    parser.add_argument("endpoint")
    parser.add_argument("platform", choices=("android", "ios"))
    parser.add_argument("destination", type=pathlib.Path)
    args = parser.parse_args()
    try:
        generate(args.profile.read_text(encoding="utf-8"), args.endpoint, args.platform, args.destination)
    except InvalidProfileError as error:
        print(f"Reporting TLS profile rejected: {error}", file=sys.stderr)
        return 1
    except UnicodeError:
        print("Reporting TLS profile rejected: Invalid reporting TLS profile", file=sys.stderr)
        return 1
    except OSError:
        print("Reporting TLS profile rejected: Cannot read or write reporting profile", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
