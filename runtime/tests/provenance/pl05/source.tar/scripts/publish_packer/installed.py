"""Verify the installed release wheel and public AAB consumer against pristine staging inputs.

Run with the wheel's interpreter, outside its source tree. No source path is added to sys.path.
The runtime owns schema validation; these checks only enforce the stricter release contract.
"""

import argparse
import importlib
import importlib.metadata
import pathlib
import subprocess
import sys
import tempfile
import zipfile

ANDROID_ABIS = ("arm64-v8a", "armeabi-v7a", "x86", "x86_64")


def verify_reporting(binary: bytes, platform: str, settings: str) -> None:
    """Verify actual native marker bytes without importing a source runtime into the isolated interpreter."""
    with tempfile.NamedTemporaryFile(prefix="reporting-profile-") as temporary:
        temporary.write(binary)
        temporary.flush()
        result = subprocess.run(
            [
                sys.executable,
                str(pathlib.Path(__file__).with_name("security.py")),
                "verify",
                temporary.name,
                platform,
                settings,
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            raise ValueError("Installed/injected reporting provenance differs from intended settings")


def verify(
    reference: pathlib.Path,
    version: str,
    app: pathlib.Path,
    output: pathlib.Path,
    android_settings: str = "[]",
    ios_settings: str = "[]",
) -> None:
    """Discover installed resources, validate exact bindings and pack a real AAB with them."""
    distribution = importlib.metadata.distribution("rasp-packer")
    if distribution.version != version:
        raise ValueError(f"Installed version {distribution.version} differs from release {version}")
    package = importlib.import_module("rasp_packer")
    if package.__file__ is None:
        raise ValueError("Installed rasp_packer package has no file")
    installed = pathlib.Path(package.__file__).resolve().parent
    if (
        installed != pathlib.Path(str(distribution.locate_file("rasp_packer"))).resolve()
        or installed.is_relative_to(pathlib.Path(sys.prefix).resolve()) is False
        or installed == reference.resolve()
    ):
        raise ValueError(f"Expected the installed wheel under {sys.prefix}, discovered {installed}")
    capabilities = importlib.import_module("rasp_packer.capabilities")
    resources = importlib.import_module("rasp_packer.android.resources")
    ios_resources = importlib.import_module("rasp_packer.ios.resources")
    runtime_binary = importlib.import_module("rasp_packer.ios.runtime_binary")
    runtime_library = importlib.import_module("rasp_packer.android.runtime_library")
    runtime_config = importlib.import_module("rasp_packer.runtime_config")
    packer = importlib.import_module("rasp_packer.packer")
    platforms = importlib.import_module("rasp_packer.platforms")
    if (installed / "checks_manifest.json").read_bytes() != (reference / "checks_manifest.json").read_bytes():
        raise ValueError("Installed catalogue differs from the selected runtime's release catalogue")
    artifacts = resources.load()
    if sorted(artifacts.libraries) != list(ANDROID_ABIS) or sorted(artifacts.manifests) != list(ANDROID_ABIS):
        raise ValueError("Installed release must contain all four Android libraries and capability sidecars")
    if artifacts.stub_dex != (reference / "android/resources/stub.dex").read_bytes():
        raise ValueError("Installed stub differs from staged release bytes")
    for abi in ANDROID_ABIS:
        binary = reference / "android/resources/lib" / abi / "librasp.so"
        pristine = artifacts.libraries[abi]
        sidecar = artifacts.manifests[abi]
        if pristine != binary.read_bytes() or sidecar != capabilities.read_sidecar(binary):
            raise ValueError(f"Installed Android {abi} binary/sidecar differs from staged release bytes")
        capabilities.bind(pristine, sidecar, "android", abi)
        verify_reporting(pristine, "android", android_settings)
        if sidecar != capabilities.emit(pristine, "android", abi, "31"):
            raise ValueError(f"Non-deterministic installed Android {abi} sidecar")
    bindings = resources.bindings(artifacts, ANDROID_ABIS)
    if bindings is None or len(bindings) != 4:
        raise ValueError("Installed Android release capabilities are unknown")
    config = runtime_config.RuntimeConfig(build_id="release-consumer-test", checks=("identity",))
    with ios_resources.framework() as framework:
        binary = framework / "RaspRuntime"
        source = reference / "ios/resources/RaspRuntime.framework"
        pristine = binary.read_bytes()
        sidecar = capabilities.read_sidecar(binary)
        if (
            pristine != (source / "RaspRuntime").read_bytes()
            or sidecar != capabilities.read_sidecar(source / "RaspRuntime")
            or (framework / "Info.plist").read_bytes() != (source / "Info.plist").read_bytes()
        ):
            raise ValueError("Installed iOS framework/sidecar differs from staged release bytes")
        binding = capabilities.bind(pristine, sidecar, "ios", "arm64")
        if binding is None:
            raise ValueError("Installed iOS release capabilities are unknown")
        if sidecar != capabilities.emit(pristine, "ios", "arm64", "12.0"):
            raise ValueError("Non-deterministic installed iOS sidecar")
        configured = runtime_binary.write_config(pristine, config)
        verify_reporting(pristine, "ios", ios_settings)
        verify_reporting(configured, "ios", ios_settings)
        if runtime_binary.read_config(configured) != [config.to_json()] or len(configured) != len(pristine):
            raise ValueError("Installed iOS consumer failed native config round-trip")
    result = packer.pack(
        app=app,
        platform=platforms.Platform.ANDROID,
        output=output,
        build_id=config.build_id,
        checks=[],
    )
    if (
        result.capability_bindings != bindings
        or result.effective_checks != config.checks
        or result.skipped_checks != ()
    ):
        raise ValueError("Public packer lost the installed release's binding or effective checks")
    with zipfile.ZipFile(output) as archive:
        libraries = sorted(
            name for name in archive.namelist() if name.startswith("base/lib/") and name.endswith("/librasp.so")
        )
        if libraries != [f"base/lib/{abi}/librasp.so" for abi in ANDROID_ABIS]:
            raise ValueError(f"Expected all four injected Android release libraries, found {libraries}")
        for abi in ANDROID_ABIS:
            injected = archive.read(f"base/lib/{abi}/librasp.so")
            verify_reporting(injected, "android", android_settings)
            if (
                injected != runtime_library.write_config(artifacts.libraries[abi], config)
                or runtime_library.read_config(injected) != config.to_json()
            ):
                raise ValueError(f"Public packer did not consume the exact bound pristine bytes for {abi}")
    print(f"Verified installed rasp-packer {version}: {capabilities.catalogue_id()}")
    for binding in bindings:
        print(f"{binding.platform}/{binding.abi}: {binding.artifact_sha256}")


def main() -> None:
    """Check a wheel installed into this interpreter's environment, then its public consumer."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reference", type=pathlib.Path, help="Verified rasp/packer/src/rasp_packer resource tree")
    parser.add_argument("version")
    parser.add_argument("app", type=pathlib.Path, help="The release smoke-test AAB")
    parser.add_argument("output", type=pathlib.Path)
    parser.add_argument("--android-settings", default="[]")
    parser.add_argument("--ios-settings", default="[]")
    args = parser.parse_args()
    verify(args.reference, args.version, args.app, args.output, args.android_settings, args.ios_settings)


if __name__ == "__main__":
    main()
