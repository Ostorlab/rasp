"""Gives the runtime and the packer of the Ostorlab/rasp release the version of the plugins release.

python3 versions.py runtime <runtime/CMakeLists.txt> <version>
python3 versions.py packer <packer/pyproject.toml> <version>
"""

import pathlib
import re
import sys
from collections import abc

_RUNTIME_VERSION = re.compile(r"(?m)^(project\(rasp_runtime VERSION )[0-9.]+( )")
_PACKER_VERSION = re.compile(r'(?m)^version = "[^"]*"$')


class Error(Exception):
    """Base error of the versions."""


class MissingVersionError(Error):
    """The file has no version line to replace."""


def set_runtime_version(path: pathlib.Path, version: str) -> None:
    """Replaces the version of the runtime's `project(rasp_runtime VERSION ...)`.

    Args:
        path: The runtime's CMakeLists.txt.
        version: The new version, such as 1.2.0.

    Raises:
        MissingVersionError: The file has no `project(rasp_runtime VERSION ...)`.
    """
    updated, replacements = _RUNTIME_VERSION.subn(rf"\g<1>{version}\g<2>", path.read_text(encoding="utf-8"), count=1)
    if replacements != 1:
        raise MissingVersionError(f"{path} has no project(rasp_runtime VERSION ...)")
    path.write_text(updated, encoding="utf-8")


def set_packer_version(path: pathlib.Path, version: str) -> None:
    """Replaces the first `version = "..."` line of the packer's pyproject.toml, the one of [project].

    Args:
        path: The packer's pyproject.toml.
        version: The new version, such as 1.2.0.

    Raises:
        MissingVersionError: The file has no `version = "..."` line.
    """
    updated, replacements = _PACKER_VERSION.subn(f'version = "{version}"', path.read_text(encoding="utf-8"), count=1)
    if replacements != 1:
        raise MissingVersionError(f"{path} has no version line")
    path.write_text(updated, encoding="utf-8")


def main(argv: abc.Sequence[str]) -> int:
    """Sets the version of the runtime or of the packer.

    Args:
        argv: runtime or packer, the file, and the version.

    Returns:
        0 when the version is set, 1 when the file has no version or the command is unknown.
    """
    target, file_path, version = argv
    version_setters = {"runtime": set_runtime_version, "packer": set_packer_version}
    if target not in version_setters:
        print(f"Unknown command {target!r}: use runtime or packer")
        return 1
    try:
        version_setters[target](pathlib.Path(file_path), version)
    except MissingVersionError as error:
        print(error)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
