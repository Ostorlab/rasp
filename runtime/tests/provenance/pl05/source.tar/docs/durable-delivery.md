# Durable measurement-cycle delivery

Select `reporting` to publish actual runtime `on_cycle` snapshots. Select `dns_reporting` as an optional fallback.
Selection remains opt-in through the runtime's plugin list. Cycle transport requires the owning cycle API and the
worker-only private-storage provider; test compatibility is pinned to runtime
`90efbcb285fc682e38aa9894e926e1196ace54e3`. Production publication still selects an explicitly released runtime and
must wait for a compatible release. The test pin does not make an unreleased runtime a production artifact.

```text
┌─────────────────┐    ┌───────────────────────┐    ┌─────────────────────┐
│ owning on_cycle │───►│ four volatile entries │───►│ bounded private disk │
└─────────────────┘    └───────────────────────┘    └──────────┬──────────┘
                                                              ▼
                                                   ┌─────────────────────┐
                                                   │ immutable HTTPS POST│
                                                   └──────┬────────┬─────┘
                                                    fail │        │ queued ack
                                                         ▼        ▼
                                                    DNS-v2    hashed tombstone
                                                    fallback  + exact cleanup
                                                    (pending)
```

Snapshots retain metadata and observations together. A **transport batch UUID** is a nonzero v4 UUID drawn from the platform cryptographic random source (`getentropy` on Android, `SecRandomCopyBytes` on Apple), independent of
the runtime's nullable session/run UUIDs. Canonical producer JSON, ordered typed values, original observed time,
cycle claims and provider installation identity remain fixed across persistence, retry, fallback and safe upgrades.
No startup `Config.install_id`, zero ID, process alias, HOME or temporary-directory fallback supplies a new cycle's
installation identity. The provider pairs its owned directory descriptor with its own nonzero installation identity.
Early Application attachment/protected-storage/entropy failures remain visible as pending/unavailable states and are
retried by the worker. They are not benign check results.

## How does collection authority binding behave across upgrades?

An upgrade preserves the original collection boundary: a record replays only under its original equivalent authority.
A change to scheme, normalized host/port, exact path/query, collection-policy token or transport profile holds the
whole record. Hostname case and an omitted/default port `443` remain the documented normalization equivalences.

`RASP_REPORTING_ENDPOINT` must be HTTPS for all production reporting. Only separately linked loopback transport fixtures permit HTTP. [Transport security](transport-security.md) defines the explicit profile and v2 authority, including holds for every v1 record and changed profiles. Two bounded policy settings default to the literal string `default`:

- `RASP_REPORTING_COLLECTION_POLICY`
- `RASP_DNS_REPORTING_COLLECTION_POLICY`

A **collection-policy token** is a 1..64-byte `[A-Za-z0-9._-]+` value. Preserve it across unchanged-policy upgrades; rotate it when collector
purpose/account/policy changes without changing its URL/zone. A token is a local declaration, not server attestation.
DNS/tenant reassignment behind unchanged configuration cannot be detected by this protocol.

Each record stores a separately hashed local authority object outside the backend producer digest (the SHA256 of
canonical JSON containing the normalized producer identity, build, observation time, cycle and ordered signals;
transport decorations are excluded). HTTPS authority
follows these rules:

- Equality includes scheme, lowercase DNS host or canonical IPv4, effective port, exact emitted path/query,
  collection-policy token and the closed system-trust/no-auth/no-redirect cycle-v2 transport policy.
- Host case and an absent or default port 443 are equivalent.
- Paths, query order, trailing slashes, percent escapes, empty query markers, ports, aliases and policies are not
  folded together.
- Fragment/userinfo/whitespace/backslash/invalid escapes, ambiguous numeric hosts, trailing root dots, IPv6 literals
  and IDNA are unavailable in this cycle endpoint parser.
- Network resolution never determines authority equivalence. The real HTTP request target is set explicitly;
  redirects and proxies are disabled.

Replay and upgrade behavior preserves the original collection boundary:

- A validated old-build record may drain through unchanged authority using its original build/install/UUID/body.
- Changed HTTPS authority holds the entire record.
- DNS additionally requires its original matching full zone and both DNS policies. A changed zone does not receive
  old evidence, and originally absent DNS is not added to an old item.
- Returning to original authority resumes eligible retries after full recovered backoff.
- Provider identity/directory changes freeze the queue rather than rebind it. Unknown versions remain held.
- Same-UID compromised code is outside this capability's protection. SHA256 detects corruption; it does not
  authenticate the record.

## What are the storage bounds and crash guarantees?

| Resource | Bound |
|---|---|
| Volatile admission | Four owning snapshots; reject newest on full/contention |
| Private records | 32 fixed slots, 4 MiB combined record bytes; no eviction |
| Producer/cycle/request | 192 KiB canonical producer / 128 KiB cycle / 256 KiB GraphQL request |
| Each record | 128-byte header + ≤ 4,096 authority bytes + ≤ 196,608 producer bytes; 200,832 bytes total |
| Each retry log | 88-byte binding header + 0..16 stage markers + optional 40-byte hashed acknowledgement; 144 bytes total |
| Owned logical file bytes | ≤ 4,400,000, including one publication temporary; filesystem overhead is additional |
| DNS-v2 | ≤ 30,090 frame bytes: 35-byte header + CBOR text + 4-byte CRC; ≤ 255 chunks; no truncation/downgrade |

The DNS-v2 CBOR budget is 30,051 bytes, including the text head. The maximum JSON text is 30,048 bytes with its
3-byte CBOR head. Larger whole batches remain pending for HTTPS; the encoder and frame builder enforce the same
full-frame budget.

The fixed `cycle_outbox_v1` child is 0700; regular files are 0600. All operations are descriptor-relative with
no-follow/nonblocking/type/owner/inode/link/size checks. Queue and sender locks use nonblocking flock. Publication
uses exclusive temporary creation, exact writes, file fsync, atomic no-replace link, verified temporary unlink,
checked close and directory fsync. No network send claims persistence before these succeed. An uncertain result is
reconciled against the same batch/content/token; it does not get a fresh UUID or overwrite another slot.

Known two-link interrupted publication can be recovered. Unknown/corrupt/partial residue is preserved and held;
unsafe files and unexpected names are not blindly replaced or treated as sent. Disk/byte/count pressure keeps older
records and rejects newest admission once four volatile entries are full. A prepared/persisted front is removed
under the short admission mutex before sending, preventing resurrection after acknowledgement. Producers always
use try_lock and never wait for disk, network or that pop.

Retry stage persists before sending and saturates at 16. It is an exact reservation count only below 16 and a lower
bound thereafter, never a terminal failure/exhaustion state or an exact number of network calls. Retries continue
with the same UUID/content at a capped monotonic cadence: 1, 2, 4, ... seconds, capped at 300 s plus nonnegative jitter.
Every sender election/restart waits the full recovered base delay; guessed wall-clock downtime never bypasses it.
At least 1 s separates HTTPS starts. There is no finite lifetime replay horizon or automatic age expiry.

Only a complete bounded 2xx response with exact boolean `data.submitObservations=true` and no errors member can
write a **hashed acknowledgement tombstone**: a 40-byte marker of validated HTTPS publication acknowledgement.
HTTP 204/205, false/null/coerced/malformed/truncated responses,
timeouts and connection failures retain pending data. Tombstone durability precedes exact-record deletion and
directory sync; recovery completes idempotent cleanup. A lost acknowledgement can replay identical bytes. A valid
publish acknowledgement means ingress queued the payload, not durable database ingestion or device attestation.

HTTPS retains 10 s connection, 10 s response and 20 s whole-post settings. DNS-v2 uses cancellable public Android resolver
APIs or Apple's DNS-SD API, with 2 s per name / 30 s per fallback and bounded poll intervals. OS filesystem/IPC/resolver
entry calls have no hard kernel deadline. Production worker state has process lifetime because the runtime has no
unload callback; host shutdown never joins those workers. Real-device availability, transport timing, Apple SDK
behavior and inherited protection/backup policy need platform verification. The provider contract establishes no
encryption, hardware identity or protection against same-UID compromise.

## How is delivery serialized and what diagnostics are exposed?

The frozen reporting-backend compatibility baseline (BE10) covers producer fixtures and wire/decoder behavior in
[Ostorlab/rasp-api](https://github.com/Ostorlab/rasp-api/commit/49674a3552dbe27684fab49c83a5d2865abf7092)
at `49674a3552dbe27684fab49c83a5d2865abf7092`. Exact uint64 strings, signed64 long strings,
UTF8/ASCII limits, four statuses, null/zero distinctions, array order and unknown session/run/time semantics apply.
Narrower wire limits drop entire observations. Native complete/dropped/status counts remain native claims;
`serializationComplete`/`serializationDropped` separately report retained rows omitted from delivery. Even an empty
cycle carries metadata. Unrepresentable metadata is rejected rather than synthesized into a known/healthy cycle.

`reporting/delivery.h` exposes atomic best-effort process diagnostics: volatile/durable/held/policy-held counts,
backoff saturation, admission/serialization loss, attempted transports, publication acknowledgements and explicit
failure/uncertainty. Counters saturate with a lower-bound flag. Totals are not durable across restart or transactionally
coherent across fields. No raw values, authority URLs, paths or DNS names are returned. Execution completion never
becomes database delivery completion or trusted coverage.

## How is durable cycle delivery verified?

Host, ASan and TSan presets exercise the actual serializer, files, worker, registration/real CycleMonitor, ack parser
and DNS encoder. Linux syscall fault tests cover replacement, short/zero writes, ENOSPC, sync/close/link/unlink
failures and process crashes at publication/ack/deletion boundaries. `rasp_cycle_emitter <fresh-output-directory>`
emits real revision 6 monitor/outbox/transport bytes without customer network. Copy
`plugins/reporting/tests/native_backend_test.py` into `rasp/tests/` of a task-owned frozen reporting-backend (BE10) source, set
`PL03_NATIVE_EMITTED` to that output, and run its pytest suite under the shared database lock. This executes actual
GraphQL, UBJSON, DNS reassembly and PostgreSQL event-worker/dedup paths, replacing only external queue publication.
The development transports send nothing. Scripts CI's exact runtime fixture builds include all three plugins before
staging/installing public APK/AAB resources; production runtime selection is unchanged. Apple IPA/device execution
and combined remote CI results must be reported separately from Linux fixtures.
