# Reporting HTTPS security contract

The `reporting` plugin verifies the CA chain and hostname of its own collector connection. An explicit compiled
profile can additionally require a primary or backup leaf SubjectPublicKeyInfo (SPKI) pin. This does not pin customer
application traffic, turn `adr_pin` measurements into enforcement, establish device integrity, or encrypt optional
DNS telemetry.

The owning measurement-cycle, immutable outbox, exact-token acknowledgement and retry rules in
[durable-delivery.md](durable-delivery.md) remain in force. Security profiles are local collection authority, outside
the reporting backend's canonical producer digest. Runtime API compatibility is pinned to the
[Ostorlab/rasp runtime commit](https://github.com/Ostorlab/rasp/commit/90efbcb285fc682e38aa9894e926e1196ace54e3)
`90efbcb285fc682e38aa9894e926e1196ace54e3`.

The frozen reporting-backend compatibility baseline, labeled **BE10**, covers producer fixtures and backend
wire/decoder behavior. It is pinned to the
[Ostorlab/rasp-api backend commit](https://github.com/Ostorlab/rasp-api/commit/49674a3552dbe27684fab49c83a5d2865abf7092)
`49674a3552dbe27684fab49c83a5d2865abf7092`. Production publication still selects a released compatible runtime.

## How do I compile an explicit reporting profile?

Both `RASP_REPORTING_ENDPOINT` and `RASP_REPORTING_SECURITY_PROFILE` are required. Publication configuration in
`plugins/reporting/plugin.yml`, CMake and the native sender validate them together. A missing or invalid pinned
profile never selects a system-only fallback. Debug builds enforce the same trust and HTTPS policy as Release.
Neither a runtime configuration slot, environment variable nor remote response changes the compiled profile.

For endpoint `https://collector.example/ingest`, the system profile is:

```json
{"host":"collector.example","mode":"system","pins":null,"port":443,"validity":null,"version":1}
```

For the same endpoint, the two-pin shape is an object with the required named `primary` and `backup` entries:

```json
{
  "host": "collector.example",
  "mode": "leaf-spki-sha256",
  "pins": {
    "primary": {"key_algorithm": "rsa-2048", "value": "sha256//AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="},
    "backup": {"key_algorithm": "ec-p256", "value": "sha256//AQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQE="}
  },
  "port": 443,
  "validity": {"not_before": 1704067200, "not_after": 1704153600},
  "version": 1
}
```

This is a **structural test fixture**: the two distinct dummy digests represent no provisioned keys, and the fixed
validity window is 2024-01-01T00:00:00Z to 2024-01-02T00:00:00Z. The profile parses at fixture clock `1704110400`.
After the window expires, the profile refuses HTTPS and DNS and the record remains held. Before configuring a real
pinned build, replace both digests/algorithm labels with reviewed independent keys and set a current bounded
`not_before`/`not_after` interval in UTC Unix seconds.
The commands below use the separate system-mode example.

```sh
security_profile='{"host":"collector.example","mode":"system","pins":null,"port":443,"validity":null,"version":1}'
cmake --preset host -DRASP_REPORTING_ENDPOINT=https://collector.example/ingest \
  -DRASP_REPORTING_SECURITY_PROFILE="$security_profile" -DRASP_DNS_REPORTING_ZONE=r.example
cmake --build --preset host --parallel 2
ctest --preset host --parallel 2
```

These are build/test commands; the host fixtures route only to their disposable local servers.

For an iOS Release framework on a Mac, run from `rasp/runtime` with the sibling `rasp-plugins/` checkout
([build requirements](building.md#what-you-need)):

```sh
endpoint=https://collector.example/ingest
# Keep the profile host/port in sync with the endpoint's normalized origin.
security_profile='{"host":"collector.example","mode":"system","pins":null,"port":443,"validity":null,"version":1}'
cmake --preset ios -DRASP_PLUGINS="$PWD/../../rasp-plugins/plugins/reporting" \
  -DRASP_REPORTING_ENDPOINT="$endpoint" -DRASP_REPORTING_SECURITY_PROFILE="$security_profile"
cmake --build --preset ios --parallel 2
```

The `ios` preset builds arm64 with an iOS 12.0 deployment floor. On iOS 12, reporting holds data without connecting
because the required public trust/proxy APIs need iOS 13 or later. Use `ios-dev` for both commands to build Debug
with the same mandatory endpoint/profile pair and verification policy.

The profile has exactly `version`, `mode`, `host`, `port`, `pins` and `validity`. Version is integer 1. Host/port must
match the endpoint's normalized origin. The cycle-endpoint authority accepts strict ASCII DNS names or canonical
IPv4 syntax only; hostname case and an omitted/default 443 are equivalent within that authority. No wildcard, suffix, CNAME, resolver-address, IDNA, trailing-dot or IPv6-literal
equivalence is added. The original exact path/query remains a separate authority field.

| Mode | Required pins and validity |
|---|---|
| `system` | Explicit `pins:null`, `validity:null`; CA and hostname checks remain mandatory |
| `leaf-spki-sha256` | Exactly two independent `primary`/`backup` pin objects, plus finite `validity` |

Each pin object has exactly `key_algorithm` and `value`. Supported public-key algorithms are `rsa-2048`, `rsa-3072`,
`rsa-4096`, `ec-p256`, `ec-p384`. The value is exactly `sha256//` plus canonical padded base64 of 32 digest bytes,
52 ASCII bytes total. The prefix is `sha256//` (curl pin syntax, two slashes), not the single-slash `sha256/` prefix
reported by `adr_pin` for the same SPKI digest; the formats are not interchangeable. The OpenSSL command below
prints the bare base64 digest; prepend `sha256//` when provisioning this profile. Both pins are accepted under the
same CA/hostname checks; backup never means weaker trust.
Duplicate digests, unknown algorithms, filenames, PEM, hex, extra separators, malformed padding and extra pins fail.
The **same matched pin** must have both the correct digest and the actual leaf key algorithm. A self-declared label
cannot authorize another algorithm. This describes the public key, not the certificate's signature algorithm.

A pin hashes the complete canonical SubjectPublicKeyInfo DER, including AlgorithmIdentifier and BIT STRING.
Review the public key's source, algorithm and size before provisioning. This offline command prints its digest:

```sh
openssl x509 -in reviewed-leaf.pem -pubkey -noout |
  openssl pkey -pubin -outform DER |
  openssl dgst -sha256 -binary | openssl base64 -A
```

Provision primary and independent backup keys separately. Do not derive release trust by accepting an unverified
live connection. Public SPKI/hash/algorithm review records belong with the release configuration; private keys do not.

Pinned `validity` has exactly integer UTC Unix seconds `not_before` and `not_after`, with
`0 <= not_before < not_after <= 253402300799`, at most 366 days apart. Publication requires the current time inside
that interval. The native sender checks available UTC before connection and during sending. Expired, future or
unavailable time holds data without HTTPS/DNS; it never removes pins. Certificate validity is independently checked
by TLS even if the pin matches. System wall time is not a trusted hardware clock or a rollback-resistant timestamp.

| Resource | Bound |
|---|---|
| Profile input/canonical JSON | 1,536 bytes; duplicate/unknown keys, coercions and unsupported nesting rejected |
| Pins | Exactly two distinct SHA256 digests, or none for explicit system mode |
| Application-inspected leaf DER | 16,384 bytes maximum; no application chain serialization |
| Public key export / canonical SPKI | 1,024 bytes maximum each; canonical supported RSA/EC forms only |
| Android resolver pool | One process-lifetime multi handle, one active transfer, at most one resolver thread |
| Apple asynchronous trust work | At most one outstanding evaluation across reporting attempts |
| Outbox authority / record / namespace | Existing 4,096 / 200,832 / 4,400,000-byte bounds; no quota increase |

## How does the Android transport verify the collector connection?

The built reporting transport uses vendored **curl 8.23.0 with Mbed TLS 4.2.0**, not the device's curl or Java HTTP
stack. CA peer verification, hostname verification, TLS >=1.2 and HTTPS-only protocols remain enabled. Proxy and
HTTP authentication support are compiled out. Redirects, connection reuse and TLS session reuse are disabled.
The native request uses the original exact request target, including dot segments, percent-escape spelling and an
empty query marker. No Authorization, cookie, client certificate, custom trust path or netrc option is introduced.

Trust store policy `android-system-cacerts-path-v1` names `/system/etc/security/cacerts` explicitly. It does not
claim Java TrustManager, Network Security Config, user-root, revocation or current Conscrypt-store parity. Android
14 introduced an updatable Conscrypt APEX store; changing/combining trust paths requires a separately reviewed
policy/authority change. An unavailable store fails closed. [AOSP Conscrypt](https://source.android.com/docs/core/ota/modular-system/conscrypt)

Pinned mode sets curl's primary/backup hash alternatives and uses a leaf verification callback to enforce the
matched digest/key-algorithm association while preserving Mbed TLS verification flags. Pinning does not replace CA
or hostname verification. Error 90 can also mean extraction failure, so diagnostics say pin verification failed,
not that interception was established. [curl pin semantics](https://curl.se/libcurl/c/CURLOPT_PINNEDPUBLICKEY.html)

The sender polls at bounded intervals and removes a cancelled transfer. Curl's pinned threaded resolver uses a
single retained pool with `CURLMOPT_RESOLVE_THREADS_MAX=1`; cancelled queued jobs are cleared.

A currently running OS resolver call may finish later. The pool owns resolver metadata, not an application request
body. Keeping the pool for the runtime ABI's process lifetime avoids joining that call on every cancellation or
accumulating detached pools.

Fresh easy handles/connections and disabled SSL caching preserve full verification on every attempt. A concurrent
sender returns transport-busy without network/fallback. OS entry calls have no hard real-time guarantee.
[Resolver pool option](https://curl.se/libcurl/c/CURLMOPT_RESOLVE_THREADS_MAX.html)

## How does the Apple transport verify the collector connection?

The sender uses Network.framework TLS and public Security APIs. Its verify block copies the handshake trust
reference, preserves its existing policies, appends an SSL server/hostname policy, and evaluates asynchronously on
its serial verification queue. Only a successful evaluation plus the optional matching pin can complete true. No
BasicX509 replacement, anchor override, trust exception, verify-date override or accept-all recovery is used in
production. Platform network-fetch/revocation policy remains unchanged.
[Public TLS options](https://raw.githubusercontent.com/apple-oss-distributions/Security/main/protocol/SecProtocolOptions.h),
[async evaluation](https://developer.apple.com/documentation/security/sectrustevaluateasyncwitherror(_:_:_:))

For pinned verification on iOS 15/macOS 12 and later, the sender obtains the public chain array, retains only its
index-zero leaf, and releases the array before inspecting that owned certificate. Older supported systems use the
original index-zero accessor with the same independent retention; that branch is excluded when the deployment
minimum already requires the modern API. No complete chain is serialized. The iOS 12 unavailable gate remains.
[Public chain API and availability](https://raw.githubusercontent.com/apple-oss-distributions/Security/main/trust/headers/SecTrust.h)

The bounded leaf parser accepts canonical RSA rsaEncryption/NULL or named P-256/P-384 uncompressed SPKI forms.
The Apple path also checks `SecKey` algorithm/size and reconstructs SPKI from the public export, requiring agreement
with the certificate's canonical SPKI. Raw RSA PKCS#1 or EC X9.63 export is never hashed as SPKI. Unsupported,
noncanonical, truncated, oversized or inconsistent key data fails closed.
[Apple key export formats](https://developer.apple.com/documentation/security/seckeycopyexternalrepresentation(_:_:))

Each verification invocation owns a copied completion block and a one-way completion latch. Timeout/cancellation
completes it false exactly once. The single evaluation slot remains occupied until its actual callback returns;
a late success cannot send, acknowledge, complete twice or revive a terminal request. Its retained state contains
profile/trust information, no complete request body or connection. A stuck evaluation makes later attempts
trust-evaluation-busy rather than creating accumulating work. TLS resumption, tickets, false start and
renegotiation are disabled.

`prefer_no_proxy` is a preference and can permit fallback. Before any HTTP bytes, policy
`apple-reject-proxy-before-post-v1` additionally requires a real establishment report with neither a configured nor
used proxy. Missing/late/unknown evidence and observed path changes reject the attempt. DNS, PAC/control-plane or
TLS handshake traffic can precede this gate; it does not promise zero packets to every intermediary or bypass of
transparent VPNs. [Apple DTS clarification](https://developer.apple.com/forums/thread/828775)

The deployment floor remains **iOS 12.0**, but this strict transport is **unavailable on iOS 12** because the required
report/trust path needs iOS 13 APIs. It holds data without starting a connection. Never omit the check or claim a
floor increase. The corresponding macOS test path requires macOS 10.15+.
[Establishment report availability](https://developer.apple.com/documentation/network/nw_connection_access_establishment_report(_:_:_:))

## How do pin rotation and authority holds work?

New records use authority version 2 and closed transport policy
`https-cycle-v2-profiled-trust-noauth-no-redirect-v2`. The original six HTTPS fields remain, with a `security` object
containing the complete canonical profile and closed trust-store, proxy and TLS descriptors. A profile name or
unchecked digest alone never establishes equivalence. The record/header/authority hashes, exact-token retry log,
canonical producer content and hashed acknowledgement format are unchanged.

| Original vs current authority | Outcome |
|---|---|
| Different build, identical complete v2 authority | Replay original build/install/batch/body after recovered backoff |
| Host case/default 443 only | Existing normalized origin equivalence; path/query remain exact |
| Legacy v1 authority -> any profiled v2 configuration | Hold old record; no reinterpretation, migration, rehash or new UUID |
| Pin replacement/addition/removal, role swap, algorithm, validity, trust/auth/redirect/proxy policy change | Hold old record, even at the same collector URL |
| Return to exact original v2 authority and active profile | Resume original bytes after full recovered wait; no stage reset |
| Changed/new DNS zone or originally absent fallback | Existing independent DNS hold rules; never reroute old evidence |
| Unsupported/expired/unavailable profile | Hold before reservation/network; validated ack cleanup can still finish |

Rotation is release driven: provision A+B, validate B before needing it, ship A+B, then rotate the served leaf to
a certificate whose SPKI matches backup pin B, without changing that profile. Those records can drain. A later B+C
app profile changes authority and holds A+B records. Drain under A+B first or obtain a separately reviewed migration.
Certificate renewal with the same canonical SPKI preserves the pin while CA/hostname/validity still apply. No
automatic expiry-based downgrade or destructive queue reset exists. Held old records consume the existing count/byte
quota and can cause newest-admission loss. Changing configuration does not revoke already-started old-process I/O.

## Which outcomes acknowledge a record and permit DNS fallback?

Only `TransportResult::kPublicationAcknowledged` authorizes the unchanged exact-token outbox acknowledgement:
complete bounded 2xx excluding 204/205, strict JSON, exact boolean `data.submitObservations=true`, no errors member.
TLS success alone, a redirect body, DNS completion or an ambiguous cancelled response never acknowledges data.
Lost acknowledgements retry the same batch/content and rely on the frozen reporting-backend (BE10) deduplication.

Trust, pin, proxy, profile, protocol, busy and cancellation outcomes suppress plaintext DNS fallback. Resolution,
connection, timeout and I/O availability failures may use the separately opted-in, original matching DNS authority.
A selected security refusal remains terminal through transport cleanup and takes precedence over an overlapping
elapsed deadline. A pure network failure with a still-active authorized profile remains eligible for fallback.
DNS remains plain telemetry and never acknowledges the HTTPS record.

Legacy direct dispatch remains **one-shot best effort**. In particular, an ambiguous complete 2xx (including
`submitObservations:false`), a 5xx, a redirect, malformed response or security/cancellation refusal has no HTTPS retry
and cannot select DNS. A bounded original run remains under `kSecuritySuppressedRun` for diagnostics; no component
consumes that key. Replacement, Context teardown or process exit loses that evidence permanently. Legacy callers
must not expect eventual delivery. Complete-cycle delivery uses the separate durable outbox and retry contract.

`kLegacyDeliveryDiagnostic` reports the precise optional HTTPS `TransportResult`, optional fallback refusal and
retention (`Acknowledged`, `AuthorizedDns`, `Suppressed`, `TooLarge`). An absent HTTPS result means no transport ran.
Development-only logging emits numeric typed codes, for example
`reporting: legacy transport=17 fallback_refusal=17 retention=2` for an unconfirmed publication suppressed from DNS.
It includes no endpoint, profile, pins, request or peer text.

Availability failure alone does not authorize a later DNS query. Both senders revalidate the current profile,
platform policy and cancellation at fallback handoff.

Queued work owns a copied configuration, its original complete
authority and a shared cancellation flag; it retains no parent actor, borrowed cancellation pointer or callback.
Stopping or destroying the owner signals that flag.

The DNS consumer checks the original selected DNS authority,
and each worker rechecks authorization after dequeue and immediately before every resolver call. Expired, unavailable
or cancelled authorization stops the remaining queries. An OS resolver already entered may finish; no later query
starts after the worker observes refusal.

The existing 30-second batch and 2-second query budgets remain.

Legacy queued work owns a `LegacyDnsAttempt`: the entire original observation vector, original authorization and
original HTTPS result, anchored in `kLegacyDnsAttempt` before enqueue. A dequeue/per-query refusal or resolver
failure retains the **whole** original, including after partial DNS sends. Context destruction can drop its
reference safely while active work still owns the attempt.

The worker updates synchronized typed state/reason and started/completed-query counts on this owned object; it
never writes through a borrowed Context or restoration callback. Successful DNS calls yield
`QueriesFinished`/`PublicationUnconfirmed`, never an HTTPS acknowledgement or retry.

This is bounded volatile retention: each admitted original is limited to **1,044,480 logical bytes** (the existing
1 MiB legacy request budget minus 4,096 bytes), counting observation slots, all statuses, string lengths and nested
string-vector slots. Fresh copies discard caller spare capacity; allocator overhead, transient caller buffers,
authorization snapshots and encoded names are additional. Oversized newest input is dropped with `TooLarge`,
preserving previously admitted evidence. `kLegacyDnsAdmission` records that handoff admission separately.

There is one latest authorized run, one latest suppressed run and one latest DNS-attempt anchor; the existing worker
has one active and one queued work item. Shared anchors refer to the same attempt. There is no linked history or
durable retry queue.

Newest-only mailbox replacement marks the displaced queued attempt `Replaced` and releases it; new Context anchors
replace older ones. An older active completion updates only its own attempt and cannot overwrite newer evidence.
A caller holding extra shared references owns their additional lifetime/memory.

Reporting-enabled legacy consumption requires one type-checked envelope containing observations and authorization.
Missing authorization, a mismatched context type, the old raw-vector context key and raw mailbox names cannot select
an unprofiled resolver. The separately compiled standalone DNS-only channel retains its existing raw delivery.
Neither queue acceptance nor a completed DNS query acknowledges or removes the original HTTPS outbox record.

Cancellation is terminal when observed before acknowledgement. The post retains its callback data through cleanup;
late callbacks cannot promote failure to success. In-flight publication may have happened before cancellation;
uncertainty preserves the original record for deduplication.

Android checks again in [curl's pre-request callback](https://curl.se/libcurl/c/CURLOPT_PREREQFUNCTION.html);
Apple serializes its final check with connection-path callbacks. Both recheck current profile validity, cancellation
and total/response deadlines immediately before releasing a POST.

Connect/response/total settings remain 10/10/20 seconds, with monotonic scheduling and bounded polling.
`DeliveryHealth.last_transport_result` provides bounded typed reasons without certificates, endpoints/queries, pin
values, payloads, headers or secrets. It does not invent a CA-versus-hostname distinction when the backend reports
one verification failure.

`DeliveryFailure::kNetwork` classifies returned resolution, connection, timeout and I/O availability failures.
Other unacknowledged transport attempts use `kTransportRefused`, with the precise reason in `last_transport_result`.
Existing authority-hold diagnostics keep their meaning; this classification does not acknowledge or rebind a record.
At DNS handoff, a fresh profile/platform/cancellation refusal with the same authority also uses `kTransportRefused`
and its exact typed result. A changed DNS authority retains `kFallbackAuthorityMismatch`; an authorized pure network
failure retains `kNetwork`. None of these diagnostic updates changes retry scheduling or acknowledges the record.

## How is the security profile verified at release gates?

**`RSPTLS1`** is the bounded native marker containing canonical profile/security descriptors and SHA256.
The validated profile generates this marker and private C++ literals. It survives stripping without new exported symbols or runtime capability
schema/catalogue changes. Publisher native staging, downloaded resources, fresh installed wheels and actual injected
AAB/configured framework bytes compare the marker with intended settings after existing exact native digest checks.
Missing, duplicate, malformed, stale or mismatched markers fail publication. Test-only HTTP/root/routing adapters
are separately linked executables and are never selected by Debug or `RASP_BUILD_TESTS` in a shipped runtime.

The Apple runtime CI job validates the source-built Release and Debug arm64 frameworks against their native
capability sidecars and intended endpoint/profile. It then checks unexpected intent, a different valid profile,
duplicate/missing markers and body/digest corruption using only in-memory copies of those actual binaries. Original
frameworks/sidecars stay byte-exact; the job retains their SHA256 provenance evidence. This is an artifact gate,
not iOS device execution. The Scripts job's checked-in markerless Mach-O remains a separate packaging fixture
with no reporting intent; adding invented reporting provenance to that fixture would not prove an Apple source build.

`ReportingTls.actualSenderOutbox` compiles the actual platform sender and drives provider-backed outbox files
against disposable local TLS servers. It exercises:

- CA, SAN, pins, algorithms, backup keys, expiry and exact request-target matching.
- Redirect, status and acknowledgement failures, with destination counters.
- Cancellation, late responses and finite timeouts, including delayed pre-send expiry/cancel/deadline rejection.
- v1/v2 authority and pin-rotation holds.

Linux additionally stalls real curl resolver scheduling through an external `getaddrinfo` fixture and measures cancellation/concurrency;
Android-source tests check hostile proxy environments. Apple target fixtures exercise actual delayed trust
completion and explicit CONNECT proxy rejection, with a valid independent proxy TLS control.

These fixture checks do not establish Android production-store/device behavior, real iOS execution, system PAC,
path-change timing, or inherited storage protection. Those need actual minimum/current target OS/device tests.
At the final source head, the release acceptance gates are:

- Host, ASan and TSan suites.
- Frozen native-to-real reporting-backend (BE10) integration cases.
- Five Android targets and artifact checks.
- Fresh wheel and installed-consumer checks.
- Public APK, AAB and IPA consumer checks.
- Strict format and tidy checks.
- Actual Apple build, test and availability evidence.

Host HTTP tests or metadata-only policy assertions cannot substitute for actual transport outcomes. Linux IPA
packaging and macOS host success do not establish iOS device execution.
