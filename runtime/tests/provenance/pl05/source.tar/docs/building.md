# Building

The plugins are not built on their own for a device. They are compiled into the runtime of
[Ostorlab/rasp](https://github.com/Ostorlab/rasp): `librasp.so` on Android, `RaspRuntime.framework` on iOS. The rasp
packer then adds that runtime to an app. So every build has the same three steps:

1. Build the runtime, with the plugins in it.
2. Put the runtime into the packer.
3. Run the packer, or package it.

There are two kinds of builds:

- A **development build** writes logs, and is built for the one device you test on.
- A **production build** writes no logs, and is built for every Android ABI and for iOS. It is the one that ships.

## What you need

- Both repositories, cloned side by side: `rasp/` and `rasp-plugins/`. The commands below run from `rasp/runtime`,
  unless they say otherwise.
- CMake 4.4.
- Python 3.10+, for strict reporting profile validation.
- For Android:
  - the Android NDK, with `ANDROID_NDK_HOME` set to its folder;
  - the Android SDK, with `ANDROID_HOME` set to its folder. It needs the build-tools (for `d8`, `zipalign` and
    `apksigner`) and a platform at API 31 or newer (for `android.jar`);
  - a JDK 17 or newer, for `javac`.
- For iOS: a Mac with Xcode 27.
- For the packer: Python 3.14 and [uv](https://docs.astral.sh/uv/).
- For the plugins' tests: Clang from LLVM 23, first in `PATH`.

## The plugins and their settings

`RASP_PLUGINS` is the list of plugin folders to compile into the runtime, separated by `;`. Each plugin takes its own
settings when the runtime is built:

| Plugin | Platforms | Setting |
|---|---|---|
| `reporting` | Android and iOS | `-DRASP_REPORTING_ENDPOINT=<https-url>`: the HTTPS URL it posts observations to; `-DRASP_REPORTING_SECURITY_PROFILE=<JSON>`: an explicit origin-bound system or two-pin TLS profile (both required; no implicit system-only fallback) |
| `dns_reporting` | Android and iOS | `-DRASP_DNS_REPORTING_ZONE=<zone>`: required collector DNS suffix, with 1..63 ASCII alphanumeric/hyphen bytes per label (alphanumeric ends) and at most 48 wire-format bytes including each label-length byte |
| `dns_reporting` | Android and iOS | `-DRASP_DNS_REPORTING_COLLECTION_POLICY=<token>`: 1..64-byte `[A-Za-z0-9._-]+` collection-policy token, default `default`; preserve for unchanged policy and rotate when collector purpose/account/policy changes without changing its zone (see [collection authority](durable-delivery.md#how-does-collection-authority-binding-behave-across-upgrades)) |
| `adr_pin` | builds everywhere, probes only on iOS | `-DRASP_ADR_PIN_HOST=<host>`: the host whose keys it reports |

A plugin that doesn't support a platform stops the build when it is configured. So pick the list for each platform.

## Test the plugins

From `rasp-plugins/`. These builds use the copy of the plugin API in `third_party/rasp`, not a rasp checkout:

```
endpoint=https://reports.example.com/rasp
# Keep the profile host/port in sync with $endpoint's normalized origin (HTTPS default port 443).
security_profile='{"host":"reports.example.com","mode":"system","pins":null,"port":443,"validity":null,"version":1}'
cmake --preset host -DRASP_REPORTING_ENDPOINT="$endpoint" \
  -DRASP_REPORTING_SECURITY_PROFILE="$security_profile" -DRASP_DNS_REPORTING_ZONE=r.example
cmake --build --preset host
ctest --preset host
```

The `host-asan` and `host-tsan` presets run the same tests with sanitizers.

## Development build

### Android

1. Build the runtime for the ABI of the device you test on, with logs. For the Android emulator, which is `x86_64`:

   ```
   # Keep the profile host/port in sync with the endpoint's normalized origin (HTTPS default port 443).
   cmake --preset android-dev -B build/android-dev-x86_64 -DANDROID_ABI=x86_64 \
     -DRASP_PLUGINS="$PWD/../../rasp-plugins/plugins/reporting" \
     -DRASP_REPORTING_ENDPOINT=https://reports.example.com/rasp \
     '-DRASP_REPORTING_SECURITY_PROFILE={"host":"reports.example.com","mode":"system","pins":null,"port":443,"validity":null,"version":1}'
   cmake --build build/android-dev-x86_64
   ```

   Use a collector with a valid CA chain and hostname, and an explicit matching profile. Debug does not enable HTTP or custom roots. Disposable loopback TLS roots/routing are restricted to the separate host test harness. For a phone, use its ABI, usually `arm64-v8a`. See [the transport contract](transport-security.md), including iOS 12 unavailability and queued-profile hold behavior.

2. Build the stub. It writes `android/stub/stub.dex`:

   ```
   ANDROID_JAR=$ANDROID_HOME/platforms/android-<api>/android.jar \
     D8=$ANDROID_HOME/build-tools/<version>/d8 ./android/stub/build.sh
   ```

3. Put the stub and the runtime into the packer:

   ```
   resources=../packer/src/rasp_packer/android/resources
   rm -rf $resources/lib
   mkdir -p $resources/lib/x86_64
   cp android/stub/stub.dex $resources/stub.dex
   cp build/android-dev-x86_64/android/librasp.so $resources/lib/x86_64/librasp.so
   # For a capability-aware runtime, keep the exact native-build sidecar too:
   cp build/android-dev-x86_64/android/librasp.so.capabilities.json $resources/lib/x86_64/
   ```

   The packer adds the runtime for every ABI it finds under `lib/`. It refuses an app that has native code for an ABI
   it doesn't have: build that ABI too, then.
   Older runtime builds without a sidecar can still be packed locally, with explicitly unknown capabilities.

4. From `rasp/packer`, pack the app, sign it and install it:

   ```
   uv run rasp pack app.apk --platform android --build-id dev --output app-protected.apk
   zipalign -f -p 4 app-protected.apk app-aligned.apk
   apksigner sign --ks debug.keystore --ks-pass pass:android --out app-signed.apk app-aligned.apk
   adb install -r app-signed.apk
   ```

   `zipalign` and `apksigner` are in the SDK's build-tools. Make the keystore once:

   ```
   keytool -genkeypair -keystore debug.keystore -storepass android -alias debug -keyalg RSA -keysize 2048 \
     -validity 10000 -dname CN=debug
   ```

   If the device already has the app signed with another key, uninstall it first: `adb uninstall <package>`.

5. Read the logs:

   ```
   adb logcat -s RaspRuntime
   ```

   The runtime logs observations. The legacy reporting sender's success message is
   `reporting: publication acknowledged`; it does not log the collector URL. Durable cycle delivery exposes its
   pending/acknowledgement state through `reporting::delivery_health()`, as described in
   [the delivery contract](durable-delivery.md).

### iOS

On a Mac:

```
cmake --preset ios-dev -DRASP_PLUGINS="$PWD/../../rasp-plugins/plugins/adr_pin" -DRASP_ADR_PIN_HOST=<host>
cmake --build --preset ios-dev
rm -rf ../packer/src/rasp_packer/ios/resources/RaspRuntime.framework
cp -R build/ios-dev/ios/RaspRuntime.framework ../packer/src/rasp_packer/ios/resources/
```

Then, from `rasp/packer`:

```
uv run rasp pack app.ipa --platform ios --build-id dev --output app-protected.ipa
```

The protected IPA is not signed. Sign it with your development identity and provisioning profile to install it on a
device. The logs go to the system log, and each line starts with `RaspRuntime`: read them in Console.app, with the
device selected.

## Production build

The Publish packer workflow builds and publishes production packers: see the README's
[Publish the packer](../README.md#publish-the-packer) section. A production packer holds the release runtime for the
four Android ABIs and for iOS, and release builds write no logs. Release publication requires a released Ostorlab/rasp
that ships the RT05 schema-1 capability producer/consumer tooling, including `runtime/tools/capabilities.py`. Older
selected releases fail with an instruction to release a newer Ostorlab/rasp first; the workflow still selects Latest,
never an unmerged development branch. To build one by hand:

1. Build the Android runtime for every ABI. Each ABI needs its own build folder:

   ```
   endpoint=https://collector.example/ingest
   # When changing $endpoint, update the profile host/port to the same normalized origin.
   security_profile='{"host":"collector.example","mode":"system","pins":null,"port":443,"validity":null,"version":1}'
   for abi in arm64-v8a armeabi-v7a x86_64 x86; do
     cmake --preset android -B build/android-$abi -DANDROID_ABI=$abi \
       -DRASP_PLUGINS="$PWD/../../rasp-plugins/plugins/reporting" \
       -DRASP_REPORTING_ENDPOINT="$endpoint" -DRASP_REPORTING_SECURITY_PROFILE="$security_profile"
     cmake --build build/android-$abi
   done
   ```

2. Check each library, as CI checks release builds: it exports nothing but `JNI_OnLoad`, it writes no log, and the
   endpoint is in it:

   ```
   nm=$(echo $ANDROID_NDK_HOME/toolchains/llvm/prebuilt/*/bin/llvm-nm)
   for abi in arm64-v8a armeabi-v7a x86_64 x86; do
     lib=build/android-$abi/android/librasp.so
     test "$($nm -D --defined-only $lib | awk '{print $3}')" = JNI_OnLoad
     test -z "$($nm -D -u $lib | grep __android_log)"
     strings -a $lib | grep -qxF "$endpoint"
   done
   ```

3. Build the iOS framework, on a Mac, and check that it exports nothing and writes no log:

   ```
   cmake --preset ios -DRASP_PLUGINS="$PWD/../../rasp-plugins/plugins/adr_pin" -DRASP_ADR_PIN_HOST=<production host>
   cmake --build --preset ios
   test -z "$(nm -gU build/ios/ios/RaspRuntime.framework/RaspRuntime)"
   test -z "$(nm -u build/ios/ios/RaspRuntime.framework/RaspRuntime | grep _os_log)"
   ```

4. Build the stub, as in development.

5. Put everything into the packer. Start from empty folders, so no development build is left in them:

   ```
   resources=../packer/src/rasp_packer
   rm -rf $resources/android/resources/lib $resources/ios/resources/RaspRuntime.framework
   cp android/stub/stub.dex $resources/android/resources/stub.dex
   for abi in arm64-v8a armeabi-v7a x86_64 x86; do
     python3 ../../rasp-plugins/scripts/publish_packer/artifacts.py stage-android \
       .. build/android-$abi/android/librasp.so $abi $resources/android/resources
   done
   cp -R <the framework built on the Mac> $resources/ios/resources/RaspRuntime.framework
   python3 ../../rasp-plugins/scripts/publish_packer/artifacts.py verify-resources .. $resources
   ```

   Staging copies **both** the pristine library and its adjacent `.capabilities.json`, after verification by the
   selected runtime's standard-library validator. The iOS framework must retain `RaspRuntime.capabilities.json` inside
   it. Validation checks deterministic encoding, catalogue identity, native SHA-256, platform, ABI and the existing
   Android API31 / iOS12.0 floors. Missing, foreign, changed or corrupt metadata fails the release; never emit or rewrite
   sidecars to make an unrelated binary fit. Hashes identify pristine release bytes before packer config insertion.

6. From `rasp/packer`, build the packer's wheel, with the runtime in it:

   ```
   uv build --wheel
   unzip -l dist/rasp_packer-*.whl | grep -E 'librasp.so|stub.dex|RaspRuntime.framework/RaspRuntime|capabilities.json'
   ```

   The second command lists what the wheel holds: the four libraries, the stub, the framework and each runtime's
   `.capabilities.json` sidecar. The wheel's version is the one in `packer/pyproject.toml`. Keep the runtime's version,
   in `runtime/CMakeLists.txt`, the same.

7. Install the wheel, and use it:

   ```
   pip install dist/rasp_packer-<version>-py3-none-any.whl
   rasp pack app.apk --platform android --build-id <build id> --output app-protected.apk
   ```

   The app's developer signs the protected app with their own key.

The release workflow also runs `scripts/publish_packer/installed.py` with the installed wheel's interpreter, using
`python -I` from outside the source tree. Given the verified package source tree, release version, test AAB and output
path, it checks version/package discovery, exact catalogue/resource/sidecar bytes, all four bindings, the iOS config
consumer, and public Android `PackResult` bindings plus every config-mutated injected byte. The subsequent CLI smoke
and existing native artifact gates remain in place. The wheel cannot publish if metadata disappears during packaging.
See the README for local installed-wheel regression commands.

This metadata is release provenance, not a signature, cryptographic attestation or proof a check ran. Plugins' outputs
and delivery changes are unmodelled. Foreign runtime/packer catalogue revisions require explicit coordinated support,
not a fallback to current expectations. Legacy local artifacts remain unknown. Real iOS build and artifact checks
require macOS/Xcode CI; fixture-based config round-trips on Linux cannot establish Apple native/device behavior.

## Reporting delivery acknowledgement

Android (libcurl) and iOS (Network.framework) acknowledge a run only after a completed 2xx response contains valid
UTF-8 JSON with the exact boolean `data.submitObservations: true`. A response containing an `errors` member is rejected,
including `errors: null` or `errors: []`. Missing, null, false or non-boolean results, duplicate keys in the root or
`data` object (including escaped equivalent keys), trailing data and malformed JSON all fail delivery. Raw server
responses are never logged. TLS trust and hostname verification remain enabled, redirects are not followed, and the
existing connection/response/whole-post deadlines remain bounded.

The body limit is 64 KiB. JSON uses the runtime's pinned yyjson reader with strict syntax/UTF-8 checks, a fixed pool
sized for the bounded input, and an additional limit of 32 levels and 4096 values. Standalone builds use the same
pinned archive and reader settings in `third_party/yyjson`; runtime builds reuse `rasp_yyjson`.

The iOS HTTP decoder accepts HTTP/1.0 and HTTP/1.1 final 2xx responses framed by Content-Length, chunked transfer
coding (including extensions and trailers), or an orderly connection EOF. Split reads are supported. A timeout or
network error is not EOF. Headers are limited to 16 KiB and the whole wire response to 96 KiB, including chunk framing. Each chunk-size or trailer line is also limited to 16 KiB.
Conflicting or repeated lengths, Content-Length combined with Transfer-Encoding, repeated Transfer-Encoding,
unsupported transfer/content codings, informational responses (all 1xx, including 100 Continue and 103 Early Hints),
malformed framing, truncation and extra bytes in a
framed response are rejected. Only identity content encoding and a single chunked transfer coding are supported;
servers should return uncompressed JSON. Android delegates HTTP framing to the pinned libcurl build and bounds the
body callback before accumulation.

Actual measurement cycles use the [bounded private outbox](durable-delivery.md). The runtime callback retains the
owning immutable snapshot; workers acquire protected storage, persist the original provider identity/content and retry
without reassigning batch IDs. DNS-v2 fallback never acknowledges or removes a pending HTTPS item. Only explicit
legacy direct `run_plugins` calls retain the old newest-run mailbox/shared-context handoff under
`reporting::kUndeliveredRun`; that legacy path remains volatile. A true acknowledgement means queued publication;
it does not prove durable database storage, attestation, processing completion or exactly-once delivery. Lost responses
can cause identical retries, resolved by the backend client-batch receipts.

The host suite includes `Transport.*` tests that compile the actual Android transport with pinned curl/Mbed TLS on
Linux, and the actual iOS Network.framework transport on macOS. A loopback server drives true/false/error responses,
malformed and oversized JSON, chunked and close framing, truncation and real response timeout through `deliver` and
checks the shared-context fallback. Shared JSON/HTTP tests cover individual framing splits and hostile envelopes.
The ordinary development transport still sends nothing and returns false. Host tests do not replace NDK and iOS SDK
builds or real-device TLS/network tests. Reporting PRs run the runtime workflow's Android and iOS release/development
builds; its private runtime checkout requires `RASP_READ_TOKEN`.

HTTP framing follows [RFC 9112](https://www.rfc-editor.org/rfc/rfc9112.html#section-6.3); callback overflow follows
[libcurl's write callback contract](https://curl.se/libcurl/c/CURLOPT_WRITEFUNCTION.html). Parser options follow the
[yyjson API](https://ibireme.github.io/yyjson/doc/doxygen/html/api.html).
