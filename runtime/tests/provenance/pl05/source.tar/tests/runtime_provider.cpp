#include <expected>
/// Standalone tests have no platform Application; integration builds link the real Android/iOS provider instead.
#include "rasp/private_storage.h"
namespace rasp {
std::expected<PrivateStorage, StorageError> acquire_private_storage() {
  return std::unexpected(StorageError::kUnavailable);
}
}  // namespace rasp
