"""The production publisher must call the tested strict release gates."""

import pathlib
import tomllib

ROOT = pathlib.Path(__file__).resolve().parents[3]


def testPublisher_whenBuildingRelease_preservesAndVerifiesCapabilities() -> None:
    workflow = (ROOT / ".github/workflows/publish-packer.yml").read_text(encoding="utf-8")
    assert 'artifacts.py" check-runtime rasp' in workflow
    assert 'artifacts.py" stage-android' in workflow
    assert 'artifacts.py" verify-native' in workflow
    assert 'artifacts.py" verify-resources' in workflow
    assert 'installed.py"' in workflow
    assert workflow.index('artifacts.py" verify-resources') < workflow.index("name: Build the wheel")
    assert workflow.index('installed.py"') < workflow.index("name: rasp-packer-wheel")
    assert "ref: refs/tags/${{ steps.releases.outputs.rasp_tag }}" in workflow
    assert workflow.count("ref: ${{ needs.version.outputs.rasp_sha }}") == 3
    assert "pattern: android-runtime-*" in workflow
    assert "merge-multiple: true" in workflow
    assert 'tar -C build/ios/ios -czf "$RUNNER_TEMP/RaspRuntime.framework.tar.gz" RaspRuntime.framework' in workflow
    assert 'cp -r "$RUNNER_TEMP/android-runtime/lib/." "$ANDROID_DIR/lib/"' in workflow
    for gate in (
        "JNI_OnLoad",
        "JNI_GetCreatedJavaVMs",
        "INIT_ARRAY",
        "minos 12",
        "Check the library writes no log",
        "Check the framework calls no forbidden function",
    ):
        assert gate in workflow


def testScripts_whenRunningCapabilityTests_usesVersionedRuntimeReference() -> None:
    workflow = (ROOT / ".github/workflows/scripts.yml").read_text(encoding="utf-8")
    assert "90efbcb285fc682e38aa9894e926e1196ace54e3" in workflow
    for plugin in ("adr_pin", "reporting", "dns_reporting"):
        assert f"$GITHUB_WORKSPACE/plugins/{plugin}" in workflow
    assert "RASP_CAPABILITY_SOURCE" in workflow
    settings = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    assert ".reference-runtime" in settings["tool"]["ruff"]["extend-exclude"]


def testScripts_whenPullRequest_runsRealInstalledWheelRegressions() -> None:
    workflow = (ROOT / ".github/workflows/scripts.yml").read_text(encoding="utf-8")
    assert "needs: android-fixtures" in workflow
    assert "max-parallel: 2" in workflow
    assert "abi: [arm64-v8a, armeabi-v7a, x86_64, x86]" in workflow
    assert workflow.count("ref: ${{ env.RASP_TEST_REF }}") == 2
    assert 'artifacts.py" stage-android' in workflow
    assert "pattern: reference-android-runtime-*" in workflow
    assert "merge-multiple: true" in workflow
    assert "uv build --wheel" in workflow
    assert "uv pip install --python" in workflow
    for variable in ("RASP_RELEASE_VENV", "RASP_RELEASE_SOURCE", "RASP_RELEASE_APP"):
        assert f"{variable}:" in workflow
    assert workflow.index("name: Install the reference wheel") < workflow.index("name: Test")
    assert "publish-packer.yml" not in workflow
