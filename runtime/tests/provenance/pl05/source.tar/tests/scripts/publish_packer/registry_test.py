"""Unittests for publish_packer.registry."""

import hashlib
import pathlib

import pytest

from publish_packer import registry


def _index(*links: str) -> str:
    return "<html><body>" + "".join(f'<a href="{link}">x</a>' for link in links) + "</body></html>"


def _sha256(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def testPublishAction_whenTheIndexListsOtherWheels_shouldPublish(wheel: pathlib.Path) -> None:
    index = _index("https://r/rasp_packer-0.3.0-py3-none-any.whl#sha256=aa")

    action = registry.publish_action(index, wheel)

    assert action == registry.PublishAction.PUBLISH


def testPublishAction_whenTheRepositoryHasNoIndexYet_shouldPublish(wheel: pathlib.Path) -> None:
    action = registry.publish_action("404 Not Found", wheel)

    assert action == registry.PublishAction.PUBLISH


def testPublishAction_whenTheIndexListsTheSameWheel_shouldSayItIsPublished(wheel: pathlib.Path) -> None:
    index = _index(f"https://r/{wheel.name}#sha256={_sha256(wheel)}")

    action = registry.publish_action(index, wheel)

    assert action == registry.PublishAction.PUBLISHED


def testPublishAction_whenTheLinkIsEscaped_shouldStillFindTheWheel(wheel: pathlib.Path) -> None:
    escaped = wheel.name.replace("-", "%2D")
    index = _index(f"../../files/{escaped}?a=1&amp;b=2#sha256={_sha256(wheel)}")

    action = registry.publish_action(index, wheel)

    assert action == registry.PublishAction.PUBLISHED


def testPublishAction_whenTheIndexListsTheWheelWithAnotherHash_shouldRaiseConflictError(wheel: pathlib.Path) -> None:
    index = _index(f"https://r/{wheel.name}#sha256=bb")

    with pytest.raises(registry.ConflictError, match="already in the repository with other content"):
        registry.publish_action(index, wheel)


@pytest.mark.parametrize("fragment", ["", "#md5=aa"])
def testPublishAction_whenTheIndexListsTheWheelWithoutASha256_shouldRaiseConflictError(
    wheel: pathlib.Path, fragment: str
) -> None:
    index = _index(f"https://r/{wheel.name}{fragment}")

    with pytest.raises(registry.ConflictError, match="without a sha256 hash to compare"):
        registry.publish_action(index, wheel)


def testMain_whenTheWheelIsNotListed_shouldPrintPublish(
    tmp_path: pathlib.Path, wheel: pathlib.Path, capsys: pytest.CaptureFixture[str]
) -> None:
    index = tmp_path / "index.html"
    index.write_text(_index(), encoding="utf-8")

    exit_code = registry.main([str(index), str(wheel)])

    assert exit_code == 0
    assert capsys.readouterr().out == "publish\n"


def testMain_whenTheWheelConflicts_shouldPrintTheReasonAndReturnOne(
    tmp_path: pathlib.Path, wheel: pathlib.Path, capsys: pytest.CaptureFixture[str]
) -> None:
    index = tmp_path / "index.html"
    index.write_text(_index(f"https://r/{wheel.name}#sha256=bb"), encoding="utf-8")

    exit_code = registry.main([str(index), str(wheel)])

    assert exit_code == 1
    assert "other content" in capsys.readouterr().err
