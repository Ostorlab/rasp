"""Unittests for publish_packer.versions."""

import pathlib

import pytest

from publish_packer import versions

RUNTIME_CMAKE = "cmake_minimum_required(VERSION 4.4)\nproject(rasp_runtime VERSION 0.3.0 LANGUAGES CXX)\n"
PACKER_PYPROJECT = '[project]\nname = "rasp-packer"\nversion = "0.3.0"\n\n[tool.other]\nversion = "9.9.9"\n'


def testSetRuntimeVersion_whenTheFileHasAProjectVersion_shouldReplaceIt(tmp_path: pathlib.Path) -> None:
    path = tmp_path / "CMakeLists.txt"
    path.write_text(RUNTIME_CMAKE, encoding="utf-8")

    versions.set_runtime_version(path, "1.2.0")

    assert path.read_text(encoding="utf-8").splitlines()[1] == "project(rasp_runtime VERSION 1.2.0 LANGUAGES CXX)"


def testSetRuntimeVersion_whenTheFileHasNoProjectVersion_shouldRaiseMissingVersionError(
    tmp_path: pathlib.Path,
) -> None:
    path = tmp_path / "CMakeLists.txt"
    path.write_text("project(other VERSION 0.3.0 LANGUAGES CXX)\n", encoding="utf-8")

    with pytest.raises(versions.MissingVersionError):
        versions.set_runtime_version(path, "1.2.0")


def testSetPackerVersion_whenTheFileHasVersionLines_shouldReplaceOnlyTheFirst(tmp_path: pathlib.Path) -> None:
    path = tmp_path / "pyproject.toml"
    path.write_text(PACKER_PYPROJECT, encoding="utf-8")

    versions.set_packer_version(path, "1.2.0")

    assert path.read_text(encoding="utf-8") == PACKER_PYPROJECT.replace('"0.3.0"', '"1.2.0"')


def testSetPackerVersion_whenTheFileHasNoVersionLine_shouldRaiseMissingVersionError(tmp_path: pathlib.Path) -> None:
    path = tmp_path / "pyproject.toml"
    path.write_text('[project]\nname = "rasp-packer"\n', encoding="utf-8")

    with pytest.raises(versions.MissingVersionError):
        versions.set_packer_version(path, "1.2.0")


def testMain_whenTheCommandIsRuntime_shouldSetTheRuntimeVersion(tmp_path: pathlib.Path) -> None:
    path = tmp_path / "CMakeLists.txt"
    path.write_text(RUNTIME_CMAKE, encoding="utf-8")

    exit_code = versions.main(["runtime", str(path), "0.1.0"])

    assert exit_code == 0
    assert "VERSION 0.1.0 LANGUAGES" in path.read_text(encoding="utf-8")


def testMain_whenTheFileHasNoVersion_shouldPrintTheReasonAndReturnOne(
    tmp_path: pathlib.Path, capsys: pytest.CaptureFixture[str]
) -> None:
    path = tmp_path / "pyproject.toml"
    path.write_text("[project]\n", encoding="utf-8")

    exit_code = versions.main(["packer", str(path), "0.1.0"])

    assert exit_code == 1
    assert "has no version line" in capsys.readouterr().out


def testMain_whenTheCommandIsUnknown_shouldReturnOne(
    tmp_path: pathlib.Path, capsys: pytest.CaptureFixture[str]
) -> None:
    exit_code = versions.main(["plugins", str(tmp_path / "x"), "0.1.0"])

    assert exit_code == 1
    assert "Unknown command 'plugins'" in capsys.readouterr().out
