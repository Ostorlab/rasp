"""Unittests for publish_packer.plugins.

The plugin configs are written as JSON, which is YAML too, and a fake `yq` on the PATH prints them as they are, so the
tests need no yq. One test reads real YAML with yq when the machine has it.
"""

import json
import pathlib
import shutil

import pytest

from publish_packer import plugins

REPORTING_CMAKE = 'set(RASP_REPORTING_ENDPOINT "" CACHE STRING\n  "The URL.")\n'
PIN_CMAKE = 'set(RASP_ADR_PIN_HOST "" CACHE STRING "The host.")\noption(RASP_ADR_PIN_STRICT "Strict." OFF)\n'


def _reporting(active: bool = True) -> dict[str, object]:
    return {
        "description": "Sends the observations.",
        "active": active,
        "platforms": ["android"],
        "settings": {
            "RASP_REPORTING_ENDPOINT": {"description": "The URL.", "value": "https://adr.ostorlab.app/apis/graphql"}
        },
    }


def _pin(active: bool = True) -> dict[str, object]:
    return {
        "description": "Reports the pins.",
        "active": active,
        "platforms": ["ios", "android"],
        "settings": {"RASP_ADR_PIN_HOST": {"description": "The host.", "value": "adr.ostorlab.app"}},
    }


def _plugin(
    folder: pathlib.Path, name: str, config: dict[str, object] | str, cmake: str | None = REPORTING_CMAKE
) -> pathlib.Path:
    plugin = folder / name
    plugin.mkdir(parents=True)
    (plugin / "plugin.yml").write_text(config if isinstance(config, str) else json.dumps(config), encoding="utf-8")
    if cmake is not None:
        (plugin / "CMakeLists.txt").write_text(cmake, encoding="utf-8")
    return plugin


@pytest.mark.usefixtures("yq")
def testReadPlugins_whenOnlyReportingIsActive_shouldBuildItForAndroidOnly(tmp_path: pathlib.Path) -> None:
    _plugin(tmp_path, "reporting", _reporting())
    _plugin(tmp_path, "adr_pin", _pin(active=False), PIN_CMAKE)

    plan = plugins.read_plugins(tmp_path)

    assert plan.plugins == {"android": ["reporting"], "ios": []}
    assert plan.settings == {
        "android": {"RASP_REPORTING_ENDPOINT": "https://adr.ostorlab.app/apis/graphql"},
        "ios": {},
    }


@pytest.mark.usefixtures("yq")
def testReadPlugins_whenBothAreActive_shouldBuildEachForItsPlatformsInFolderOrder(tmp_path: pathlib.Path) -> None:
    _plugin(tmp_path, "reporting", _reporting())
    _plugin(tmp_path, "adr_pin", _pin(), PIN_CMAKE)

    plan = plugins.read_plugins(tmp_path)

    assert plan.plugins == {"android": ["adr_pin", "reporting"], "ios": ["adr_pin"]}
    assert plan.settings["ios"] == {"RASP_ADR_PIN_HOST": "adr.ostorlab.app"}


@pytest.mark.usefixtures("yq")
def testReadPlugins_whenAFolderHasNoPluginYml_shouldIgnoreIt(tmp_path: pathlib.Path) -> None:
    _plugin(tmp_path, "reporting", _reporting())
    (tmp_path / "dns_reporting").mkdir()

    plan = plugins.read_plugins(tmp_path)

    assert plan.plugins["android"] == ["reporting"]


@pytest.mark.usefixtures("yq")
def testReadPlugins_whenASettingIsAnOption_shouldAcceptIt(tmp_path: pathlib.Path) -> None:
    config = _pin()
    config["settings"] = {"RASP_ADR_PIN_STRICT": {"description": "Strict.", "value": "ON"}}
    _plugin(tmp_path, "adr_pin", config, PIN_CMAKE)

    plan = plugins.read_plugins(tmp_path)

    assert plan.settings["ios"] == {"RASP_ADR_PIN_STRICT": "ON"}


@pytest.mark.usefixtures("yq")
@pytest.mark.parametrize(
    ("change", "message"),
    [
        ({"owner": "me"}, "has unknown fields: owner"),
        ({"description": ""}, "description must be a non-empty quoted string"),
        ({"active": "true"}, "active must be true or false"),
        ({"active": None}, "active must be true or false"),
        ({"platforms": []}, "platforms must be a list of android and ios"),
        ({"platforms": ["windows"]}, "platforms has 'windows'"),
        ({"platforms": ["android", "android"]}, "platforms has 'android'"),
        ({"settings": []}, "settings must be a mapping"),
        (
            {"settings": {"rasp_endpoint": {"description": "d", "value": "v"}}},
            "settings.rasp_endpoint: the name must be made of A-Z, 0-9 and _",
        ),
        (
            {"settings": {"RASP_REPORTING_ENDPIONT": {"description": "d", "value": "v"}}},
            "declares no cache variable or option RASP_REPORTING_ENDPIONT",
        ),
        (
            {"settings": {"RASP_REPORTING": {"description": "d", "value": "v"}}},
            "declares no cache variable or option RASP_REPORTING",
        ),
        (
            {"settings": {"RASP_REPORTING_ENDPOINT": {"value": "v"}}},
            "must have exactly a description and a value",
        ),
        (
            {"settings": {"RASP_REPORTING_ENDPOINT": {"description": "d", "value": "v", "secret": True}}},
            "must have exactly a description and a value",
        ),
        (
            {"settings": {"RASP_REPORTING_ENDPOINT": {"description": "d", "value": 3}}},
            "value must be a non-empty quoted string",
        ),
    ],
)
def testReadPlugins_whenTheConfigBreaksARule_shouldRaiseInvalidPluginError(
    tmp_path: pathlib.Path, change: dict[str, object], message: str
) -> None:
    _plugin(tmp_path, "reporting", _reporting() | change)

    with pytest.raises(plugins.InvalidPluginError, match=message):
        plugins.read_plugins(tmp_path)


@pytest.mark.usefixtures("yq")
def testReadPlugins_whenAnInactivePluginBreaksARule_shouldStillRaiseInvalidPluginError(
    tmp_path: pathlib.Path,
) -> None:
    _plugin(tmp_path, "reporting", _reporting())
    config = _pin(active=False)
    config["settings"] = {"RASP_ADR_PIN_HSOT": {"description": "d", "value": "v"}}
    _plugin(tmp_path, "adr_pin", config, PIN_CMAKE)

    with pytest.raises(plugins.InvalidPluginError, match="RASP_ADR_PIN_HSOT"):
        plugins.read_plugins(tmp_path)


@pytest.mark.usefixtures("yq")
def testReadPlugins_whenASettingIsDeclaredWithoutCache_shouldRaiseInvalidPluginError(tmp_path: pathlib.Path) -> None:
    _plugin(tmp_path, "reporting", _reporting(), 'set(RASP_REPORTING_ENDPOINT "x")\n')

    with pytest.raises(plugins.InvalidPluginError, match="declares no cache variable"):
        plugins.read_plugins(tmp_path)


@pytest.mark.usefixtures("yq")
def testReadPlugins_whenTwoActivePluginsSetTheSameSetting_shouldRaiseInvalidPluginError(
    tmp_path: pathlib.Path,
) -> None:
    _plugin(tmp_path, "reporting", _reporting())
    _plugin(tmp_path, "second", _reporting())

    with pytest.raises(plugins.InvalidPluginError, match="another active plugin built for android sets it too"):
        plugins.read_plugins(tmp_path)


@pytest.mark.usefixtures("yq")
def testReadPlugins_whenNoPluginIsActive_shouldRaiseInvalidPluginError(tmp_path: pathlib.Path) -> None:
    _plugin(tmp_path, "reporting", _reporting(active=False))

    with pytest.raises(plugins.InvalidPluginError, match="No plugin is active"):
        plugins.read_plugins(tmp_path)


@pytest.mark.usefixtures("yq")
def testReadPlugins_whenAPluginHasNoCMakeLists_shouldRaiseInvalidPluginError(tmp_path: pathlib.Path) -> None:
    _plugin(tmp_path, "reporting", _reporting(), cmake=None)

    with pytest.raises(plugins.InvalidPluginError, match=r"has a plugin\.yml but no CMakeLists\.txt"):
        plugins.read_plugins(tmp_path)


@pytest.mark.usefixtures("yq")
def testReadPlugins_whenThePluginNameStartsWithADigit_shouldRaiseInvalidPluginError(tmp_path: pathlib.Path) -> None:
    _plugin(tmp_path, "1reporting", _reporting())

    with pytest.raises(plugins.InvalidPluginError, match="does not start with a-z"):
        plugins.read_plugins(tmp_path)


@pytest.mark.usefixtures("yq")
def testReadPlugins_whenTheConfigIsNotAMapping_shouldRaiseInvalidPluginError(tmp_path: pathlib.Path) -> None:
    _plugin(tmp_path, "reporting", '["android"]')

    with pytest.raises(plugins.InvalidPluginError, match="must be a mapping"):
        plugins.read_plugins(tmp_path)


@pytest.mark.skipif(shutil.which("yq") is None, reason="needs yq, which every runner of the workflow has")
def testReadYaml_whenTheFileIsYaml_shouldGiveItsValueWithStringKeys(tmp_path: pathlib.Path) -> None:
    path = tmp_path / "plugin.yml"
    path.write_text('active: true\nplatforms: ["android"]\nsettings:\n  123: {}\n', encoding="utf-8")

    value = plugins.read_yaml(path)

    assert value == {"active": True, "platforms": ["android"], "settings": {"123": {}}}


def testWriteStepOutputs_whenGivenABuild_shouldAppendEachPlatformsPluginsAndSettings(tmp_path: pathlib.Path) -> None:
    plan = plugins.BuildPlan(
        plugins={"android": ["adr_pin", "reporting"], "ios": []},
        settings={"android": {"RASP_ADR_PIN_HOST": "adr.ostorlab.app"}, "ios": {}},
    )
    output = tmp_path / "output"
    summary = tmp_path / "summary"

    plugins.write_step_outputs(plan, output, summary)

    assert output.read_text(encoding="utf-8").splitlines() == [
        "android_plugins=adr_pin reporting",
        'android_settings=[{"name": "RASP_ADR_PIN_HOST", "value": "adr.ostorlab.app"}]',
        "ios_plugins=",
        "ios_settings=[]",
    ]
    assert "| ios | none | none |" in summary.read_text(encoding="utf-8")


@pytest.mark.usefixtures("yq")
def testMain_whenAPluginBreaksARule_shouldPrintTheReasonAndReturnOne(
    tmp_path: pathlib.Path, capsys: pytest.CaptureFixture[str]
) -> None:
    folder = tmp_path / "plugins"
    _plugin(folder, "reporting", _reporting(active=False))

    exit_code = plugins.main([str(folder), str(tmp_path / "output"), str(tmp_path / "summary")])

    assert exit_code == 1
    assert "No plugin is active" in capsys.readouterr().out
    assert (tmp_path / "output").exists() is False


@pytest.mark.usefixtures("yq")
def testMain_whenThePluginsAreValid_shouldWriteTheOutputsAndReturnZero(tmp_path: pathlib.Path) -> None:
    folder = tmp_path / "plugins"
    _plugin(folder, "reporting", _reporting())

    exit_code = plugins.main([str(folder), str(tmp_path / "output"), str(tmp_path / "summary")])

    assert exit_code == 0
    assert "android_plugins=reporting" in (tmp_path / "output").read_text(encoding="utf-8")
