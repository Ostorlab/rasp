"""Release staging against the versioned RT05 native validator, without native builds."""

import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys
import tarfile
import textwrap

import pytest

from publish_packer import artifacts

SCRIPT = pathlib.Path(__file__).resolve().parents[3] / "scripts/publish_packer/artifacts.py"


@pytest.fixture
def runtime() -> pathlib.Path:
    reference = os.environ.get("RASP_CAPABILITY_SOURCE")
    if reference is None:
        pytest.skip("Set RASP_CAPABILITY_SOURCE to the pinned runtime reference (see Scripts workflow)")
    root = pathlib.Path(reference)
    assert (root / "runtime/tools/capabilities.py").is_file()
    return root


def run(*arguments: object) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(SCRIPT), *map(str, arguments)], capture_output=True, text=True, check=False
    )


def emit(runtime: pathlib.Path, binary: pathlib.Path, platform: str, abi: str, floor: str) -> pathlib.Path:
    binary.parent.mkdir(parents=True, exist_ok=True)
    binary.write_bytes(b"pristine native fixture " + abi.encode())
    subprocess.run(
        [sys.executable, str(runtime / "runtime/tools/capabilities.py"), "emit", str(binary), platform, abi, floor],
        check=True,
    )
    return binary.with_name(binary.name + ".capabilities.json")


def testStageAndroid_whenValid_copiesExactPair(runtime: pathlib.Path, tmp_path: pathlib.Path) -> None:
    binary = tmp_path / "build/librasp.so"
    sidecar = emit(runtime, binary, "android", "arm64-v8a", "31")
    result = run("stage-android", runtime, binary, "arm64-v8a", tmp_path / "upload")
    assert result.returncode == 0, result.stderr
    staged = tmp_path / "upload/lib/arm64-v8a/librasp.so"
    assert staged.read_bytes() == binary.read_bytes()
    assert staged.with_name(sidecar.name).read_bytes() == sidecar.read_bytes()


@pytest.mark.parametrize(
    ("mutation", "message"),
    [
        ("missing", "missing capability sidecar"),
        ("corrupt", "invalid capability JSON"),
        ("digest", "digest mismatch"),
        ("abi", "platform/ABI mismatch"),
        ("platform", "platform/ABI mismatch"),
        ("floor", "OS floor mismatch"),
        ("foreign", "catalogue identity"),
        ("schema", "unsupported artifact capability version"),
        ("noncanonical", "non-deterministic"),
    ],
)
def testStageAndroid_whenMetadataInvalid_refusesBeforeCopy(
    runtime: pathlib.Path, tmp_path: pathlib.Path, mutation: str, message: str
) -> None:
    binary = tmp_path / "build/librasp.so"
    sidecar = emit(runtime, binary, "android", "arm64-v8a", "31")
    data = json.loads(sidecar.read_bytes())
    match mutation:
        case "missing":
            sidecar.unlink()
        case "corrupt":
            sidecar.write_bytes(b"{")
        case "digest":
            binary.write_bytes(binary.read_bytes() + b"changed")
        case "abi":
            data["abi"] = "x86"
        case "platform":
            data["platform"] = "ios"
        case "floor":
            data["minimum_os"] = "30"
        case "foreign":
            data["catalogue"]["revision"] += 1
            canonical = json.dumps(data["catalogue"], sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()
            data["catalogue_id"] = hashlib.sha256(canonical).hexdigest()
        case "schema":
            data["schema_version"] = 2
        case "noncanonical":
            sidecar.write_bytes(sidecar.read_bytes() + b"\n")
    if mutation in {"abi", "platform", "floor", "foreign", "schema"}:
        sidecar.write_text(json.dumps(data), encoding="utf-8")
    result = run("stage-android", runtime, binary, "arm64-v8a", tmp_path / "upload")
    assert result.returncode != 0
    assert message in result.stderr
    assert message in result.stderr.split("Capability-bound release validation failed:", 1)[1]
    assert "Traceback" not in result.stderr
    assert (tmp_path / "upload").exists() is False


def testCheckRuntime_whenOldSelectedRelease_explainsMinimumSupport(tmp_path: pathlib.Path) -> None:
    result = run("check-runtime", tmp_path)
    assert result.returncode != 0
    assert "release a newer Ostorlab/rasp" in result.stderr
    assert "capability" in result.stderr


def testVerifyNative_whenIosFrameworkValid_preservesSidecar(runtime: pathlib.Path, tmp_path: pathlib.Path) -> None:
    binary = tmp_path / "RaspRuntime.framework/RaspRuntime"
    sidecar = emit(runtime, binary, "ios", "arm64", "12.0")
    original = sidecar.read_bytes()
    result = run("verify-native", runtime, binary, "ios", "arm64")
    assert result.returncode == 0, result.stderr
    assert sidecar.read_bytes() == original


def testVerifyResources_whenDownloadedPairLost_refusesUnknown(runtime: pathlib.Path, tmp_path: pathlib.Path) -> None:
    root = tmp_path / "rasp_packer"
    for abi in ("arm64-v8a", "armeabi-v7a", "x86", "x86_64"):
        emit(runtime, root / f"android/resources/lib/{abi}/librasp.so", "android", abi, "31")
    emit(runtime, root / "ios/resources/RaspRuntime.framework/RaspRuntime", "ios", "arm64", "12.0")
    stub = root / "android/resources/stub.dex"
    stub.write_bytes(b"stub")
    valid = run("verify-resources", runtime, root)
    assert valid.returncode == 0, valid.stderr
    (root / "android/resources/lib/x86/librasp.so.capabilities.json").unlink()
    result = run("verify-resources", runtime, root)
    assert result.returncode != 0
    assert "missing capability sidecar" in result.stderr


@pytest.mark.parametrize("platform", ["android", "ios"])
def testPublisherStep_whenUploadingNativeArtifact_preservesExactPair(
    runtime: pathlib.Path, tmp_path: pathlib.Path, platform: str
) -> None:
    """Execute the actual workflow staging/archive shell, including its validator invocation."""
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    (workspace / "rasp").symlink_to(runtime, target_is_directory=True)
    repository = SCRIPT.parents[2]
    (workspace / "rasp-plugins").symlink_to(repository, target_is_directory=True)
    temporary = tmp_path / "runner"
    temporary.mkdir()
    if platform == "android":
        step = "Stage the library"
        binary = tmp_path / "build/android/android/librasp.so"
        sidecar = emit(runtime, binary, "android", "arm64-v8a", "31")
    else:
        step = "Archive the framework"
        binary = tmp_path / "build/ios/ios/RaspRuntime.framework/RaspRuntime"
        sidecar = emit(runtime, binary, "ios", "arm64", "12.0")
    workflow = (repository / ".github/workflows/publish-packer.yml").read_text(encoding="utf-8")
    body = workflow.split(f"      - name: {step}\n", 1)[1]
    script = re.search(r"        run: \|\n((?:          .*\n)+)", body)
    assert script is not None
    environment = dict(
        os.environ,
        GITHUB_WORKSPACE=str(workspace),
        RUNNER_TEMP=str(temporary),
        ABI="arm64-v8a",
        SETTINGS="[]",
        UV_PYTHON=sys.executable,
    )
    result = subprocess.run(
        ["bash", "-euo", "pipefail", "-c", textwrap.dedent(script[1])],
        cwd=tmp_path,
        env=environment,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr
    if platform == "android":
        staged = temporary / "android-runtime/lib/arm64-v8a/librasp.so"
        assert staged.read_bytes() == binary.read_bytes()
        assert staged.with_name(sidecar.name).read_bytes() == sidecar.read_bytes()
    else:
        with tarfile.open(temporary / "RaspRuntime.framework.tar.gz") as archive:
            for source in (binary, sidecar):
                stream = archive.extractfile(f"RaspRuntime.framework/{source.name}")
                assert stream is not None
                assert stream.read() == source.read_bytes()


@pytest.mark.parametrize("duplicate", [False, True])
def testVerifyNative_whenRealValidatorRejects_includesReasonInException(
    runtime: pathlib.Path, tmp_path: pathlib.Path, capfd: pytest.CaptureFixture[str], duplicate: bool
) -> None:
    binary = tmp_path / "librasp.so"
    sidecar = emit(runtime, binary, "android", "arm64-v8a", "31")
    if duplicate is True:
        key = json.dumps("private-sidecar-value\nprivate-next-line")
        sidecar.write_text(f"{{{key}: 1, {key}: 2}}", encoding="utf-8")
        reason = "duplicate manifest key"
    else:
        sidecar.write_bytes(b"{")
        reason = "invalid capability JSON"
    with pytest.raises(artifacts.Error, match=reason) as caught:
        artifacts.verify_native(runtime, binary, "android", "arm64-v8a")
    assert "private-sidecar-value" not in str(caught.value)
    assert "private-next-line" not in str(caught.value)
    assert capfd.readouterr().err == ""


@pytest.mark.parametrize("diagnostic", ["bounded", "empty", "duplicate", "short-environment-value"])
def testVerifyNative_whenChildFails_boundsAndRedactsDiagnostic(
    tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch, diagnostic: str
) -> None:
    # A real child exercises output capture; production-validator behavior is covered above.
    for relative in (
        "runtime/tools/capabilities.py",
        "runtime/cmake/capabilities.cmake",
        "packer/src/rasp_packer/capabilities.py",
        "packer/src/rasp_packer/checks_manifest.json",
    ):
        path = tmp_path / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.touch()
    secret = "test-only-sensitive-value"
    monkeypatch.setenv("RASP_TEST_TOKEN", secret)
    monkeypatch.setenv("RASP_TEST_KEY_INDEX", "1")
    reason = {
        "bounded": f"ValueError: invalid artifact {secret} " + "x" * 2000,
        "empty": "",
        "duplicate": "rasp_packer.errors.InvalidRuntimeError: duplicate manifest key: private-sidecar-value",
        "short-environment-value": "ValueError: unsupported schema version 1",
    }[diagnostic]
    (tmp_path / "runtime/tools/capabilities.py").write_text(
        f"import sys\nprint('do not expose child stdout')\nprint({reason!r}, file=sys.stderr)\nsys.exit(7)\n",
        encoding="utf-8",
    )
    binary = tmp_path / "librasp.so"
    binary.with_name(binary.name + ".capabilities.json").touch()
    with pytest.raises(artifacts.Error) as caught:
        artifacts.verify_native(tmp_path, binary, "android", "arm64-v8a")
    message = str(caught.value)
    assert "status 7" in message
    assert len(message) < 1200
    assert secret not in message
    assert "private-sidecar-value" not in message
    assert "do not expose child stdout" not in message
    if diagnostic == "bounded":
        assert "ValueError: invalid artifact" in message
        assert "[redacted]" in message
    elif diagnostic == "duplicate":
        assert "duplicate manifest key" in message
    elif diagnostic == "short-environment-value":
        assert "ValueError: unsupported schema version 1" in message
    else:
        assert "without diagnostics" in message
