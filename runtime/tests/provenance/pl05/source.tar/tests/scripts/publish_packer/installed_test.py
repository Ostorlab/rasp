"""Installed-wheel regressions. Run after the documented bounded local wheel setup."""

import collections.abc
import hashlib
import importlib.metadata
import json
import os
import pathlib
import shutil
import subprocess

import pytest

SCRIPT = pathlib.Path(__file__).resolve().parents[3] / "scripts/publish_packer/installed.py"


def snapshot(directory: pathlib.Path) -> dict[pathlib.Path, str]:
    """Hash every file, including native resources and distribution metadata."""
    return {
        path.relative_to(directory): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in directory.rglob("*")
        if path.is_file() is True
    }


@pytest.fixture(scope="module")
def release_environment(
    tmp_path_factory: pytest.TempPathFactory,
) -> collections.abc.Iterator[tuple[pathlib.Path, pathlib.Path, pathlib.Path, pathlib.Path]]:
    environment = os.environ.get("RASP_RELEASE_VENV")
    reference = os.environ.get("RASP_RELEASE_SOURCE")
    app = os.environ.get("RASP_RELEASE_APP")
    if environment is None or reference is None or app is None:
        message = "Set RASP_RELEASE_VENV, RASP_RELEASE_SOURCE and RASP_RELEASE_APP for installed-wheel regressions"
        if os.environ.get("GITHUB_ACTIONS") == "true":
            pytest.fail(message)
        pytest.skip(message)
    root = tmp_path_factory.mktemp("release-wheel")
    try:
        copied = root / "venv"
        shutil.copytree(environment, copied, symlinks=True)
        packages = list((copied / "lib").glob("python*/site-packages/rasp_packer"))
        assert len(packages) == 1
        package = packages[0]
        metadata = list(package.parent.glob("rasp_packer-*.dist-info"))
        assert len(metadata) == 1
        original = pathlib.Path(environment) / package.relative_to(copied)
        pristine = root / "pristine"
        shutil.copytree(original, pristine)
        baseline = snapshot(pristine)
        assert snapshot(original) == snapshot(package) == baseline
        metadata_baseline = snapshot(metadata[0])
        assert snapshot(pathlib.Path(environment) / metadata[0].relative_to(copied)) == metadata_baseline
        yield copied, pathlib.Path(reference), pathlib.Path(app), pristine
        assert snapshot(pristine) == baseline
        assert snapshot(metadata[0]) == metadata_baseline
    finally:
        shutil.rmtree(root)


@pytest.fixture
def wheel_environment(
    release_environment: tuple[pathlib.Path, pathlib.Path, pathlib.Path, pathlib.Path],
) -> collections.abc.Iterator[tuple[pathlib.Path, pathlib.Path, pathlib.Path]]:
    environment, reference, app, pristine = release_environment
    package = next((environment / "lib").glob("python*/site-packages/rasp_packer"))
    baseline = snapshot(pristine)

    def restore() -> None:
        shutil.rmtree(package)
        shutil.copytree(pristine, package)
        assert snapshot(package) == baseline

    # installed.py only reads dist-info; all seven negative cases mutate this package or a private reference copy.
    restore()
    try:
        yield environment, reference, app
    finally:
        restore()


def run(
    environment: pathlib.Path, reference: pathlib.Path, app: pathlib.Path, output: pathlib.Path
) -> subprocess.CompletedProcess[str]:
    metadata = next((environment / "lib").glob("python*/site-packages/rasp_packer-*.dist-info"))
    version = importlib.metadata.PathDistribution(metadata).version
    return subprocess.run(
        [
            str(environment / "bin/python"),
            "-I",
            str(SCRIPT),
            str(reference),
            version,
            str(app),
            str(output),
            "--android-settings",
            os.environ.get("RASP_RELEASE_ANDROID_SETTINGS", "[]"),
            "--ios-settings",
            os.environ.get("RASP_RELEASE_IOS_SETTINGS", "[]"),
        ],
        capture_output=True,
        text=True,
        cwd=output.parent,
        check=False,
    )


def testInstalled_whenRealWheelPacks_verifiesExactConsumerBytes(
    wheel_environment: tuple[pathlib.Path, pathlib.Path, pathlib.Path], tmp_path: pathlib.Path
) -> None:
    environment, reference, app = wheel_environment
    result = run(environment, reference, app, tmp_path / "packed.aab")
    assert result.returncode == 0, result.stderr
    assert "Verified installed rasp-packer" in result.stdout
    assert "android/arm64-v8a" in result.stdout


@pytest.mark.parametrize(
    ("mutation", "message"),
    [
        ("missing", "all four Android libraries and capability sidecars"),
        ("corrupt", "invalid capability JSON"),
        ("abi", "platform/ABI mismatch"),
        ("digest", "digest mismatch"),
        ("ios-missing", "iOS framework/sidecar differs"),
        ("reference", "differs from staged release bytes"),
        ("catalogue", "unknown capability catalogue identity"),
    ],
)
def testInstalled_whenWheelLosesBinding_refusesBeforePublicPack(
    wheel_environment: tuple[pathlib.Path, pathlib.Path, pathlib.Path],
    tmp_path: pathlib.Path,
    mutation: str,
    message: str,
) -> None:
    environment, reference, app = wheel_environment
    package = next((environment / "lib").glob("python*/site-packages/rasp_packer"))
    binary = package / "android/resources/lib/arm64-v8a/librasp.so"
    sidecar = binary.with_name(binary.name + ".capabilities.json")
    match mutation:
        case "missing":
            sidecar.unlink()
        case "corrupt":
            sidecar.write_bytes(b"{")
        case "abi":
            data = json.loads(sidecar.read_bytes())
            data["abi"] = "x86"
            sidecar.write_text(json.dumps(data), encoding="utf-8")
        case "digest":
            binary.write_bytes(binary.read_bytes() + b"changed")
        case "ios-missing":
            (package / "ios/resources/RaspRuntime.framework/RaspRuntime.capabilities.json").unlink()
        case "reference":
            reference_copy = tmp_path / "reference"
            shutil.copytree(reference, reference_copy)
            reference = reference_copy
            (reference / "android/resources/stub.dex").write_bytes(b"different-stub")
        case "catalogue":
            catalogue = package / "checks_manifest.json"
            data = json.loads(catalogue.read_bytes())
            data["revision"] += 1
            catalogue.write_text(json.dumps(data), encoding="utf-8")
    output = tmp_path / "bad.aab"
    result = run(environment, reference, app, output)
    assert result.returncode != 0
    # Catalogue equality is checked before Android loading; either boundary must reject this mismatch.
    if mutation == "catalogue":
        assert "Installed catalogue differs" in result.stderr
    else:
        assert message in result.stderr
    assert output.exists() is False
