"""Fixtures of the publish_packer tests: fake out-of-process tools on the PATH, and a wheel to publish."""

import os
import pathlib
import stat

import pytest


def _install(folder: pathlib.Path, name: str, script: str) -> None:
    tool = folder / name
    tool.write_text(f"#!/bin/sh\n{script}\n", encoding="utf-8")
    tool.chmod(tool.stat().st_mode | stat.S_IXUSR)


@pytest.fixture
def tools(tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch) -> pathlib.Path:
    """Puts an empty folder first on the PATH, for the fake tools of a test, and gives it."""
    folder = tmp_path / "bin"
    folder.mkdir()
    monkeypatch.setenv("PATH", f"{folder}{os.pathsep}{os.environ['PATH']}")
    return folder


@pytest.fixture
def yq(tools: pathlib.Path) -> None:
    """Puts a fake yq on the PATH, which prints the file it is given: the tests write their YAML as JSON."""
    _install(tools, "yq", 'cat "$3"')


@pytest.fixture
def cmake(tools: pathlib.Path, tmp_path: pathlib.Path) -> pathlib.Path:
    """Puts a fake cmake on the PATH, which writes its arguments one per line, and gives that file."""
    called = tmp_path / "arguments"
    _install(tools, "cmake", f'printf "%s\\n" "$@" > "{called}"')
    return called


@pytest.fixture
def wheel(tmp_path: pathlib.Path) -> pathlib.Path:
    """Gives a wheel file to publish."""
    path = tmp_path / "rasp_packer-0.1.0-py3-none-any.whl"
    path.write_bytes(b"wheel-bytes")
    return path
