"""Reporting profiles and exact native marker checks."""

from __future__ import annotations

import base64
import json
import pathlib

import pytest

from publish_packer import security


def profile() -> dict[str, object]:
    return {"version": 1, "mode": "system", "host": "collector.example", "port": 443, "pins": None, "validity": None}


def testProfile_whenSystemOriginMatches_acceptsCanonicalBytes() -> None:
    value = security.validate(json.dumps(profile()), "https://COLLECTOR.example:443/a/../b?", now=100)
    assert json.loads(value) == profile()


@pytest.mark.parametrize(
    "change", [{"port": True}, {"version": 1.0}, {"host": "other.example"}, {"mode": "test"}, {"pins": {}}]
)
def testProfile_whenUnsupportedOrAmbiguous_rejects(change: dict[str, object]) -> None:
    value = profile() | change
    with pytest.raises(security.InvalidProfileError):
        security.validate(json.dumps(value), "https://collector.example/", now=100)


@pytest.mark.parametrize(
    "endpoint",
    [
        "http://collector.example",
        "https://user@collector.example",
        "https://127.1/",
        "https://collector.example:0443/",
        "https://collector.example/%xx",
        "https://collector.example/#x",
    ],
)
def testProfile_whenEndpointAmbiguous_rejects(endpoint: str) -> None:
    with pytest.raises(security.InvalidProfileError):
        security.validate(json.dumps(profile()), endpoint, now=100)


def testProfile_whenPinsAndFiniteInterval_enforcesBackupEncodingAndExpiry() -> None:
    value = profile() | {"mode": "leaf-spki-sha256", "validity": {"not_before": 100, "not_after": 200}}
    pins = {
        role: {"key_algorithm": "rsa-2048", "value": "sha256//" + base64.b64encode(bytes([index]) * 32).decode()}
        for index, role in enumerate(("primary", "backup"))
    }
    value["pins"] = pins
    assert security.validate(json.dumps(value), "https://collector.example/", now=100) != ""
    for now in (99, 200, -1):
        with pytest.raises(security.InvalidProfileError):
            security.validate(json.dumps(value), "https://collector.example/", now=now)
    pins["backup"] = pins["primary"].copy()
    with pytest.raises(security.InvalidProfileError):
        security.validate(json.dumps(value), "https://collector.example/", now=100)


def testMarker_whenIntactOrTampered_requiresOneExactBoundedMarker() -> None:
    body = security.descriptor(security.validate(json.dumps(profile()), "https://collector.example/"), "android")
    marker = security.marker(body)
    assert security.read_marker(b"ELF prefix" + marker + b"suffix") == body
    for binary in (b"", marker + marker, marker[:-2], marker.replace(b"system", b"systEm", 1)):
        with pytest.raises(security.InvalidProfileError):
            security.read_marker(binary)


def testGenerate_whenProfileChanges_regeneratesHeaderFromValidatedBytes(tmp_path: pathlib.Path) -> None:
    destination = tmp_path / "security.h"
    security.generate(json.dumps(profile()), "https://collector.example/", "android", destination)
    first = destination.read_bytes()
    security.generate(json.dumps(profile()), "https://collector.example/", "ios", destination)
    assert destination.read_bytes() != first
    assert b"#pragma once" in first


def testNativeProfile_whenMarkerAbsentOrDifferent_rejectsIntendedReportingBuild() -> None:
    settings = json.dumps(
        [
            {"name": "RASP_REPORTING_ENDPOINT", "value": "https://collector.example/"},
            {"name": "RASP_REPORTING_SECURITY_PROFILE", "value": json.dumps(profile())},
        ]
    )
    with pytest.raises(security.InvalidProfileError):
        security.verify_native_profile(b"native without reporting marker", "android", settings)


def testNativeProfile_whenTestTransportLinked_rejectsEvenValidProfile() -> None:
    canonical = security.validate(json.dumps(profile()), "https://collector.example/")
    settings = json.dumps(
        [
            {"name": "RASP_REPORTING_ENDPOINT", "value": "https://collector.example/"},
            {"name": "RASP_REPORTING_SECURITY_PROFILE", "value": canonical},
        ]
    )
    native = security.marker(security.descriptor(canonical, "android")) + b"RSPTLS_TEST_ONLY_V1"
    with pytest.raises(security.InvalidProfileError):
        security.verify_native_profile(native, "android", settings)


def testNativeProfile_whenOnlyProfileSettingProvided_rejectsIncompleteIntent() -> None:
    settings = json.dumps([{"name": "RASP_REPORTING_SECURITY_PROFILE", "value": json.dumps(profile())}])
    with pytest.raises(security.InvalidProfileError):
        security.verify_native_profile(b"no reporting plugin", "android", settings)
