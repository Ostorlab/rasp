"""Reporting profiles and exact native marker checks."""

from __future__ import annotations

import base64
import json
import pathlib
import shutil
import subprocess
import sys

import pytest

from publish_packer import security


def profile() -> dict[str, object]:
    return {"version": 1, "mode": "system", "host": "collector.example", "port": 443, "pins": None, "validity": None}


def testProfile_whenSystemOriginMatches_acceptsCanonicalBytes() -> None:
    value = security.validate(json.dumps(profile()), "https://COLLECTOR.example:443/a/../b?", now=100)
    assert json.loads(value) == profile()


@pytest.mark.parametrize(
    "change", [{"port": True}, {"version": 1.0}, {"host": "other.example"}, {"mode": "test"}, {"pins": {}}]
)
def testProfile_whenUnsupportedOrAmbiguous_rejects(change: dict[str, object]) -> None:
    value = profile() | change
    with pytest.raises(security.InvalidProfileError):
        security.validate(json.dumps(value), "https://collector.example/", now=100)


@pytest.mark.parametrize(
    "endpoint",
    [
        "http://collector.example",
        "https://user@collector.example",
        "https://127.1/",
        "https://collector.example:0443/",
        "https://collector.example/%xx",
        "https://collector.example/#x",
    ],
)
def testProfile_whenEndpointAmbiguous_rejects(endpoint: str) -> None:
    with pytest.raises(security.InvalidProfileError):
        security.validate(json.dumps(profile()), endpoint, now=100)


def testProfile_whenPinsAndFiniteInterval_enforcesBackupEncodingAndExpiry() -> None:
    value = profile() | {"mode": "leaf-spki-sha256", "validity": {"not_before": 100, "not_after": 200}}
    pins = {
        role: {"key_algorithm": "rsa-2048", "value": "sha256//" + base64.b64encode(bytes([index]) * 32).decode()}
        for index, role in enumerate(("primary", "backup"))
    }
    value["pins"] = pins
    assert security.validate(json.dumps(value), "https://collector.example/", now=100) != ""
    for now in (99, 200, -1):
        with pytest.raises(security.InvalidProfileError):
            security.validate(json.dumps(value), "https://collector.example/", now=now)
    pins["backup"] = pins["primary"].copy()
    with pytest.raises(security.InvalidProfileError):
        security.validate(json.dumps(value), "https://collector.example/", now=100)


def testMarker_whenIntactOrTampered_requiresOneExactBoundedMarker() -> None:
    body = security.descriptor(security.validate(json.dumps(profile()), "https://collector.example/"), "android")
    marker = security.marker(body)
    assert security.read_marker(b"ELF prefix" + marker + b"suffix") == body
    for binary in (b"", marker + marker, marker[:-2], marker.replace(b"system", b"systEm", 1)):
        with pytest.raises(security.InvalidProfileError):
            security.read_marker(binary)


def testGenerate_whenProfileChanges_regeneratesHeaderFromValidatedBytes(tmp_path: pathlib.Path) -> None:
    destination = tmp_path / "security.h"
    security.generate(json.dumps(profile()), "https://collector.example/", "android", destination)
    first = destination.read_bytes()
    security.generate(json.dumps(profile()), "https://collector.example/", "ios", destination)
    assert destination.read_bytes() != first
    assert b"#pragma once" in first


def testNativeProfile_whenMarkerAbsentOrDifferent_rejectsIntendedReportingBuild() -> None:
    settings = json.dumps(
        [
            {"name": "RASP_REPORTING_ENDPOINT", "value": "https://collector.example/"},
            {"name": "RASP_REPORTING_SECURITY_PROFILE", "value": json.dumps(profile())},
        ]
    )
    with pytest.raises(security.InvalidProfileError):
        security.verify_native_profile(b"native without reporting marker", "android", settings)


def testNativeProfile_whenTestTransportLinked_rejectsEvenValidProfile() -> None:
    canonical = security.validate(json.dumps(profile()), "https://collector.example/")
    settings = json.dumps(
        [
            {"name": "RASP_REPORTING_ENDPOINT", "value": "https://collector.example/"},
            {"name": "RASP_REPORTING_SECURITY_PROFILE", "value": canonical},
        ]
    )
    native = security.marker(security.descriptor(canonical, "android")) + b"RSPTLS_TEST_ONLY_V1"
    with pytest.raises(security.InvalidProfileError):
        security.verify_native_profile(native, "android", settings)


def testNativeProfile_whenOnlyProfileSettingProvided_rejectsIncompleteIntent() -> None:
    settings = json.dumps([{"name": "RASP_REPORTING_SECURITY_PROFILE", "value": json.dumps(profile())}])
    with pytest.raises(security.InvalidProfileError):
        security.verify_native_profile(b"no reporting plugin", "android", settings)


def rejected_profiles() -> list[tuple[str, str]]:
    """Untrusted text must never replace a deliberate, constant rejection reason."""
    expired = profile() | {
        "mode": "leaf-spki-sha256",
        "pins": {
            role: {"key_algorithm": "rsa-2048", "value": "sha256//" + base64.b64encode(bytes([index]) * 32).decode()}
            for index, role in enumerate(("primary", "backup"))
        },
        "validity": {"not_before": 100, "not_after": 200},
    }
    return [
        ("secret-untrusted-json", "Invalid reporting TLS profile"),
        (json.dumps(profile() | {"host": "secret-untrusted-host"}), "Reporting profile origin/version mismatch"),
        (json.dumps(profile() | {"version": "secret-untrusted-version"}), "Reporting profile origin/version mismatch"),
        (json.dumps(expired), "Reporting pin profile is outside its validity interval"),
        (json.dumps(profile() | {"mode": "secret-untrusted-mode"}), "Unsupported reporting profile mode"),
    ]


@pytest.mark.parametrize(("value", "reason"), rejected_profiles())
def testCli_whenProfileRejected_explainsWithoutEchoingInput(tmp_path: pathlib.Path, value: str, reason: str) -> None:
    source = tmp_path / "secret-filename.json"
    source.write_text(value, encoding="utf-8")
    result = subprocess.run(
        [sys.executable, security.__file__, str(source), "https://collector.example/", "android", str(tmp_path / "h")],
        capture_output=True,
        text=True,
        check=False,
        timeout=10,
    )
    assert result.returncode == 1
    assert result.stdout == ""
    assert result.stderr == f"Reporting TLS profile rejected: {reason}\n"
    assert "secret" not in result.stderr
    assert (tmp_path / "h").exists() is False


@pytest.mark.parametrize("failure", ["encoding", "missing", "destination"])
def testCli_whenFileFails_redactsContentsAndFilenames(tmp_path: pathlib.Path, failure: str) -> None:
    source = tmp_path / "secret-filename.json"
    destination = tmp_path / "h"
    if failure == "encoding":
        source.write_bytes(b"secret-untrusted-encoding\xff")
    elif failure == "destination":
        source.write_text(json.dumps(profile()), encoding="utf-8")
        destination = tmp_path / "secret-missing-dir" / "h"
    result = subprocess.run(
        [sys.executable, security.__file__, str(source), "https://collector.example/", "android", str(destination)],
        capture_output=True,
        text=True,
        check=False,
        timeout=10,
    )
    reason = "Invalid reporting TLS profile" if failure == "encoding" else "Cannot read or write reporting profile"
    assert result.returncode == 1
    assert result.stdout == ""
    assert result.stderr == f"Reporting TLS profile rejected: {reason}\n"
    assert "secret" not in result.stderr
    assert destination.exists() is False


@pytest.mark.parametrize(("value", "reason"), [*rejected_profiles(), (json.dumps(profile()), "")])
def testCmake_whenValidationRuns_surfacesOnlySafeReason(tmp_path: pathlib.Path, value: str, reason: str) -> None:
    # Execute the actual configure gate verbatim, without unrelated native target/dependency setup.
    plugin = pathlib.Path(security.__file__).resolve().parents[2] / "plugins" / "reporting"
    gate = (plugin / "CMakeLists.txt").read_text(encoding="utf-8").split("set(RASP_REPORTING_COLLECTION_POLICY", 1)[0]
    script = tmp_path / "gate.cmake"
    script.write_text(
        f'set(CMAKE_CURRENT_SOURCE_DIR "{plugin.as_posix()}")\n'
        f'set(CMAKE_CURRENT_BINARY_DIR "{tmp_path.as_posix()}")\n' + gate,
        encoding="utf-8",
    )
    cmake = shutil.which("cmake")
    assert cmake is not None
    result = subprocess.run(
        [
            cmake,
            f"-DPython3_EXECUTABLE={sys.executable}",
            "-DRASP_REPORTING_ENDPOINT=https://collector.example/",
            f"-DRASP_REPORTING_SECURITY_PROFILE={value}",
            "-P",
            str(script),
        ],
        capture_output=True,
        text=True,
        check=False,
        timeout=20,
    )
    assert "secret" not in result.stdout + result.stderr
    generated = tmp_path / "generated" / "reporting_security_build.h"
    if reason != "":
        assert result.returncode != 0
        assert reason in " ".join(result.stderr.split())
        assert generated.exists() is False
    else:
        assert result.returncode == 0, result.stderr
        expected = tmp_path / "expected.h"
        security.generate(value, "https://collector.example/", "android", expected)
        assert generated.read_bytes() == expected.read_bytes()
