"""Unittests for publish_packer.configure."""

import json
import pathlib

import pytest

from publish_packer import configure

FOLDER = pathlib.Path("/work/rasp-plugins/plugins")
PROFILE = '{"host":"adr.ostorlab.app","mode":"system","pins":null,"port":443,"validity":null,"version":1}'
SETTINGS = json.dumps(
    [
        {"name": "RASP_REPORTING_ENDPOINT", "value": "https://adr.ostorlab.app/apis/graphql"},
        {"name": "RASP_REPORTING_SECURITY_PROFILE", "value": PROFILE},
    ]
)


@pytest.mark.parametrize("profile", [None, "{}", "not json", '{"version":1,"version":1}', "x" * 1537])
def testCmakeCommand_whenReportingProfileMissingOrMalformed_rejectsBeforeBuild(profile: str | None) -> None:
    settings = [item for item in json.loads(SETTINGS) if item["name"] != "RASP_REPORTING_SECURITY_PROFILE"]
    if profile is not None:
        settings.append({"name": "RASP_REPORTING_SECURITY_PROFILE", "value": profile})
    with pytest.raises(configure.InvalidSettingsError):
        configure.cmake_command("android", FOLDER, ["reporting"], json.dumps(settings), [])


def testCmakeCommand_whenReportingUsesHttp_rejectsBeforeBuild() -> None:
    with pytest.raises(configure.InvalidSettingsError):
        configure.cmake_command("android", FOLDER, ["reporting"], SETTINGS.replace("https:", "http:"), [])


def testCmakeCommand_whenGivenPluginsAndSettings_shouldPassEachAsOneArgument() -> None:
    command = configure.cmake_command("android", FOLDER, ["adr_pin", "reporting"], SETTINGS, ["-DANDROID_ABI=x86"])

    assert command == [
        "cmake",
        "--preset",
        "android",
        "-DANDROID_ABI=x86",
        "-DRASP_PLUGINS=/work/rasp-plugins/plugins/adr_pin;/work/rasp-plugins/plugins/reporting",
        "-DRASP_REPORTING_ENDPOINT=https://adr.ostorlab.app/apis/graphql",
        "-DRASP_REPORTING_SECURITY_PROFILE=" + PROFILE,
    ]


def testCmakeCommand_whenAValueHasSpaces_shouldKeepItInOneArgument() -> None:
    command = configure.cmake_command("ios", FOLDER, ["x"], '[{"name": "RASP_X", "value": "a b; c"}]', [])

    assert command[-1] == "-DRASP_X=a b; c"


def testCmakeCommand_whenThereIsNoPlugin_shouldPassOnlyThePreset() -> None:
    command = configure.cmake_command("ios", FOLDER, [], "[]", [])

    assert command == ["cmake", "--preset", "ios"]


@pytest.mark.parametrize("settings", ["", "{", '{"name": "x"}', '[{"name": "x"}]', '["x"]'])
def testCmakeCommand_whenTheSettingsAreInvalid_shouldRaiseInvalidSettingsError(settings: str) -> None:
    with pytest.raises(configure.InvalidSettingsError):
        configure.cmake_command("android", FOLDER, ["reporting"], settings, [])


def testMain_whenTheSettingsAreValid_shouldRunCmakeWithTheAbsolutePluginsFolder(
    cmake: pathlib.Path, tmp_path: pathlib.Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)

    exit_code = configure.main(["android", "plugins", "reporting", SETTINGS, "-DANDROID_ABI=x86"])

    assert exit_code == 0
    assert cmake.read_text(encoding="utf-8").splitlines() == [
        "--preset",
        "android",
        "-DANDROID_ABI=x86",
        f"-DRASP_PLUGINS={tmp_path / 'plugins' / 'reporting'}",
        "-DRASP_REPORTING_ENDPOINT=https://adr.ostorlab.app/apis/graphql",
        "-DRASP_REPORTING_SECURITY_PROFILE=" + PROFILE,
    ]


def testMain_whenTheSettingsAreEmpty_shouldPrintTheReasonAndNotRunCmake(
    cmake: pathlib.Path, capsys: pytest.CaptureFixture[str]
) -> None:
    exit_code = configure.main(["android", "plugins", "reporting", ""])

    assert exit_code == 1
    assert "The settings are not JSON" in capsys.readouterr().out
    assert cmake.exists() is False


def testMain_whenMalformedSettingsContainPrivateValue_doesNotEchoInput(
    cmake: pathlib.Path, capsys: pytest.CaptureFixture[str]
) -> None:
    exit_code = configure.main(["android", "plugins", "reporting", "[CANARY_PRIVATE_SETTING"])
    assert exit_code == 1
    assert "CANARY_PRIVATE_SETTING" not in capsys.readouterr().out
    assert cmake.exists() is False
